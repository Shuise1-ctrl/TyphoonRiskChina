from __future__ import annotations

import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import shutil
import stat
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import redirect_stdout
from typing import Any
import uuid
import zipfile

import yaml
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field


APP_ROOT = Path(__file__).resolve().parent.parent
ENGINE_ROOT = APP_ROOT / "engine"


def configured_web_root() -> Path:
    """Select the bundled web UI, with an optional compiled UI override."""
    configured = os.environ.get("TYPHOON_WEB_ROOT")
    candidate = Path(configured).resolve() if configured else APP_ROOT / "web"
    if not (candidate / "index.html").is_file():
        raise RuntimeError(f"The web entry point does not exist: {candidate / 'index.html'}")
    return candidate


WEB_ROOT = configured_web_root()
DATA_ROOT = APP_ROOT / "data"
JOBS_ROOT = DATA_ROOT / "jobs"
EXAMPLE_ROOT = APP_ROOT / "example_folder"

# Large scientific inputs live in the repository-local runtime directory by
# default. Every location can be overridden without accepting arbitrary paths
# from HTTP requests.
FULL_ALGORITHM_ROOT = Path(
    os.environ.get("TYPHOON_FULL_ALGORITHM_ROOT", str(APP_ROOT / "algorithm_full"))
).absolute()
FULL_BUNDLE_ROOT = Path(
    os.environ.get("TYPHOON_FULL_BUNDLE_ROOT", str(APP_ROOT / "runtime"))
).absolute()
FULL_CASES_ROOT = Path(
    os.environ.get("TYPHOON_FULL_CASES_ROOT", str(FULL_BUNDLE_ROOT / "cases"))
).absolute()
APPROVED_WIND_SOURCES_PATH = Path(
    os.environ.get(
        "TYPHOON_APPROVED_WIND_SOURCES",
        str(DATA_ROOT / "approved_wind_sources.json"),
    )
).absolute()
FULL_RUNTIME_ROOT = Path(
    os.environ.get(
        "TYPHOON_FULL_RUNTIME_ROOT",
        str(FULL_BUNDLE_ROOT / "downscaling"),
    )
).absolute()
FULL_EXPOSURE_ROOT = Path(
    os.environ.get(
        "TYPHOON_FULL_EXPOSURE_ROOT",
        str(FULL_BUNDLE_ROOT / "exposure"),
    )
).absolute()
FULL_PYTHON = Path(
    os.environ.get(
        "TYPHOON_FULL_PYTHON",
        str(
            APP_ROOT
            / ".venv-full"
            / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
        ),
    )
).absolute()
FULL_CLI = Path(
    os.environ.get(
        "TYPHOON_FULL_CLI",
        str(
            FULL_ALGORITHM_ROOT
            / "modules"
            / "webready"
            / "backend"
            / "end_to_end_cli.py"
        ),
    )
).absolute()
FULL_STAGE_CLI = Path(
    os.environ.get(
        "TYPHOON_FULL_STAGE_CLI",
        str(APP_ROOT / "backend" / "full_stage_cli.py"),
    )
).absolute()
FULL_TEMP_ROOT = Path(
    os.environ.get("TYPHOON_FULL_TEMP_ROOT", str(DATA_ROOT / "full-temp"))
).absolute()

sys.path.insert(0, str(ENGINE_ROOT))

from typhoonriskchina.workflow import run_from_config  # noqa: E402


MAX_FILES = 5000
MAX_UPLOAD_BYTES = 2 * 1024 * 1024 * 1024
MAX_WIND_UPLOAD_BYTES = 512 * 1024 * 1024
MAX_TRACK_UPLOAD_BYTES = 16 * 1024 * 1024
MAX_WIND_INPUT_MANIFEST_BYTES = 512 * 1024
MAX_LOSS_UPLOAD_BYTES = 256 * 1024 * 1024
MAX_LOSS_PACKAGE_BYTES = 512 * 1024 * 1024
DEFAULT_LOSS_IMPACT_THRESHOLD_MS = 17.3
BUNDLE_TOKEN_TTL_SECONDS = 30 * 60
MAX_BUNDLE_TOKENS = 256
WIND_INPUT_TOKEN_TTL_SECONDS = 30 * 60
MAX_WIND_INPUT_TOKENS = 64
EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="typhoon-risk")
FULL_EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="typhoon-full")

STAGE_TIMEOUT_SECONDS = {
    "wind-local": 60 * 60,
    "wind-inputs": 60 * 60,
    "wind-nc": 15 * 60,
    "loss": 30 * 60,
}

EXPECTED_FNL_NAMES = tuple(f"{hour:03d}.nc" for hour in range(6, 169, 6))
FULL_PROVINCES = ("fujian", "guangdong", "hainan", "jiangsu", "zhejiang")
FULL_EXPOSURE_DIR_NAME = "00000 沿海省份风险暴露"
FULL_GRID_DIR_NAME = "00000 沿海省份网格"
FULL_ARTIFACTS: dict[str, tuple[Path, str]] = {
    "wind-map": (Path("vulnerability/maximum_wind_distribution.png"), "image/png"),
    "loss-map": (Path("vulnerability/loss_distribution.png"), "image/png"),
    "report": (Path("vulnerability/typhoon_loss_assessment.pdf"), "application/pdf"),
    "grid-wind": (Path("vulnerability/grid_wind.csv"), "text/csv"),
    "grid-loss": (Path("vulnerability/grid_loss.csv"), "text/csv"),
    "vulnerability-curve": (Path("vulnerability/vulnerability_curve.csv"), "text/csv"),
    "vulnerability-curve-figure": (Path("vulnerability/vulnerability_curve.svg"), "image/svg+xml"),
    "result-manifest": (Path("vulnerability/result_manifest.json"), "application/json"),
    "pipeline-manifest": (Path("pipeline_result.json"), "application/json"),
}
WIND_ARTIFACTS: dict[str, tuple[Path, str]] = {
    "track-composite-map": (Path("wind_output/track_composite_weighted.png"), "image/png"),
    "track-composite-nc": (Path("wind_output/track_composite_weighted.nc"), "application/x-netcdf"),
    "wind-circle-gif": (Path("wind_output/wind_circle_track_growth.gif"), "image/gif"),
    "fixed-wind-nc": (Path("wind_output/fixed_grid_max_wind.nc"), "application/x-netcdf"),
    "wind-map": (Path("wind_output/fixed_grid_max_wind.png"), "image/png"),
    "diagnostics": (Path("wind_output/hourly_summary.csv"), "text/csv"),
    "wind-manifest": (Path("wind_output/wind_manifest.json"), "application/json"),
    "interactive-map": (Path("wind_output/interactive_wind_map.json"), "application/json"),
    "loss-input-package": (Path("wind_input_for_loss.zip"), "application/zip"),
}
LOSS_ARTIFACTS: dict[str, tuple[Path, str]] = {
    "wind-map": (Path("loss_output/maximum_wind_distribution.png"), "image/png"),
    "loss-map": (Path("loss_output/loss_distribution.png"), "image/png"),
    "report": (Path("loss_output/typhoon_loss_assessment.pdf"), "application/pdf"),
    "grid-wind": (Path("loss_output/grid_wind.csv"), "text/csv"),
    "grid-loss": (Path("loss_output/grid_loss.csv"), "text/csv"),
    "vulnerability-curve": (Path("loss_output/vulnerability_curve.csv"), "text/csv"),
    "vulnerability-curve-figure": (Path("loss_output/vulnerability_curve.svg"), "image/svg+xml"),
    "result-manifest": (Path("loss_output/result_manifest.json"), "application/json"),
    "interactive-map": (Path("loss_output/interactive_loss_map.json"), "application/json"),
}
_FULL_RUNTIME_CACHE: tuple[float, dict[str, Any]] | None = None
_STAGE_RUNTIME_CACHE: dict[str, tuple[float, dict[str, Any]]] = {}
_BUNDLE_TOKENS: dict[str, tuple[float, frozenset[str]]] = {}
_BUNDLE_TOKEN_LOCK = threading.Lock()
_WIND_INPUT_TOKENS: dict[str, dict[str, Any]] = {}
_WIND_INPUT_TOKEN_LOCK = threading.Lock()


class FullJobRequest(BaseModel):
    case_key: str = Field(min_length=1, max_length=120, pattern=r"^[A-Za-z0-9_-]+$")
    impact_threshold_ms: float = Field(
        default=DEFAULT_LOSS_IMPACT_THRESHOLD_MS,
        ge=0.0,
        le=100.0,
    )
    force_downscaling: bool = False


class WindLocalJobRequest(BaseModel):
    case_key: str = Field(min_length=1, max_length=120, pattern=r"^[A-Za-z0-9_-]+$")
    bundle_token: str | None = Field(default=None, min_length=20, max_length=200)


class WindInputsJobRequest(BaseModel):
    input_token: str = Field(min_length=20, max_length=200)


class LocalBundleManifestFile(BaseModel):
    path: str = Field(min_length=1, max_length=1024)
    size: int = Field(ge=0, le=9_007_199_254_740_991)
    last_modified_ms: int | None = Field(default=None, ge=0)


class LocalBundleValidationRequest(BaseModel):
    root_name: str = Field(min_length=1, max_length=200)
    files: list[LocalBundleManifestFile] = Field(min_length=1, max_length=MAX_FILES)


class LossFromWindRequest(BaseModel):
    wind_job_id: str = Field(min_length=32, max_length=32, pattern=r"^[0-9a-f]{32}$")
    impact_threshold_ms: float = Field(
        default=DEFAULT_LOSS_IMPACT_THRESHOLD_MS,
        ge=0.0,
        le=100.0,
    )


def artifact_specifications(mode: str) -> dict[str, tuple[Path, str]]:
    if mode == "full":
        return {
            key: (Path("full_output") / relative, media_type)
            for key, (relative, media_type) in FULL_ARTIFACTS.items()
        }
    if mode == "wind":
        return WIND_ARTIFACTS
    if mode == "loss":
        return LOSS_ARTIFACTS
    return {}


app = FastAPI(title="TyphoonRiskChina Local Analysis", version="1.3.0")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, default=str),
        encoding="utf-8",
    )
    temporary.replace(path)


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def interactive_map_warnings(root: Path, mode: str) -> list[str]:
    """Return data-quality warnings embedded in a compact map payload."""

    specification = artifact_specifications(mode).get("interactive-map")
    if specification is None:
        return []
    path = root / specification[0]
    if not path.is_file():
        return []
    try:
        payload = read_json(path)
    except (OSError, ValueError, TypeError):
        return ["The interactive map data could not be read; other algorithm outputs are unaffected."]
    return [str(item) for item in payload.get("warnings") or [] if str(item).strip()]


def job_root(job_id: str) -> Path:
    if not re.fullmatch(r"[0-9a-f]{32}", job_id):
        raise HTTPException(status_code=400, detail="The job ID is invalid.")
    return JOBS_ROOT / job_id


def safe_relative_path(value: str) -> Path:
    raw = str(value or "").strip()
    text = raw.replace("\\", "/")
    if not text or text.startswith("/") or re.match(r"^[A-Za-z]:", text):
        raise ValueError(f"Unsafe file path: {value!r}")
    text = text.rstrip("/")
    candidate = PurePosixPath(text)
    if not text or candidate.is_absolute() or ".." in candidate.parts:
        raise ValueError(f"Unsafe file path: {value!r}")
    if any(":" in part or part in {"", "."} for part in candidate.parts):
        raise ValueError(f"Invalid file path: {value!r}")
    return Path(*candidate.parts)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def full_runtime_status(*, check_python_packages: bool) -> dict[str, Any]:
    """Check the fixed, server-controlled full-mode runtime."""

    issues: list[str] = []
    required_paths = {
        "full Python 3.10": FULL_PYTHON,
        "full pipeline CLI": FULL_CLI,
        "independent stage CLI": FULL_STAGE_CLI,
        "downscaling model": FULL_RUNTIME_ROOT / "models" / "direct_unet_model.h5",
        "input scaler": FULL_RUNTIME_ROOT / "scalers" / "scaler_x.save",
        "output scaler": FULL_RUNTIME_ROOT / "scalers" / "scaler_y.save",
        "province boundaries": (
            FULL_ALGORITHM_ROOT
            / "assets"
            / "vulnerability"
            / "boundaries"
            / "coastal_provinces.geojson"
        ),
        "city boundaries": (
            FULL_ALGORITHM_ROOT
            / "assets"
            / "vulnerability"
            / "boundaries"
            / "coastal_prefecture_cities.geojson"
        ),
        "national boundaries": (
            FULL_ALGORITHM_ROOT
            / "assets"
            / "vulnerability"
            / "boundaries"
            / "china_provinces_with_taiwan.geojson"
        ),
        "nine-dash-line boundaries": (
            FULL_ALGORITHM_ROOT
            / "assets"
            / "vulnerability"
            / "boundaries"
            / "nine_dash_line.geojson"
        ),
    }
    for label, path in required_paths.items():
        if not path.is_file():
            issues.append(f"Missing {label}.")

    exposure_dir = FULL_EXPOSURE_ROOT / FULL_EXPOSURE_DIR_NAME
    grid_dir = FULL_EXPOSURE_ROOT / FULL_GRID_DIR_NAME
    if not exposure_dir.is_dir():
        issues.append("The five-province exposure directory is missing.")
    if not grid_dir.is_dir():
        issues.append("The five-province grid directory is missing.")
    for province in FULL_PROVINCES:
        if not (exposure_dir / f"{province}.parquet").is_file():
            issues.append(f"The {province} exposure Parquet file is missing.")
        if grid_dir.is_dir() and len(list(grid_dir.glob(f"{province}_*.parquet"))) != 1:
            issues.append(f"Expected exactly one {province} grid Parquet file.")

    python_version: str | None = None
    packages_checked = False
    if check_python_packages and FULL_PYTHON.is_file():
        packages_checked = True
        modules = [
            "numpy",
            "pandas",
            "xarray",
            "scipy",
            "matplotlib",
            "joblib",
            "sklearn",
            "openpyxl",
            "h5py",
            "h5netcdf",
            "tensorflow",
            "geopandas",
            "shapely",
            "pyarrow",
            "fiona",
            "pyproj",
            "reportlab",
            "pypdf",
        ]
        probe = (
            "import importlib.util,json,sys;"
            f"mods={modules!r};"
            "print(json.dumps({'version': '.'.join(map(str,sys.version_info[:3])),"
            "'missing':[m for m in mods if importlib.util.find_spec(m) is None]}))"
        )
        try:
            completed = subprocess.run(
                [str(FULL_PYTHON), "-c", probe],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=30,
                check=False,
                shell=False,
            )
            if completed.returncode:
                issues.append("The full-runtime Python dependency check could not run.")
            else:
                payload = json.loads(completed.stdout.strip().splitlines()[-1])
                python_version = str(payload.get("version") or "")
                if not python_version.startswith("3.10."):
                    issues.append(
                        "The full runtime requires Python 3.10; "
                        f"the current version is {python_version or 'unknown'}."
                    )
                for module in payload.get("missing") or []:
                    issues.append(f"The full runtime is missing the Python module {module}.")
        except (OSError, subprocess.TimeoutExpired, ValueError, json.JSONDecodeError):
            issues.append("The full-runtime Python dependency check failed.")

    return {
        "ready": not issues,
        "engine": "TyphoonRiskChina 1.1.0 full-local",
        "python_version": python_version,
        "packages_checked": packages_checked,
        "issues": issues,
    }


def stage_runtime_status(stage: str, *, check_python_packages: bool) -> dict[str, Any]:
    """Check only the resources needed by one independently runnable stage."""

    profiles = {
        "wind-local": {
            "engine": "TyphoonRiskChina 1.1.0 wind-local",
            "modules": [
                "numpy",
                "pandas",
                "xarray",
                "scipy",
                "matplotlib",
                "joblib",
                "sklearn",
                "openpyxl",
                "h5py",
                "h5netcdf",
                "tensorflow",
            ],
        },
        "wind-upload": {
            "engine": "TyphoonRiskChina 1.1.0 wind-netcdf",
            "modules": [
                "numpy",
                "pandas",
                "xarray",
                "scipy",
                "matplotlib",
                "h5py",
                "h5netcdf",
            ],
        },
        "loss": {
            "engine": "TyphoonRiskChina 1.1.0 vulnerability-loss",
            "modules": [
                "numpy",
                "pandas",
                "xarray",
                "scipy",
                "matplotlib",
                "openpyxl",
                "h5py",
                "h5netcdf",
                "geopandas",
                "shapely",
                "pyarrow",
                "fiona",
                "pyproj",
                "reportlab",
                "pypdf",
            ],
        },
    }
    profile = profiles.get(stage)
    if profile is None:
        raise ValueError(f"Unknown independent algorithm stage: {stage}")

    issues: list[str] = []
    required_paths: dict[str, Path] = {
        "full Python 3.10": FULL_PYTHON,
        "independent stage CLI": FULL_STAGE_CLI,
        "interactive map generator": FULL_STAGE_CLI.parent / "interactive_map.py",
    }
    algorithm_backend = FULL_CLI.parent
    if stage == "wind-local":
        required_paths.update(
            {
                "downscaling service source": algorithm_backend / "service.py",
                "downscaling model": FULL_RUNTIME_ROOT / "models" / "direct_unet_model.h5",
                "input scaler": FULL_RUNTIME_ROOT / "scalers" / "scaler_x.save",
                "output scaler": FULL_RUNTIME_ROOT / "scalers" / "scaler_y.save",
            }
        )
    if stage == "wind-upload":
        required_paths["fixed-grid source"] = (
            algorithm_backend / "typhoon_downscaling" / "core" / "fixed_grid.py"
        )
    if stage == "loss":
        boundary_dir = FULL_ALGORITHM_ROOT / "assets" / "vulnerability" / "boundaries"
        required_paths.update(
            {
                "exposure source": algorithm_backend / "typhoon_risk_pipeline" / "exposure.py",
                "vulnerability engine source": (
                    algorithm_backend / "typhoon_vulnerability" / "engine.py"
                ),
                "province boundaries": boundary_dir / "coastal_provinces.geojson",
                "city boundaries": boundary_dir / "coastal_prefecture_cities.geojson",
                "national boundaries": boundary_dir / "china_provinces_with_taiwan.geojson",
                "nine-dash-line boundaries": boundary_dir / "nine_dash_line.geojson",
            }
        )
    for label, path in required_paths.items():
        if not path.is_file():
            issues.append(f"Missing {label}.")

    if stage == "loss":
        exposure_dir = FULL_EXPOSURE_ROOT / FULL_EXPOSURE_DIR_NAME
        grid_dir = FULL_EXPOSURE_ROOT / FULL_GRID_DIR_NAME
        if not exposure_dir.is_dir():
            issues.append("The five-province exposure directory is missing.")
        if not grid_dir.is_dir():
            issues.append("The five-province grid directory is missing.")
        for province in FULL_PROVINCES:
            if not (exposure_dir / f"{province}.parquet").is_file():
                issues.append(f"The {province} exposure Parquet file is missing.")
            if grid_dir.is_dir() and len(list(grid_dir.glob(f"{province}_*.parquet"))) != 1:
                issues.append(f"Expected exactly one {province} grid Parquet file.")

    python_version: str | None = None
    packages_checked = False
    if check_python_packages and FULL_PYTHON.is_file():
        packages_checked = True
        modules = list(profile["modules"])
        probe = (
            "import importlib.util,json,sys;"
            f"mods={modules!r};"
            "print(json.dumps({'version': '.'.join(map(str,sys.version_info[:3])),"
            "'missing':[m for m in mods if importlib.util.find_spec(m) is None]}))"
        )
        try:
            completed = subprocess.run(
                [str(FULL_PYTHON), "-c", probe],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=30,
                check=False,
                shell=False,
            )
            if completed.returncode:
                issues.append("The stage-runtime Python dependency check could not run.")
            else:
                payload = json.loads(completed.stdout.strip().splitlines()[-1])
                python_version = str(payload.get("version") or "")
                if not python_version.startswith("3.10."):
                    issues.append(
                        "The stage runtime requires Python 3.10; "
                        f"the current version is {python_version or 'unknown'}."
                    )
                for module in payload.get("missing") or []:
                    issues.append(f"The stage runtime is missing the Python module {module}.")
        except (OSError, subprocess.TimeoutExpired, ValueError, json.JSONDecodeError):
            issues.append("The stage-runtime Python dependency check failed.")

    return {
        "ready": not issues,
        "stage": stage,
        "engine": str(profile["engine"]),
        "python_version": python_version,
        "packages_checked": packages_checked,
        "issues": issues,
    }


def cached_full_runtime_status(max_age_seconds: float = 30.0) -> dict[str, Any]:
    """Avoid starting a Python probe on every Vite/launcher health poll."""

    global _FULL_RUNTIME_CACHE
    now = time.monotonic()
    if _FULL_RUNTIME_CACHE and now - _FULL_RUNTIME_CACHE[0] <= max_age_seconds:
        return _FULL_RUNTIME_CACHE[1]
    status = full_runtime_status(check_python_packages=True)
    _FULL_RUNTIME_CACHE = (now, status)
    return status


def cached_stage_runtime_status(
    stage: str,
    max_age_seconds: float = 30.0,
) -> dict[str, Any]:
    """Cache each independent stage probe without coupling their requirements."""

    now = time.monotonic()
    cached = _STAGE_RUNTIME_CACHE.get(stage)
    if cached and now - cached[0] <= max_age_seconds:
        return cached[1]
    status = stage_runtime_status(stage, check_python_packages=True)
    _STAGE_RUNTIME_CACHE[stage] = (now, status)
    return status


def scan_full_cases() -> list[dict[str, Any]]:
    """Discover direct children of the configured case root; never trust an HTTP path."""

    if not FULL_CASES_ROOT.is_dir():
        return []
    cases: list[dict[str, Any]] = []
    expected = set(EXPECTED_FNL_NAMES)
    for case_dir in sorted(FULL_CASES_ROOT.iterdir(), key=lambda item: item.name.lower()):
        if not case_dir.is_dir() or not re.fullmatch(r"[A-Za-z0-9_-]+", case_dir.name):
            continue
        config_candidates = [case_dir / "config.yml", case_dir / "config.yaml"]
        config_path = next((path for path in config_candidates if path.is_file()), None)
        if config_path is None:
            continue
        issues: list[str] = []
        warnings: list[str] = []
        try:
            payload = yaml.safe_load(config_path.read_text(encoding="utf-8-sig")) or {}
        except (OSError, UnicodeError, yaml.YAMLError) as exc:
            payload = {}
            issues.append(f"The case configuration could not be read ({type(exc).__name__}).")
        if not isinstance(payload, dict):
            payload = {}
            issues.append("The case configuration must contain a YAML mapping at its root.")
        if str(payload.get("mode", "")) != "full":
            issues.append("The case configuration mode must be 'full'.")
        case_block = payload.get("case") or {}
        case_id = str(case_block.get("id") or "").strip().upper()
        typhoon_name = clean_label(case_block.get("name"), case_id or case_dir.name)
        if not re.fullmatch(r"ID\d{4}", case_id):
            issues.append("The Case ID must use the format ID2609.")

        track_candidates = (case_dir / "track.xlsx", case_dir / "工作路径.xlsx")
        track_path = next((path for path in track_candidates if path.is_file()), track_candidates[0])
        if not track_path.is_file():
            issues.append("The required track workbook is missing.")
        fnl_dir = case_dir / "FNL"
        actual_paths = list(fnl_dir.glob("*.nc")) if fnl_dir.is_dir() else []
        actual = {path.name.lower() for path in actual_paths}
        missing = sorted(expected - actual)
        unexpected = sorted(actual - expected)
        if missing:
            issues.append("Missing FNL forecast hours: " + ", ".join(path[:3] for path in missing))
        if unexpected:
            issues.append("The FNL folder contains NetCDF files outside the 006–168 sequence.")
        fnl_bytes = sum(path.stat().st_size for path in actual_paths if path.is_file())
        accepted_manifest = (
            FULL_BUNDLE_ROOT
            / "outputs_corrected"
            / case_dir.name
            / "vulnerability"
            / "result_manifest.json"
        )
        if accepted_manifest.is_file():
            warnings.append(
                "The accepted-output folder contains a historical fixed-grid reference; "
                "a new run regenerates the wind field from the current code, model, and inputs."
            )
        reference_dir = FULL_ALGORITHM_ROOT / "examples" / case_dir.name / "input"
        reference_candidates = (reference_dir / "track.xlsx", reference_dir / "工作路径.xlsx")
        reference_track = next((path for path in reference_candidates if path.is_file()), reference_candidates[0])
        if track_path.is_file() and reference_track.is_file():
            if sha256_file(track_path) != sha256_file(reference_track):
                warnings.append(
                    "This case track differs from the algorithm's acceptance-test track, "
                    "so a new result may differ from the accepted reference value."
                )
        cases.append(
            {
                "case_key": case_dir.name,
                "case_id": case_id,
                "typhoon_name": typhoon_name,
                "case_dir": case_dir.absolute(),
                "config_path": config_path.absolute(),
                "track_path": track_path.absolute(),
                "fnl_dir": fnl_dir.absolute(),
                "fnl_count": len(actual & expected),
                "fnl_bytes": fnl_bytes,
                "accepted_result_available": accepted_manifest.is_file(),
                "issues": issues,
                "warnings": warnings,
                "ready": not issues,
            }
        )
    return cases


def load_registered_wind_sources() -> list[dict[str, Any]]:
    """Load exact server-owned case directories; never accept paths from HTTP."""

    if not APPROVED_WIND_SOURCES_PATH.is_file():
        return []
    try:
        payload = json.loads(APPROVED_WIND_SOURCES_PATH.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError):
        return []
    if not isinstance(payload, dict) or payload.get("schema_version") != 1:
        return []
    raw_sources = payload.get("sources") if isinstance(payload, dict) else None
    if not isinstance(raw_sources, list):
        return []

    sources: list[dict[str, Any]] = []
    for item in raw_sources:
        if not isinstance(item, dict) or item.get("enabled", True) is False:
            continue
        case_key = str(item.get("case_key") or "").strip()
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,120}", case_key):
            continue
        case_id = str(item.get("case_id") or "").strip().upper()
        if not re.fullmatch(r"ID\d{4}", case_id):
            continue
        raw_case_dir = str(item.get("case_dir") or "").strip()
        if not raw_case_dir or "\x00" in raw_case_dir:
            continue
        try:
            case_dir = Path(raw_case_dir).expanduser()
        except (OSError, RuntimeError, ValueError):
            continue
        if not case_dir.is_absolute():
            continue
        sources.append(
            {
                "case_key": case_key,
                "case_id": case_id,
                "typhoon_name": clean_label(item.get("typhoon_name"), case_id),
                "case_dir": case_dir.absolute(),
            }
        )
    return sources


def approved_wind_case_specs() -> list[dict[str, Any]]:
    """Combine exact registry entries with direct children of the legacy case root."""

    specs: list[dict[str, Any]] = []
    seen: set[str] = set()
    seen_keys: set[str] = set()

    for registered in load_registered_wind_sources():
        case_dir = Path(registered["case_dir"])
        if not case_dir.is_dir():
            continue
        try:
            resolved = case_dir.resolve(strict=True)
        except (OSError, RuntimeError):
            continue
        key = os.path.normcase(str(resolved))
        source_key = str(registered["case_key"]).casefold()
        if key in seen or source_key in seen_keys:
            continue
        seen.add(key)
        seen_keys.add(source_key)
        specs.append(
            {
                **registered,
                "case_dir": case_dir,
                "approval_root": case_dir,
                "identity_source": "registry",
            }
        )

    if FULL_CASES_ROOT.is_dir():
        for case_dir in sorted(FULL_CASES_ROOT.iterdir(), key=lambda item: item.name.casefold()):
            if not case_dir.is_dir():
                continue
            try:
                resolved = case_dir.resolve(strict=True)
            except (OSError, RuntimeError):
                continue
            key = os.path.normcase(str(resolved))
            source_key = case_dir.name.casefold()
            if key in seen or source_key in seen_keys:
                continue
            seen.add(key)
            seen_keys.add(source_key)
            specs.append(
                {
                    "case_key": case_dir.name,
                    "case_id": "",
                    "typhoon_name": "",
                    "case_dir": case_dir,
                    "approval_root": FULL_CASES_ROOT,
                    "identity_source": "",
                }
            )
    return specs


def scan_approved_fnl_sources(
    workbook_case_id: str | None = None,
) -> list[dict[str, Any]]:
    """Discover allowlisted FNL-only sources without requiring a server-side track."""

    workbook_identity = str(workbook_case_id or "").strip().upper()
    if not re.fullmatch(r"ID\d{4}", workbook_identity):
        workbook_identity = ""
    expected = {name.casefold() for name in EXPECTED_FNL_NAMES}
    sources: list[dict[str, Any]] = []
    for spec in approved_wind_case_specs():
        case_dir = Path(spec["case_dir"])
        fnl_dir = case_dir / "FNL"
        if not fnl_dir.is_dir():
            continue
        actual_paths = [path for path in fnl_dir.iterdir() if path.is_file() and path.suffix.casefold() == ".nc"]
        actual = {path.name.casefold() for path in actual_paths}
        if actual != expected:
            continue
        try:
            resolved_fnl_dir = fnl_dir.resolve(strict=True)
            resolved_approval_root = Path(spec["approval_root"]).resolve(strict=True)
            resolved_fnl_dir.relative_to(resolved_approval_root)
            if any(path.resolve(strict=True).parent != resolved_fnl_dir for path in actual_paths):
                continue
        except (OSError, RuntimeError, ValueError):
            continue

        case_id = str(spec.get("case_id") or "").strip().upper()
        typhoon_name = clean_label(spec.get("typhoon_name"), case_id) if case_id else ""
        identity_source = str(spec.get("identity_source") or "") if case_id else ""
        config_path = next(
            (path for path in (case_dir / "config.yml", case_dir / "config.yaml") if path.is_file()),
            None,
        )
        if not case_id and config_path is not None:
            try:
                payload = yaml.safe_load(config_path.read_text(encoding="utf-8-sig")) or {}
                case_block = payload.get("case") if isinstance(payload, dict) else {}
                if not isinstance(case_block, dict):
                    case_block = {}
                configured_id = str((case_block or {}).get("id") or "").strip().upper()
                if re.fullmatch(r"ID\d{4}", configured_id):
                    case_id = configured_id
                    typhoon_name = clean_label((case_block or {}).get("name"), case_dir.name)
                    identity_source = "config"
            except (OSError, UnicodeError, yaml.YAMLError):
                pass

        if not case_id:
            folder_match = re.fullmatch(r"(.+?)[_-](ID\d{4})", case_dir.name, flags=re.IGNORECASE)
            if folder_match:
                case_id = folder_match.group(2).upper()
                typhoon_name = clean_label(
                    re.sub(r"[_-]+", " ", folder_match.group(1)).strip(),
                    case_dir.name,
                )
                identity_source = "folder"
        if not case_id:
            case_id = workbook_identity or "ID0000"
            typhoon_name = clean_label(re.sub(r"[_-]+", " ", case_dir.name), "Uploaded typhoon")
            identity_source = "workbook" if workbook_identity else "generic"

        configured_key = str(spec.get("case_key") or "").strip()
        source_key = configured_key if re.fullmatch(r"[A-Za-z0-9_-]{1,120}", configured_key) else (
            case_dir.name
            if re.fullmatch(r"[A-Za-z0-9_-]{1,120}", case_dir.name)
            else "source_" + hashlib.sha256(case_dir.name.encode("utf-8")).hexdigest()[:16]
        )
        sources.append(
            {
                "case_key": source_key,
                "case_id": case_id,
                "typhoon_name": typhoon_name,
                "identity_source": identity_source,
                "case_dir": case_dir.absolute(),
                "fnl_dir": resolved_fnl_dir,
                "approval_root": resolved_approval_root,
                "fnl_count": len(EXPECTED_FNL_NAMES),
                "fnl_bytes": sum(path.stat().st_size for path in actual_paths),
                "issues": [],
                "warnings": [],
                "ready": True,
            }
        )
    return sources


def public_full_case(case: dict[str, Any]) -> dict[str, Any]:
    """Remove all server filesystem paths before returning case metadata."""

    allowed = {
        "case_key",
        "case_id",
        "typhoon_name",
        "fnl_count",
        "fnl_bytes",
        "accepted_result_available",
        "issues",
        "warnings",
        "ready",
    }
    return {key: value for key, value in case.items() if key in allowed}


def get_full_case(case_key: str) -> dict[str, Any]:
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,120}", str(case_key or "")):
        raise HTTPException(status_code=400, detail="The case key is invalid.")
    for case in scan_full_cases():
        if case["case_key"] == case_key:
            return case
    raise HTTPException(status_code=404, detail="The requested local case is not available.")


def normalize_browser_manifest_path(value: str, root_name: str) -> str:
    """Normalize a webkitRelativePath without accepting an absolute filesystem path."""

    relative = safe_relative_path(value)
    parts = list(relative.parts)
    if parts and parts[0].casefold() == root_name.casefold():
        parts = parts[1:]
    if not parts:
        raise ValueError("The manifest contains a folder entry instead of a file path.")
    return Path(*parts).as_posix().casefold()


def approved_bundle_manifest_key(path: Path) -> str | None:
    """Return a path relative to the fixed bundle root, or None when it escapes it."""

    try:
        bundle_root = FULL_BUNDLE_ROOT.resolve(strict=True)
        relative = path.resolve(strict=True).relative_to(bundle_root)
    except (OSError, RuntimeError, ValueError):
        return None
    return relative.as_posix().casefold()


def manifest_matches_local_file(manifest: dict[str, int], path: Path) -> bool:
    key = approved_bundle_manifest_key(path)
    if key is None or key not in manifest:
        return False
    try:
        return manifest[key] == path.stat().st_size
    except OSError:
        return False


def issue_bundle_token(case_keys: set[str]) -> str:
    """Issue a bounded, short-lived token tied only to discovered case keys."""

    now = time.monotonic()
    expires_at = now + BUNDLE_TOKEN_TTL_SECONDS
    with _BUNDLE_TOKEN_LOCK:
        for token, (expiry, _keys) in list(_BUNDLE_TOKENS.items()):
            if expiry <= now:
                _BUNDLE_TOKENS.pop(token, None)
        if len(_BUNDLE_TOKENS) >= MAX_BUNDLE_TOKENS:
            oldest = min(_BUNDLE_TOKENS, key=lambda token: _BUNDLE_TOKENS[token][0])
            _BUNDLE_TOKENS.pop(oldest, None)
        token = secrets.token_urlsafe(32)
        while token in _BUNDLE_TOKENS:
            token = secrets.token_urlsafe(32)
        _BUNDLE_TOKENS[token] = (expires_at, frozenset(case_keys))
    return token


def require_bundle_token(token: str, case_key: str) -> None:
    """Validate a supplied token; callers that omit it retain legacy API behavior."""

    now = time.monotonic()
    with _BUNDLE_TOKEN_LOCK:
        entry = _BUNDLE_TOKENS.get(token)
        if entry is not None and entry[0] <= now:
            _BUNDLE_TOKENS.pop(token, None)
            entry = None
    if entry is None:
        raise HTTPException(
            status_code=409,
            detail=(
                "The large-dataset folder verification is missing or has expired. "
                "Select the Illustrative examples folder again."
            ),
        )
    if case_key not in entry[1]:
        raise HTTPException(
            status_code=403,
            detail="The selected case was not verified in this large-dataset folder.",
        )


def validate_local_bundle_manifest(
    request: LocalBundleValidationRequest,
) -> dict[str, Any]:
    """Verify browser metadata against the approved bundle without copying its files."""

    if not FULL_BUNDLE_ROOT.is_dir():
        raise HTTPException(
            status_code=503,
            detail="The approved local large-dataset bundle is not available on this computer.",
        )
    expected_root_name = FULL_BUNDLE_ROOT.name
    root_name = request.root_name.strip()
    if root_name.casefold() != expected_root_name.casefold():
        raise HTTPException(
            status_code=400,
            detail=f"Select the {expected_root_name} folder itself, not one of its subfolders.",
        )

    manifest: dict[str, int] = {}
    total_bytes = 0
    try:
        for item in request.files:
            key = normalize_browser_manifest_path(item.path, root_name)
            if key in manifest:
                raise ValueError("The selected folder contains duplicate file paths.")
            manifest[key] = item.size
            total_bytes += item.size
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    shared_wind_files = (
        FULL_BUNDLE_ROOT
        / "runtime"
        / "downscaling"
        / "models"
        / "direct_unet_model.h5",
        FULL_BUNDLE_ROOT
        / "runtime"
        / "downscaling"
        / "scalers"
        / "scaler_x.save",
        FULL_BUNDLE_ROOT
        / "runtime"
        / "downscaling"
        / "scalers"
        / "scaler_y.save",
    )
    if not all(manifest_matches_local_file(manifest, path) for path in shared_wind_files):
        raise HTTPException(
            status_code=400,
            detail=(
                "The selected folder does not match the approved large dataset: "
                "one or more wind-model files are missing or have a different size."
            ),
        )

    selected_cases: list[dict[str, Any]] = []
    for case in scan_full_cases():
        if not case.get("ready"):
            continue
        required_case_files = [case["config_path"], case["track_path"]]
        required_case_files.extend(
            case["fnl_dir"] / filename for filename in EXPECTED_FNL_NAMES
        )
        if all(
            manifest_matches_local_file(manifest, path)
            for path in required_case_files
        ):
            selected_cases.append(case)

    if not selected_cases:
        raise HTTPException(
            status_code=400,
            detail=(
                "No complete wind case was found in the selected folder. "
                "Each case requires its configuration, track workbook, and all 28 FNL files."
            ),
        )

    case_keys = {str(case["case_key"]) for case in selected_cases}
    token = issue_bundle_token(case_keys)
    return {
        "status": "ready",
        "mode": "local-large-dataset",
        "root_name": expected_root_name,
        "bundle_token": token,
        "token_expires_in_seconds": BUNDLE_TOKEN_TTL_SECONDS,
        "cases": [public_full_case(case) for case in selected_cases],
        "file_count": len(request.files),
        "total_bytes": total_bytes,
        "verified_in_place": True,
        "copy_required": False,
    }


def resolve_uploaded_case(
    case_key: str,
    case_id: str = "",
    typhoon_name: str = "",
) -> dict[str, Any]:
    """Resolve identity and track from the allowlist, never from an HTTP path."""

    if not str(case_key or "").strip():
        raise HTTPException(
            status_code=400,
            detail="Select a local case so the associated track workbook can be read safely.",
        )
    case = get_full_case(str(case_key).strip())
    if not case.get("ready"):
        raise HTTPException(status_code=400, detail="The selected local case is not ready.")
    supplied_id = str(case_id or "").strip().upper()
    supplied_name = str(typhoon_name or "").strip()
    if supplied_id and supplied_id != case["case_id"]:
        raise HTTPException(status_code=400, detail="The Case ID does not match the selected local case.")
    if supplied_name and supplied_name.casefold() != str(case["typhoon_name"]).casefold():
        raise HTTPException(status_code=400, detail="The typhoon name does not match the selected local case.")
    return case


async def save_upload_limited(upload: UploadFile, destination: Path, limit: int) -> int:
    """Stream one upload to the local job directory with a hard byte limit."""

    destination.parent.mkdir(parents=True, exist_ok=True)
    total = 0
    try:
        with destination.open("wb") as stream:
            while block := await upload.read(1024 * 1024):
                total += len(block)
                if total > limit:
                    raise HTTPException(
                        status_code=413,
                detail=f"The input file exceeds the {limit // (1024 * 1024)} MB limit.",
                    )
                stream.write(block)
    finally:
        await upload.close()
    return total


def inspect_track_workbook(path: Path) -> dict[str, Any]:
    """Validate a bounded XLSX workbook without executing formulas or macros."""

    try:
        with zipfile.ZipFile(path) as archive:
            members = archive.infolist()
            if not members or len(members) > 512:
                raise ValueError("The track workbook has an invalid XLSX structure.")
            if any(item.flag_bits & 0x1 for item in members):
                raise ValueError("Encrypted track workbooks are not supported.")
            if sum(int(item.file_size) for item in members) > 64 * 1024 * 1024:
                raise ValueError("The expanded track workbook is too large.")
            names = {item.filename.replace("\\", "/") for item in members}
            if "[Content_Types].xml" not in names or "xl/workbook.xml" not in names:
                raise ValueError("The selected file is not a valid XLSX workbook.")
    except (OSError, zipfile.BadZipFile) as exc:
        raise ValueError("The selected file is not a valid XLSX workbook.") from exc

    try:
        from openpyxl import load_workbook

        workbook = load_workbook(path, read_only=True, data_only=True)
    except Exception as exc:
        raise ValueError("The track workbook could not be read.") from exc

    workbook_case_id: str | None = None
    valid_table = False
    try:
        for worksheet in workbook.worksheets[:20]:
            row_limit = min(int(worksheet.max_row or 0), 5000)
            column_limit = min(int(worksheet.max_column or 0), 64)
            if row_limit < 1 or column_limit < 1:
                continue
            rows = list(
                worksheet.iter_rows(
                    min_row=1,
                    max_row=min(row_limit, 64),
                    max_col=column_limit,
                    values_only=True,
                )
            )
            header_index: int | None = None
            header_map: dict[str, int] = {}
            for index, row in enumerate(rows):
                for value in row:
                    match = re.search(r"\bID\d{4}\b", str(value or "").upper())
                    if match and workbook_case_id is None:
                        workbook_case_id = match.group(0)
                normalized = {
                    str(value or "").strip().casefold(): position
                    for position, value in enumerate(row)
                    if str(value or "").strip()
                }
                longitude_key = next(
                    (key for key in ("long", "lon", "longitude") if key in normalized),
                    None,
                )
                latitude_key = next(
                    (key for key in ("lat", "latitude") if key in normalized),
                    None,
                )
                if "time" in normalized and latitude_key and longitude_key:
                    header_index = index + 1
                    header_map = {
                        "time": normalized["time"],
                        "lat": normalized[latitude_key],
                        "lon": normalized[longitude_key],
                    }
                    break
            if header_index is None:
                continue

            valid_timestamps: set[str] = set()
            for row in worksheet.iter_rows(
                min_row=header_index + 1,
                max_row=min(row_limit, header_index + 2000),
                max_col=column_limit,
                values_only=True,
            ):
                try:
                    time_value = row[header_map["time"]]
                    latitude = float(row[header_map["lat"]])
                    longitude = float(row[header_map["lon"]])
                except (IndexError, TypeError, ValueError):
                    continue
                if time_value not in (None, "") and -90 <= latitude <= 90 and -180 <= longitude <= 360:
                    valid_timestamps.add(str(time_value).strip())
                    if len(valid_timestamps) >= 2:
                        valid_table = True
                        break
            if valid_table:
                break
    finally:
        workbook.close()

    if not valid_table:
        raise ValueError(
            "The track workbook must contain at least two valid rows with distinct times and latitude/longitude values."
        )
    return {"workbook_case_id": workbook_case_id}


def validate_fnl_folder_manifest(
    root_name: str,
    manifest_json: str,
    workbook_case_id: str | None = None,
) -> tuple[dict[str, Any], dict[str, dict[str, int]], int]:
    """Identify one approved FNL source solely from safe browser file metadata."""

    selected_root = str(root_name or "").strip()
    if selected_root.casefold() != "fnl":
        raise HTTPException(
            status_code=400,
            detail="Select the FNL folder itself, not its parent or a nested folder.",
        )
    if len(manifest_json.encode("utf-8")) > MAX_WIND_INPUT_MANIFEST_BYTES:
        raise HTTPException(status_code=413, detail="The FNL folder manifest is too large.")
    try:
        raw_items = json.loads(manifest_json)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=400, detail="The FNL folder manifest is not valid JSON.") from exc
    if not isinstance(raw_items, list) or not 1 <= len(raw_items) <= MAX_FILES:
        raise HTTPException(
            status_code=400,
            detail=f"The FNL folder manifest must contain between 1 and {MAX_FILES} files.",
        )

    selected: dict[str, LocalBundleManifestFile] = {}
    try:
        for raw_item in raw_items:
            item = LocalBundleManifestFile.model_validate(raw_item)
            key = normalize_browser_manifest_path(item.path, selected_root)
            relative = PurePosixPath(key)
            if len(relative.parts) != 1 or relative.suffix.casefold() != ".nc":
                raise ValueError("The FNL folder may contain only the 28 forecast NetCDF files at its top level.")
            if key in selected:
                raise ValueError("The FNL folder manifest contains a duplicate filename.")
            if item.last_modified_ms is None:
                raise ValueError("The FNL folder manifest is missing file modification times.")
            selected[key] = item
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=400, detail="The FNL folder manifest contains an invalid file entry.") from exc

    expected_names = {name.casefold() for name in EXPECTED_FNL_NAMES}
    missing = sorted(expected_names - selected.keys())
    unexpected = sorted(selected.keys() - expected_names)
    if missing:
        hours = ", ".join(name[:3] for name in missing)
        raise HTTPException(status_code=400, detail=f"The FNL folder is missing forecast hours: {hours}.")
    if unexpected:
        raise HTTPException(
            status_code=400,
            detail="The FNL folder contains files outside the required 006.nc through 168.nc sequence.",
        )

    matches: list[tuple[dict[str, Any], dict[str, dict[str, int]], int]] = []
    for case in scan_approved_fnl_sources(workbook_case_id):
        if not case.get("ready"):
            continue
        fnl_dir = Path(case["fnl_dir"])
        try:
            resolved_fnl_dir = fnl_dir.resolve(strict=True)
            resolved_approval_root = Path(case["approval_root"]).resolve(strict=True)
            resolved_fnl_dir.relative_to(resolved_approval_root)
        except (OSError, RuntimeError, ValueError):
            continue
        signature: dict[str, dict[str, int]] = {}
        total_bytes = 0
        matched = True
        for filename in EXPECTED_FNL_NAMES:
            path = fnl_dir / filename
            try:
                stat_result = path.stat()
            except OSError:
                matched = False
                break
            item = selected[filename.casefold()]
            actual_modified_ms = stat_result.st_mtime_ns // 1_000_000
            if item.size != stat_result.st_size or abs(item.last_modified_ms - actual_modified_ms) > 2000:
                matched = False
                break
            signature[filename] = {
                "size": int(stat_result.st_size),
                "last_modified_ms": int(actual_modified_ms),
            }
            total_bytes += int(stat_result.st_size)
        if matched:
            matches.append((case, signature, total_bytes))

    if not matches:
        raise HTTPException(
            status_code=400,
            detail=(
                "The selected FNL folder does not match any approved local source. "
                "Select the complete, unchanged FNL folder."
            ),
        )
    if len(matches) != 1:
        raise HTTPException(
            status_code=409,
            detail="The selected FNL folder matches more than one approved source, so its identity is ambiguous.",
        )
    return matches[0]


def cleanup_wind_input_record(record: dict[str, Any]) -> None:
    """Delete only the dedicated temporary directory owned by a verification token."""

    raw_root = record.get("temp_root")
    if not raw_root:
        return
    try:
        allowed_root = (FULL_TEMP_ROOT / "validated-wind-inputs").resolve()
        candidate = Path(raw_root).resolve()
        candidate.relative_to(allowed_root)
        if candidate == allowed_root:
            return
    except (OSError, RuntimeError, ValueError):
        return
    shutil.rmtree(candidate, ignore_errors=True)


def cleanup_abandoned_wind_input_uploads() -> None:
    """Remove workbook uploads whose in-memory tokens cannot survive a restart."""

    token_root = FULL_TEMP_ROOT / "validated-wind-inputs"
    if not token_root.is_dir():
        return
    try:
        allowed_root = token_root.resolve(strict=True)
        candidates = list(token_root.iterdir())
    except OSError:
        return
    for candidate in candidates:
        try:
            resolved = candidate.resolve(strict=True)
            resolved.relative_to(allowed_root)
            if resolved == allowed_root or not resolved.is_dir():
                continue
        except (OSError, RuntimeError, ValueError):
            continue
        shutil.rmtree(resolved, ignore_errors=True)


# Verification tokens are process-local, so no upload can remain valid across
# an application restart. Clean these small orphan directories during import,
# before the server begins accepting requests.
cleanup_abandoned_wind_input_uploads()


def issue_wind_input_token(record: dict[str, Any]) -> str:
    """Issue a bounded, one-use token tied to one verified FNL-and-track pair."""

    now = time.monotonic()
    expired: list[dict[str, Any]] = []
    with _WIND_INPUT_TOKEN_LOCK:
        for old_token, old_record in list(_WIND_INPUT_TOKENS.items()):
            if float(old_record.get("expires_at", 0)) <= now:
                expired.append(_WIND_INPUT_TOKENS.pop(old_token))
        if len(_WIND_INPUT_TOKENS) >= MAX_WIND_INPUT_TOKENS:
            oldest_token = min(
                _WIND_INPUT_TOKENS,
                key=lambda item: float(_WIND_INPUT_TOKENS[item].get("expires_at", 0)),
            )
            expired.append(_WIND_INPUT_TOKENS.pop(oldest_token))
        token = secrets.token_urlsafe(32)
        while token in _WIND_INPUT_TOKENS:
            token = secrets.token_urlsafe(32)
        stored = dict(record)
        stored["expires_at"] = now + WIND_INPUT_TOKEN_TTL_SECONDS
        _WIND_INPUT_TOKENS[token] = stored
    for old_record in expired:
        cleanup_wind_input_record(old_record)
    return token


def consume_wind_input_token(token: str) -> dict[str, Any]:
    """Atomically consume a verified input token so duplicate jobs cannot reuse it."""

    now = time.monotonic()
    with _WIND_INPUT_TOKEN_LOCK:
        record = _WIND_INPUT_TOKENS.pop(token, None)
    if record is None:
        raise HTTPException(
            status_code=409,
            detail="The input verification is missing, expired, or has already been used. Select both inputs again.",
        )
    if float(record.get("expires_at", 0)) <= now:
        cleanup_wind_input_record(record)
        raise HTTPException(
            status_code=409,
            detail="The input verification has expired. Select both inputs again.",
        )
    return record


def verified_case_from_wind_input_record(record: dict[str, Any]) -> dict[str, Any]:
    """Recheck token binding and input immutability immediately before job creation."""

    case = next(
        (
            source
            for source in scan_approved_fnl_sources(record.get("workbook_case_id"))
            if source["case_key"] == str(record.get("case_key") or "")
        ),
        None,
    )
    if case is None:
        raise HTTPException(status_code=409, detail="The verified FNL source is no longer approved.")
    if (
        case.get("case_id") != record.get("case_id")
        or case.get("typhoon_name") != record.get("typhoon_name")
    ):
        raise HTTPException(status_code=409, detail="The verified input identity has changed. Select both inputs again.")
    try:
        current_fnl_dir = Path(case["fnl_dir"]).resolve(strict=True)
        verified_fnl_dir = Path(record.get("fnl_dir") or "").resolve(strict=True)
    except (OSError, RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=409, detail="The verified FNL source is no longer approved.") from exc
    if current_fnl_dir != verified_fnl_dir:
        raise HTTPException(status_code=409, detail="The verified FNL source registration has changed.")
    track_path = Path(record.get("track_path") or "")
    try:
        track_matches = track_path.is_file() and secrets.compare_digest(
            sha256_file(track_path),
            str(record.get("track_sha256") or ""),
        )
    except OSError:
        track_matches = False
    if not track_matches:
        raise HTTPException(status_code=409, detail="The verified track workbook is no longer available.")

    signature = record.get("fnl_signature") or {}
    for filename in EXPECTED_FNL_NAMES:
        expected = signature.get(filename) or {}
        try:
            stat_result = (Path(case["fnl_dir"]) / filename).stat()
        except OSError as exc:
            raise HTTPException(status_code=409, detail="The verified FNL source is no longer available.") from exc
        if (
            int(expected.get("size", -1)) != stat_result.st_size
            or int(expected.get("last_modified_ms", -1)) != stat_result.st_mtime_ns // 1_000_000
        ):
            raise HTTPException(status_code=409, detail="The verified FNL source changed after selection.")
    return case


def extract_loss_input_package(archive: Path, input_root: Path) -> tuple[Path, Path]:
    """Safely extract exactly one fixed-grid NC and one track workbook."""

    try:
        bundle = zipfile.ZipFile(archive)
    except (OSError, zipfile.BadZipFile) as exc:
        raise ValueError("The loss-input package is not a valid ZIP file.") from exc
    with bundle:
        members = [item for item in bundle.infolist() if not item.is_dir()]
        if not members or len(members) > 8:
            raise ValueError("The loss-input package may contain only the wind-field NetCDF, track XLSX, and a small number of manifest files.")
        if sum(int(item.file_size) for item in members) > MAX_LOSS_PACKAGE_BYTES:
            raise ValueError("The extracted loss-input package exceeds the 512 MB limit.")
        safe_members: list[tuple[zipfile.ZipInfo, Path]] = []
        seen: set[str] = set()
        for item in members:
            relative = safe_relative_path(item.filename)
            normalized = relative.as_posix().casefold()
            mode = (item.external_attr >> 16) & 0xFFFF
            if item.flag_bits & 0x1 or stat.S_ISLNK(mode):
                raise ValueError("The loss-input package cannot contain encrypted files or symbolic links.")
            if normalized in seen:
                raise ValueError("The loss-input package contains duplicate filenames.")
            seen.add(normalized)
            safe_members.append((item, relative))
        nc_members = [
            (item, relative)
            for item, relative in safe_members
            if relative.suffix.lower() in {".nc", ".nc4"}
        ]
        track_members = [
            (item, relative)
            for item, relative in safe_members
            if relative.suffix.lower() == ".xlsx"
        ]
        if len(nc_members) != 1:
            raise ValueError("The loss-input package must contain exactly one fixed-grid wind-field NetCDF file.")
        if len(track_members) != 1:
            raise ValueError("The loss-input package must contain exactly one track XLSX workbook.")

        def extract_one(item: zipfile.ZipInfo, destination: Path) -> None:
            written = 0
            destination.parent.mkdir(parents=True, exist_ok=True)
            with bundle.open(item, "r") as source, destination.open("wb") as target:
                while block := source.read(1024 * 1024):
                    written += len(block)
                    if written > MAX_LOSS_PACKAGE_BYTES:
                        raise ValueError("A loss-input package entry exceeds the permitted size.")
                    target.write(block)

        nc_path = input_root / "fixed_grid_max_wind.nc"
        track_path = input_root / "track.xlsx"
        extract_one(nc_members[0][0], nc_path)
        extract_one(track_members[0][0], track_path)
        return nc_path, track_path


def csv_columns(path: Path) -> set[str]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            return set(next(csv.reader(stream), []))
    except (UnicodeError, OSError):
        return set()


TRACK_ALIASES = {"latitude": "lat", "longitude": "lon"}
EXPOSURE_ALIASES = {"wind_ms": "wind_speed_ms"}


def canonical_columns(columns: set[str], aliases: dict[str, str]) -> set[str]:
    return {aliases.get(column.strip().lower(), column.strip().lower()) for column in columns}


def normalize_and_validate_csv(path: Path, kind: str, input_root: Path) -> tuple[Path, list[str]]:
    aliases = TRACK_ALIASES if kind == "track" else EXPOSURE_ALIASES
    required = (
        {"time", "lat", "lon"}
        if kind == "track"
        else {"grid_id", "province", "city", "wind_speed_ms", "exposure_value"}
    )
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        original_fields = list(reader.fieldnames or [])
        mapped_fields = [
            aliases.get(field.strip().lower(), field.strip().lower())
            for field in original_fields
        ]
        if len(mapped_fields) != len(set(mapped_fields)):
            raise ValueError(
                f"{path.name} contains duplicate columns after header normalization."
            )
        missing = sorted(required - set(mapped_fields))
        if missing:
            raise ValueError(
                f"{path.name} is missing required columns: {', '.join(missing)}"
            )
        rows = []
        for source in reader:
            rows.append(
                {
                    mapped: source.get(original, "")
                    for original, mapped in zip(original_fields, mapped_fields)
                }
            )

    if kind == "track":
        if len(rows) < 2:
            raise ValueError("The track file must contain at least two points.")
        for index, row in enumerate(rows, start=2):
            try:
                lat = float(row["lat"])
                lon = float(row["lon"])
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"Track row {index} has an invalid latitude or longitude."
                ) from exc
            if not math.isfinite(lat) or not -90 <= lat <= 90:
                raise ValueError(
                    f"Track row {index} has a latitude outside -90° to 90°."
                )
            if not math.isfinite(lon) or not -180 <= lon <= 360:
                raise ValueError(
                    f"Track row {index} has a longitude outside -180° to 360°."
                )
            if not str(row["time"]).strip():
                raise ValueError(f"Track row {index} has an empty timestamp.")
    else:
        if not rows:
            raise ValueError("The exposure file contains no data rows.")
        seen: set[str] = set()
        for index, row in enumerate(rows, start=2):
            grid_id = str(row["grid_id"]).strip()
            if not grid_id:
                raise ValueError(f"Exposure row {index} has an empty grid_id.")
            if grid_id in seen:
                raise ValueError(
                    f"The exposure file contains a duplicate grid_id: {grid_id}"
                )
            seen.add(grid_id)
            if not str(row["province"]).strip() or not str(row["city"]).strip():
                raise ValueError(
                    f"Exposure row {index} has an empty province or city."
                )
            try:
                wind = float(row["wind_speed_ms"])
                exposure = float(row["exposure_value"])
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"Exposure row {index} has an invalid wind speed or exposure value."
                ) from exc
            if not math.isfinite(wind) or not 0 <= wind <= 150:
                raise ValueError(
                    f"Exposure row {index} must have a wind speed between 0 and 150 m/s."
                )
            if not math.isfinite(exposure) or exposure < 0:
                raise ValueError(
                    f"Exposure row {index} must have a finite, non-negative exposure value."
                )

    changed = mapped_fields != original_fields
    warnings = []
    if changed:
        normalized_dir = input_root / "_normalized"
        normalized_dir.mkdir(parents=True, exist_ok=True)
        target = normalized_dir / f"{kind}.csv"
        with target.open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=mapped_fields)
            writer.writeheader()
            writer.writerows(rows)
        warnings.append(
            f"Column aliases in {path.name} were normalized to the algorithm's canonical fields."
        )
        return target, warnings
    return path, warnings


def find_inputs(input_root: Path) -> tuple[Path, Path, Path | None]:
    configs = sorted(
        [*input_root.rglob("*.yml"), *input_root.rglob("*.yaml")],
        key=lambda p: (len(p.parts), p.name.lower()),
    )
    config_path = configs[0] if configs else None

    if config_path:
        payload = yaml.safe_load(config_path.read_text(encoding="utf-8-sig")) or {}
        if not isinstance(payload, dict):
            raise ValueError("The configuration root must be a YAML mapping.")
        if str(payload.get("mode", "reviewer_demo")) != "reviewer_demo":
            raise ValueError(
                "A full research configuration was detected. Switch to the Large Dataset entry point; "
                "the multi-gigabyte FNL dataset remains in its local directory and is not uploaded through the browser."
            )
        inputs = payload.get("inputs") or {}
        track = (config_path.parent / str(inputs.get("track", ""))).resolve()
        exposure = (config_path.parent / str(inputs.get("exposure", ""))).resolve()
        root_resolved = input_root.resolve()
        if root_resolved not in track.parents or root_resolved not in exposure.parents:
            raise ValueError("The configuration references a path outside the uploaded folder.")
        if track.is_file() and exposure.is_file():
            return track, exposure, config_path

    track_required = {"time", "lat", "lon"}
    exposure_required = {
        "grid_id",
        "province",
        "city",
        "wind_speed_ms",
        "exposure_value",
    }
    tracks: list[Path] = []
    exposures: list[Path] = []
    for path in input_root.rglob("*.csv"):
        columns = csv_columns(path)
        if track_required.issubset(canonical_columns(columns, TRACK_ALIASES)):
            tracks.append(path)
        if exposure_required.issubset(canonical_columns(columns, EXPOSURE_ALIASES)):
            exposures.append(path)
    if len(tracks) != 1:
        raise ValueError(
            f"Exactly one track CSV is required (columns: time, lat, lon); {len(tracks)} were detected."
        )
    if len(exposures) != 1:
        raise ValueError(
            "Exactly one exposure CSV is required (columns: grid_id, province, city, "
            f"wind_speed_ms, exposure_value); {len(exposures)} were detected."
        )
    return tracks[0], exposures[0], config_path


def clean_label(value: str, fallback: str) -> str:
    label = str(value or "").strip()
    return label[:80] if label else fallback


def prepare_config(
    root: Path,
    case_id: str,
    typhoon_name: str,
    impact_threshold_ms: float,
) -> dict[str, Any]:
    input_root = root / "input"
    track, exposure, original_config = find_inputs(input_root)
    track, track_warnings = normalize_and_validate_csv(track, "track", input_root)
    exposure, exposure_warnings = normalize_and_validate_csv(exposure, "exposure", input_root)
    original: dict[str, Any] = {}
    if original_config:
        original = yaml.safe_load(original_config.read_text(encoding="utf-8-sig")) or {}
    original_case = original.get("case") or {}
    original_parameters = original.get("parameters") or {}
    resolved_case = clean_label(case_id, clean_label(original_case.get("id"), "uploaded-case"))
    resolved_name = clean_label(
        typhoon_name,
        clean_label(original_case.get("name"), resolved_case),
    )
    threshold = float(
        impact_threshold_ms
        if impact_threshold_ms is not None
        else original_parameters.get(
            "impact_threshold_ms",
            DEFAULT_LOSS_IMPACT_THRESHOLD_MS,
        )
    )
    if threshold < 0 or threshold > 100:
        raise ValueError("The impact threshold must be between 0 and 100 m/s.")
    generated = {
        "schema_version": 1,
        "mode": "reviewer_demo",
        "case": {"id": resolved_case, "name": resolved_name},
        "inputs": {
            "track": os.path.relpath(track, root).replace("\\", "/"),
            "exposure": os.path.relpath(exposure, root).replace("\\", "/"),
        },
        "parameters": {"impact_threshold_ms": threshold},
        "output": {"directory": "output"},
    }
    config_path = root / "run_config.yml"
    config_path.write_text(
        yaml.safe_dump(generated, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    return {
        "config_path": config_path,
        "track": track,
        "exposure": exposure,
        "case_id": resolved_case,
        "typhoon_name": resolved_name,
        "threshold": threshold,
        "warnings": [*track_warnings, *exposure_warnings],
    }


def aggregate_rows(rows: list[dict[str, str]], key: str) -> list[dict[str, Any]]:
    grouped: dict[str, dict[str, float]] = {}
    for row in rows:
        label = row.get(key) or "Unlabeled"
        bucket = grouped.setdefault(
            label,
            {"exposure_value": 0.0, "total_loss": 0.0, "max_wind_ms": 0.0},
        )
        bucket["exposure_value"] += float(row["exposure_value"])
        bucket["total_loss"] += float(row["total_loss"])
        wind_value = row.get("max_wind_ms", row.get("wind_speed_ms", 0.0))
        bucket["max_wind_ms"] = max(bucket["max_wind_ms"], float(wind_value or 0.0))
    return [
        {key: label, **values}
        for label, values in sorted(
            grouped.items(), key=lambda item: item[1]["total_loss"], reverse=True
        )
    ]


def build_result(root: Path) -> dict[str, Any]:
    output = root / "output"
    summary = read_json(output / "loss_summary.json")
    with (output / "grid_loss.csv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as stream:
        rows = list(csv.DictReader(stream))
    numeric_fields = {
        "max_wind_ms",
        "wind_speed_ms",
        "vulnerability_wind_speed_10min_ms",
        "loss_ratio",
        "exposure_value",
        "total_loss",
    }
    normalized_rows: list[dict[str, Any]] = []
    for row in rows:
        normalized_rows.append(
            {
                key: float(value) if key in numeric_fields else value
                for key, value in row.items()
            }
        )
    payload = {
        "summary": summary,
        "rows": normalized_rows,
        "by_province": aggregate_rows(rows, "province"),
        "by_city": aggregate_rows(rows, "city"),
    }
    atomic_json(root / "result.json", payload)
    return payload


def _finite_number(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return number if math.isfinite(number) else default


def build_full_result(
    job_id: str,
    root: Path,
    case: dict[str, Any],
    *,
    output_directory: str = "full_output",
    result_mode: str = "full",
    manifest_relative_path: str | Path = Path("vulnerability/result_manifest.json"),
) -> dict[str, Any]:
    """Normalize the compact full-mode manifest to the existing web contract."""

    output = root / output_directory
    canonical_path = output / Path(manifest_relative_path)
    if not canonical_path.is_file():
        raise FileNotFoundError(f"The full-result manifest has not been generated: {canonical_path.name}")
    manifest = read_json(canonical_path)
    province_results = list(manifest.get("province_results") or [])
    top_cities = list(manifest.get("top_cities") or [])
    totals = dict(manifest.get("totals") or {})
    grid_count = sum(int(_finite_number(row.get("grid_count"))) for row in province_results)
    impacted_grid_count = sum(
        int(_finite_number(row.get("grids_at_or_above_impact_threshold")))
        for row in province_results
    )
    max_wind = max(
        (_finite_number(row.get("max_wind_ms")) for row in province_results),
        default=0.0,
    )
    warnings: list[str] = []
    warnings.extend(
        str(item) for item in manifest.get("warnings") or [] if str(item).strip()
    )
    warnings.extend(interactive_map_warnings(root, result_mode))
    pipeline_path = output / "pipeline_result.json"
    if pipeline_path.is_file():
        pipeline = read_json(pipeline_path)
        pipeline_totals = (
            (pipeline.get("stages") or {}).get("vulnerability") or {}
        ).get("totals") or {}
        pipeline_loss = _finite_number(pipeline_totals.get("total_loss"), math.nan)
        canonical_loss = _finite_number(totals.get("total_loss"), math.nan)
        if (
            math.isfinite(pipeline_loss)
            and math.isfinite(canonical_loss)
            and not math.isclose(pipeline_loss, canonical_loss, rel_tol=1e-9, abs_tol=1e-6)
        ):
            warnings.append(
                "pipeline_result.json did not match the vulnerability result manifest; the "
                "vulnerability/result_manifest.json file was used instead."
            )
    warnings = list(dict.fromkeys(warnings))

    by_province = [
        {
            "province": row.get("province_name") or row.get("province") or "Unlabeled",
            "province_code": row.get("province"),
            "grid_count": int(_finite_number(row.get("grid_count"))),
            "exposure_value": _finite_number(row.get("exposure_value")),
            "total_loss": _finite_number(row.get("total_loss")),
            "max_wind_ms": _finite_number(row.get("max_wind_ms")),
            "grids_at_or_above_impact_threshold": int(
                _finite_number(row.get("grids_at_or_above_impact_threshold"))
            ),
        }
        for row in province_results
    ]
    by_province.sort(key=lambda row: row["total_loss"], reverse=True)
    by_city = [
        {
            "city": row.get("city_name_en") or row.get("city_name") or "Unassigned",
            "city_en": row.get("city_name_en"),
            "province": row.get("province_name") or row.get("province"),
            "grid_count": int(_finite_number(row.get("grid_count"))),
            "exposure_value": _finite_number(row.get("exposure_value")),
            "total_loss": _finite_number(row.get("total_loss")),
            "max_wind_ms": _finite_number(row.get("max_wind_ms")),
        }
        for row in top_cities
    ]
    by_city.sort(key=lambda row: row["total_loss"], reverse=True)
    summary = {
        "mode": result_mode,
        "case_id": str(manifest.get("case_id") or case["case_id"]),
        "typhoon_name": str(manifest.get("typhoon_name") or case["typhoon_name"]),
        "event_id": manifest.get("event_id"),
        "grid_count": grid_count,
        "grids_at_or_above_impact_threshold": impacted_grid_count,
        "impact_threshold_ms": _finite_number(
            manifest.get("impact_threshold_ms"),
            DEFAULT_LOSS_IMPACT_THRESHOLD_MS,
        ),
        "max_wind_ms": max_wind,
        "impact_detected": bool(manifest.get("impact_detected")),
        "affected_provinces": list(manifest.get("affected_provinces") or []),
        "screening": manifest.get("screening") or {},
        "landfall": manifest.get("landfall"),
        "track": None,
        "totals": totals,
    }
    artifacts = {
        key: f"/api/jobs/{job_id}/artifacts/{key}"
        for key, (relative, _media_type) in artifact_specifications(result_mode).items()
        if (root / relative).is_file()
    }
    payload = {
        "mode": result_mode,
        "summary": summary,
        # Full grid_loss can exceed 100 MB; aggregates and artifacts are enough
        # for the page and keep the JSON response small.
        "rows": [],
        "by_province": by_province,
        "by_city": by_city,
        "artifacts": artifacts,
        "interactive_map_url": artifacts.get("interactive-map"),
        "download_url": f"/api/jobs/{job_id}/download",
        "warnings": warnings,
    }
    atomic_json(root / "result.json", payload)
    return payload


def build_wind_result(job_id: str, root: Path, case: dict[str, Any]) -> dict[str, Any]:
    output = root / "wind_output"
    manifest_path = output / "wind_manifest.json"
    if not manifest_path.is_file():
        raise FileNotFoundError("The wind-field result manifest has not been generated.")
    manifest = read_json(manifest_path)
    metrics = dict(manifest.get("summary") or {})
    maximum_wind_ms = _finite_number(metrics.get("maximum_wind_ms"))
    summary = {
        "mode": "wind",
        "case_id": str(manifest.get("case_id") or case["case_id"]),
        "typhoon_name": str(manifest.get("typhoon_name") or case["typhoon_name"]),
        "grid_count": int(_finite_number(metrics.get("grid_count"))),
        "valid_grid_count": int(_finite_number(metrics.get("valid_grid_count"))),
        "latitude_count": int(_finite_number(metrics.get("latitude_count"))),
        "longitude_count": int(_finite_number(metrics.get("longitude_count"))),
        "minimum_wind_ms": _finite_number(metrics.get("minimum_wind_ms")),
        "mean_wind_ms": _finite_number(metrics.get("mean_wind_ms")),
        "maximum_wind_ms": maximum_wind_ms,
        "max_wind_ms": maximum_wind_ms,
        "loss_input_ready": bool(manifest.get("loss_input_ready")),
        "source": manifest.get("source"),
    }
    artifacts = {
        key: f"/api/jobs/{job_id}/artifacts/{key}"
        for key, (relative, _media_type) in artifact_specifications("wind").items()
        if (root / relative).is_file()
    }
    payload = {
        "mode": "wind",
        "summary": summary,
        "rows": [],
        "by_province": [],
        "by_city": [],
        "artifacts": artifacts,
        "download_url": f"/api/jobs/{job_id}/download",
        "loss_input_url": artifacts.get("loss-input-package"),
        "interactive_map_url": artifacts.get("interactive-map"),
        "warnings": list(
            dict.fromkeys(
                list(case.get("warnings") or [])
                + [str(item) for item in manifest.get("warnings") or [] if str(item).strip()]
                + interactive_map_warnings(root, "wind")
            )
        ),
    }
    atomic_json(root / "result.json", payload)
    return payload


def make_wind_loss_input_package(root: Path) -> Path | None:
    output = root / "wind_output"
    fixed_nc = output / "fixed_grid_max_wind.nc"
    track = output / "track.xlsx"
    manifest = output / "wind_manifest.json"
    if not fixed_nc.is_file() or not track.is_file() or not manifest.is_file():
        return None
    archive = root / "wind_input_for_loss.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as bundle:
        bundle.write(fixed_nc, "fixed_grid_max_wind.nc")
        bundle.write(track, "track.xlsx")
        bundle.write(manifest, "wind_manifest.json")
    return archive


def make_wind_result_zip(root: Path) -> Path:
    output = root / "wind_output"
    archive = root / "typhoon_wind_result.zip"
    selected = [
        output / "fixed_grid_max_wind.nc",
        output / "fixed_grid_max_wind.png",
        output / "hourly_summary.csv",
        output / "track.xlsx",
        output / "wind_manifest.json",
        output / "interactive_wind_map.json",
        output / "stage_manifest.json",
        root / "wind_input_for_loss.zip",
        root / "result.json",
        root / "calculation.log",
    ]
    selected.extend(sorted(output.glob("ID[0-9][0-9][0-9][0-9]_track_composite_weighted.png")))
    selected.extend([output / "track_composite_weighted.nc", output / "wind_circle_track_growth.gif"])
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as bundle:
        for path in selected:
            if path.is_file():
                arcname = path.name if path.parent == root else str(Path("wind_results") / path.name)
                bundle.write(path, arcname)
    return archive


def make_loss_result_zip(root: Path) -> Path:
    output = root / "loss_output"
    archive = root / "typhoon_loss_result.zip"
    selected = [
        output / "result_manifest.json",
        output / "stage_manifest.json",
        output / "maximum_wind_distribution.png",
        output / "loss_distribution.png",
        output / "typhoon_loss_assessment.pdf",
        output / "interactive_loss_map.json",
        output / "grid_wind.csv",
        output / "grid_loss.csv",
        output / "vulnerability_curve.csv",
        output / "vulnerability_curve.svg",
        root / "result.json",
        root / "calculation.log",
    ]
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as bundle:
        for path in selected:
            if path.is_file():
                arcname = path.name if path.parent == root else str(Path("loss_results") / path.name)
                bundle.write(path, arcname)
    return archive


def make_result_zip(root: Path) -> Path:
    archive = root / "typhoon_loss_result.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted((root / "output").rglob("*")):
            if path.is_file():
                bundle.write(path, Path("results") / path.relative_to(root / "output"))
        bundle.write(root / "run_config.yml", "run_config.yml")
        if (root / "result.json").is_file():
            bundle.write(root / "result.json", "result.json")
        if (root / "calculation.log").is_file():
            bundle.write(root / "calculation.log", "calculation.log")
    return archive


def make_full_result_zip(root: Path) -> Path:
    """Bundle reviewer-sized full outputs; leave large CSV/NetCDF as artifacts."""

    output = root / "full_output"
    archive = root / "typhoon_loss_result.zip"
    selected = [
        Path("pipeline_result.json"),
        Path("vulnerability/result_manifest.json"),
        Path("vulnerability/maximum_wind_distribution.png"),
        Path("vulnerability/loss_distribution.png"),
        Path("vulnerability/vulnerability_curve.csv"),
        Path("vulnerability/vulnerability_curve.svg"),
        Path("vulnerability/typhoon_loss_assessment.pdf"),
    ]
    selected.extend(
        path.relative_to(output)
        for path in sorted((output / "downscaling").glob("*_fixed_grid_max_wind.png"))
    )
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
        for relative in selected:
            path = output / relative
            if path.is_file():
                bundle.write(path, Path("results") / relative)
        if (root / "result.json").is_file():
            bundle.write(root / "result.json", "result.json")
        if (root / "calculation.log").is_file():
            bundle.write(root / "calculation.log", "calculation.log")
    return archive


def run_job(job_id: str, prepared: dict[str, Any]) -> None:
    root = JOBS_ROOT / job_id
    state_path = root / "job.json"
    state = read_json(state_path)
    state.update({"status": "running", "stage": "calculation", "started_at": utc_now()})
    atomic_json(state_path, state)
    output_buffer = io.StringIO()
    try:
        with redirect_stdout(output_buffer):
            run_from_config(prepared["config_path"])
        (root / "calculation.log").write_text(output_buffer.getvalue(), encoding="utf-8")
        result = build_result(root)
        make_result_zip(root)
        state.update(
            {
                "status": "complete",
                "stage": "complete",
                "completed_at": utc_now(),
                "totals": result["summary"].get("totals", {}),
            }
        )
    except Exception as exc:
        (root / "calculation.log").write_text(output_buffer.getvalue(), encoding="utf-8")
        state.update(
            {
                "status": "failed",
                "stage": "failed",
                "failed_at": utc_now(),
                "error": {"type": type(exc).__name__, "message": str(exc)},
            }
        )
    atomic_json(state_path, state)


def _log_tail(path: Path, line_count: int = 60) -> str:
    if not path.is_file():
        return ""
    return "\n".join(
        path.read_text(encoding="utf-8", errors="replace").splitlines()[-line_count:]
    )


def full_process_environment(job_id: str) -> dict[str, str]:
    job_temp = FULL_TEMP_ROOT / job_id
    job_temp.mkdir(parents=True, exist_ok=True)
    environment = dict(os.environ)
    python_paths = [
        str(FULL_ALGORITHM_ROOT / "src"),
        str(FULL_CLI.parent),
        str(FULL_STAGE_CLI.parent),
    ]
    if environment.get("PYTHONPATH"):
        python_paths.append(environment["PYTHONPATH"])
    environment.update(
        {
            "PYTHONPATH": os.pathsep.join(python_paths),
            "PYTHONNOUSERSITE": "1",
            "PYTHONUTF8": "1",
            "PYTHONIOENCODING": "utf-8",
            "MPLBACKEND": "Agg",
            "MPLCONFIGDIR": str(job_temp / "matplotlib"),
            "TEMP": str(job_temp),
            "TMP": str(job_temp),
            "TF_CPP_MIN_LOG_LEVEL": "2",
            "CUDA_VISIBLE_DEVICES": "-1",
            "TYPHOON_ALLOW_FONT_FALLBACK": "1",
            "TYPHOON_NETCDF_ENGINE": "h5netcdf",
        }
    )
    return environment


def run_stage_job(
    job_id: str,
    mode: str,
    case: dict[str, Any],
    command_arguments: list[str],
) -> None:
    """Run one independent scientific stage in the isolated Python 3.10 runtime."""

    root = JOBS_ROOT / job_id
    state_path = root / "job.json"
    state = read_json(state_path)
    state.update({"status": "running", "stage": "validation", "started_at": utc_now()})
    atomic_json(state_path, state)
    output_name = "wind_output" if mode == "wind" else "loss_output"
    output = root / output_name
    output.mkdir(parents=True, exist_ok=True)
    log_path = root / "calculation.log"
    command = [
        str(FULL_PYTHON),
        str(FULL_STAGE_CLI),
        *command_arguments,
        "--output",
        str(output),
    ]
    stage_command = command_arguments[0] if command_arguments else mode
    timeout_seconds = STAGE_TIMEOUT_SECONDS.get(stage_command, 30 * 60)
    try:
        with log_path.open("w", encoding="utf-8") as log:
            completed = subprocess.run(
                command,
                cwd=FULL_STAGE_CLI.parent,
                env=full_process_environment(job_id),
                stdout=log,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                check=False,
                shell=False,
                timeout=timeout_seconds,
            )
        stage_path = output / "stage_manifest.json"
        stage = read_json(stage_path) if stage_path.is_file() else {}
        if completed.returncode or stage.get("status") != "complete":
            stage_error = stage.get("error") or {}
            message = str(
                stage_error.get("message")
                or _log_tail(log_path)
                or "The standalone algorithm stage did not complete."
            )
            raise RuntimeError(message)

        if mode == "wind":
            make_wind_loss_input_package(root)
            result = build_wind_result(job_id, root, case)
            make_wind_result_zip(root)
            state["wind_summary"] = result["summary"]
        else:
            result = build_full_result(
                job_id,
                root,
                case,
                output_directory="loss_output",
                result_mode="loss",
                manifest_relative_path="result_manifest.json",
            )
            make_loss_result_zip(root)
            state["totals"] = result["summary"].get("totals", {})
        state.update(
            {
                "status": "complete",
                "stage": "complete",
                "completed_at": utc_now(),
            }
        )
    except subprocess.TimeoutExpired:
        message = f"The {stage_command} stage exceeded {timeout_seconds} seconds; waiting was stopped."
        with log_path.open("a", encoding="utf-8") as log:
            log.write(f"\n[TIMEOUT] {message}\n")
        state.update(
            {
                "status": "failed",
                "stage": "failed",
                "failed_at": utc_now(),
                "error": {
                    "type": "TimeoutExpired",
                    "message": message,
                    "timeout_seconds": timeout_seconds,
                },
            }
        )
    except Exception as exc:
        state.update(
            {
                "status": "failed",
                "stage": "failed",
                "failed_at": utc_now(),
                "error": {"type": type(exc).__name__, "message": str(exc)},
            }
        )
    atomic_json(state_path, state)


def run_full_job(
    job_id: str,
    case: dict[str, Any],
    impact_threshold_ms: float,
    force_downscaling: bool,
) -> None:
    """Run the official full pipeline in its isolated Python 3.10 process."""

    root = JOBS_ROOT / job_id
    state_path = root / "job.json"
    state = read_json(state_path)
    state.update(
        {
            "status": "running",
            "stage": "validation",
            "started_at": utc_now(),
        }
    )
    atomic_json(state_path, state)
    output_root = root / "full_output"
    log_path = root / "calculation.log"
    job_temp = FULL_TEMP_ROOT / job_id
    job_temp.mkdir(parents=True, exist_ok=True)
    output_root.mkdir(parents=True, exist_ok=True)
    command = [
        str(FULL_PYTHON),
        str(FULL_CLI),
        "--case",
        str(case["case_id"]),
        "--typhoon-name",
        str(case["typhoon_name"]),
        "--case-dir",
        str(case["case_dir"]),
        "--runtime-root",
        str(FULL_RUNTIME_ROOT),
        "--risk-root",
        str(FULL_EXPOSURE_ROOT),
        "--output-root",
        str(output_root),
        "--impact-threshold-ms",
        str(float(impact_threshold_ms)),
    ]
    if force_downscaling:
        command.append("--force-downscaling")
    environment = dict(os.environ)
    python_paths = [str(FULL_ALGORITHM_ROOT / "src"), str(FULL_CLI.parent)]
    if environment.get("PYTHONPATH"):
        python_paths.append(environment["PYTHONPATH"])
    environment.update(
        {
            "PYTHONPATH": os.pathsep.join(python_paths),
            "PYTHONNOUSERSITE": "1",
            "PYTHONUTF8": "1",
            "PYTHONIOENCODING": "utf-8",
            "MPLBACKEND": "Agg",
            "MPLCONFIGDIR": str(job_temp / "matplotlib"),
            "TEMP": str(job_temp),
            "TMP": str(job_temp),
            "TF_CPP_MIN_LOG_LEVEL": "2",
            "CUDA_VISIBLE_DEVICES": "-1",
            "TYPHOON_ALLOW_FONT_FALLBACK": "1",
            "TYPHOON_NETCDF_ENGINE": "h5netcdf",
        }
    )
    try:
        with log_path.open("w", encoding="utf-8") as log:
            completed = subprocess.run(
                command,
                cwd=FULL_CLI.parent,
                env=environment,
                stdout=log,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                check=False,
                shell=False,
            )
        if completed.returncode:
            raise RuntimeError(
            f"The full algorithm process exited with code {completed.returncode}.\n{_log_tail(log_path)}"
            )
        pipeline_path = output_root / "pipeline_result.json"
        if not pipeline_path.is_file():
            raise FileNotFoundError("The full algorithm did not generate pipeline_result.json.")
        pipeline = read_json(pipeline_path)
        if pipeline.get("status") != "complete":
            algorithm_error = pipeline.get("error") or {}
            raise RuntimeError(
                str(algorithm_error.get("message") or "The full algorithm did not complete.")
            )
        result = build_full_result(job_id, root, case)
        make_full_result_zip(root)
        state.update(
            {
                "status": "complete",
                "stage": "complete",
                "completed_at": utc_now(),
                "totals": result["summary"].get("totals", {}),
            }
        )
    except Exception as exc:
        state.update(
            {
                "status": "failed",
                "stage": "failed",
                "failed_at": utc_now(),
                "error": {"type": type(exc).__name__, "message": str(exc)},
            }
        )
    atomic_json(state_path, state)


@app.get("/api/health")
def health() -> dict[str, Any]:
    full = cached_full_runtime_status()
    wind_local = cached_stage_runtime_status("wind-local")
    wind_upload = cached_stage_runtime_status("wind-upload")
    loss = cached_stage_runtime_status("loss")
    return {
        "status": "ok",
        "service": app.title,
        "version": app.version,
        "engine": "TyphoonRiskChina 1.1.0 wind + loss stages",
        "engines": {
            "reviewer_demo": {
                "ready": True,
                "engine": "TyphoonRiskChina 1.0.0 reviewer_demo",
            },
            "full": full,
            "wind": {
                "ready": bool(wind_local["ready"]),
                "primary_input": "fnl-folder-plus-track-workbook",
                "local": wind_local,
                "upload": wind_upload,
            },
            "loss": loss,
        },
    }


@app.get("/api/capabilities")
def capabilities() -> dict[str, Any]:
    full = cached_full_runtime_status()
    wind_local = cached_stage_runtime_status("wind-local")
    wind_upload = cached_stage_runtime_status("wind-upload")
    loss = cached_stage_runtime_status("loss")
    return {
        "reviewer_demo": {
            "ready": True,
            "input": "browser-folder-upload",
            "max_upload_bytes": MAX_UPLOAD_BYTES,
        },
        "full": {
            **full,
            "input": "server-side-local-case",
            "browser_upload": False,
        },
        "wind": {
            "ready": bool(wind_local["ready"]),
            "local": {
                **wind_local,
                "input": "fnl-folder-plus-track-workbook",
                "validation_endpoint": "/api/wind/inputs/validate",
                "job_endpoint": "/api/wind/jobs/inputs",
                "netcdf_browser_copy": False,
                "max_track_upload_bytes": MAX_TRACK_UPLOAD_BYTES,
            },
            "upload": wind_upload,
            "inputs": ["fnl-folder-plus-track-workbook"],
        },
        "loss": {
            **loss,
            "inputs": ["completed-wind-job", "fixed-grid-netcdf", "wind-result-package"],
            "max_upload_bytes": MAX_LOSS_UPLOAD_BYTES,
        },
    }


@app.get("/api/full/cases")
def list_full_cases() -> dict[str, Any]:
    return {
        "runtime": cached_full_runtime_status(),
        "cases": [public_full_case(case) for case in scan_full_cases()],
    }


@app.post("/api/wind/bundles/validate")
def validate_wind_bundle(
    request: LocalBundleValidationRequest,
) -> dict[str, Any]:
    return validate_local_bundle_manifest(request)


@app.post("/api/wind/inputs/validate")
async def validate_wind_inputs(
    root_name: str = Form(...),
    fnl_manifest: str = Form(...),
    track_file: UploadFile = File(...),
) -> dict[str, Any]:
    """Verify exactly one FNL folder and its track workbook without copying NetCDF data."""

    if Path(track_file.filename or "").suffix.casefold() != ".xlsx":
        await track_file.close()
        raise HTTPException(status_code=400, detail="Select one track workbook in .xlsx format.")

    temporary_root = FULL_TEMP_ROOT / "validated-wind-inputs" / uuid.uuid4().hex
    track_path = temporary_root / "track.xlsx"
    record: dict[str, Any] = {"temp_root": temporary_root}
    try:
        track_bytes = await save_upload_limited(
            track_file,
            track_path,
            MAX_TRACK_UPLOAD_BYTES,
        )
        if track_bytes < 1:
            raise HTTPException(status_code=400, detail="The track workbook is empty.")
        workbook = inspect_track_workbook(track_path)
        case, fnl_signature, fnl_bytes = validate_fnl_folder_manifest(
            root_name,
            fnl_manifest,
            workbook.get("workbook_case_id"),
        )

        internal_warnings = list(case.get("warnings") or [])
        workbook_case_id = workbook.get("workbook_case_id")
        if workbook_case_id and workbook_case_id != case["case_id"]:
            internal_warnings.append(
                "The workbook's internal ID differs from the matched FNL source; "
                "the approved FNL configuration is authoritative for calculation identity."
            )
        record.update(
            {
                "case_key": case["case_key"],
                "case_id": case["case_id"],
                "typhoon_name": case["typhoon_name"],
                "workbook_case_id": workbook.get("workbook_case_id"),
                "track_path": track_path,
                "track_sha256": sha256_file(track_path),
                "track_bytes": track_bytes,
                "fnl_signature": fnl_signature,
                "fnl_bytes": fnl_bytes,
                "fnl_dir": Path(case["fnl_dir"]).resolve(strict=True),
                "internal_warnings": internal_warnings,
            }
        )
        token = issue_wind_input_token(record)
        return {
            "status": "ready",
            "mode": "fnl-folder-plus-track-workbook",
            "input_token": token,
            "token_expires_in_seconds": WIND_INPUT_TOKEN_TTL_SECONDS,
            "identity": {
                "case_id": case["case_id"],
                "typhoon_name": case["typhoon_name"],
            },
            "case_id": case["case_id"],
            "typhoon_name": case["typhoon_name"],
            "fnl": {
                "root_name": Path(case["fnl_dir"]).name,
                "file_count": len(EXPECTED_FNL_NAMES),
                "total_bytes": fnl_bytes,
            },
            "track": {
                "name": "track.xlsx",
                "size": track_bytes,
            },
            "verified_in_place": True,
            "copy_required": False,
        }
    except HTTPException:
        cleanup_wind_input_record(record)
        raise
    except ValueError as exc:
        cleanup_wind_input_record(record)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        cleanup_wind_input_record(record)
        raise HTTPException(
            status_code=400,
            detail="The two wind-field inputs could not be verified.",
        ) from exc


@app.post("/api/full/jobs", status_code=202)
def create_full_job(request: FullJobRequest) -> dict[str, Any]:
    runtime = full_runtime_status(check_python_packages=True)
    if not runtime["ready"]:
        raise HTTPException(
            status_code=503,
            detail="The full algorithm runtime is not ready: " + "; ".join(runtime["issues"]),
        )
    case = get_full_case(request.case_key)
    if not case["ready"]:
        raise HTTPException(
            status_code=400,
            detail="Full-case validation failed: " + "; ".join(case["issues"]),
        )
    job_id = uuid.uuid4().hex
    root = JOBS_ROOT / job_id
    root.mkdir(parents=True, exist_ok=False)
    state = {
        "job_id": job_id,
        "mode": "full",
        "status": "queued",
        "stage": "queued",
        "created_at": utc_now(),
        "source": "server-side-local-case",
        "case_key": case["case_key"],
        "case_id": case["case_id"],
        "typhoon_name": case["typhoon_name"],
        "impact_threshold_ms": float(request.impact_threshold_ms),
        "file_count": case["fnl_count"] + 1,
        "bytes": case["fnl_bytes"] + case["track_path"].stat().st_size,
        "detected": {
            "track": "Track workbook",
            "fnl": f"{case['fnl_count']}/28 (006.nc–168.nc)",
        },
        "warnings": list(case.get("warnings") or []),
    }
    atomic_json(root / "job.json", state)
    FULL_EXECUTOR.submit(
        run_full_job,
        job_id,
        case,
        float(request.impact_threshold_ms),
        bool(request.force_downscaling),
    )
    return state


@app.post("/api/wind/jobs/local", status_code=202)
def create_local_wind_job(request: WindLocalJobRequest) -> dict[str, Any]:
    if request.bundle_token:
        require_bundle_token(request.bundle_token, request.case_key)
    runtime = stage_runtime_status("wind-local", check_python_packages=True)
    if not runtime["ready"]:
        raise HTTPException(
            status_code=503,
            detail="The wind-field runtime is not ready: " + "; ".join(runtime["issues"]),
        )
    case = get_full_case(request.case_key)
    if not case["ready"]:
        raise HTTPException(
            status_code=400,
            detail="The selected wind case did not pass validation: " + "; ".join(case["issues"]),
        )
    job_id = uuid.uuid4().hex
    root = JOBS_ROOT / job_id
    root.mkdir(parents=True, exist_ok=False)
    state = {
        "job_id": job_id,
        "mode": "wind",
        "status": "queued",
        "stage": "queued",
        "created_at": utc_now(),
        "source": (
            "local-large-dataset"
            if request.bundle_token
            else "server-side-local-case"
        ),
        "case_key": case["case_key"],
        "case_id": case["case_id"],
        "typhoon_name": case["typhoon_name"],
        "file_count": case["fnl_count"] + 1,
        "bytes": case["fnl_bytes"] + case["track_path"].stat().st_size,
        "warnings": list(case.get("warnings") or []),
    }
    atomic_json(root / "job.json", state)
    command_arguments = [
        "wind-local",
        "--case",
        str(case["case_id"]),
        "--typhoon-name",
        str(case["typhoon_name"]),
        "--case-dir",
        str(case["case_dir"]),
        "--runtime-root",
        str(FULL_RUNTIME_ROOT),
        "--track",
        str(case["track_path"]),
    ]
    FULL_EXECUTOR.submit(run_stage_job, job_id, "wind", case, command_arguments)
    return state


@app.post("/api/wind/jobs/inputs", status_code=202)
def create_wind_inputs_job(request: WindInputsJobRequest) -> dict[str, Any]:
    """Create one wind job from an already verified, one-use FNL-and-track token."""

    runtime = stage_runtime_status("wind-local", check_python_packages=True)
    if not runtime["ready"]:
        raise HTTPException(
            status_code=503,
            detail="The wind-field runtime is not ready: " + "; ".join(runtime["issues"]),
        )

    record = consume_wind_input_token(request.input_token)
    root: Path | None = None
    try:
        case = verified_case_from_wind_input_record(record)
        job_id = uuid.uuid4().hex
        root = JOBS_ROOT / job_id
        input_root = root / "input"
        input_root.mkdir(parents=True, exist_ok=False)
        track_input = input_root / "track.xlsx"
        shutil.move(str(record["track_path"]), track_input)

        job_case = dict(case)
        job_case["track_path"] = track_input
        job_case["warnings"] = list(record.get("internal_warnings") or [])
        state = {
            "job_id": job_id,
            "mode": "wind",
            "status": "queued",
            "stage": "queued",
            "created_at": utc_now(),
            "source": "fnl-folder-plus-track-workbook",
            "case_key": case["case_key"],
            "case_id": case["case_id"],
            "typhoon_name": case["typhoon_name"],
            "file_count": len(EXPECTED_FNL_NAMES) + 1,
            "bytes": int(record["fnl_bytes"]) + int(record["track_bytes"]),
            "warnings": list(record.get("internal_warnings") or []),
        }
        atomic_json(root / "job.json", state)
        command_arguments = [
            "wind-inputs",
            "--case",
            str(case["case_id"]),
            "--typhoon-name",
            str(case["typhoon_name"]),
            "--fnl-dir",
            str(case["fnl_dir"]),
            "--runtime-root",
            str(FULL_RUNTIME_ROOT),
            "--track",
            str(track_input),
        ]
        FULL_EXECUTOR.submit(run_stage_job, job_id, "wind", job_case, command_arguments)
        return state
    except HTTPException:
        if root is not None:
            shutil.rmtree(root, ignore_errors=True)
        raise
    except Exception as exc:
        if root is not None:
            shutil.rmtree(root, ignore_errors=True)
        raise HTTPException(status_code=400, detail="The verified wind-field job could not be created.") from exc
    finally:
        cleanup_wind_input_record(record)


@app.post("/api/wind/jobs/upload", status_code=202)
async def create_uploaded_wind_job(
    wind_file: UploadFile = File(...),
    case_key: str = Form(...),
    case_id: str = Form(""),
    typhoon_name: str = Form(""),
) -> dict[str, Any]:
    runtime = stage_runtime_status("wind-upload", check_python_packages=True)
    if not runtime["ready"]:
        raise HTTPException(status_code=503, detail="The full algorithm runtime is not ready: " + "; ".join(runtime["issues"]))
    case = resolve_uploaded_case(case_key, case_id, typhoon_name)
    suffix = Path(wind_file.filename or "").suffix.lower()
    if suffix not in {".nc", ".nc4"}:
        await wind_file.close()
        raise HTTPException(
            status_code=400,
            detail="The wind-field module accepts a NetCDF4/HDF5 file (.nc or .nc4), not a .cdf file, folder, or individual FNL lead-time file.",
        )
    job_id = uuid.uuid4().hex
    root = JOBS_ROOT / job_id
    input_root = root / "input"
    input_root.mkdir(parents=True, exist_ok=False)
    prediction = input_root / "prediction.nc"
    try:
        total_bytes = await save_upload_limited(wind_file, prediction, MAX_WIND_UPLOAD_BYTES)
        state = {
            "job_id": job_id,
            "mode": "wind",
            "status": "queued",
            "stage": "queued",
            "created_at": utc_now(),
            "source": "uploaded-prediction-netcdf",
            "case_key": case["case_key"],
            "case_id": case["case_id"],
            "typhoon_name": case["typhoon_name"],
            "file_count": 1,
            "bytes": total_bytes,
            "warnings": list(case.get("warnings") or []),
        }
        atomic_json(root / "job.json", state)
        command_arguments = [
            "wind-nc",
            "--case",
            str(case["case_id"]),
            "--typhoon-name",
            str(case["typhoon_name"]),
            "--input-nc",
            str(prediction),
            "--track",
            str(case["track_path"]),
        ]
        FULL_EXECUTOR.submit(run_stage_job, job_id, "wind", case, command_arguments)
        return state
    except HTTPException:
        shutil.rmtree(root, ignore_errors=True)
        raise
    except Exception as exc:
        shutil.rmtree(root, ignore_errors=True)
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/loss/jobs/from-wind", status_code=202)
def create_loss_from_wind_job(request: LossFromWindRequest) -> dict[str, Any]:
    runtime = stage_runtime_status("loss", check_python_packages=True)
    if not runtime["ready"]:
        raise HTTPException(status_code=503, detail="The full algorithm runtime is not ready: " + "; ".join(runtime["issues"]))
    source_root = job_root(request.wind_job_id)
    source_state_path = source_root / "job.json"
    if not source_state_path.is_file():
        raise HTTPException(status_code=404, detail="The wind-field job does not exist.")
    source_state = read_json(source_state_path)
    if source_state.get("mode") != "wind":
        raise HTTPException(status_code=400, detail="The selected job is not a wind-field job.")
    if source_state.get("status") != "complete":
        raise HTTPException(status_code=409, detail="The wind-field job has not completed.")
    source_nc = source_root / "wind_output" / "fixed_grid_max_wind.nc"
    source_track = source_root / "wind_output" / "track.xlsx"
    if not source_nc.is_file() or not source_track.is_file():
        raise HTTPException(status_code=409, detail="The wind-field job is missing its fixed-grid NetCDF or associated track workbook.")

    job_id = uuid.uuid4().hex
    root = JOBS_ROOT / job_id
    input_root = root / "input"
    try:
        input_root.mkdir(parents=True, exist_ok=False)
        wind_input = input_root / "fixed_grid_max_wind.nc"
        track_input = input_root / "track.xlsx"
        shutil.copy2(source_nc, wind_input)
        shutil.copy2(source_track, track_input)
        case = {
            "case_key": source_state.get("case_key"),
            "case_id": source_state.get("case_id"),
            "typhoon_name": source_state.get("typhoon_name"),
        }
        state = {
            "job_id": job_id,
            "mode": "loss",
            "status": "queued",
            "stage": "queued",
            "created_at": utc_now(),
            "source": "wind-job",
            "source_wind_job_id": request.wind_job_id,
            "case_key": case["case_key"],
            "case_id": case["case_id"],
            "typhoon_name": case["typhoon_name"],
            "impact_threshold_ms": float(request.impact_threshold_ms),
            "file_count": 2,
            "bytes": wind_input.stat().st_size + track_input.stat().st_size,
            "warnings": list(source_state.get("warnings") or []),
        }
        atomic_json(root / "job.json", state)
        command_arguments = [
            "loss",
            "--case",
            str(case["case_id"]),
            "--typhoon-name",
            str(case["typhoon_name"]),
            "--input-nc",
            str(wind_input),
            "--track-xlsx",
            str(track_input),
            "--risk-root",
            str(FULL_EXPOSURE_ROOT),
            "--bundle-root",
            str(FULL_CLI.parent.parent),
            "--impact-threshold",
            str(float(request.impact_threshold_ms)),
        ]
        FULL_EXECUTOR.submit(run_stage_job, job_id, "loss", case, command_arguments)
        return state
    except Exception:
        shutil.rmtree(root, ignore_errors=True)
        raise


@app.post("/api/loss/jobs/upload", status_code=202)
async def create_uploaded_loss_job(
    input_file: UploadFile = File(...),
    case_key: str = Form(...),
    case_id: str = Form(""),
    typhoon_name: str = Form(""),
    impact_threshold_ms: float = Form(DEFAULT_LOSS_IMPACT_THRESHOLD_MS),
) -> dict[str, Any]:
    if not 0 <= float(impact_threshold_ms) <= 100:
        await input_file.close()
        raise HTTPException(status_code=400, detail="The impact threshold must be between 0 and 100 m/s.")
    runtime = stage_runtime_status("loss", check_python_packages=True)
    if not runtime["ready"]:
        await input_file.close()
        raise HTTPException(status_code=503, detail="The full algorithm runtime is not ready: " + "; ".join(runtime["issues"]))
    case = resolve_uploaded_case(case_key, case_id, typhoon_name)
    suffix = Path(input_file.filename or "").suffix.lower()
    if suffix not in {".zip", ".nc", ".nc4"}:
        await input_file.close()
        raise HTTPException(
            status_code=400,
            detail="The loss module accepts one wind-result ZIP package or fixed-grid NetCDF4/HDF5 file (.nc or .nc4), not a .cdf file.",
        )
    job_id = uuid.uuid4().hex
    root = JOBS_ROOT / job_id
    input_root = root / "input"
    input_root.mkdir(parents=True, exist_ok=False)
    uploaded = input_root / ("input.zip" if suffix == ".zip" else "fixed_grid_max_wind.nc")
    try:
        total_bytes = await save_upload_limited(input_file, uploaded, MAX_LOSS_UPLOAD_BYTES)
        if suffix == ".zip":
            wind_input, track_input = extract_loss_input_package(uploaded, input_root)
            if sha256_file(track_input) != sha256_file(case["track_path"]):
                raise ValueError("The track in the input package does not match the selected local case.")
        else:
            wind_input = uploaded
            track_input = input_root / "track.xlsx"
            shutil.copy2(case["track_path"], track_input)
        state = {
            "job_id": job_id,
            "mode": "loss",
            "status": "queued",
            "stage": "queued",
            "created_at": utc_now(),
            "source": "uploaded-loss-input",
            "case_key": case["case_key"],
            "case_id": case["case_id"],
            "typhoon_name": case["typhoon_name"],
            "impact_threshold_ms": float(impact_threshold_ms),
            "file_count": 1,
            "bytes": total_bytes,
            "warnings": list(case.get("warnings") or []),
        }
        atomic_json(root / "job.json", state)
        command_arguments = [
            "loss",
            "--case",
            str(case["case_id"]),
            "--typhoon-name",
            str(case["typhoon_name"]),
            "--input-nc",
            str(wind_input),
            "--track-xlsx",
            str(track_input),
            "--risk-root",
            str(FULL_EXPOSURE_ROOT),
            "--bundle-root",
            str(FULL_CLI.parent.parent),
            "--impact-threshold",
            str(float(impact_threshold_ms)),
        ]
        FULL_EXECUTOR.submit(run_stage_job, job_id, "loss", case, command_arguments)
        return state
    except HTTPException:
        shutil.rmtree(root, ignore_errors=True)
        raise
    except Exception as exc:
        shutil.rmtree(root, ignore_errors=True)
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/jobs", status_code=202)
async def create_job(
    files: list[UploadFile] = File(...),
    paths: list[str] = Form(...),
    case_id: str = Form(""),
    typhoon_name: str = Form(""),
    impact_threshold_ms: float = Form(DEFAULT_LOSS_IMPACT_THRESHOLD_MS),
) -> dict[str, Any]:
    if len(files) != len(paths):
        raise HTTPException(status_code=400, detail="The number of files does not match the number of relative paths.")
    if not files or len(files) > MAX_FILES:
        raise HTTPException(status_code=400, detail=f"The file count must be between 1 and {MAX_FILES}.")
    job_id = uuid.uuid4().hex
    root = JOBS_ROOT / job_id
    input_root = root / "input"
    input_root.mkdir(parents=True, exist_ok=False)
    total_bytes = 0
    try:
        for upload, relative in zip(files, paths):
            destination = input_root / safe_relative_path(relative)
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open("wb") as stream:
                while block := await upload.read(1024 * 1024):
                    total_bytes += len(block)
                    if total_bytes > MAX_UPLOAD_BYTES:
                        raise ValueError("The uploaded folder exceeds the 2 GB limit.")
                    stream.write(block)
            await upload.close()
        prepared = prepare_config(
            root,
            case_id=case_id,
            typhoon_name=typhoon_name,
            impact_threshold_ms=impact_threshold_ms,
        )
        state = {
            "job_id": job_id,
            "mode": "reviewer_demo",
            "status": "queued",
            "stage": "queued",
            "created_at": utc_now(),
            "file_count": len(files),
            "bytes": total_bytes,
            "case_id": prepared["case_id"],
            "typhoon_name": prepared["typhoon_name"],
            "impact_threshold_ms": prepared["threshold"],
            "detected": {
                "track": str(prepared["track"].relative_to(input_root)).replace("\\", "/"),
                "exposure": str(prepared["exposure"].relative_to(input_root)).replace("\\", "/"),
            },
            "warnings": prepared["warnings"],
        }
        atomic_json(root / "job.json", state)
        EXECUTOR.submit(run_job, job_id, prepared)
        return state
    except Exception as exc:
        shutil.rmtree(root, ignore_errors=True)
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str) -> dict[str, Any]:
    root = job_root(job_id)
    state_path = root / "job.json"
    if not state_path.is_file():
        raise HTTPException(status_code=404, detail="The job does not exist.")
    state = read_json(state_path)
    mode = str(state.get("mode") or "reviewer_demo")
    manifest = {
        "full": root / "full_output" / "pipeline_result.json",
        "wind": root / "wind_output" / "stage_manifest.json",
        "loss": root / "loss_output" / "stage_manifest.json",
    }.get(mode, root / "output" / "run_manifest.json")
    if manifest.is_file() and state.get("status") == "running":
        # The calculation process updates this manifest while the browser polls.
        # It can be briefly incomplete during an in-place write; keep serving
        # the last stable job state so one transient read does not return HTTP 500.
        try:
            algorithm_state = read_json(manifest)
        except (OSError, ValueError, TypeError):
            algorithm_state = {}
        if isinstance(algorithm_state, dict) and algorithm_state:
            state["algorithm"] = {
                "status": algorithm_state.get("status"),
                "stages": list((algorithm_state.get("stages") or {}).keys()),
            }
            if mode in {"full", "wind", "loss"}:
                state["algorithm"]["current_stage"] = algorithm_state.get("current_stage")
    return state


@app.get("/api/jobs/{job_id}/result")
def get_result(job_id: str) -> dict[str, Any]:
    root = job_root(job_id)
    state_path = root / "job.json"
    if not state_path.is_file():
        raise HTTPException(status_code=404, detail="The job does not exist.")
    state = read_json(state_path)
    if state.get("status") != "complete" or not (root / "result.json").is_file():
        raise HTTPException(status_code=409, detail="The result has not been generated.")
    return read_json(root / "result.json")


@app.get("/api/jobs/{job_id}/download")
def download_result(job_id: str):
    root = job_root(job_id)
    state_path = root / "job.json"
    if not state_path.is_file():
        raise HTTPException(status_code=404, detail="The job does not exist.")
    state = read_json(state_path)
    if state.get("status") != "complete":
        raise HTTPException(status_code=409, detail="The result has not been generated.")
    mode = str(state.get("mode") or "reviewer_demo")
    archive = root / ("typhoon_wind_result.zip" if mode == "wind" else "typhoon_loss_result.zip")
    if not archive.is_file():
        raise HTTPException(status_code=404, detail="The result archive has not been generated.")
    prefix = "typhoon-wind" if mode == "wind" else "typhoon-loss"
    return FileResponse(
        archive,
        filename=f"{prefix}-{job_id[:8]}.zip",
        media_type="application/zip",
    )


@app.get("/api/jobs/{job_id}/artifacts/{artifact_key}")
def download_full_artifact(job_id: str, artifact_key: str):
    root = job_root(job_id)
    state_path = root / "job.json"
    if not state_path.is_file():
        raise HTTPException(status_code=404, detail="The job does not exist.")
    state = read_json(state_path)
    if state.get("status") != "complete":
        raise HTTPException(status_code=409, detail="The result file has not been generated.")
    specification = artifact_specifications(str(state.get("mode") or "")).get(artifact_key)
    if specification is None:
        raise HTTPException(status_code=404, detail="The requested result-file type does not exist.")
    relative, media_type = specification
    output = root.resolve()
    candidate = (root / relative).resolve()
    try:
        candidate.relative_to(output)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail="The result-file path is invalid.") from exc
    if not candidate.is_file():
        raise HTTPException(status_code=404, detail="The result file has not been generated.")
    return FileResponse(candidate, filename=candidate.name, media_type=media_type)


@app.get("/api/example/download")
def download_example():
    archive = DATA_ROOT / "TyphoonRiskChina-example-folder.zip"
    if not archive.is_file():
        archive.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
            for path in EXAMPLE_ROOT.rglob("*"):
                if path.is_file():
                    bundle.write(path, Path("typhoon_example") / path.relative_to(EXAMPLE_ROOT))
    return FileResponse(
        archive,
        filename="TyphoonRiskChina-example-folder.zip",
        media_type="application/zip",
    )


@app.get("/")
def index():
    return FileResponse(WEB_ROOT / "index.html")


app.mount("/static", StaticFiles(directory=WEB_ROOT), name="static")


@app.get("/{resource_path:path}", include_in_schema=False)
def web_resource(resource_path: str):
    """Serve compiled frontend assets and fall back to its SPA entry page."""
    if resource_path.startswith("api/"):
        raise HTTPException(status_code=404, detail="The API endpoint does not exist.")

    web_root = WEB_ROOT.resolve()
    candidate = (web_root / resource_path).resolve()
    try:
        candidate.relative_to(web_root)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail="The requested web resource does not exist.") from exc

    if candidate.is_file():
        return FileResponse(candidate)
    return FileResponse(web_root / "index.html")
