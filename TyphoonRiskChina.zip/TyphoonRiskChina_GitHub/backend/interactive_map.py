"""Build compact, browser-friendly payloads for interactive typhoon maps.

The calculation pipeline writes scientific NetCDF and detailed CSV files that
are intentionally much larger than a browser should load.  This module keeps
the scientific aggregation semantics while reducing those files to at most a
roughly 220 by 220 display grid:

* wind is block-reduced with a maximum, so a local wind maximum is not lost;
* loss and exposure are summed into regular geographic bins;
* the maximum wind in every loss bin is retained;
* source counts are included so empty display cells are distinguishable from
  real zero values.

No source path or NetCDF global attribute is copied into the returned payload.
Some upstream attributes contain absolute local paths, which must never leak to
the web client.
"""

from __future__ import annotations

from datetime import date, datetime
import json
import math
import os
from pathlib import Path
import re
import tempfile
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
import xarray as xr


SCHEMA_VERSION = "1.1"
DEFAULT_MAX_DIMENSION = 220
MIN_MAX_DIMENSION = 1
MAX_MAX_DIMENSION = 512

WIND_COLOR_SCALE = {
    "type": "linear",
    "palette": "typhoon-wind",
    "unit": "m/s",
    "null_color": "transparent",
    "stops": [
        [0.0, "#313695"],
        [0.2, "#4575b4"],
        [0.4, "#74add1"],
        [0.6, "#66bd63"],
        [0.75, "#fee08b"],
        [0.9, "#f46d43"],
        [1.0, "#a50026"],
    ],
}

LOSS_COLOR_SCALE = {
    "type": "logarithmic",
    "transform": "log10",
    "palette": "typhoon-loss",
    "unit": "CNY",
    "zero_color": "transparent",
    "null_color": "transparent",
    "stops": [
        [0.0, "#d8f3dc"],
        [0.2, "#52b69a"],
        [0.42, "#b7e4a8"],
        [0.62, "#ffe066"],
        [0.82, "#f4a261"],
        [1.0, "#d1495b"],
    ],
}

EXPOSURE_COLOR_SCALE = {
    "type": "logarithmic",
    "transform": "log10",
    "palette": "viridis",
    "unit": "CNY",
    "zero_color": "transparent",
    "null_color": "transparent",
}


def _resolve_boundary_directory(boundary_dir: str | Path | None) -> Path | None:
    """Find the server-owned coastal administrative boundary directory."""

    candidates: list[Path] = []
    if boundary_dir is not None:
        candidates.append(Path(boundary_dir))
    configured_root = os.environ.get("TYPHOON_FULL_ALGORITHM_ROOT")
    if configured_root:
        candidates.append(
            Path(configured_root) / "assets" / "vulnerability" / "boundaries"
        )
    candidates.append(
        Path(__file__).resolve().parent.parent
        / "algorithm_full"
        / "assets"
        / "vulnerability"
        / "boundaries"
    )
    for candidate in candidates:
        if (
            (candidate / "coastal_provinces.geojson").is_file()
            and (candidate / "coastal_prefecture_cities.geojson").is_file()
        ):
            return candidate
    return None


def _administrative_grid(
    latitude: Sequence[float],
    longitude: Sequence[float],
    *,
    boundary_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Assign English province/city names to regular-grid cell centres.

    The returned arrays use the same flat row-major encoding as scientific
    layers.  Boundaries remain server-owned, and only short English names are
    serialized into result payloads.
    """

    lat = np.asarray(latitude, dtype=np.float64)
    lon = np.asarray(longitude, dtype=np.float64)
    lon_grid, lat_grid = np.meshgrid(lon, lat)
    point_count = int(lat_grid.size)
    province = np.full(point_count, None, dtype=object)
    city = np.full(point_count, None, dtype=object)
    directory = _resolve_boundary_directory(boundary_dir)
    if directory is None:
        return {
            "encoding": "flat-row-major",
            "province": {"label": "Province", "values": province.tolist()},
            "city": {"label": "City", "values": city.tolist()},
        }

    # Shapely performs vectorized point-in-polygon tests, keeping a 220 x 220
    # display grid inexpensive even with all coastal prefecture geometries.
    from shapely import intersects_xy
    from shapely.geometry import shape

    def features(name: str) -> list[dict[str, Any]]:
        with (directory / name).open("r", encoding="utf-8") as stream:
            document = json.load(stream)
        return list(document.get("features") or [])

    x = lon_grid.ravel(order="C")
    y = lat_grid.ravel(order="C")
    for feature in features("coastal_provinces.geojson"):
        properties = feature.get("properties") or {}
        name = _track_text(properties.get("province_name"))
        geometry = feature.get("geometry")
        if name and geometry:
            province[intersects_xy(shape(geometry), x, y)] = name

    for feature in features("coastal_prefecture_cities.geojson"):
        properties = feature.get("properties") or {}
        city_name = _track_text(properties.get("city_name_en"))
        province_name = _track_text(properties.get("province_name"))
        geometry = feature.get("geometry")
        if not city_name or not geometry:
            continue
        mask = intersects_xy(shape(geometry), x, y)
        city[mask] = city_name
        if province_name:
            province[mask] = province_name

    return {
        "encoding": "flat-row-major",
        "province": {"label": "Province", "values": province.tolist()},
        "city": {"label": "City", "values": city.tolist()},
    }


def _checked_max_dimension(max_dimension: int) -> int:
    value = int(max_dimension)
    if not MIN_MAX_DIMENSION <= value <= MAX_MAX_DIMENSION:
        raise ValueError(
            f"max_dimension must be between {MIN_MAX_DIMENSION} and "
            f"{MAX_MAX_DIMENSION}"
        )
    return value


def _normalise_name(value: object) -> str:
    text = str(value).strip().lower().replace("\ufeff", "")
    return re.sub(r"[^0-9a-z\u4e00-\u9fff]+", "", text)


def _resolve_name(
    names: Iterable[object], aliases: Sequence[str], *, required: bool = True
) -> object | None:
    lookup = {_normalise_name(name): name for name in names}
    for alias in aliases:
        found = lookup.get(_normalise_name(alias))
        if found is not None:
            return found
    if required:
        raise ValueError(f"required field is missing; expected one of {list(aliases)}")
    return None


def _finite_number(value: object) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _rounded_number(value: object, digits: int = 6) -> float | None:
    number = _finite_number(value)
    if number is None:
        return None
    rounded = round(number, digits)
    # Avoid a surprising -0.0 in tooltips and serialized test output.
    return 0.0 if rounded == 0 else rounded


def _flat_floats(
    values: np.ndarray,
    *,
    digits: int = 6,
    present: np.ndarray | None = None,
) -> list[float | None]:
    array = np.asarray(values, dtype=np.float64)
    valid = np.isfinite(array)
    if present is not None:
        valid &= np.asarray(present, dtype=bool)
    rounded = np.round(array, digits)
    result: list[float | None] = []
    for value, keep in zip(rounded.ravel(order="C"), valid.ravel(order="C")):
        result.append(float(value) if keep else None)
    return result


def _flat_integers(values: np.ndarray) -> list[int]:
    array = np.asarray(values)
    return [int(value) for value in array.ravel(order="C")]


def _block_layout(shape: tuple[int, int], maximum: int) -> tuple[int, int, int, int]:
    rows, columns = shape
    row_block = max(1, math.ceil(rows / maximum))
    column_block = max(1, math.ceil(columns / maximum))
    display_rows = math.ceil(rows / row_block)
    display_columns = math.ceil(columns / column_block)
    return row_block, column_block, display_rows, display_columns


def _block_max(values: np.ndarray, row_block: int, column_block: int) -> np.ndarray:
    source = np.asarray(values, dtype=np.float64)
    rows, columns = source.shape
    display_rows = math.ceil(rows / row_block)
    display_columns = math.ceil(columns / column_block)
    padded = np.full(
        (display_rows * row_block, display_columns * column_block),
        -np.inf,
        dtype=np.float64,
    )
    finite = np.isfinite(source)
    padded[:rows, :columns] = np.where(finite, source, -np.inf)
    blocks = padded.reshape(display_rows, row_block, display_columns, column_block)
    reduced = blocks.max(axis=(1, 3))
    reduced[~np.isfinite(reduced)] = np.nan
    return reduced


def _block_source_count(
    values: np.ndarray, row_block: int, column_block: int
) -> np.ndarray:
    source = np.isfinite(np.asarray(values))
    rows, columns = source.shape
    display_rows = math.ceil(rows / row_block)
    display_columns = math.ceil(columns / column_block)
    padded = np.zeros(
        (display_rows * row_block, display_columns * column_block), dtype=np.uint16
    )
    padded[:rows, :columns] = source
    blocks = padded.reshape(display_rows, row_block, display_columns, column_block)
    return blocks.sum(axis=(1, 3), dtype=np.uint32)


def _block_value_at_wind_max(
    wind: np.ndarray,
    values: np.ndarray,
    row_block: int,
    column_block: int,
) -> np.ndarray:
    """Take the companion value at the source cell that supplies each wind max."""

    reference = np.asarray(wind, dtype=np.float64)
    companion = np.asarray(values)
    if reference.shape != companion.shape:
        raise ValueError("companion wind field has a different grid shape")
    rows, columns = reference.shape
    display_rows = math.ceil(rows / row_block)
    display_columns = math.ceil(columns / column_block)
    padded_shape = (display_rows * row_block, display_columns * column_block)
    padded_wind = np.full(padded_shape, -np.inf, dtype=np.float64)
    padded_wind[:rows, :columns] = np.where(
        np.isfinite(reference), reference, -np.inf
    )
    wind_blocks = padded_wind.reshape(
        display_rows, row_block, display_columns, column_block
    ).transpose(0, 2, 1, 3)
    wind_blocks = wind_blocks.reshape(display_rows, display_columns, -1)
    winner = wind_blocks.argmax(axis=2)
    has_wind = np.isfinite(wind_blocks.max(axis=2))

    if np.issubdtype(companion.dtype, np.datetime64):
        fill_value: Any = np.datetime64("NaT")
    elif np.issubdtype(companion.dtype, np.number):
        companion = companion.astype(np.float64)
        fill_value = np.nan
    else:
        companion = companion.astype(object)
        fill_value = None
    padded_companion = np.full(padded_shape, fill_value, dtype=companion.dtype)
    padded_companion[:rows, :columns] = companion
    companion_blocks = padded_companion.reshape(
        display_rows, row_block, display_columns, column_block
    ).transpose(0, 2, 1, 3)
    companion_blocks = companion_blocks.reshape(display_rows, display_columns, -1)
    selected = np.take_along_axis(companion_blocks, winner[..., None], axis=2)[..., 0]
    selected[~has_wind] = fill_value
    return selected


def _flat_times(values: np.ndarray) -> list[str | None]:
    result: list[str | None] = []
    for value in np.asarray(values).ravel(order="C"):
        if isinstance(value, np.datetime64):
            result.append(
                None if np.isnat(value) else np.datetime_as_string(value, unit="s")
            )
        else:
            result.append(_track_time(value))
    return result


def _block_axis_centres(axis: np.ndarray, block: int) -> list[float]:
    values = np.asarray(axis, dtype=np.float64)
    result = []
    for start in range(0, values.size, block):
        section = values[start : start + block]
        finite = section[np.isfinite(section)]
        if not finite.size:
            raise ValueError("coordinate axis contains an entirely invalid block")
        result.append(float(np.round(finite.mean(), 6)))
    return result


def _axis_outer_bounds(axis: np.ndarray) -> tuple[float, float]:
    values = np.asarray(axis, dtype=np.float64)
    values = values[np.isfinite(values)]
    if not values.size:
        raise ValueError("coordinate axis contains no finite values")
    low = float(values.min())
    high = float(values.max())
    unique = np.unique(values)
    if unique.size > 1:
        spacing = float(np.median(np.abs(np.diff(unique))))
        if math.isfinite(spacing) and spacing > 0:
            low -= spacing / 2
            high += spacing / 2
    return low, high


def _direction(axis: np.ndarray) -> str:
    values = np.asarray(axis, dtype=np.float64)
    if values.size < 2:
        return "constant"
    return "ascending" if values[-1] >= values[0] else "descending"


def _domain(values: np.ndarray, *, logarithmic: bool = False) -> list[float]:
    finite = np.asarray(values, dtype=np.float64)
    finite = finite[np.isfinite(finite)]
    if logarithmic:
        finite = finite[finite > 0]
    if not finite.size:
        return [0.0, 1.0]
    low = float(finite.min()) if logarithmic else min(0.0, float(finite.min()))
    high = float(finite.max())
    if high <= low:
        high = low * 10 if logarithmic and low > 0 else low + 1.0
    return [_rounded_number(low) or 0.0, _rounded_number(high) or 1.0]


def _loss_quantile_stops(values: np.ndarray) -> list[list[float | str]]:
    """Spread the loss palette across positive cells using log-quantiles."""

    positive = np.asarray(values, dtype=np.float64)
    positive = positive[np.isfinite(positive) & (positive > 0.0)]
    if not positive.size:
        return [list(stop) for stop in LOSS_COLOR_SCALE["stops"]]

    quantile_levels = np.asarray([0.0, 0.15, 0.35, 0.55, 0.75, 0.90, 1.0])
    colors = ["#d8f3dc", "#52b69a", "#3a86a8", "#b7e4a8", "#ffe066", "#f4a261", "#d1495b"]
    quantiles = np.quantile(positive, quantile_levels)
    low = float(quantiles[0])
    high = float(quantiles[-1])
    if high <= low:
        return [[0.0, colors[0]], [1.0, colors[-1]]]

    log_low = float(np.log10(low))
    log_span = float(np.log10(high) - log_low)
    stops: list[list[float | str]] = []
    for value, color in zip(quantiles, colors):
        position = float((np.log10(float(value)) - log_low) / log_span)
        position = min(1.0, max(0.0, position))
        if stops and position <= float(stops[-1][0]) + 1e-9:
            continue
        stops.append([round(position, 6), color])
    if not stops or float(stops[0][0]) > 0.0:
        stops.insert(0, [0.0, colors[0]])
    if float(stops[-1][0]) < 1.0:
        stops.append([1.0, colors[-1]])
    return stops


def _track_time(value: object) -> str | None:
    if value is None or (not isinstance(value, str) and pd.isna(value)):
        return None
    if isinstance(value, (pd.Timestamp, datetime, date)):
        return pd.Timestamp(value).isoformat()
    text = str(value).strip().replace("：", ":").replace("．", ".")
    if not text or text.lower() in {"nan", "nat", "none"}:
        return None
    parsed = pd.to_datetime(text, errors="coerce")
    if not pd.isna(parsed):
        return pd.Timestamp(parsed).isoformat()
    return text


def _track_text(value: object) -> str | None:
    if value is None or (not isinstance(value, str) and pd.isna(value)):
        return None
    text = str(value).strip()
    return text if text and text.lower() not in {"nan", "none"} else None


def _english_track_strength(value: object) -> str | None:
    text = _track_text(value)
    if text is None:
        return None
    labels = {
        "热带低压": "Tropical Depression",
        "热带风暴": "Tropical Storm",
        "强热带风暴": "Severe Tropical Storm",
        "台风": "Typhoon",
        "强台风": "Severe Typhoon",
        "超强台风": "Super Typhoon",
    }
    normalized = re.sub(r"\s+", "", text)
    if normalized in labels:
        return labels[normalized]
    if re.search(r"[\u3400-\u9fff]", text):
        return "Unspecified tropical-cyclone intensity"
    return text


def read_track_points(track_path: str | Path) -> dict[str, Any]:
    """Read the first recognizable track table from an Excel workbook.

    Real case workbooks may put an event ID in the first row, leave another row
    blank, then use a later row as the actual header.  The reader therefore does
    not rely on Excel's first-row header convention.
    """

    path = Path(track_path)
    if not path.is_file():
        raise FileNotFoundError(f"track workbook does not exist: {path.name}")

    sheets = pd.read_excel(path, sheet_name=None, header=None, dtype=object)
    time_aliases = ("time", "datetime", "date", "时间", "日期")
    lat_aliases = ("lat", "latitude", "纬度")
    lon_aliases = ("lon", "long", "longitude", "经度")
    wind_aliases = (
        "uv",
        "wind",
        "windspeed",
        "windms",
        "maxwindms",
        "最大风速",
        "风速",
    )
    pressure_aliases = ("slp", "pressure", "pressurehpa", "气压", "中心气压")
    strength_aliases = ("strength", "intensity", "强度", "等级")

    for _sheet_name, raw in sheets.items():
        if raw.empty:
            continue
        for header_row in range(min(len(raw), 30)):
            labels = list(raw.iloc[header_row])
            lat_column = _resolve_name(labels, lat_aliases, required=False)
            lon_column = _resolve_name(labels, lon_aliases, required=False)
            if lat_column is None or lon_column is None:
                continue
            time_column = _resolve_name(labels, time_aliases, required=False)
            wind_column = _resolve_name(labels, wind_aliases, required=False)
            pressure_column = _resolve_name(labels, pressure_aliases, required=False)
            strength_column = _resolve_name(labels, strength_aliases, required=False)
            positions = {
                str(label): index for index, label in enumerate(labels) if not pd.isna(label)
            }

            def position(column: object | None) -> int | None:
                return positions.get(str(column)) if column is not None else None

            lat_position = position(lat_column)
            lon_position = position(lon_column)
            if lat_position is None or lon_position is None:
                continue
            points: list[dict[str, Any]] = []
            for _, row in raw.iloc[header_row + 1 :].iterrows():
                lat = _finite_number(row.iloc[lat_position])
                lon = _finite_number(row.iloc[lon_position])
                if lat is None or lon is None or not -90 <= lat <= 90 or not -180 <= lon <= 360:
                    continue
                point: dict[str, Any] = {
                    "lat": round(lat, 6),
                    "lon": round(lon, 6),
                }
                time_position = position(time_column)
                wind_position = position(wind_column)
                pressure_position = position(pressure_column)
                strength_position = position(strength_column)
                if time_position is not None:
                    time_value = _track_time(row.iloc[time_position])
                    if time_value is not None:
                        point["time"] = time_value
                if wind_position is not None:
                    wind_value = _rounded_number(row.iloc[wind_position], 3)
                    if wind_value is not None:
                        point["wind_ms"] = wind_value
                if pressure_position is not None:
                    pressure_value = _rounded_number(row.iloc[pressure_position], 2)
                    if pressure_value is not None:
                        point["pressure_hpa"] = pressure_value
                if strength_position is not None:
                    strength_value = _english_track_strength(row.iloc[strength_position])
                    if strength_value is not None:
                        point["strength"] = strength_value
                points.append(point)

            if not points:
                continue
            track_id = None
            for value in raw.iloc[:header_row].to_numpy().ravel(order="C"):
                text = _track_text(value)
                if text and re.fullmatch(r"ID\s*\d+", text, flags=re.IGNORECASE):
                    track_id = re.sub(r"\s+", "", text).upper()
                    break
            result: dict[str, Any] = {"count": len(points), "points": points}
            if track_id:
                # source_id describes the workbook as-is.  It is intentionally
                # not rewritten when the task/case ID differs.
                result["source_id"] = track_id
            return result

    raise ValueError("no track table with latitude and longitude columns was found")


def _track_quality_warnings(track: Mapping[str, Any]) -> list[str]:
    abnormal: list[dict[str, Any]] = []
    for point in track.get("points") or []:
        pressure = _finite_number(point.get("pressure_hpa"))
        if pressure is not None and not 800 <= pressure <= 1100:
            abnormal.append(point)
    if not abnormal:
        return []
    first = abnormal[0]
    source_time = first.get("time") or "unknown source time"
    return [
        "Track source contains "
        f"{len(abnormal)} pressure value(s) outside 800–1100 hPa "
        f"(first: {first.get('pressure_hpa')} hPa at {source_time}); "
        "the source data was preserved unchanged."
    ]


def _netcdf_name(dataset: xr.Dataset, aliases: Sequence[str]) -> str:
    found = _resolve_name(dataset.variables, aliases)
    return str(found)


def build_wind_payload(
    netcdf_path: str | Path,
    *,
    track_path: str | Path | None = None,
    case_id: str | None = None,
    max_dimension: int = DEFAULT_MAX_DIMENSION,
    boundary_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Build a maximum-preserving wind-map payload from fixed-grid NetCDF."""

    maximum = _checked_max_dimension(max_dimension)
    path = Path(netcdf_path)
    if not path.is_file():
        raise FileNotFoundError(f"wind NetCDF does not exist: {path.name}")

    with xr.open_dataset(path, engine="h5netcdf") as dataset:
        latitude_name = _netcdf_name(dataset, ("lat", "latitude"))
        longitude_name = _netcdf_name(dataset, ("lon", "long", "longitude"))
        wind_name = _netcdf_name(
            dataset,
            ("max_wind_speed", "max_wind_ms", "maximum_wind_speed", "wind_speed"),
        )
        latitude = np.asarray(dataset[latitude_name].values, dtype=np.float64).squeeze()
        longitude = np.asarray(dataset[longitude_name].values, dtype=np.float64).squeeze()
        if latitude.ndim != 1 or longitude.ndim != 1:
            raise ValueError("fixed-grid latitude and longitude coordinates must be 1-D")
        wind_data = dataset[wind_name]
        if latitude_name not in wind_data.dims or longitude_name not in wind_data.dims:
            raise ValueError("wind variable is not indexed by latitude and longitude")
        wind = np.asarray(
            wind_data.transpose(latitude_name, longitude_name).values, dtype=np.float64
        )
        if wind.ndim != 2 or wind.shape != (latitude.size, longitude.size):
            raise ValueError("wind variable must be a 2-D regular latitude-longitude grid")
        valid_name = _resolve_name(dataset.variables, ("valid_count",), required=False)
        if valid_name is not None:
            valid_data = dataset[str(valid_name)]
            if latitude_name in valid_data.dims and longitude_name in valid_data.dims:
                valid_count = np.asarray(
                    valid_data.transpose(latitude_name, longitude_name).values,
                    dtype=np.float64,
                )
            else:
                valid_count = np.where(np.isfinite(wind), 1.0, 0.0)
        else:
            valid_count = np.where(np.isfinite(wind), 1.0, 0.0)
        time_name = _resolve_name(dataset.variables, ("time_of_max",), required=False)
        time_of_max = None
        if time_name is not None:
            time_data = dataset[str(time_name)]
            if latitude_name in time_data.dims and longitude_name in time_data.dims:
                time_of_max = np.asarray(
                    time_data.transpose(latitude_name, longitude_name).values
                )
        lead_name = _resolve_name(
            dataset.variables, ("lead_hour_of_max", "lead_hours_of_max"), required=False
        )
        lead_hour_of_max = None
        if lead_name is not None:
            lead_data = dataset[str(lead_name)]
            if latitude_name in lead_data.dims and longitude_name in lead_data.dims:
                lead_hour_of_max = np.asarray(
                    lead_data.transpose(latitude_name, longitude_name).values,
                    dtype=np.float64,
                )
        typhoon_id = _track_text(dataset.attrs.get("typhoon_id"))
        resolution_km = _rounded_number(dataset.attrs.get("target_grid_resolution_km"), 3)

    row_block, column_block, display_rows, display_columns = _block_layout(
        wind.shape, maximum
    )
    reduced_wind = _block_max(wind, row_block, column_block)
    reduced_valid = _block_max(valid_count, row_block, column_block)
    source_count = _block_source_count(wind, row_block, column_block)
    reduced_time = (
        _block_value_at_wind_max(
            wind, time_of_max, row_block, column_block
        )
        if time_of_max is not None
        else None
    )
    reduced_lead = (
        _block_value_at_wind_max(
            wind, lead_hour_of_max, row_block, column_block
        )
        if lead_hour_of_max is not None
        else None
    )
    lat_centres = _block_axis_centres(latitude, row_block)
    lon_centres = _block_axis_centres(longitude, column_block)
    south, north = _axis_outer_bounds(latitude)
    west, east = _axis_outer_bounds(longitude)
    wind_scale = dict(WIND_COLOR_SCALE)
    wind_scale["domain"] = _domain(reduced_wind)

    payload: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "kind": "wind",
        "grid": {
            "type": "regular-latlon-blocks",
            "encoding": "flat-row-major",
            "shape": [display_rows, display_columns],
            "source_shape": [int(wind.shape[0]), int(wind.shape[1])],
            "block_shape": [row_block, column_block],
            "bounds": {
                "south": round(south, 6),
                "west": round(west, 6),
                "north": round(north, 6),
                "east": round(east, 6),
            },
            "latitude": lat_centres,
            "longitude": lon_centres,
            "latitude_direction": _direction(latitude),
            "longitude_direction": _direction(longitude),
        },
        "layers": {
            "max_wind_ms": {
                "label": "Maximum wind speed",
                "unit": "m/s",
                "aggregation": "maximum",
                "values": _flat_floats(reduced_wind, digits=4),
                "color_scale": wind_scale,
            },
            "valid_count": {
                "label": "Maximum valid-hour count",
                "unit": "hour",
                "aggregation": "maximum",
                "values": _flat_integers(np.nan_to_num(reduced_valid, nan=0.0)),
                "display": "hover",
            },
            "source_count": {
                "label": "Source cells in display cell",
                "unit": "cell",
                "aggregation": "count",
                "values": _flat_integers(source_count),
                "display": "hover",
            },
        },
        "administrative": _administrative_grid(
            lat_centres,
            lon_centres,
            boundary_dir=boundary_dir,
        ),
        "summary": {
            "source_cell_count": int(wind.size),
            "valid_source_cell_count": int(np.isfinite(wind).sum()),
            "display_cell_count": int(reduced_wind.size),
            "populated_display_cell_count": int((source_count > 0).sum()),
            "maximum_wind_ms": _rounded_number(np.nanmax(wind), 6)
            if np.isfinite(wind).any()
            else None,
        },
        "warnings": [],
    }
    if typhoon_id:
        payload["summary"]["typhoon_id"] = typhoon_id
    if resolution_km is not None:
        payload["summary"]["source_resolution_km"] = resolution_km
    task_case_id = _track_text(case_id) or typhoon_id
    if task_case_id:
        payload["summary"]["case_id"] = task_case_id
    if reduced_time is not None:
        payload["layers"]["time_of_max"] = {
            "label": "Time of maximum wind",
            "aggregation": "value at maximum wind cell",
            "values": _flat_times(reduced_time),
            "display": "hover",
        }
    if reduced_lead is not None:
        payload["layers"]["lead_hour_of_max"] = {
            "label": "Lead hour of maximum wind",
            "unit": "hour",
            "aggregation": "value at maximum wind cell",
            "values": _flat_floats(reduced_lead, digits=3),
            "display": "hover",
        }
    if track_path is not None:
        track = read_track_points(track_path)
        payload["track"] = track
        source_id = _track_text(track.get("source_id"))
        if task_case_id and source_id and task_case_id.upper() != source_id.upper():
            payload["warnings"].append(
                f"Track source ID {source_id} differs from task case ID "
                f"{task_case_id}; the source track was preserved unchanged."
            )
        payload["warnings"].extend(_track_quality_warnings(track))
    return payload


def _csv_columns(path: Path) -> tuple[list[str], dict[str, str | None]]:
    names = list(pd.read_csv(path, nrows=0).columns)
    columns: dict[str, str | None] = {
        "lon": str(_resolve_name(names, ("lon", "long", "longitude", "经度"))),
        "lat": str(_resolve_name(names, ("lat", "latitude", "纬度"))),
        "total_loss": str(
            _resolve_name(names, ("total_loss", "totalloss", "loss", "总损失"))
        ),
        "exposure_value": str(
            _resolve_name(names, ("exposure_value", "exposure", "暴露价值", "暴露量"))
        ),
    }
    wind = _resolve_name(
        names,
        ("max_wind_ms", "maxwindspeed", "maximum_wind_speed", "wind_speed", "风速"),
        required=False,
    )
    columns["max_wind_ms"] = str(wind) if wind is not None else None
    coverage = _resolve_name(
        names,
        ("wind_covered", "track_composite_coverage", "wind_coverage"),
        required=False,
    )
    columns["wind_covered"] = str(coverage) if coverage is not None else None
    return names, columns


def _read_numeric_csv(path: Path, columns: Mapping[str, str | None]) -> pd.DataFrame:
    selected = [name for name in columns.values() if name is not None]
    frame = pd.read_csv(path, usecols=selected, low_memory=False)
    rename = {original: canonical for canonical, original in columns.items() if original}
    frame = frame.rename(columns=rename)
    for column in frame.columns:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    return frame


def _loss_grid_geometry(
    longitude: np.ndarray, latitude: np.ndarray, maximum: int
) -> dict[str, Any]:
    finite = np.isfinite(longitude) & np.isfinite(latitude)
    if not finite.any():
        raise ValueError("loss CSV contains no finite longitude/latitude pairs")
    lon = longitude[finite]
    lat = latitude[finite]
    unique_lon = np.unique(lon)
    unique_lat = np.unique(lat)
    columns = min(maximum, max(1, int(unique_lon.size)))
    rows = min(maximum, max(1, int(unique_lat.size)))
    west, east = _axis_outer_bounds(unique_lon)
    south, north = _axis_outer_bounds(unique_lat)
    if east <= west:
        west -= 0.5
        east += 0.5
    if north <= south:
        south -= 0.5
        north += 0.5
    lon_step = (east - west) / columns
    lat_step = (north - south) / rows
    lon_centres = [round(west + (index + 0.5) * lon_step, 6) for index in range(columns)]
    lat_centres = [round(south + (index + 0.5) * lat_step, 6) for index in range(rows)]
    return {
        "rows": rows,
        "columns": columns,
        "west": west,
        "east": east,
        "south": south,
        "north": north,
        "longitude": lon_centres,
        "latitude": lat_centres,
    }


def _bin_indices(
    longitude: np.ndarray, latitude: np.ndarray, geometry: Mapping[str, Any]
) -> tuple[np.ndarray, np.ndarray]:
    rows = int(geometry["rows"])
    columns = int(geometry["columns"])
    lon_index = np.floor(
        (longitude - float(geometry["west"]))
        / (float(geometry["east"]) - float(geometry["west"]))
        * columns
    ).astype(np.int64)
    lat_index = np.floor(
        (latitude - float(geometry["south"]))
        / (float(geometry["north"]) - float(geometry["south"]))
        * rows
    ).astype(np.int64)
    return np.clip(lat_index, 0, rows - 1), np.clip(lon_index, 0, columns - 1)


def _binned_max(
    flat_indices: np.ndarray, values: np.ndarray, cell_count: int
) -> np.ndarray:
    result = np.full(cell_count, -np.inf, dtype=np.float64)
    valid = np.isfinite(values)
    if valid.any():
        np.maximum.at(result, flat_indices[valid], values[valid])
    result[~np.isfinite(result)] = np.nan
    return result


def build_loss_payload(
    grid_loss_path: str | Path,
    *,
    grid_wind_path: str | Path | None = None,
    track_path: str | Path | None = None,
    case_id: str | None = None,
    max_dimension: int = DEFAULT_MAX_DIMENSION,
    boundary_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Build a binned, sum-preserving loss-map payload from detailed CSVs."""

    maximum = _checked_max_dimension(max_dimension)
    loss_path = Path(grid_loss_path)
    if not loss_path.is_file():
        raise FileNotFoundError(f"loss CSV does not exist: {loss_path.name}")
    _, loss_columns = _csv_columns(loss_path)
    loss_frame = _read_numeric_csv(loss_path, loss_columns)
    lon = loss_frame["lon"].to_numpy(dtype=np.float64)
    lat = loss_frame["lat"].to_numpy(dtype=np.float64)
    coordinate_valid = np.isfinite(lon) & np.isfinite(lat)
    coverage_column = loss_columns.get("wind_covered")
    if coverage_column is not None:
        coordinate_valid &= loss_frame["wind_covered"].to_numpy(dtype=np.float64) > 0
    elif loss_columns.get("max_wind_ms") is not None:
        # Older outputs store uncovered grid winds as numeric zero.
        coordinate_valid &= loss_frame["max_wind_ms"].to_numpy(dtype=np.float64) > 0
    if not coordinate_valid.any():
        raise ValueError("loss CSV contains no wind-covered coordinate rows")
    geometry = _loss_grid_geometry(lon[coordinate_valid], lat[coordinate_valid], maximum)
    valid_lon = lon[coordinate_valid]
    valid_lat = lat[coordinate_valid]
    lat_index, lon_index = _bin_indices(valid_lon, valid_lat, geometry)
    rows = int(geometry["rows"])
    columns = int(geometry["columns"])
    cell_count = rows * columns
    flat_index = lat_index * columns + lon_index
    source_count = np.bincount(flat_index, minlength=cell_count).astype(np.uint32)

    total_loss_source = loss_frame["total_loss"].to_numpy(dtype=np.float64)[coordinate_valid]
    exposure_source = loss_frame["exposure_value"].to_numpy(dtype=np.float64)[coordinate_valid]
    total_loss = np.bincount(
        flat_index,
        weights=np.where(np.isfinite(total_loss_source), total_loss_source, 0.0),
        minlength=cell_count,
    )
    exposure = np.bincount(
        flat_index,
        weights=np.where(np.isfinite(exposure_source), exposure_source, 0.0),
        minlength=cell_count,
    )

    wind_column = loss_columns.get("max_wind_ms")
    if wind_column is not None:
        wind_source = loss_frame["max_wind_ms"].to_numpy(dtype=np.float64)[coordinate_valid]
        max_wind = _binned_max(flat_index, wind_source, cell_count)
    else:
        if grid_wind_path is None:
            raise ValueError(
                "loss CSV has no max-wind field; a grid_wind.csv file is required"
            )
        wind_path = Path(grid_wind_path)
        if not wind_path.is_file():
            raise FileNotFoundError(f"wind CSV does not exist: {wind_path.name}")
        wind_headers = list(pd.read_csv(wind_path, nrows=0).columns)
        wind_columns: dict[str, str | None] = {
            "lon": str(_resolve_name(wind_headers, ("lon", "long", "longitude", "经度"))),
            "lat": str(_resolve_name(wind_headers, ("lat", "latitude", "纬度"))),
            "max_wind_ms": str(
                _resolve_name(
                    wind_headers,
                    (
                        "max_wind_ms",
                        "maxwindspeed",
                        "maximum_wind_speed",
                        "wind_speed",
                        "风速",
                    ),
                )
            ),
        }
        wind_frame = _read_numeric_csv(wind_path, wind_columns)
        wind_lon = wind_frame["lon"].to_numpy(dtype=np.float64)
        wind_lat = wind_frame["lat"].to_numpy(dtype=np.float64)
        wind_values = wind_frame["max_wind_ms"].to_numpy(dtype=np.float64)
        wind_valid = (
            np.isfinite(wind_lon)
            & np.isfinite(wind_lat)
            & (wind_lon >= float(geometry["west"]))
            & (wind_lon <= float(geometry["east"]))
            & (wind_lat >= float(geometry["south"]))
            & (wind_lat <= float(geometry["north"]))
        )
        wind_lat_index, wind_lon_index = _bin_indices(
            wind_lon[wind_valid], wind_lat[wind_valid], geometry
        )
        wind_flat_index = wind_lat_index * columns + wind_lon_index
        max_wind = _binned_max(wind_flat_index, wind_values[wind_valid], cell_count)

    total_loss = total_loss.reshape(rows, columns)
    exposure = exposure.reshape(rows, columns)
    max_wind = max_wind.reshape(rows, columns)
    source_count = source_count.reshape(rows, columns)
    populated = source_count > 0
    positive_loss = populated & (total_loss > 0.0)
    loss_scale = dict(LOSS_COLOR_SCALE)
    loss_scale["domain"] = _domain(total_loss[positive_loss], logarithmic=True)
    loss_scale["stops"] = _loss_quantile_stops(total_loss[positive_loss])
    wind_scale = dict(WIND_COLOR_SCALE)
    wind_scale["domain"] = _domain(max_wind)
    exposure_scale = dict(EXPOSURE_COLOR_SCALE)
    exposure_scale["domain"] = _domain(exposure[populated], logarithmic=True)

    payload: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "kind": "loss",
        "grid": {
            "type": "regular-latlon-bins",
            "encoding": "flat-row-major",
            "shape": [rows, columns],
            "bounds": {
                "south": round(float(geometry["south"]), 6),
                "west": round(float(geometry["west"]), 6),
                "north": round(float(geometry["north"]), 6),
                "east": round(float(geometry["east"]), 6),
            },
            "latitude": geometry["latitude"],
            "longitude": geometry["longitude"],
            "latitude_direction": "ascending",
            "longitude_direction": "ascending",
        },
        "layers": {
            "total_loss": {
                "label": "Total loss",
                "unit": "CNY",
                "aggregation": "sum",
                "values": _flat_floats(total_loss, digits=6, present=positive_loss),
                "color_scale": loss_scale,
            },
            "max_wind_ms": {
                "label": "Maximum wind speed",
                "unit": "m/s",
                "aggregation": "maximum",
                "values": _flat_floats(max_wind, digits=4),
                "color_scale": wind_scale,
            },
            "exposure_value": {
                "label": "Exposure value",
                "unit": "CNY",
                "aggregation": "sum",
                "values": _flat_floats(exposure, digits=6, present=populated),
                "color_scale": exposure_scale,
                "display": "optional",
            },
            "source_count": {
                "label": "Source records in display cell",
                "unit": "record",
                "aggregation": "count",
                "values": _flat_integers(source_count),
                "display": "hover",
            },
        },
        "administrative": _administrative_grid(
            geometry["latitude"],
            geometry["longitude"],
            boundary_dir=boundary_dir,
        ),
        "summary": {
            "source_row_count": int(len(loss_frame)),
            "valid_source_row_count": int(coordinate_valid.sum()),
            "display_cell_count": int(cell_count),
            "populated_display_cell_count": int(populated.sum()),
            "total_loss": _rounded_number(
                np.sum(total_loss_source[np.isfinite(total_loss_source)], dtype=np.float64),
                6,
            ),
            "total_exposure_value": _rounded_number(
                np.sum(exposure_source[np.isfinite(exposure_source)], dtype=np.float64),
                6,
            ),
            "maximum_wind_ms": _rounded_number(np.nanmax(max_wind), 6)
            if np.isfinite(max_wind).any()
            else None,
        },
        "warnings": [],
    }
    task_case_id = _track_text(case_id)
    if task_case_id:
        payload["summary"]["case_id"] = task_case_id
    if track_path is not None:
        track = read_track_points(track_path)
        payload["track"] = track
        source_id = _track_text(track.get("source_id"))
        if task_case_id and source_id and task_case_id.upper() != source_id.upper():
            payload["warnings"].append(
                f"Track source ID {source_id} differs from task case ID "
                f"{task_case_id}; the source track was preserved unchanged."
            )
        payload["warnings"].extend(_track_quality_warnings(track))
    return payload


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, Path):
        raise TypeError("filesystem paths must not be serialized into map payloads")
    if isinstance(value, (float, np.floating)):
        number = float(value)
        return number if math.isfinite(number) else None
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, (datetime, date, pd.Timestamp)):
        return pd.Timestamp(value).isoformat()
    if isinstance(value, Mapping):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, np.ndarray)):
        return [_json_safe(item) for item in value]
    raise TypeError(f"unsupported JSON payload value: {type(value).__name__}")


def atomic_write_json(payload: Mapping[str, Any], output_path: str | Path) -> Path:
    """Strictly serialize *payload* and atomically replace *output_path*."""

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    safe_payload = _json_safe(payload)
    encoded = json.dumps(
        safe_payload,
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
    ).encode("utf-8")
    file_descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(file_descriptor, "wb") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def generate_wind_json(
    netcdf_path: str | Path,
    output_path: str | Path,
    *,
    track_path: str | Path | None = None,
    case_id: str | None = None,
    max_dimension: int = DEFAULT_MAX_DIMENSION,
    boundary_dir: str | Path | None = None,
) -> Path:
    payload = build_wind_payload(
        netcdf_path,
        track_path=track_path,
        case_id=case_id,
        max_dimension=max_dimension,
        boundary_dir=boundary_dir,
    )
    return atomic_write_json(payload, output_path)


def generate_loss_json(
    grid_loss_path: str | Path,
    output_path: str | Path,
    *,
    grid_wind_path: str | Path | None = None,
    track_path: str | Path | None = None,
    case_id: str | None = None,
    max_dimension: int = DEFAULT_MAX_DIMENSION,
    boundary_dir: str | Path | None = None,
) -> Path:
    payload = build_loss_payload(
        grid_loss_path,
        grid_wind_path=grid_wind_path,
        track_path=track_path,
        case_id=case_id,
        max_dimension=max_dimension,
        boundary_dir=boundary_dir,
    )
    return atomic_write_json(payload, output_path)


__all__ = [
    "DEFAULT_MAX_DIMENSION",
    "SCHEMA_VERSION",
    "atomic_write_json",
    "build_loss_payload",
    "build_wind_payload",
    "generate_loss_json",
    "generate_wind_json",
    "read_track_points",
]
