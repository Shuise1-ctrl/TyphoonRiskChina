"""Windows-safe stage runner for independent wind-field and loss jobs.

This wrapper deliberately calls the supplied TyphoonRiskChina 1.1.0 modules
instead of reimplementing either the downscaling or vulnerability formulas.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import re
import shutil
import traceback
from typing import Any

os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")

DEFAULT_LOSS_IMPACT_THRESHOLD_MS = 17.3

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=str),
        encoding="utf-8",
    )
    temporary.replace(path)


def absolute_path(value: str | Path) -> Path:
    return Path(os.path.abspath(os.path.expanduser(str(value))))


def validate_case_id(value: str) -> str:
    case_id = str(value or "").strip().upper()
    if not re.fullmatch(r"ID\d{4}", case_id):
        raise ValueError("Case ID must look like ID2609")
    return case_id


def event_id(case_id: str) -> str:
    return "20" + validate_case_id(case_id)[2:]


def netcdf_engine() -> str | None:
    return os.environ.get("TYPHOON_NETCDF_ENGINE") or ("h5netcdf" if os.name == "nt" else None)


def netcdf_open_kwargs() -> dict[str, str]:
    engine = netcdf_engine()
    return {"engine": engine} if engine else {}


def _case_identity_error(attribute: str, actual: Any, expected: str) -> ValueError:
    return ValueError(
        f"NetCDF {attribute}={actual!r} does not match requested case {expected}"
    )


def validate_netcdf_case_identity(dataset: Any, case_id: str) -> None:
    """Reject a labelled NetCDF that belongs to a different typhoon case.

    Older fixed-grid products use ``typhoon_id`` while some generated products
    use ``case_id``.  An absent label remains supported for backwards
    compatibility, but a present label is part of the scientific input
    contract and must agree with ``--case``.
    """

    expected = validate_case_id(case_id)
    for attribute in ("typhoon_id", "case_id"):
        actual = dataset.attrs.get(attribute)
        if actual is None or not str(actual).strip():
            continue
        if str(actual).strip().upper() != expected:
            raise _case_identity_error(attribute, actual, expected)


def validate_prediction_netcdf(path: Path, case_id: str) -> None:
    """Validate the moving-window NetCDF shape supported by the extractor."""

    import numpy as np
    import xarray as xr

    required = ("wind_speed_1h_max_pred", "XLAT", "XLONG", "time")
    with xr.open_dataset(path, **netcdf_open_kwargs()) as dataset:
        missing = [name for name in required if name not in dataset]
        if missing:
            raise KeyError(
                "Prediction NetCDF is missing required variables: " + ", ".join(missing)
            )
        validate_netcdf_case_identity(dataset, case_id)

        wind = dataset["wind_speed_1h_max_pred"]
        latitude = dataset["XLAT"]
        longitude = dataset["XLONG"]
        if (
            wind.ndim != 3
            or latitude.ndim != 3
            or longitude.ndim != 3
            or not wind.dims
            or wind.dims[0] != "time"
            or wind.dims != latitude.dims
            or wind.dims != longitude.dims
        ):
            raise ValueError(
                "Prediction wind, XLAT and XLONG must share a three-dimensional "
                "(time, y, x) layout"
            )
        if dataset.sizes.get("time", 0) < 1:
            raise ValueError("Prediction NetCDF does not contain any time steps")
        if wind.sizes.get("time") != dataset.sizes.get("time"):
            raise ValueError("Prediction wind time dimension does not match the time coordinate")

        # extract_fixed_grid_max constructs a 1-D latitude axis from column 0
        # and a 1-D longitude axis from row 0.  Guard that assumption before a
        # scientifically invalid interpolation can be produced.
        for index in range(dataset.sizes["time"]):
            lat = np.asarray(latitude.isel(time=index).values, dtype=np.float64)
            lon = np.asarray(longitude.isel(time=index).values, dtype=np.float64)
            if not np.isfinite(lat).all() or not np.isfinite(lon).all():
                raise ValueError("XLAT and XLONG must be finite at every grid cell")
            lat_axis = lat[:, 0]
            lon_axis = lon[0, :]
            if not np.allclose(lat, lat_axis[:, None], rtol=0.0, atol=1e-6):
                raise ValueError(
                    "XLAT is not rectilinear; fixed-grid conversion requires latitude "
                    "to be constant along each row"
                )
            if not np.allclose(lon, lon_axis[None, :], rtol=0.0, atol=1e-6):
                raise ValueError(
                    "XLONG is not rectilinear; fixed-grid conversion requires longitude "
                    "to be constant along each column"
                )
            if len(lat_axis) < 2 or len(lon_axis) < 2:
                raise ValueError("Prediction spatial grid must be at least 2 by 2")
            latitude_steps = np.diff(lat_axis)
            longitude_steps = np.diff(lon_axis)
            if not (
                np.all(latitude_steps > 0)
                or np.all(latitude_steps < 0)
            ):
                raise ValueError("XLAT must be strictly monotonic along the y axis")
            if not (
                np.all(longitude_steps > 0)
                or np.all(longitude_steps < 0)
            ):
                raise ValueError("XLONG must be strictly monotonic along the x axis")


def validate_fixed_grid_netcdf(path: Path, case_id: str) -> None:
    """Validate the fixed-grid identity before risk exposure is loaded."""

    import xarray as xr

    with xr.open_dataset(path, **netcdf_open_kwargs()) as dataset:
        validate_netcdf_case_identity(dataset, case_id)


def fixed_grid_summary(path: Path) -> dict[str, Any]:
    import numpy as np
    import xarray as xr

    with xr.open_dataset(path, **netcdf_open_kwargs()) as dataset:
        if "max_wind_speed" not in dataset:
            raise KeyError("Fixed-grid NetCDF is missing max_wind_speed")
        values = np.asarray(dataset["max_wind_speed"].values, dtype=np.float64)
        finite = values[np.isfinite(values)]
        if not finite.size:
            raise ValueError("Fixed-grid wind field does not contain finite wind values")
        return {
            "grid_count": int(values.size),
            "valid_grid_count": int(finite.size),
            "latitude_count": int(dataset.sizes.get("lat", values.shape[-2])),
            "longitude_count": int(dataset.sizes.get("lon", values.shape[-1])),
            "minimum_wind_ms": float(np.min(finite)),
            "mean_wind_ms": float(np.mean(finite)),
            "maximum_wind_ms": float(np.max(finite)),
            "source_variable": str(dataset["max_wind_speed"].attrs.get("long_name") or "max_wind_speed"),
            "units": str(dataset["max_wind_speed"].attrs.get("units") or "m s-1"),
        }


def copy_if_present(source: str | Path | None, destination: Path) -> Path | None:
    if not source:
        return None
    source_path = absolute_path(source)
    if not source_path.is_file():
        raise FileNotFoundError(source_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_path, destination)
    return destination


def relative_artifact_name(path: str | Path, output: Path) -> str | None:
    """Return only an output-relative artifact name; never serialize a host path."""

    try:
        return absolute_path(path).relative_to(output).as_posix()
    except ValueError:
        return None


def generate_wind_visualization(
    fixed_nc: Path,
    output: Path,
    *,
    track: Path | None,
    case_id: str,
) -> tuple[Path | None, str | None]:
    """Build the compact browser map without risking completed science output."""

    from interactive_map import generate_wind_json

    destination = output / "interactive_wind_map.json"
    try:
        generate_wind_json(
            fixed_nc,
            destination,
            track_path=track,
            case_id=case_id,
        )
        return destination, None
    except Exception as exc:
        destination.unlink(missing_ok=True)
        return None, (
            "The interactive wind map could not be generated, but the wind-field algorithm outputs were retained: "
            f"{type(exc).__name__}: {exc}"
        )


def generate_loss_visualization(
    output: Path,
    *,
    track: Path,
    case_id: str,
) -> tuple[Path | None, str | None]:
    """Build a sum-preserving loss display grid for the browser."""

    from interactive_map import generate_loss_json

    destination = output / "interactive_loss_map.json"
    try:
        generate_loss_json(
            output / "grid_loss.csv",
            destination,
            grid_wind_path=output / "grid_wind.csv",
            track_path=track,
            case_id=case_id,
        )
        return destination, None
    except Exception as exc:
        destination.unlink(missing_ok=True)
        return None, (
            "The interactive loss map could not be generated, but the loss-algorithm outputs were retained: "
            f"{type(exc).__name__}: {exc}"
        )



def publish_track_products(result, output: Path, case_id: str) -> dict[str, str]:
    """Copy service products into the job's public wind-output directory."""
    products = {}
    for attr, destination, key in (
        ("track_composite_nc", "track_composite_weighted.nc", "track_composite_nc"),
        ("track_composite_png", f"{case_id}_track_composite_weighted.png", "track_composite_png"),
        ("animation_gif", "wind_circle_track_growth.gif", "wind_circle_gif"),
    ):
        source = getattr(result, attr, None)
        if source is not None and Path(source).is_file():
            target = output / destination
            shutil.copy2(source, target)
            products[key] = destination
            print(f"{key}: {target}")
            if attr == "track_composite_png":
                shutil.copy2(target, output / "track_composite_weighted.png")
    return products


def align_fixed_grid_to_track_composite(fixed_nc: Path, composite_nc: Path) -> None:
    """Mask fixed-grid wind to the track composite's finite 450 km footprint."""

    import numpy as np
    import xarray as xr

    with xr.open_dataset(composite_nc, **netcdf_open_kwargs()) as source:
        required = {"track_composite_wind", "lat", "lon"}
        missing = required.difference(source.variables)
        if missing:
            raise ValueError(
                "Track-composite NetCDF is missing: " + ", ".join(sorted(missing))
            )
        support = np.isfinite(source["track_composite_wind"]).astype(np.uint8).load()
        composite_attrs = dict(source.attrs)

    with xr.open_dataset(fixed_nc, **netcdf_open_kwargs()) as source:
        dataset = source.load()

    if not {"lat", "lon", "max_wind_speed"}.issubset(dataset.variables):
        dataset.close()
        raise ValueError("Fixed-grid NetCDF is missing lat, lon, or max_wind_speed")

    mask = support.interp(
        lat=dataset["lat"],
        lon=dataset["lon"],
        method="nearest",
        kwargs={"fill_value": 0},
    ).values > 0
    wind = dataset["max_wind_speed"]
    mask &= np.isfinite(wind.values)
    if not mask.any():
        dataset.close()
        raise ValueError("Track-composite footprint does not overlap the fixed wind grid")

    dataset["track_composite_coverage"] = (("lat", "lon"), mask.astype(np.uint8))
    dataset["track_composite_coverage"].attrs.update(
        {
            "long_name": "Cells inside the finite track-composite wind footprint",
            "flag_values": [0, 1],
            "flag_meanings": "outside inside",
        }
    )
    dataset["max_wind_speed"] = wind.where(mask)
    dataset["valid_count"] = dataset["valid_count"].where(mask, 0)
    dataset["lead_hour_of_max"] = dataset["lead_hour_of_max"].where(mask)
    dataset["time_index_of_max"] = dataset["time_index_of_max"].where(mask, -1)
    if "time_of_max" in dataset:
        dataset["time_of_max"] = dataset["time_of_max"].where(mask)
    radius = composite_attrs.get("max_center_distance_km")
    dataset.attrs.update(
        {
            "coverage_mask": "nearest-neighbour finite support from track_composite_weighted.nc",
            "coverage_mask_max_center_distance_km": radius,
        }
    )
    temporary = fixed_nc.with_name(fixed_nc.stem + ".masked.tmp.nc")
    temporary.unlink(missing_ok=True)
    try:
        dataset.to_netcdf(temporary, **netcdf_open_kwargs())
        dataset.close()
        temporary.replace(fixed_nc)
    except Exception:
        dataset.close()
        temporary.unlink(missing_ok=True)
        raise


def regenerate_masked_wind_png(fixed_nc: Path, destination: Path, case_id: str) -> None:
    """Regenerate the static fixed-grid image after the coverage mask is applied."""

    import matplotlib.pyplot as plt
    import numpy as np
    import xarray as xr

    with xr.open_dataset(fixed_nc, **netcdf_open_kwargs()) as dataset:
        latitude = np.asarray(dataset["lat"].values, dtype=np.float64)
        longitude = np.asarray(dataset["lon"].values, dtype=np.float64)
        wind = np.asarray(dataset["max_wind_speed"].values, dtype=np.float64)
    figure, axis = plt.subplots(figsize=(10, 8))
    mesh = axis.pcolormesh(
        longitude,
        latitude,
        np.ma.masked_invalid(wind),
        shading="auto",
        cmap="turbo",
        vmin=0,
        vmax=75,
    )
    figure.colorbar(mesh, ax=axis, label="Maximum wind speed (m/s)")
    axis.set_xlabel("Longitude")
    axis.set_ylabel("Latitude")
    axis.set_title(f"{case_id} Fixed-grid Maximum Wind Speed")
    figure.tight_layout()
    figure.savefig(destination, dpi=300)
    plt.close(figure)


def run_wind_local(args: argparse.Namespace) -> dict[str, Any]:
    # Downscaling imports TensorFlow and model assets; keep the command parser
    # and the standalone NetCDF/loss commands importable without them.
    from service import TyphoonDownscalingService

    output = absolute_path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    stage_path = output / "stage_manifest.json"
    case_id = validate_case_id(args.case)
    state: dict[str, Any] = {
        "schema_version": "1.0",
        "mode": "wind",
        "source": "local-case",
        "case_id": case_id,
        "typhoon_name": args.typhoon_name,
        "status": "running",
        "current_stage": "validation",
        "started_at_utc": utc_now(),
    }
    write_json(stage_path, state)

    service = TyphoonDownscalingService(absolute_path(args.runtime_root))
    service.validate_common_runtime()
    state["current_stage"] = "downscaling"
    write_json(stage_path, state)

    algorithm_output = output / "algorithm"
    result = service.run_case(
        case_id,
        algorithm_output,
        show_plot=False,
        case_dir=absolute_path(args.case_dir),
    )
    fixed_nc = output / "fixed_grid_max_wind.nc"
    fixed_png = output / "fixed_grid_max_wind.png"
    shutil.copy2(result.fixed_grid_nc, fixed_nc)
    shutil.copy2(result.fixed_grid_png, fixed_png)
    track_products = publish_track_products(result, output, case_id)
    composite_nc = output / "track_composite_weighted.nc"
    if composite_nc.is_file():
        align_fixed_grid_to_track_composite(fixed_nc, composite_nc)
        regenerate_masked_wind_png(fixed_nc, fixed_png, case_id)
    track = copy_if_present(args.track, output / "track.xlsx")
    diagnostics = None
    if result.diagnostics_csv.is_file():
        diagnostics = output / "hourly_summary.csv"
        shutil.copy2(result.diagnostics_csv, diagnostics)

    state["current_stage"] = "visualization"
    write_json(stage_path, state)
    interactive_map, visualization_warning = generate_wind_visualization(
        fixed_nc,
        output,
        track=track,
        case_id=case_id,
    )

    manifest = {
        "schema_version": "1.0",
        "mode": "wind",
        "source": "local-case",
        "case_id": case_id,
        "typhoon_name": args.typhoon_name,
        "summary": fixed_grid_summary(fixed_nc),
        "loss_input_ready": track is not None,
        "files": {
            "fixed_grid_nc": fixed_nc.name,
            "wind_map": fixed_png.name,
            "track": track.name if track else None,
            "diagnostics": diagnostics.name if diagnostics else None,
            "prediction_nc": relative_artifact_name(result.prediction_nc, output),
            **track_products,
            "interactive_map": interactive_map.name if interactive_map else None,
        },
        "warnings": [visualization_warning] if visualization_warning else [],
        "completed_at_utc": utc_now(),
    }
    write_json(output / "wind_manifest.json", manifest)
    state.update({"status": "complete", "current_stage": None, "completed_at_utc": utc_now()})
    write_json(stage_path, state)
    return manifest


def run_wind_inputs(args: argparse.Namespace) -> dict[str, Any]:
    """Run downscaling from an explicit FNL directory and explicit track workbook."""

    from service import TyphoonDownscalingService
    from typhoon_downscaling.config import TyphoonCase

    output = absolute_path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    stage_path = output / "stage_manifest.json"
    case_id = validate_case_id(args.case)
    fnl_dir = absolute_path(args.fnl_dir)
    input_track = absolute_path(args.track)
    if not fnl_dir.is_dir():
        raise FileNotFoundError("The verified FNL directory is no longer available.")
    if not input_track.is_file():
        raise FileNotFoundError("The verified track workbook is no longer available.")

    state: dict[str, Any] = {
        "schema_version": "1.0",
        "mode": "wind",
        "source": "fnl-folder-plus-track-workbook",
        "case_id": case_id,
        "typhoon_name": args.typhoon_name,
        "status": "running",
        "current_stage": "validation",
        "started_at_utc": utc_now(),
    }
    write_json(stage_path, state)

    algorithm_output = output / "algorithm"
    explicit_case = TyphoonCase(
        typhoon_id=case_id,
        case_dir=fnl_dir.parent,
        fnl_dir=fnl_dir,
        track_file=input_track,
        output_dir=algorithm_output,
        prediction_nc=(
            algorithm_output
            / f"{case_id}_center_model_outer_coarse_largefield_oneeye.nc"
        ),
        diagnostics_csv=algorithm_output / f"{case_id}_hourly_useful_summary.csv",
        fixed_grid_nc=algorithm_output / f"{case_id}_fixed_grid_max_wind.nc",
        fixed_grid_png=algorithm_output / f"{case_id}_fixed_grid_max_wind.png",
    )
    service = TyphoonDownscalingService(absolute_path(args.runtime_root))
    service.validate_common_runtime()

    # Reuse the supplied service's unchanged scientific pipeline while binding
    # every internal case construction to the two explicitly verified inputs.
    service.build_case = lambda *_args, **_kwargs: explicit_case
    state["current_stage"] = "downscaling"
    write_json(stage_path, state)
    result = service.run_case(case_id, algorithm_output, show_plot=False)

    fixed_nc = output / "fixed_grid_max_wind.nc"
    fixed_png = output / "fixed_grid_max_wind.png"
    shutil.copy2(result.fixed_grid_nc, fixed_nc)
    shutil.copy2(result.fixed_grid_png, fixed_png)
    track_products = publish_track_products(result, output, case_id)
    composite_nc = output / "track_composite_weighted.nc"
    if composite_nc.is_file():
        align_fixed_grid_to_track_composite(fixed_nc, composite_nc)
        regenerate_masked_wind_png(fixed_nc, fixed_png, case_id)
    track = copy_if_present(input_track, output / "track.xlsx")
    diagnostics = None
    if result.diagnostics_csv.is_file():
        diagnostics = output / "hourly_summary.csv"
        shutil.copy2(result.diagnostics_csv, diagnostics)

    state["current_stage"] = "visualization"
    write_json(stage_path, state)
    interactive_map, visualization_warning = generate_wind_visualization(
        fixed_nc,
        output,
        track=track,
        case_id=case_id,
    )
    manifest = {
        "schema_version": "1.0",
        "mode": "wind",
        "source": "fnl-folder-plus-track-workbook",
        "case_id": case_id,
        "typhoon_name": args.typhoon_name,
        "summary": fixed_grid_summary(fixed_nc),
        "loss_input_ready": True,
        "files": {
            "fixed_grid_nc": fixed_nc.name,
            "wind_map": fixed_png.name,
            "track": track.name,
            "diagnostics": diagnostics.name if diagnostics else None,
            "prediction_nc": relative_artifact_name(result.prediction_nc, output),
            **track_products,
            "interactive_map": interactive_map.name if interactive_map else None,
        },
        "warnings": [visualization_warning] if visualization_warning else [],
        "completed_at_utc": utc_now(),
    }
    write_json(output / "wind_manifest.json", manifest)
    state.update({"status": "complete", "current_stage": None, "completed_at_utc": utc_now()})
    write_json(stage_path, state)
    return manifest


def run_wind_nc(args: argparse.Namespace) -> dict[str, Any]:
    from typhoon_downscaling.core.fixed_grid import extract_fixed_grid_max

    output = absolute_path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    stage_path = output / "stage_manifest.json"
    case_id = validate_case_id(args.case)
    input_nc = absolute_path(args.input_nc)
    state: dict[str, Any] = {
        "schema_version": "1.0",
        "mode": "wind",
        "source": "prediction-netcdf",
        "case_id": case_id,
        "typhoon_name": args.typhoon_name,
        "status": "running",
        "current_stage": "validation",
        "started_at_utc": utc_now(),
    }
    write_json(stage_path, state)
    if not input_nc.is_file():
        raise FileNotFoundError(input_nc)
    validate_prediction_netcdf(input_nc, case_id)

    # The fixed-grid extractor validates the required moving-window variables:
    # wind_speed_1h_max_pred, XLAT and XLONG.
    state["current_stage"] = "fixed_grid"
    write_json(stage_path, state)
    fixed_nc = output / "fixed_grid_max_wind.nc"
    fixed_png = output / "fixed_grid_max_wind.png"
    extract_fixed_grid_max(
        nc_file=input_nc,
        out_nc=fixed_nc,
        out_png=fixed_png,
        typhoon_id=case_id,
        target_km=3.0,
        vmin=0,
        vmax=75,
        show_plot=False,
    )
    track = copy_if_present(args.track, output / "track.xlsx")
    state["current_stage"] = "visualization"
    write_json(stage_path, state)
    interactive_map, visualization_warning = generate_wind_visualization(
        fixed_nc,
        output,
        track=track,
        case_id=case_id,
    )
    manifest = {
        "schema_version": "1.0",
        "mode": "wind",
        "source": "prediction-netcdf",
        "case_id": case_id,
        "typhoon_name": args.typhoon_name,
        "summary": fixed_grid_summary(fixed_nc),
        "loss_input_ready": track is not None,
        "files": {
            "fixed_grid_nc": fixed_nc.name,
            "wind_map": fixed_png.name,
            "track": track.name if track else None,
            "diagnostics": None,
            "prediction_nc": None,
            "interactive_map": interactive_map.name if interactive_map else None,
        },
        "warnings": [visualization_warning] if visualization_warning else [],
        "completed_at_utc": utc_now(),
    }
    write_json(output / "wind_manifest.json", manifest)
    state.update({"status": "complete", "current_stage": None, "completed_at_utc": utc_now()})
    write_json(stage_path, state)
    return manifest


def run_loss(args: argparse.Namespace) -> dict[str, Any]:
    from typhoon_risk_pipeline.exposure import ExposureLayout
    from typhoon_vulnerability.engine import VulnerabilityEngine
    from typhoon_vulnerability.wind import load_wind_field

    output = absolute_path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    stage_path = output / "stage_manifest.json"
    case_id = validate_case_id(args.case)
    input_nc = absolute_path(args.input_nc)
    track = absolute_path(args.track_xlsx)
    state: dict[str, Any] = {
        "schema_version": "1.0",
        "mode": "loss",
        "case_id": case_id,
        "typhoon_name": args.typhoon_name,
        "status": "running",
        "current_stage": "validation",
        "started_at_utc": utc_now(),
    }
    write_json(stage_path, state)
    if not input_nc.is_file():
        raise FileNotFoundError(input_nc)
    if not track.is_file():
        raise FileNotFoundError(track)
    validate_fixed_grid_netcdf(input_nc, case_id)
    # Fail early with a precise NetCDF schema error before loading exposures.
    load_wind_field(input_nc)

    exposure = ExposureLayout.resolve(args.risk_root, args.bundle_root)
    state["current_stage"] = "risk_exposure"
    write_json(stage_path, state)
    config = exposure.module_config(
        impact_threshold_ms=float(args.impact_threshold),
        top_city_count=5,
    )
    state["current_stage"] = "vulnerability"
    write_json(stage_path, state)
    result = VulnerabilityEngine(config).run(
        nc_path=input_nc,
        track_xlsx=track,
        typhoon_name=str(args.typhoon_name),
        event_id=event_id(case_id),
        output_dir=output,
        impact_threshold_ms=float(args.impact_threshold),
    )
    state["current_stage"] = "visualization"
    write_json(stage_path, state)
    interactive_map, visualization_warning = generate_loss_visualization(
        output,
        track=track,
        case_id=case_id,
    )
    # Keep the public manifest useful for the web UI without leaking local
    # runtime/exposure/input paths returned by the upstream engine.
    public_fields = (
        "schema_version",
        "event_id",
        "impact_threshold_ms",
        "impact_detected",
        "affected_provinces",
        "landfall",
        "screening",
        "totals",
        "province_results",
        "top_cities",
    )
    manifest = {key: result[key] for key in public_fields if key in result}
    manifest.update(
        {
            "case_id": case_id,
            "typhoon_name": str(args.typhoon_name),
            "mode": "loss",
            "files": {
                name: name
                for name in (
                    "maximum_wind_distribution.png",
                    "loss_distribution.png",
                    "typhoon_loss_assessment.pdf",
                    "grid_wind.csv",
                    "grid_loss.csv",
                    "vulnerability_curve.csv",
                    "vulnerability_curve.svg",
                    "interactive_loss_map.json",
                )
                if (output / name).is_file()
            },
            "warnings": [visualization_warning] if visualization_warning else [],
        }
    )
    write_json(output / "result_manifest.json", manifest)
    state.update({"status": "complete", "current_stage": None, "completed_at_utc": utc_now()})
    write_json(stage_path, state)
    return manifest


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run independent TyphoonRiskChina stages")
    commands = parser.add_subparsers(dest="command", required=True)

    wind_local = commands.add_parser("wind-local", help="Generate a wind field from a local FNL case")
    wind_local.add_argument("--case", required=True)
    wind_local.add_argument("--typhoon-name", required=True)
    wind_local.add_argument("--case-dir", required=True)
    wind_local.add_argument("--runtime-root", required=True)
    wind_local.add_argument("--track", required=True)
    wind_local.add_argument("--output", required=True)

    wind_inputs = commands.add_parser(
        "wind-inputs",
        help="Generate a wind field from an explicit FNL folder and track workbook",
    )
    wind_inputs.add_argument("--case", required=True)
    wind_inputs.add_argument("--typhoon-name", required=True)
    wind_inputs.add_argument("--fnl-dir", required=True)
    wind_inputs.add_argument("--runtime-root", required=True)
    wind_inputs.add_argument("--track", required=True)
    wind_inputs.add_argument("--output", required=True)

    wind_nc = commands.add_parser("wind-nc", help="Convert a prediction NetCDF to a fixed-grid wind field")
    wind_nc.add_argument("--case", required=True)
    wind_nc.add_argument("--typhoon-name", required=True)
    wind_nc.add_argument("--input-nc", required=True)
    wind_nc.add_argument("--track", default=None)
    wind_nc.add_argument("--output", required=True)

    loss = commands.add_parser("loss", help="Calculate vulnerability and loss from a fixed-grid wind field")
    loss.add_argument("--case", required=True)
    loss.add_argument("--typhoon-name", required=True)
    loss.add_argument("--input-nc", required=True)
    loss.add_argument("--track-xlsx", required=True)
    loss.add_argument("--risk-root", required=True)
    loss.add_argument("--bundle-root", required=True)
    loss.add_argument(
        "--impact-threshold",
        type=float,
        default=DEFAULT_LOSS_IMPACT_THRESHOLD_MS,
    )
    loss.add_argument("--output", required=True)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    output = absolute_path(args.output)
    try:
        if args.command == "wind-local":
            result = run_wind_local(args)
        elif args.command == "wind-inputs":
            result = run_wind_inputs(args)
        elif args.command == "wind-nc":
            result = run_wind_nc(args)
        else:
            result = run_loss(args)
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    except Exception as exc:
        state_path = output / "stage_manifest.json"
        previous: dict[str, Any] = {}
        if state_path.is_file():
            try:
                previous = json.loads(state_path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                previous = {}
        previous.update(
            {
                "status": "failed",
                "current_stage": None,
                "failed_at_utc": utc_now(),
                "error": {
                    "type": type(exc).__name__,
                    "message": str(exc),
                    "traceback": traceback.format_exc(),
                },
            }
        )
        write_json(state_path, previous)
        raise


if __name__ == "__main__":
    main()
