<script setup>
const links = [
  { id: '#top', label: 'Live Weather' },
  { id: '#storm-database', label: 'Storm Archive' },
  { id: '#wind-field', label: 'Wind Field' },
  { id: '#loss', label: 'Loss' },
]

function scrollTo(id) {
  document.querySelector(id)?.scrollIntoView({ behavior: 'smooth' })
}
</script>

<template>
  <nav class="float-nav" aria-label="Section navigation">
    <button
      v-for="link in links"
      :key="link.id"
      class="nav-btn"
      type="button"
      @click="scrollTo(link.id)"
    >
      {{ link.label }}
    </button>
  </nav>
</template>

<style scoped>
.float-nav {
  position: fixed;
  top: 50%;
  right: 1rem;
  transform: translateY(-50%);
  z-index: 1000;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  gap: 0.55rem;
  max-width: calc(100vw - 1.5rem);
  padding: 0.55rem 0.65rem;
  border-radius: 0.85rem;
  background: rgba(248, 252, 253, 0.92);
  border: 1px solid rgba(16, 39, 52, 0.08);
  box-shadow:
    0 10px 30px rgba(8, 24, 34, 0.16),
    0 2px 8px rgba(8, 24, 34, 0.08);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
}

.nav-btn {
  min-height: 2.45rem;
  padding: 0 1.05rem;
  border-radius: 0.5rem;
  font-size: 0.9rem;
  letter-spacing: 0.01em;
  color: var(--deep);
  background: rgba(255, 255, 255, 0.95);
  border: 1px solid rgba(16, 39, 52, 0.08);
  transition:
    transform 0.2s var(--ease),
    background 0.2s var(--ease),
    border-color 0.2s var(--ease),
    box-shadow 0.2s var(--ease);
  white-space: nowrap;
}

.nav-btn:hover {
  transform: translateY(-1px);
  background: #fff;
  border-color: rgba(74, 143, 163, 0.35);
  box-shadow: 0 4px 12px rgba(16, 39, 52, 0.08);
}

@media (max-width: 720px) {
  .float-nav {
    right: 0.45rem;
    gap: 0.4rem;
    padding: 0.45rem 0.5rem;
  }

  .nav-btn {
    min-height: 2.2rem;
    padding: 0 0.55rem;
    font-size: 0.78rem;
  }
}
</style>
