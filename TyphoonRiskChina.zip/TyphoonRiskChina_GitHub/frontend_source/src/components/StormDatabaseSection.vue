<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'

const grades = {
  0: { n: 'Below Tropical Depression Strength', c: '#94a3b8' },
  1: { n: 'Tropical Depression', c: '#2eb872' },
  2: { n: 'Tropical Storm', c: '#27a9e1' },
  3: { n: 'Severe Tropical Storm', c: '#f3cb35' },
  4: { n: 'Typhoon', c: '#f28e2b' },
  5: { n: 'Severe Typhoon', c: '#e64b35' },
  6: { n: 'Super Typhoon', c: '#a51f65' },
  9: { n: 'Extratropical', c: '#6f4b9e' },
}

const meta = ref({ storms: 0, records: 0 })
const storms = ref([])
const year = ref(2025)
const search = ref('')
const selected = ref(null)
const timeline = ref(0)
const currentText = ref('—')
const chartHtml = ref('')
const playLabel = ref('▶')
const loading = ref(true)
const loadError = ref('')

const mapEl = ref(null)

let map = null
let layers = []
let timer = null

const years = Array.from({ length: 77 }, (_, i) => 2025 - i)

const visible = computed(() => {
  const y = year.value
  const q = search.value.trim().toLowerCase()
  return storms.value.filter(
    (s) =>
      s.y === y &&
      (!q ||
        s.name.toLowerCase().includes(q) ||
        s.id.includes(q) ||
        String(s.cn).includes(q)),
  )
})

const maxWindText = computed(() => {
  if (!selected.value) return '—'
  const valid = selected.value.p.map((p) => p[5]).filter((v) => v > 0)
  return valid.length ? `${Math.max(...valid)} m/s` : '—'
})

const minPressureText = computed(() => {
  if (!selected.value) return '—'
  const valid = selected.value.p.map((p) => p[4]).filter((v) => v > 0)
  return valid.length ? `${Math.min(...valid)} hPa` : '—'
})

const maxGradeText = computed(() => {
  if (!selected.value) return '—'
  const mg = Math.max(...selected.value.p.map((p) => p[1]))
  return grades[mg]?.n || 'Unknown'
})

const subtitle = computed(() => {
  if (!selected.value) return ''
  const s = selected.value
  const cn = s.cn === '0000' ? '—' : s.cn
  return `${s.y} · International ID ${s.id} · CMA ID ${cn} · ${s.interval}-hour intervals`
})

function loadCmaData() {
  return new Promise((resolve, reject) => {
    if (window.CMA_DATA) {
      resolve(window.CMA_DATA)
      return
    }
    const script = document.createElement('script')
    script.src = '/cma-data.js'
    script.onload = () => {
      if (window.CMA_DATA) resolve(window.CMA_DATA)
      else reject(new Error('The CMA best-track archive is unavailable.'))
    }
    script.onerror = () => reject(new Error('Unable to load the CMA best-track archive.'))
    document.head.appendChild(script)
  })
}

function peakGrade(s) {
  return Math.max(...s.p.map((p) => p[1]))
}

function fmt(t) {
  return `${t.slice(0, 4)}-${t.slice(4, 6)}-${t.slice(6, 8)} ${t.slice(8)}:00 UTC`
}

function stopPlay() {
  if (timer) {
    clearInterval(timer)
    timer = null
  }
  playLabel.value = '▶'
}

function clearLayers() {
  if (!map) return
  layers.forEach((l) => map.removeLayer(l))
  layers = []
  stopPlay()
}

function drawChart(s) {
  const v = s.p.map((p) => p[5])
  const w = 320
  const h = 88
  const max = Math.max(1, ...v)
  const pts = v
    .map((x, i) => `${(i / (v.length - 1 || 1)) * w},${h - (x / max) * 70}`)
    .join(' ')
  chartHtml.value = `<line x1="0" y1="88" x2="320" y2="88" stroke="#dce5eb"/><polyline points="${pts}" fill="none" stroke="#08717c" stroke-width="2.5"/><text x="2" y="102" font-size="10" fill="#6c7c89">Maximum wind speed (m/s)</text><text x="318" y="14" text-anchor="end" font-size="10" fill="#08717c">${max}</text>`
}

/** Reveal track points one-by-one up to index i; map view stays fixed */
function revealUpTo(i) {
  if (!selected.value || !map) return
  const s = selected.value
  const end = Math.max(0, Math.min(i, s.p.length - 1))

  layers.forEach((l) => map.removeLayer(l))
  layers = []

  for (let j = 1; j <= end; j++) {
    const a = s.p[j - 1]
    const b = s.p[j]
    const line = L.polyline(
      [
        [a[2], a[3]],
        [b[2], b[3]],
      ],
      { color: grades[b[1]]?.c || '#888', weight: 4, opacity: 0.9 },
    ).addTo(map)
    layers.push(line)
  }

  for (let j = 0; j <= end; j++) {
    const p = s.p[j]
    const m = L.circleMarker([p[2], p[3]], {
      radius: j === end ? 6 : j === 0 ? 5 : 3,
      color: '#fff',
      weight: 1,
      fillColor: grades[p[1]]?.c || '#888',
      fillOpacity: 1,
    }).bindTooltip(`${fmt(p[0])}<br>${grades[p[1]]?.n || 'Unknown'} · ${p[5]} m/s · ${p[4]} hPa`)
    m.addTo(map)
    layers.push(m)
  }

  const p = s.p[end]
  currentText.value = `${fmt(p[0])} · ${p[2].toFixed(1)}° N, ${p[3].toFixed(1)}° E`
  timeline.value = end
}

function selectStorm(s) {
  selected.value = s
  if (!map) return
  clearLayers()

  const bounds = L.latLngBounds(s.p.map((p) => [p[2], p[3]]))
  if (bounds.isValid()) map.fitBounds(bounds, { padding: [45, 45], maxZoom: 6 })

  drawChart(s)
  revealUpTo(s.p.length - 1)
}

function onTimelineInput(e) {
  stopPlay()
  revealUpTo(+e.target.value)
}

function togglePlay() {
  if (!selected.value) return
  if (timer) {
    stopPlay()
    return
  }

  // Restart from first point and grow the track one point at a time
  let i = 0
  revealUpTo(0)
  playLabel.value = 'Ⅱ'
  timer = setInterval(() => {
    i += 1
    if (i >= selected.value.p.length) {
      stopPlay()
      return
    }
    revealUpTo(i)
  }, 350)
}

watch(year, () => {
  const list = visible.value
  if (list.length) selectStorm(list[0])
  else {
    selected.value = null
    if (map) clearLayers()
  }
})

watch(search, () => {
  const list = visible.value
  if (list.length && !list.includes(selected.value)) selectStorm(list[0])
})

onMounted(async () => {
  try {
    const data = await loadCmaData()
    meta.value = data.meta
    storms.value = data.storms
    loading.value = false

    await nextTick()
    map = L.map(mapEl.value, { zoomControl: false, preferCanvas: true }).setView([20, 125], 4)
    L.control.zoom({ position: 'bottomright' }).addTo(map)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 8,
      attribution: '© OpenStreetMap contributors',
    }).addTo(map)

    setTimeout(() => map?.invalidateSize(), 120)

    const list = visible.value
    if (list.length) selectStorm(list[0])
  } catch (err) {
    loading.value = false
    loadError.value = err.message || 'Unable to load the storm archive.'
  }
})

onBeforeUnmount(() => {
  if (timer) clearInterval(timer)
  if (map) {
    map.remove()
    map = null
  }
})
</script>

<template>
  <section id="storm-database" class="storm-section" aria-label="Historical Storm Database">
    <div class="storm-intro">
      <h2>Historical Storm Database</h2>
    </div>

    <div v-if="loading" class="state-panel" role="status">Loading the CMA best-track archive…</div>
    <div v-else-if="loadError" class="state-panel error">{{ loadError }}</div>

    <div v-else class="cma-app">
      <header class="top">
        <div class="brand">
          Typhoon Track Archive
          <small>CMA BEST-TRACK DATA · 1949–2025</small>
        </div>
        <div class="top-stats">
          <div>
            <b>{{ meta.storms.toLocaleString() }}</b>
            <span>Tropical cyclones</span>
          </div>
          <div>
            <b>{{ meta.records.toLocaleString() }}</b>
            <span>Track records</span>
          </div>
        </div>
      </header>

      <div class="layout">
        <aside class="sidebar">
          <div class="filters">
            <div class="filter-row">
              <div>
                <label for="cma-year">Year</label>
                <select id="cma-year" v-model.number="year">
                  <option v-for="y in years" :key="y" :value="y">{{ y }}</option>
                </select>
              </div>
              <div>
                <label for="cma-search">Name / ID</label>
                <input
                  id="cma-search"
                  v-model="search"
                  type="search"
                  placeholder="e.g. WUTIP or 2501"
                />
              </div>
            </div>
          </div>

          <div class="storm-list">
            <button
              v-for="s in visible"
              :key="`${s.y}-${s.serial}-${s.name}`"
              type="button"
              class="storm"
              :class="{ active: selected === s }"
              @click="selectStorm(s)"
            >
              <b>{{ s.name }}</b>
              <span>International ID {{ s.id }} · {{ s.p.length }} track points</span>
              <i class="badge" :style="{ background: grades[peakGrade(s)]?.c || '#888' }">
                {{ grades[peakGrade(s)]?.n || 'Unknown' }}
              </i>
            </button>
            <div v-if="!visible.length" class="empty">No storms match these filters.</div>
          </div>
        </aside>

        <div class="main">
          <div ref="mapEl" class="map"></div>

          <section class="info">
            <div class="info-head">
              <h3>{{ selected ? selected.name : 'Select a storm' }}</h3>
              <p>{{ subtitle }}</p>
            </div>
            <div class="cards">
              <div class="card">
                <span>Maximum wind speed</span>
                <b>{{ maxWindText }}</b>
              </div>
              <div class="card">
                <span>Minimum pressure</span>
                <b>{{ minPressureText }}</b>
              </div>
              <div class="card">
                <span>Peak intensity</span>
                <b>{{ maxGradeText }}</b>
              </div>
            </div>
            <div class="timeline">
              <div class="time-row">
                <button class="play" type="button" aria-label="Play" @click="togglePlay">
                  {{ playLabel }}
                </button>
                <input
                  class="range"
                  type="range"
                  min="0"
                  :max="selected ? selected.p.length - 1 : 0"
                  :value="timeline"
                  :disabled="!selected"
                  @input="onTimelineInput"
                />
              </div>
              <div class="current">{{ currentText }}</div>
              <svg
                class="chart"
                viewBox="0 0 320 105"
                preserveAspectRatio="none"
                v-html="chartHtml"
              ></svg>
            </div>
            <div class="legend">
              <span v-for="(g, k) in grades" :key="k" class="legend-item">
                <i class="dot" :style="{ background: g.c }"></i>
                {{ k }} {{ g.n }}
              </span>
            </div>
          </section>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.storm-section {
  padding: clamp(2.5rem, 5vw, 3.5rem) clamp(1rem, 2.5vw, 2rem);
  background: linear-gradient(180deg, #f8fbfc 0%, #eef5f7 100%);
}

.storm-intro {
  max-width: 1600px;
  margin: 0 auto 1.25rem;
}

h2 {
  font-family: var(--font-display);
  font-weight: 400;
  font-size: clamp(1.85rem, 3.5vw, 2.5rem);
  line-height: 1.2;
  color: var(--ink);
}

.state-panel {
  max-width: 1600px;
  margin: 0 auto;
  min-height: 320px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid var(--line);
  border-radius: 0.75rem;
  background: rgba(255, 255, 255, 0.85);
  color: var(--ink-soft);
}

.state-panel.error {
  color: #b42318;
}

.cma-app {
  max-width: 1600px;
  margin: 0 auto;
  height: min(92vh, 980px);
  min-height: 720px;
  display: grid;
  grid-template-rows: auto 1fr;
  border: 1px solid var(--line);
  border-radius: 0.85rem;
  overflow: hidden;
  background: #edf3f5;
  box-shadow: 0 10px 30px rgba(16, 39, 52, 0.06);
}

.top {
  display: flex;
  align-items: center;
  gap: 20px;
  padding: 14px 18px;
  background: #092b3c;
  color: #fff;
}

.brand {
  font-weight: 700;
  letter-spacing: 0.03em;
  font-size: 1rem;
}

.brand small {
  display: block;
  color: #a8cad2;
  font-size: 11px;
  font-weight: 500;
  margin-top: 2px;
}

.top-stats {
  display: flex;
  gap: 24px;
  margin-left: auto;
}

.top-stats b {
  display: block;
  font-size: 18px;
}

.top-stats span {
  font-size: 11px;
  color: #a8cad2;
}

.layout {
  min-height: 0;
  display: grid;
  grid-template-columns: 340px 1fr;
}

.sidebar {
  background: #fff;
  border-right: 1px solid #dce5eb;
  display: flex;
  flex-direction: column;
  min-height: 0;
}

.filters {
  padding: 14px;
  border-bottom: 1px solid #dce5eb;
}

label {
  font-size: 12px;
  font-weight: 700;
  color: #48606f;
  display: block;
  margin-bottom: 6px;
}

.filter-row {
  display: grid;
  grid-template-columns: 96px 1fr;
  gap: 8px;
}

select,
input {
  width: 100%;
  border: 1px solid #c9d6dd;
  border-radius: 8px;
  padding: 9px 10px;
  background: #fff;
  color: var(--ink);
  outline: none;
  font: inherit;
}

select:focus,
input:focus {
  border-color: #278794;
  box-shadow: 0 0 0 3px #27879420;
}

.storm-list {
  overflow: auto;
  padding: 8px;
}

.storm {
  width: 100%;
  border: 0;
  background: transparent;
  text-align: left;
  padding: 11px 12px;
  border-radius: 9px;
  cursor: pointer;
  color: var(--ink);
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 3px 8px;
}

.storm:hover {
  background: #f0f6f7;
}

.storm.active {
  background: #dceff0;
  color: #064f58;
}

.storm b {
  font-size: 14px;
}

.storm span {
  font-size: 11px;
  color: #6c7c89;
}

.storm .badge {
  grid-row: 1 / 3;
  grid-column: 2;
  align-self: center;
  color: #fff;
  font-size: 10px;
  padding: 3px 6px;
  border-radius: 10px;
  font-style: normal;
  max-width: 7.5rem;
  text-align: center;
  line-height: 1.25;
}

.empty {
  padding: 28px;
  text-align: center;
  color: #6c7c89;
}

.main {
  position: relative;
  min-width: 0;
  min-height: 0;
}

.map {
  height: 100%;
  background: #dfecef;
}

.info {
  position: absolute;
  z-index: 900;
  top: 14px;
  right: 14px;
  width: min(340px, calc(100% - 28px));
  background: #ffffffed;
  border: 1px solid #fff;
  border-radius: 14px;
  box-shadow: 0 10px 30px #17394c2b;
  backdrop-filter: blur(10px);
  overflow: hidden;
}

.info-head {
  padding: 14px 15px 11px;
  border-bottom: 1px solid #dce5eb;
}

.info-head h3 {
  font-size: 18px;
  margin: 0 0 4px;
  font-weight: 600;
}

.info-head p {
  font-size: 12px;
  color: #6c7c89;
  margin: 0;
}

.cards {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1px;
  background: #dce5eb;
}

.card {
  background: #fff;
  padding: 10px;
}

.card span {
  font-size: 10px;
  color: #6c7c89;
  display: block;
}

.card b {
  font-size: 14px;
}

.timeline {
  padding: 12px 15px;
}

.time-row {
  display: flex;
  align-items: center;
  gap: 9px;
}

.play {
  width: 34px;
  height: 34px;
  border: 0;
  border-radius: 50%;
  background: #0b6671;
  color: #fff;
  cursor: pointer;
  flex-shrink: 0;
}

.range {
  width: 100%;
  accent-color: #0b6671;
}

.current {
  font-size: 12px;
  font-weight: 700;
  margin: 8px 0 4px;
}

.chart {
  height: 105px;
  width: 100%;
  display: block;
}

.legend {
  display: flex;
  flex-wrap: wrap;
  gap: 7px 11px;
  padding: 0 15px 13px;
}

.legend-item {
  font-size: 10px;
  color: #526572;
  display: flex;
  align-items: center;
  gap: 4px;
}

.dot {
  width: 9px;
  height: 9px;
  border-radius: 50%;
  display: inline-block;
}

@media (max-width: 900px) {
  .cma-app {
    height: auto;
    min-height: 0;
  }

  .layout {
    grid-template-columns: 1fr;
    grid-template-rows: 260px 62vh;
  }

  .sidebar {
    border-right: 0;
    border-bottom: 1px solid #dce5eb;
  }

  .info {
    top: 10px;
    right: 10px;
    width: calc(100% - 20px);
    max-width: 340px;
  }

  .brand small {
    display: none;
  }
}
</style>
