<template>
  <footer id="about" class="footer">
    <div class="footer-inner">
      <span class="name">TyphoonRiskChina</span>
    </div>
  </footer>
</template>

<style scoped>
.footer {
  border-top: 1px solid var(--line);
  padding: 2rem clamp(1.25rem, 4vw, 3.5rem) 2.4rem;
  background: #f5f9fb;
}

.footer-inner {
  max-width: 1080px;
  margin: 0 auto;
  display: flex;
  justify-content: center;
  text-align: center;
}

.name {
  font-family: var(--font-display);
  font-size: 1.35rem;
  letter-spacing: 0.04em;
}

</style>
