<script setup>
const windySrc =
  'https://embed.windy.com/embed2.html?' +
  new URLSearchParams({
    lat: '35.0',
    lon: '105.0',
    detailLat: '35.0',
    detailLon: '105.0',
    zoom: '4',
    level: 'surface',
    overlay: 'wind',
    product: 'ecmwf',
    menu: '',
    message: 'true',
    marker: '',
    calendar: 'now',
    pressure: '',
    type: 'map',
    location: 'coordinates',
    detail: '',
    metricWind: 'default',
    metricTemp: 'default',
    radarRange: '-1',
    lang: 'en',
  }).toString()
</script>

<template>
  <section id="top" class="hero" aria-label="Live Weather">
    <iframe
      class="windy-frame"
      :src="windySrc"
      title="Live Weather"
      loading="eager"
      tabindex="-1"
      referrerpolicy="no-referrer-when-downgrade"
    />
    <div class="map-lock" aria-hidden="true"></div>
    <div class="scrim" aria-hidden="true"></div>

    <div class="hero-content">
      <p class="brand-signal">TyphoonRiskChina</p>
      <p class="lead">
        An open-source framework for forecast-driven typhoon wind-field downscaling and loss
        assessment in coastal China
      </p>
    </div>

    <a
      class="windy-attribution"
      href="https://www.windy.com/"
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Weather source attribution: Windy.com"
    >
      <img src="/branding/windy-logo-white.svg" alt="Windy.com" />
      <span>Source: Windy.com | Live weather</span>
    </a>
  </section>
</template>

<style scoped>
.hero {
  position: relative;
  min-height: 100vh;
  min-height: 100dvh;
  display: flex;
  align-items: flex-end;
  overflow: hidden;
  color: #f4fafc;
  background: #0b1c24;
  touch-action: none;
  user-select: none;
}

.windy-frame {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  border: 0;
  display: block;
  pointer-events: none;
}

.map-lock {
  position: absolute;
  inset: 0;
  z-index: 1;
  cursor: default;
}

.scrim {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 2;
  height: min(62%, 520px);
  pointer-events: none;
  background: linear-gradient(
    180deg,
    transparent 0%,
    rgba(8, 24, 34, 0.28) 40%,
    rgba(8, 24, 34, 0.78) 100%
  );
}

.hero-content {
  position: relative;
  z-index: 3;
  width: min(960px, 100%);
  padding: 0 clamp(1.25rem, 4vw, 3.5rem) clamp(3.5rem, 8vh, 5.5rem);
  pointer-events: auto;
  margin-right: auto;
  animation: rise 1.1s var(--ease) 0.15s both;
}

.windy-attribution {
  position: absolute;
  left: clamp(1.25rem, 4vw, 3.5rem);
  bottom: max(1rem, env(safe-area-inset-bottom));
  z-index: 4;
  display: inline-flex;
  align-items: center;
  gap: 0.65rem;
  min-height: 2.25rem;
  padding: 0.35rem 0.65rem;
  border-radius: 0.3rem;
  color: #f4fafc;
  background: rgba(10, 32, 43, 0.92);
  font-size: 0.72rem;
  line-height: 1.2;
  text-decoration: none;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.18);
}

.windy-attribution img {
  display: block;
  width: 4.4rem;
  height: auto;
}

.windy-attribution:hover,
.windy-attribution:focus-visible {
  background: rgba(10, 32, 43, 0.99);
  text-decoration: underline;
  outline: 2px solid #fff;
  outline-offset: 2px;
}

.brand-signal {
  font-family: var(--font-body);
  font-weight: 600;
  font-size: clamp(2.2rem, 5.5vw, 3.8rem);
  letter-spacing: 0.02em;
  line-height: 1.15;
  max-width: 14em;
  margin-bottom: 1.1rem;
  text-shadow: 0 8px 40px rgba(8, 24, 34, 0.35);
}

.lead {
  font-size: clamp(0.98rem, 2vw, 1.1rem);
  font-weight: 300;
  line-height: 1.65;
  color: rgba(232, 244, 248, 0.88);
  max-width: 34em;
  margin-bottom: 0;
}

@keyframes rise {
  from {
    opacity: 0;
    transform: translateY(28px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 640px) {
  .hero-content {
    padding-bottom: 3rem;
  }
}
</style>
