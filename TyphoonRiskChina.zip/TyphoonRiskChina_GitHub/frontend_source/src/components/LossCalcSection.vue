<script setup>
import { computed, onBeforeUnmount, onMounted, reactive, ref, shallowRef } from 'vue'
import InteractiveResultMap from './InteractiveResultMap.vue'
import VulnerabilityCurve from './VulnerabilityCurve.vue'

const FNL_MAX_FILES = 5000
const TRACK_MAX_BYTES = 32 * 1024 * 1024
const DEFAULT_IMPACT_THRESHOLD_MS = 17.3

const windSteps = [
  { key: 'validation', label: 'Validate inputs and case materials' },
  { key: 'wind_field', label: 'Generate the fixed-grid wind field' },
  { key: 'artifacts', label: 'Package wind-field outputs' },
]

const lossSteps = [
  { key: 'validation', label: 'Validate wind-field and track data' },
  { key: 'exposure', label: 'Match exposure grids' },
  { key: 'vulnerability', label: 'Calculate vulnerability and loss' },
  { key: 'artifacts', label: 'Generate maps and reports' },
]

const artifactLabels = {
  'track-composite-map': 'Storm-track composite wind map (PNG)',
  'track-composite-nc': 'Storm-track composite wind field (NetCDF)',

  'fixed-wind-nc': 'Fixed-grid wind field (NetCDF)',
  'fixed-grid-nc': 'Fixed-grid wind field (NetCDF)',
  'fixed-grid-png': 'Fixed-grid wind-field map',
  'wind-map': 'Maximum wind-speed map',
  'wind-manifest': 'Wind-field output manifest',
  'hourly-summary': 'Hourly wind-field summary',
  diagnostics: 'Hourly wind-field diagnostics',
  'loss-input-package': 'Loss-module input package',
  'loss-map': 'Loss distribution map',
  'vulnerability-curve': 'Vulnerability curve (CSV)',
  report: 'Typhoon loss assessment report',
  'grid-wind': 'Grid wind-speed CSV',
  'grid-loss': 'Grid loss CSV',
  'result-manifest': 'Loss output manifest',
  'pipeline-manifest': 'Pipeline manifest',
  'interactive-map': 'Interactive map data',
}

const windBundleTypes = [
  { key: 'nc', short: 'NC', label: 'NetCDF data' },
  { key: 'png', short: 'PNG', label: 'Map image' },
  { key: 'csv', short: 'CSV', label: 'Summary table' },
  { key: 'xlsx', short: 'XLSX', label: 'Track workbook' },
  { key: 'zip', short: 'ZIP', label: 'Input package' },
]
const lossBundleTypes = [
  { key: 'csv', short: 'CSV', label: 'Grid data tables' },
  { key: 'png', short: 'PNG', label: 'Result maps' },
  { key: 'pdf', short: 'PDF', label: 'Assessment report' },
  { key: 'json', short: 'JSON', label: 'Machine-readable results' },
  { key: 'zip', short: 'ZIP', label: 'Complete result package' },
]

const healthOk = ref(null)
const windLocalReady = ref(null)
const lossAlgorithmReady = ref(null)
const algorithmIssues = ref([])
const healthText = ref('Connecting to the local computation service…')

const fnlFolderInput = ref(null)
const trackFileInput = ref(null)
const fnlManifest = ref([])
const trackFile = shallowRef(null)
const fnlSelection = reactive({
  selected: false,
  verified: false,
  rootName: '',
  fileCount: 0,
  totalBytes: 0,
})
const trackSelection = reactive({
  selected: false,
  verified: false,
  name: '',
  size: 0,
})
const windInputs = reactive({
  validating: false,
  verified: false,
  token: '',
  caseId: '',
  typhoonName: '',
  fnlCount: 0,
  totalBytes: 0,
  trackName: '',
  error: '',
})
let windInputVersion = 0

const latestWind = ref(null)
const windRankingRows = ref([])
const pollTimers = new Map()
const pollFailureCounts = new Map()
const WIND_JOB_STORAGE_KEY = 'typhoonriskchina.active-wind-job'

function createRunState() {
  return reactive({
    running: false,
    jobId: '',
    source: '',
    caseKey: '',
    caseId: '',
    typhoonName: '',
    progress: 0,
    stage: 'validation',
    activeStep: -1,
    message: 'Preparing',
    error: '',
    warnings: [],
    result: null,
    downloadUrl: '',
  })
}

const windRun = createRunState()
const lossRun = createRunState()

function clearCompletedRun(run) {
  if (run.running) return
  Object.assign(run, {
    jobId: '',
    source: '',
    caseKey: '',
    caseId: '',
    typhoonName: '',
    progress: 0,
    stage: 'validation',
    activeStep: -1,
    message: 'Preparing',
    error: '',
    warnings: [],
    result: null,
    downloadUrl: '',
  })
}

function clearWindHandoff() {
  latestWind.value = null
  clearCompletedRun(lossRun)
}

const serviceBusy = computed(() => windRun.running || lossRun.running)

const canStartWind = computed(
  () =>
    !serviceBusy.value &&
    windLocalReady.value === true &&
    fnlSelection.verified &&
    trackSelection.verified &&
    windInputs.verified &&
    Boolean(windInputs.token),
)

const canStartLoss = computed(
  () => !serviceBusy.value && lossAlgorithmReady.value === true && Boolean(latestWind.value?.ready),
)

const windSummary = computed(() => windRun.result?.summary || {})
const lossSummary = computed(() => lossRun.result?.summary || {})
const lossTotals = computed(() => lossSummary.value.totals || {})

const windReadyForLoss = computed(
  () => Boolean(windRun.result) && windSummary.value.loss_input_ready !== false,
)

const lossMetrics = computed(() => {
  const exposure = finiteNumber(
    lossTotals.value.exposure_value ?? lossTotals.value.total_exposure,
  )
  const total = finiteNumber(lossTotals.value.total_loss)
  return [
    { label: 'Total modeled loss', value: `￥${money(total)}` },
    { label: 'Total exposure', value: `￥${money(exposure)}` },
    {
      label: 'Loss ratio',
      value: exposure > 0 ? `${((total / exposure) * 100).toFixed(4)}%` : '—',
    },
    {
      label: 'Cells above threshold',
      value: integer(lossSummary.value.grids_at_or_above_impact_threshold),
    },
  ]
})

const lossProvinceRows = computed(() =>
  (lossRun.result?.by_province || [])
    .map((row) => {
      const province = row.province_en || row.province_name_en || row.province_name || row.province
      const value = Number(row.total_loss)
      return { province: String(province || ''), value: Number.isFinite(value) ? value : 0 }
    })
    .filter((row) => row.province && row.value > 0)
    .sort((left, right) => right.value - left.value)
    .map((row) => ({ ...row, loss: `￥${money(row.value)}` })),
)

const lossRankingRows = computed(() =>
  (lossRun.result?.by_city || [])
    .map((row) => {
      const city = row.city_en || row.city_name_en || row.city || row.city_name
      const province = row.province_en || row.province_name_en || row.province_name || row.province
      const value = Number(row.total_loss)
      return {
        region: [city, province].filter(Boolean).join(', ') || 'Unassigned',
        value: Number.isFinite(value) ? value : 0,
      }
    })
    .filter((row) => row.value > 0 && row.region !== 'Unassigned')
    .sort((left, right) => right.value - left.value)
    .map((row) => ({ ...row, loss: `￥${money(row.value)}` })),
)

const lossTrackCells = computed(() => {
  const summary = lossSummary.value
  const landfall = summary.landfall
  if (landfall) {
    return [
      { label: 'Landfall time', value: displayTime(landfall.time) },
      {
        label: 'Landfall location',
        value: [landfall.city_name_en || landfall.city_name, landfall.province_name_en || landfall.province_name]
          .filter(Boolean)
          .join(', ') || '—',
      },
      { label: 'Latitude', value: coordinate(landfall.latitude) },
      { label: 'Longitude', value: coordinate(landfall.longitude) },
      { label: 'Landfall wind speed', value: windSpeed(landfall.track_wind_ms) },
    ]
  }
  const affected = Array.isArray(summary.affected_provinces) ? summary.affected_provinces : []
  return [
    { label: 'Affected provinces', value: affected.length ? affected.join(', ') : '—' },
    { label: 'Maximum wind speed', value: windSpeed(summary.max_wind_ms) },
  ]
})

const windResultMeta = computed(() => {
  if (!windRun.result) return ''
  return `${windSummary.value.typhoon_name || windRun.typhoonName || '—'} · ${windSummary.value.case_id || windRun.caseId || '—'} · Wind field`
})

const lossResultMeta = computed(() => {
  if (!lossRun.result) return ''
  return `${lossSummary.value.typhoon_name || lossRun.typhoonName || '—'} · ${lossSummary.value.case_id || lossRun.caseId || '—'} · ${integer(lossSummary.value.grid_count)} grid cells`
})

function finiteNumber(value, fallback = 0) {
  const number = Number(value)
  return Number.isFinite(number) ? number : fallback
}

function integer(value) {
  const number = Number(value)
  return Number.isFinite(number) ? Math.round(number).toLocaleString('en-US') : '—'
}

function windSpeed(value) {
  const number = Number(value)
  return Number.isFinite(number) ? `${number.toFixed(2)} m/s` : '—'
}

function coordinate(value) {
  const number = Number(value)
  return Number.isFinite(number) ? `${number.toFixed(3)}°` : '—'
}

function displayTime(value) {
  if (!value) return '—'
  const raw = String(value).trim().replace(/(\.\d{3})\d+/, '$1')
  const timestamp = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(raw) ? raw : `${raw}Z`
  const date = new Date(timestamp)
  if (Number.isNaN(date.getTime())) return String(value)
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date)
  const part = (type) => parts.find((item) => item.type === type)?.value || ''
  return `${part('year')}-${part('month')}-${part('day')} ${part('hour')}:${part('minute')}:${part('second')}`
}

function money(value) {
  const number = finiteNumber(value)
  return number.toLocaleString('en-US', { maximumFractionDigits: 2 })
}

function formatBytes(bytes) {
  const units = ['B', 'KB', 'MB', 'GB']
  let value = Number(bytes) || 0
  let unit = 0
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024
    unit += 1
  }
  return `${value.toFixed(unit ? 1 : 0)} ${units[unit]}`
}

function normalizeWarnings(value) {
  const values = Array.isArray(value) ? value : value ? [value] : []
  return values
    .map((item) => localizeWarning(String(item || '').trim()))
    .filter(Boolean)
}

function localizeWarning(message) {
  return message
}

function mergeWarnings(run, value) {
  run.warnings = [...new Set([...run.warnings, ...normalizeWarnings(value)])]
}

function normalizeArtifacts(artifacts) {
  const entries = Array.isArray(artifacts)
    ? artifacts.map((item, index) => [String(index), item])
    : Object.entries(artifacts || {})

  return entries
    .map(([key, item]) => {
      const value = typeof item === 'string' ? { url: item } : item || {}
      const url = String(value.url || value.href || value.download_url || '')
      if (!url.startsWith('/') && !/^https?:\/\//i.test(url)) return null
      return {
        key,
        label: String(value.label || value.name || artifactLabels[key] || key.replaceAll('_', ' ')),
        url,
        meta: [value.type || value.format, value.size || value.size_text]
          .filter(Boolean)
          .join(' · '),
      }
    })
    .filter(Boolean)
}

async function checkHealth() {
  try {
    const response = await fetch('/api/health')
    if (!response.ok) throw new Error()
    const body = await response.json()
    const engines = body?.engines || {}
    const windReady =
      (engines.wind?.inputs?.ready ?? engines.wind?.local?.ready ?? engines.wind?.ready) === true
    const lossReady = engines.loss?.ready === true
    windLocalReady.value = windReady
    lossAlgorithmReady.value = lossReady
    algorithmIssues.value = [
      ...(Array.isArray(engines.wind?.issues) ? engines.wind.issues : []),
      ...(Array.isArray(engines.wind?.inputs?.issues) ? engines.wind.inputs.issues : []),
      ...(Array.isArray(engines.wind?.local?.issues) ? engines.wind.local.issues : []),
      ...(Array.isArray(engines.loss?.issues) ? engines.loss.issues : []),
    ].filter((issue, index, values) => issue && values.indexOf(issue) === index)
    healthOk.value = windReady || lossReady
    if (windReady && lossReady) {
      healthText.value = 'Local service, wind-field engine, and loss engine are ready'
    } else {
      const readyModules = [windReady ? 'wind-field' : '', lossReady ? 'loss' : ''].filter(Boolean)
      const unavailableModules = [!windReady ? 'wind-field' : '', !lossReady ? 'loss' : ''].filter(Boolean)
      healthText.value = `Local service connected. ${readyModules.length ? `${readyModules.join(' and ')} module${readyModules.length > 1 ? 's are' : ' is'} available. ` : ''}${unavailableModules.join(' and ')} module${unavailableModules.length > 1 ? 's are' : ' is'} unavailable${algorithmIssues.value.length ? `: ${algorithmIssues.value.join('; ')}` : '.'}`
    }
  } catch {
    healthOk.value = false
    windLocalReady.value = false
    lossAlgorithmReady.value = false
    algorithmIssues.value = []
    healthText.value = 'The computation service is offline. Restart the local website service.'
  }
}

function rootNameFromFiles(files) {
  const firstPath = String(files[0]?.webkitRelativePath || files[0]?.name || '').replaceAll('\\', '/')
  return firstPath.split('/').filter(Boolean)[0] || ''
}

function invalidateWindInputs(error = '') {
  windInputVersion += 1
  clearWindHandoff()
  clearCompletedRun(windRun)
  Object.assign(windInputs, {
    validating: false,
    verified: false,
    token: '',
    caseId: '',
    typhoonName: '',
    fnlCount: 0,
    totalBytes: 0,
    trackName: '',
    error,
  })
  fnlSelection.verified = false
  trackSelection.verified = false
  windRun.error = ''
}

function chooseFnlFolder() {
  if (!fnlFolderInput.value || windInputs.validating || windRun.running) return
  fnlFolderInput.value.value = ''
  fnlFolderInput.value.click()
}

function chooseTrackWorkbook() {
  if (!trackFileInput.value || windInputs.validating || windRun.running) return
  trackFileInput.value.value = ''
  trackFileInput.value.click()
}

async function onFnlFolderChange(event) {
  const files = [...(event.target.files || [])]
  if (!files.length) return
  invalidateWindInputs()

  const netcdfFiles = files.filter((file) => /\.nc$/i.test(String(file.name || '')))
  if (netcdfFiles.length < 2) {
    fnlManifest.value = []
    Object.assign(fnlSelection, {
      selected: false,
      verified: false,
      rootName: '',
      fileCount: 0,
      totalBytes: 0,
    })
    windInputs.error = 'Select a folder containing the complete FNL sequence of .nc files.'
    return
  }
  if (netcdfFiles.length > FNL_MAX_FILES) {
    windInputs.error = `The selected folder contains ${netcdfFiles.length.toLocaleString('en-US')} NetCDF files. The validator accepts up to ${FNL_MAX_FILES.toLocaleString('en-US')} manifest entries.`
    return
  }

  const rootName = rootNameFromFiles(netcdfFiles)
  const rootNames = new Set(netcdfFiles.map((file) => rootNameFromFiles([file])))
  if (!rootName || rootNames.size !== 1) {
    windInputs.error = 'The selected NetCDF files must come from one folder.'
    return
  }

  const manifest = netcdfFiles.map((file) => ({
    path: String(file.webkitRelativePath || file.name || '').replaceAll('\\', '/'),
    size: Number(file.size) || 0,
    last_modified_ms: Number(file.lastModified) || null,
  }))
  fnlManifest.value = manifest
  Object.assign(fnlSelection, {
    selected: true,
    verified: false,
    rootName,
    fileCount: manifest.length,
    totalBytes: manifest.reduce((total, item) => total + item.size, 0),
  })
  await validateWindInputs()
}

async function onTrackFileChange(event) {
  const files = [...(event.target.files || [])]
  if (!files.length) return
  invalidateWindInputs()

  if (files.length !== 1 || !/\.xlsx$/i.test(String(files[0]?.name || ''))) {
    trackFile.value = null
    Object.assign(trackSelection, {
      selected: false,
      verified: false,
      name: '',
      size: 0,
    })
    windInputs.error = 'Select exactly one Excel track workbook (.xlsx).'
    return
  }

  const file = files[0]
  if (file.size > TRACK_MAX_BYTES) {
    windInputs.error = `The track workbook is ${formatBytes(file.size)}, which exceeds the ${formatBytes(TRACK_MAX_BYTES)} limit.`
    return
  }

  trackFile.value = file
  Object.assign(trackSelection, {
    selected: true,
    verified: false,
    name: file.name,
    size: file.size,
  })
  await validateWindInputs()
}

async function validateWindInputs() {
  if (!fnlSelection.selected || !fnlManifest.value.length || !trackSelection.selected || !trackFile.value) {
    return
  }

  const requestVersion = ++windInputVersion
  windInputs.validating = true
  windInputs.verified = false
  windInputs.token = ''
  windInputs.error = ''
  fnlSelection.verified = false
  trackSelection.verified = false

  try {
    const form = new FormData()
    form.append('root_name', fnlSelection.rootName)
    form.append('fnl_manifest', JSON.stringify(fnlManifest.value))
    form.append('track_file', trackFile.value, trackSelection.name)
    const body = await requestJson('/api/wind/inputs/validate', { method: 'POST', body: form }, 'wind')
    if (requestVersion !== windInputVersion) return
    if (body?.status !== 'ready' || !body?.input_token) {
      throw new Error('The local service could not verify the two wind-field inputs.')
    }

    const identity = body.identity || {}
    Object.assign(windInputs, {
      validating: false,
      verified: true,
      token: String(body.input_token),
      caseId: String(identity.case_id || ''),
      typhoonName: String(identity.typhoon_name || ''),
      fnlCount: finiteNumber(body.fnl_count, fnlSelection.fileCount),
      totalBytes: finiteNumber(body.total_bytes, fnlSelection.totalBytes),
      trackName: String(body.track_name || trackSelection.name),
      error: '',
    })
    fnlSelection.verified = true
    trackSelection.verified = true
  } catch (error) {
    if (requestVersion !== windInputVersion) return
    windInputs.validating = false
    windInputs.error = error.message || 'The two wind-field inputs could not be verified.'
  }
}

async function responseError(response, kind) {
  if (response.status === 413) {
    return `The ${kind === 'wind' ? 'track workbook' : 'loss request'} exceeds the local service limit.`
  }
  try {
    const body = await response.json()
    const detail = body.detail ?? body.error ?? body.message
    if (Array.isArray(detail)) {
      return detail.map((item) => item.msg || item.message || String(item)).join('; ')
    }
    const message = typeof detail === 'object' ? detail?.message : detail
    if (/parsing the body/i.test(String(message || ''))) {
      return 'The request could not be parsed. Confirm that the selected input matches the required format and size.'
    }
    return String(message || `Request failed (HTTP ${response.status}).`)
  } catch {
    return `Request failed (HTTP ${response.status}).`
  }
}

async function requestJson(url, options, kind) {
  const response = await fetch(url, options)
  if (!response.ok) throw new Error(await responseError(response, kind))
  return response.json()
}

function beginRun(run, context) {
  clearPoll(context.module)
  Object.assign(run, {
    running: true,
    jobId: '',
    source: context.source,
    caseKey: context.caseKey || '',
    caseId: context.caseId || '',
    typhoonName: context.typhoonName || '',
    progress: 4,
    stage: 'validation',
    activeStep: 0,
    message: context.message || 'Validating input data',
    error: '',
    warnings: [],
    result: null,
    downloadUrl: '',
  })
}

function failRun(run, message) {
  run.running = false
  run.error = String(message || 'The calculation could not be completed.')
}

async function startWindCalculation() {
  if (!canStartWind.value) return
  windRankingRows.value = []
  clearWindHandoff()
  const context = {
    module: 'wind',
    source: 'inputs',
    caseKey: '',
    caseId: windInputs.caseId,
    typhoonName: windInputs.typhoonName,
    message: `Loading ${windInputs.fnlCount || fnlSelection.fileCount} FNL files and the verified track workbook`,
  }

  beginRun(windRun, context)
  try {
    const job = await requestJson(
      '/api/wind/jobs/inputs',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input_token: windInputs.token }),
      },
      'wind',
    )
    if (!job?.job_id) throw new Error('The computation service did not return a job ID.')
    // The backend token is one-use. Keep the verified labels for this active
    // run, but never offer the consumed token for a second calculation.
    windInputs.token = ''
    windRun.jobId = String(job.job_id)
    try { sessionStorage.setItem(WIND_JOB_STORAGE_KEY, windRun.jobId) } catch {}
    mergeWarnings(windRun, job.warnings)
    updateJobProgress(windRun, 'wind', job)
    pollJob('wind', windRun.jobId)
  } catch (error) {
    windInputs.token = ''
    windInputs.verified = false
    fnlSelection.verified = false
    trackSelection.verified = false
    windInputs.error = 'Verify both selected inputs again before retrying.'
    failRun(windRun, error.message)
  }
}

function setWindRankingRows(rows) {
  windRankingRows.value = Array.isArray(rows) ? rows : []
}

async function startLossCalculation() {
  if (!canStartLoss.value) return
  const context = {
    module: 'loss',
    source: 'from-wind',
    caseKey: latestWind.value.caseKey,
    caseId: latestWind.value.caseId,
    typhoonName: latestWind.value.typhoonName,
    message: `Loading the ${latestWind.value.typhoonName} wind-field result`,
  }

  beginRun(lossRun, context)
  try {
    const job = await requestJson(
      '/api/loss/jobs/from-wind',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          wind_job_id: latestWind.value.jobId,
          impact_threshold_ms: DEFAULT_IMPACT_THRESHOLD_MS,
        }),
      },
      'loss',
    )
    if (!job?.job_id) throw new Error('The computation service did not return a job ID.')
    lossRun.jobId = String(job.job_id)
    mergeWarnings(lossRun, job.warnings)
    updateJobProgress(lossRun, 'loss', job)
    pollJob('loss', lossRun.jobId)
  } catch (error) {
    failRun(lossRun, error.message)
  }
}

function stageState(module, job) {
  const progress = typeof job.progress === 'object' && job.progress ? job.progress : {}
  const raw = String(
    progress.stage ||
      job.current_stage ||
      job.algorithm?.current_stage ||
      job.algorithm?.stage ||
      job.stage ||
      'validation',
  ).toLowerCase()
  const aliases =
    module === 'wind'
      ? {
          queued: 'validation',
          input_validation: 'validation',
          downscaling: 'wind_field',
          prediction: 'wind_field',
          fixed_grid: 'wind_field',
          packaging: 'artifacts',
          report: 'artifacts',
          visualization: 'artifacts',
        }
      : {
          queued: 'validation',
          input_validation: 'validation',
          risk_exposure: 'exposure',
          exposure_matching: 'exposure',
          loss: 'vulnerability',
          report: 'artifacts',
          packaging: 'artifacts',
          visualization: 'artifacts',
        }
  const stage = aliases[raw] || raw
  const defaults =
    module === 'wind'
      ? {
          validation: [7, 'Validating wind-field inputs'],
          wind_field: [55, 'Generating the fixed-grid wind field'],
          artifacts: [92, 'Packaging wind-field outputs'],
        }
      : {
          validation: [7, 'Validating loss inputs'],
          exposure: [35, 'Matching exposure grids'],
          vulnerability: [68, 'Calculating vulnerability and loss'],
          artifacts: [92, 'Generating maps and reports'],
        }
  const resolvedStage = defaults[stage] ? stage : 'validation'
  let percent = Number(
    progress.percent ?? job.progress_percent ?? (typeof job.progress === 'number' ? job.progress : NaN),
  )
  if (!Number.isFinite(percent)) percent = defaults[resolvedStage][0]
  if (percent > 0 && percent <= 1) percent *= 100
  return {
    stage: resolvedStage,
    percent: Math.max(0, Math.min(100, percent)),
    message: String(progress.message || job.progress_message || defaults[resolvedStage][1]),
  }
}

function updateJobProgress(run, module, job) {
  const state = stageState(module, job)
  const steps = module === 'wind' ? windSteps : lossSteps
  run.stage = state.stage
  run.progress = state.percent
  run.message = state.message
  run.activeStep = Math.max(0, steps.findIndex((step) => step.key === state.stage))
  mergeWarnings(run, job.warnings)
}

function clearPoll(module) {
  const timer = pollTimers.get(module)
  if (timer) window.clearTimeout(timer)
  pollTimers.delete(module)
}

async function pollJob(module, jobId) {
  const run = module === 'wind' ? windRun : lossRun
  if (!run.running || run.jobId !== jobId) return
  try {
    const job = await requestJson(`/api/jobs/${encodeURIComponent(jobId)}`, {}, module)
    pollFailureCounts.delete(jobId)
    if (run.jobId !== jobId) return
    const status = String(job.status || '').toLowerCase()
    if (['failed', 'error'].includes(status)) {
      const detail = typeof job.error === 'string' ? job.error : job.error?.message
      failRun(run, detail || `The ${module === 'wind' ? 'wind-field' : 'loss'} calculation failed.`)
      if (module === 'wind') {
        try { sessionStorage.removeItem(WIND_JOB_STORAGE_KEY) } catch {}
      }
      return
    }
    if (['complete', 'completed', 'success', 'succeeded'].includes(status)) {
      await loadResult(module, jobId)
      return
    }
    updateJobProgress(run, module, job)
    const timer = window.setTimeout(() => pollJob(module, jobId), module === 'wind' ? 1400 : 900)
    pollTimers.set(module, timer)
  } catch (error) {
    if (/HTTP (400|404)\b/.test(error.message)) {
      failRun(run, error.message)
      return
    }
    const failures = (pollFailureCounts.get(jobId) || 0) + 1
    pollFailureCounts.set(jobId, failures)
    run.message = `Temporary local-service error while checking this job. Retrying status check (${failures})…`
    const delay = Math.min(10000, 1400 * (2 ** Math.min(failures, 3)))
    const timer = window.setTimeout(() => pollJob(module, jobId), delay)
    pollTimers.set(module, timer)
  }
}

async function loadResult(module, jobId) {
  const run = module === 'wind' ? windRun : lossRun
  const steps = module === 'wind' ? windSteps : lossSteps
  try {
    const result = await requestJson(
      `/api/jobs/${encodeURIComponent(jobId)}/result`,
      {},
      module,
    )
    run.result = result
    run.downloadUrl = String(result.download_url || `/api/jobs/${encodeURIComponent(jobId)}/download`)
    run.progress = 100
    run.stage = 'artifacts'
    run.activeStep = steps.length
    run.message = 'Calculation complete. Result files are ready.'
    run.running = false
    mergeWarnings(run, result.warnings)
    clearPoll(module)
    if (module === 'wind') {
      try { sessionStorage.removeItem(WIND_JOB_STORAGE_KEY) } catch {}
    }

    if (module === 'wind') {
      const summary = result.summary || {}
      latestWind.value = {
        jobId,
        caseKey: run.caseKey,
        caseId: String(summary.case_id || run.caseId || ''),
        typhoonName: String(summary.typhoon_name || run.typhoonName || ''),
        ready: summary.loss_input_ready !== false,
        lossInputUrl: String(result.loss_input_url || ''),
      }
    }
  } catch (error) {
    failRun(run, error.message)
  }
}

async function resumeWindJob(jobId) {
  if (!/^[0-9a-f]{32}$/i.test(String(jobId || ''))) return
  try {
    const job = await requestJson(`/api/jobs/${encodeURIComponent(jobId)}`, {}, 'wind')
    if (job.mode === 'loss') {
      const sourceWindJobId = String(job.source_wind_job_id || '')
      if (sourceWindJobId) await resumeWindJob(sourceWindJobId)
      await resumeLossJob(String(job.job_id || jobId), job)
      return
    }
    if (job.mode !== 'wind') return
    windRun.jobId = String(job.job_id || jobId)
    windRun.source = String(job.source || 'inputs')
    windRun.caseKey = String(job.case_key || '')
    windRun.caseId = String(job.case_id || '')
    windRun.typhoonName = String(job.typhoon_name || '')
    windRun.warnings = normalizeWarnings(job.warnings)
    const status = String(job.status || '').toLowerCase()
    if (['complete', 'completed', 'success', 'succeeded'].includes(status)) {
      await loadResult('wind', windRun.jobId)
      return
    }
    if (['failed', 'error'].includes(status)) {
      const detail = typeof job.error === 'string' ? job.error : job.error?.message
      failRun(windRun, detail || 'The wind-field calculation failed.')
      try { sessionStorage.removeItem(WIND_JOB_STORAGE_KEY) } catch {}
      return
    }
    windRun.running = true
    updateJobProgress(windRun, 'wind', job)
    pollJob('wind', windRun.jobId)
  } catch (error) {
    windRun.error = error.message
  }
}

async function resumeLossJob(jobId, savedJob = null) {
  if (!/^[0-9a-f]{32}$/i.test(String(jobId || ''))) return
  try {
    const job = savedJob || await requestJson(`/api/jobs/${encodeURIComponent(jobId)}`, {}, 'loss')
    if (job.mode !== 'loss') return
    lossRun.jobId = String(job.job_id || jobId)
    lossRun.source = String(job.source || '')
    lossRun.caseKey = String(job.case_key || '')
    lossRun.caseId = String(job.case_id || '')
    lossRun.typhoonName = String(job.typhoon_name || '')
    lossRun.warnings = normalizeWarnings(job.warnings)
    const status = String(job.status || '').toLowerCase()
    if (['complete', 'completed', 'success', 'succeeded'].includes(status)) {
      await loadResult('loss', lossRun.jobId)
      return
    }
    if (['failed', 'error'].includes(status)) {
      const detail = typeof job.error === 'string' ? job.error : job.error?.message
      failRun(lossRun, detail || 'The loss calculation failed.')
      return
    }
    lossRun.running = true
    updateJobProgress(lossRun, 'loss', job)
    pollJob('loss', lossRun.jobId)
  } catch (error) {
    lossRun.error = error.message
  }
}

function useWindForLoss() {
  if (!latestWind.value?.ready) return
  document.getElementById('loss')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

function goToWindModule() {
  document.getElementById('wind-field')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

onMounted(() => {
  checkHealth()
  const requestedJob = new URLSearchParams(window.location.search).get('resume')
  let savedJob = ''
  try { savedJob = sessionStorage.getItem(WIND_JOB_STORAGE_KEY) || '' } catch {}
  if (requestedJob || savedJob) resumeWindJob(requestedJob || savedJob)
})

onBeforeUnmount(() => {
  clearPoll('wind')
  clearPoll('loss')
})
</script>

<template>
  <section id="wind-field" class="section wind-section" aria-label="Typhoon wind-field calculation">
    <div class="intro">
      <div>
        <h2>Typhoon Wind Field Calculation</h2>
      </div>
      <div class="health" :class="{ ok: healthOk === true, bad: healthOk === false }">
        <i aria-hidden="true"></i>
        <span>{{ healthText }}</span>
      </div>
    </div>

    <div class="panel">
      <div class="panel-scroll">
        <section
          id="module-panel-wind"
          class="module-panel"
          :aria-busy="windRun.running"
        >
          <div class="module-heading">
            <span>WF</span>
            <div>
              <h3>Wind-Field Calculation</h3>
            </div>
          </div>

          <div class="workspace card">
            <div class="section-title">
              <span>01</span>
              <div>
                <h3>Upload the two required inputs</h3>
              </div>
            </div>

            <input
              ref="fnlFolderInput"
              type="file"
              accept=".nc,application/x-netcdf"
              webkitdirectory
              directory
              multiple
              hidden
              @change="onFnlFolderChange"
            />
            <input
              ref="trackFileInput"
              type="file"
              accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
              hidden
              @change="onTrackFileChange"
            />

            <div class="wind-input-grid">
              <article
                class="input-card"
                :class="{ selected: fnlSelection.selected, verified: fnlSelection.verified }"
              >
                <div class="input-card-head">
                  <div class="file-badge" aria-hidden="true">FNL</div>
                  <div>
                    <span class="input-number">Input 1 of 2</span>
                    <h4>FNL NetCDF folder</h4>
                  </div>
                  <span class="input-state" :class="{ verified: fnlSelection.verified }">
                    {{
                      fnlSelection.verified
                        ? 'Verified'
                        : windInputs.validating && fnlSelection.selected
                          ? 'Verifying…'
                          : fnlSelection.selected
                            ? 'Selected'
                            : 'Not selected'
                    }}
                  </span>
                </div>
                <p>
                  Choose the folder that contains the complete FNL .nc sequence.
                </p>
                <div v-if="fnlSelection.selected" class="input-file-meta">
                  <strong>{{ fnlSelection.rootName }}</strong>
                  <span>{{ integer(fnlSelection.fileCount) }} NetCDF files · {{ formatBytes(fnlSelection.totalBytes) }}</span>
                </div>
                <button
                  class="button secondary"
                  type="button"
                  :disabled="windRun.running || windInputs.validating"
                  @click="chooseFnlFolder"
                >
                  {{ fnlSelection.selected ? 'Change FNL folder' : 'Select FNL folder' }}
                </button>
              </article>

              <article
                class="input-card"
                :class="{ selected: trackSelection.selected, verified: trackSelection.verified }"
              >
                <div class="input-card-head">
                  <div class="file-badge track" aria-hidden="true">XLSX</div>
                  <div>
                    <span class="input-number">Input 2 of 2</span>
                    <h4>Track workbook</h4>
                  </div>
                  <span class="input-state" :class="{ verified: trackSelection.verified }">
                    {{
                      trackSelection.verified
                        ? 'Verified'
                        : windInputs.validating && trackSelection.selected
                          ? 'Verifying…'
                          : trackSelection.selected
                            ? 'Selected'
                            : 'Not selected'
                    }}
                  </span>
                </div>
                <p>Choose the matching .xlsx workbook that contains the typhoon track.</p>
                <div v-if="trackSelection.selected" class="input-file-meta">
                  <strong>{{ trackSelection.name }}</strong>
                  <span>{{ formatBytes(trackSelection.size) }}</span>
                </div>
                <button
                  class="button secondary"
                  type="button"
                  :disabled="windRun.running || windInputs.validating"
                  @click="chooseTrackWorkbook"
                >
                  {{ trackSelection.selected ? 'Change track workbook' : 'Select track workbook' }}
                </button>
              </article>
            </div>

            <div v-if="windInputs.validating" class="input-validation" role="status" aria-live="polite">
              <span class="validation-spinner" aria-hidden="true"></span>
              <div><strong>Verifying both inputs</strong><p>Checking the FNL sequence and track workbook…</p></div>
            </div>

            <div v-else-if="windInputs.verified" class="input-ready" role="status">
              <div><span>Typhoon</span><strong>{{ windInputs.typhoonName || 'Identified from inputs' }}</strong></div>
              <div><span>Case ID</span><strong>{{ windInputs.caseId || 'Identified from inputs' }}</strong></div>
              <div><span>FNL sequence</span><strong>{{ integer(windInputs.fnlCount) }} files</strong></div>
              <div><span>Track workbook</span><strong>{{ windInputs.trackName }}</strong></div>
            </div>

            <div v-if="windInputs.error" class="inline-error" role="alert">
              <span>{{ windInputs.error }}</span>
              <button
                v-if="fnlSelection.selected && trackSelection.selected"
                type="button"
                @click="validateWindInputs"
              >
                Verify again
              </button>
            </div>

            <div class="action-row">
              <button
                class="button primary"
                type="button"
                :disabled="!canStartWind"
                @click="startWindCalculation"
              >
                {{ windRun.running ? 'Generating wind field…' : 'Generate wind field' }}
              </button>
              <p v-if="lossRun.running">A loss job is running. Wait for it to finish before starting a new wind-field job.</p>
              <p v-else-if="windRun.result">The generated wind field is ready. Continue to the loss module, or change either input to start a new run.</p>
              <p v-else-if="!windInputs.verified">Select and verify both inputs to enable wind-field generation.</p>
              <p v-else>Both inputs are verified. All calculations and outputs remain on this computer.</p>
            </div>
          </div>

          <div v-if="windRun.running" class="progress-card card" role="status" aria-live="polite">
            <div class="section-title">
              <span>02</span>
              <div><h3>Wind-field progress</h3><p>{{ windRun.message }}</p></div>
            </div>
            <div
              class="progress-line"
              role="progressbar"
              aria-label="Wind-field calculation progress"
              aria-valuemin="0"
              aria-valuemax="100"
              :aria-valuenow="Math.round(windRun.progress)"
            >
              <i :style="{ width: `${windRun.progress}%` }"></i>
            </div>
            <ol class="steps">
              <li
                v-for="(step, index) in windSteps"
                :key="step.key"
                :class="{ done: windRun.activeStep > index, active: windRun.activeStep === index }"
              >
                {{ step.label }}
              </li>
            </ol>
          </div>

          <div v-if="windRun.error" class="error-card card" role="alert">
            <strong>The wind-field calculation could not be completed</strong>
            <p>{{ windRun.error }}</p>
          </div>

          <div v-if="windRun.result" class="result card">
            <div class="result-heading">
              <div class="section-title">
                <span>03</span>
                <div><h3>Wind-field result</h3><p>{{ windResultMeta }}</p></div>
              </div>
              <div class="result-actions">

                <button
                  v-if="windReadyForLoss"
                  class="button primary"
                  type="button"
                  @click="useWindForLoss"
                >
                  Continue to loss calculation →
                </button>
              </div>
            </div>

            <article v-if="lossRun.result" class="subpanel track-panel wind-track-panel">
              <div class="panel-head"><h4>Typhoon and landfall information</h4><span>UTC+8</span></div>
              <div class="track-summary">
                <div v-for="cell in lossTrackCells" :key="cell.label">
                  <span>{{ cell.label }}</span><strong>{{ cell.value }}</strong>
                </div>
              </div>
            </article>

            <div class="result-split">
              <InteractiveResultMap
                :key="`wind-map-${windRun.jobId}`"
                :job-id="windRun.jobId"
                mode="wind"
                title="Full-track fixed-grid maximum wind field"
                @rankings-ready="setWindRankingRows"
              />
              <article class="subpanel ranking-panel">
                <div class="panel-head"><h4>Maximum Wind Speed by City</h4><span>Highest first</span></div>
                <div class="table-wrap ranking-table-wrap">
                  <table>
                    <thead><tr><th>City / Province</th><th>Maximum wind speed</th></tr></thead>
                    <tbody>
                      <tr v-for="row in windRankingRows" :key="row.region">
                        <td>{{ row.region }}</td><td>{{ Number(row.wind).toFixed(2) }} m/s</td>
                      </tr>
                      <tr v-if="!windRankingRows.length"><td colspan="2">No city-level wind data is available in the selected provinces.</td></tr>
                    </tbody>
                  </table>
                </div>
              </article>
            </div>

            <article v-if="windRun.downloadUrl" class="subpanel artifact-panel bundle-panel">
              <div class="panel-head"><h4>Wind-field output files</h4><span>One-click ZIP download</span></div>
              <div class="bundle-row">
                <a class="bundle-download" :href="windRun.downloadUrl" download>
                  <span class="bundle-download-symbol" aria-hidden="true">↓</span>
                  <span><strong>Download all wind-field files</strong><small>Single ZIP package</small></span>
                </a>
                <div class="filetype-icons" aria-label="Included file types">
                  <span v-for="fileType in windBundleTypes" :key="fileType.key" class="filetype-icon" :class="`filetype-icon--${fileType.key}`" role="img" :aria-label="fileType.label" :title="fileType.label">
                    <svg viewBox="0 0 42 48" aria-hidden="true"><path d="M9 3.5h16l8 8V44H9zM25 4v8h8M14 20h14M14 25h14"/><text x="21" y="38" text-anchor="middle">{{ fileType.short }}</text></svg>
                  </span>
                </div>
              </div>
            </article>
          </div>
        </section>
      </div>
    </div>
  </section>

  <section id="loss" class="section loss-section" aria-label="Typhoon loss calculation">
    <div class="intro">
      <div>
        <h2>Typhoon Loss Calculation</h2>
        <p>Calculate exposure and vulnerability losses from the generated wind field</p>
      </div>
    </div>

    <div class="panel">
      <div class="panel-scroll">
        <section
          id="module-panel-loss"
          class="module-panel"
          :aria-busy="lossRun.running"
        >
          <div id="loss-calc" class="module-heading">
            <span>LS</span>
            <div>
              <h3>Loss Calculation</h3>
            </div>
          </div>

          <div class="workspace card">
            <div class="section-title">
              <span>01</span>
              <div>
                <h3>Use the generated wind field</h3>
              </div>
            </div>

            <div class="handoff-card">
              <template v-if="latestWind?.ready">
                <div class="handoff-mark" aria-hidden="true">✓</div>
                <div>
                  <strong>{{ latestWind.typhoonName }} · {{ latestWind.caseId }}</strong>
                </div>
              </template>
              <template v-else>
                <div class="handoff-mark muted" aria-hidden="true">WF</div>
                <div>
                  <strong>No wind-field result is available yet</strong>
                  <p>Complete a wind-field calculation first. Its output will appear here automatically.</p>
                </div>
                <button class="button secondary" type="button" @click="goToWindModule">
                  Generate a wind field
                </button>
              </template>
            </div>

            <div class="action-row">
              <button
                class="button primary"
                type="button"
                :disabled="!canStartLoss"
                @click="startLossCalculation"
              >
                {{ lossRun.running ? 'Calculating loss…' : 'Calculate loss' }}
              </button>
              <p v-if="windRun.running">A wind-field job is running. Wait for it to finish before starting loss calculation.</p>
              <p v-else>The loss algorithm runs locally; exposure data is not sent to a remote server.</p>
            </div>

          </div>

          <div v-if="lossRun.running" class="progress-card card" role="status" aria-live="polite">
            <div class="section-title">
              <span>02</span>
              <div><h3>Loss-calculation progress</h3><p>{{ lossRun.message }}</p></div>
            </div>
            <div
              class="progress-line"
              role="progressbar"
              aria-label="Loss-calculation progress"
              aria-valuemin="0"
              aria-valuemax="100"
              :aria-valuenow="Math.round(lossRun.progress)"
            >
              <i :style="{ width: `${lossRun.progress}%` }"></i>
            </div>
            <ol class="steps">
              <li
                v-for="(step, index) in lossSteps"
                :key="step.key"
                :class="{ done: lossRun.activeStep > index, active: lossRun.activeStep === index }"
              >
                {{ step.label }}
              </li>
            </ol>
          </div>

          <div v-if="lossRun.error" class="error-card card" role="alert">
            <strong>The loss calculation could not be completed</strong>
            <p>{{ lossRun.error }}</p>
          </div>

          <div v-if="lossRun.result" class="result card">
            <div class="result-heading">
              <div class="section-title">
                <span>03</span>
                <div><h3>Loss result</h3><p>{{ lossResultMeta }}</p></div>
              </div>

            </div>

            <div class="metrics">
                <article v-for="metric in lossMetrics" :key="metric.label">
                  <span>{{ metric.label }}</span><strong>{{ metric.value }}</strong>
              </article>
            </div>

            <div class="result-split">
              <InteractiveResultMap
                :key="`loss-map-${lossRun.jobId}`"
                :job-id="lossRun.jobId"
                :reference-job-id="windRun.jobId"
                mode="loss"
                title="Exposure-grid loss across five coastal provinces"
              />
              <article class="subpanel ranking-panel loss-ranking-panel">
                <div class="panel-head"><h4>Loss Ranking by Province and City</h4><span>Highest first</span></div>
                <section class="loss-ranking-block province-loss-block">
                  <h5>Provincial loss summary</h5>
                  <div class="table-wrap ranking-table-wrap province-ranking-wrap">
                    <table>
                      <thead><tr><th>Province</th><th>Total loss (￥)</th></tr></thead>
                      <tbody>
                        <tr v-for="row in lossProvinceRows" :key="row.province"><td>{{ row.province }}</td><td>{{ row.loss }}</td></tr>
                        <tr v-if="!lossProvinceRows.length"><td colspan="2">No non-zero provincial losses are available.</td></tr>
                      </tbody>
                    </table>
                  </div>
                </section>
                <section class="loss-ranking-block">
                  <h5>City-level loss ranking</h5>
                  <div class="table-wrap ranking-table-wrap city-ranking-wrap">
                    <table>
                      <thead><tr><th>City / Province</th><th>Maximum loss (￥)</th></tr></thead>
                      <tbody>
                        <tr v-for="(row, index) in lossRankingRows" :key="`${row.region}-${index}`"><td>{{ row.region }}</td><td>{{ row.loss }}</td></tr>
                        <tr v-if="!lossRankingRows.length"><td colspan="2">No non-zero city losses are available.</td></tr>
                      </tbody>
                    </table>
                  </div>
                </section>
                          <figure class="vulnerability-figure compact-vulnerability-figure">
              <div class="panel-head"><h4>Vulnerability curve</h4></div>
              <VulnerabilityCurve />
              <figcaption>Reference: Zhong XC, Fang WH, Cao SJ. Probabilistic component-based Monte Carlo simulation of vulnerability for a typical low-rise rural residential building in coastal China. J Beijing Norm Univ (Nat Sci) 2017;53(1):51-59 (in Chinese). <a href="https://doi.org/10.16360/j.cnki.jbnuns.2017.01.010" target="_blank" rel="noopener">https://doi.org/10.16360/j.cnki.jbnuns.2017.01.010</a>.</figcaption>
            </figure>
              </article>
            </div>



            <article v-if="lossRun.downloadUrl" class="subpanel artifact-panel bundle-panel">
              <div class="panel-head"><h4>Loss output files</h4><span>One-click ZIP download</span></div>
              <div class="bundle-row">
                <a class="bundle-download" :href="lossRun.downloadUrl" download>
                  <span class="bundle-download-symbol" aria-hidden="true">↓</span>
                  <span><strong>Download all loss files</strong><small>Grid CSVs, maps, report, curve and results</small></span>
                </a>
                <div class="filetype-icons" aria-label="Included file types">
                  <span v-for="fileType in lossBundleTypes" :key="fileType.key" class="filetype-icon" :class="`filetype-icon--${fileType.key}`" role="img" :aria-label="fileType.label" :title="fileType.label">
                    <svg viewBox="0 0 42 48" aria-hidden="true"><path d="M9 3.5h16l8 8V44H9zM25 4v8h8M14 20h14M14 25h14"/><text x="21" y="38" text-anchor="middle">{{ fileType.short }}</text></svg>
                  </span>
                </div>
              </div>
            </article>


          </div>
        </section>
      </div>
    </div>
  </section>
</template>

<style scoped>
.section {
  padding: clamp(2.5rem, 5vw, 3.5rem) clamp(1rem, 2.5vw, 2rem);
  background: linear-gradient(180deg, #f8fbfc 0%, #eef5f7 100%);
  scroll-margin-top: 5.75rem;
}

.loss-section {
  border-top: 1px solid rgba(16, 39, 52, 0.07);
  background: linear-gradient(180deg, #f4f9fa 0%, #eaf2f5 100%);
}

.intro {
  max-width: 1600px;
  margin: 0 auto 1.25rem;
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 1rem;
  flex-wrap: wrap;
}

.intro h2 {
  margin: 0;
  font-family: var(--font-display);
  font-weight: 400;
  font-size: clamp(1.85rem, 3.5vw, 2.5rem);
  line-height: 1.2;
  color: var(--ink);
}

.intro > div > p {
  margin: 0.35rem 0 0;
  color: #6c7f8b;
  font-size: 0.82rem;
}

.health {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: #6c7f8b;
}

.health i {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #dfb64b;
  box-shadow: 0 0 0 4px rgba(223, 182, 75, 0.13);
}

.health.ok i { background: #55c49b; }
.health.bad i { background: #e56565; }

.panel {
  --teal: #0c7880;
  --sea: #e8f4f3;
  --line: #dbe5e7;
  --muted: #6c7f8b;
  --navy: #092d3f;
  max-width: 1600px;
  margin: 0 auto;
  border: 1px solid var(--line);
  border-radius: 0.85rem;
  background: #f2f6f6;
  box-shadow: 0 10px 30px rgba(16, 39, 52, 0.06);
}

.panel-scroll { padding: 1.5rem clamp(1rem, 2vw, 1.75rem) 2.25rem; }

.module-panel {
  outline: none;
  scroll-margin-top: 9rem;
}

.module-panel:focus-visible {
  border-radius: 12px;
  box-shadow: 0 0 0 3px rgba(12, 120, 128, 0.22);
}

.module-heading {
  display: flex;
  align-items: flex-start;
  gap: 14px;
  margin: 0.2rem 0 1rem;
  padding: 0 0.25rem;
}

.module-heading > span {
  display: grid;
  place-items: center;
  width: 42px;
  height: 42px;
  flex: 0 0 42px;
  border-radius: 12px;
  background: #0c7880;
  color: #fff;
  font-size: 11px;
  font-weight: 800;
}

.module-heading h3 { margin: 0 0 5px; font-size: 1.25rem; }
.module-heading p { margin: 0; color: var(--muted); font-size: 12px; }

.card {
  margin-bottom: 1rem;
  padding: 1.5rem;
  border: 1px solid var(--line);
  border-radius: 16px;
  background: #fff;
  box-shadow: 0 18px 55px rgba(18, 55, 68, 0.06);
}

.section-title {
  display: flex;
  align-items: flex-start;
  gap: 14px;
  margin-bottom: 1.2rem;
}

.section-title > span {
  display: grid;
  place-items: center;
  width: 34px;
  height: 34px;
  flex: 0 0 34px;
  border-radius: 50%;
  background: var(--sea);
  color: var(--teal);
  font-size: 11px;
  font-weight: 800;
}

.section-title h3 { margin: 1px 0 5px; font-size: 1.15rem; font-weight: 600; }
.section-title p { margin: 0; color: var(--muted); font-size: 12px; }

.source-switch { margin-bottom: 1rem; }

.full-case-picker,
.handoff-card {
  padding: clamp(1.15rem, 3vw, 1.8rem);
  border: 1.5px solid #b7d2d2;
  border-radius: 13px;
  background: linear-gradient(145deg, #f7fbfb, #edf6f5);
}

.case-loading {
  display: grid;
  min-height: 130px;
  place-items: center;
  color: var(--muted);
  font-size: 13px;
}

.dataset-picker {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  align-items: center;
  gap: 16px;
}

.dataset-picker h4 {
  margin: 0 0 5px;
  font-size: 1rem;
}

.dataset-picker p {
  max-width: 760px;
  margin: 0;
  color: var(--muted);
  font-size: 12px;
  line-height: 1.55;
}

.file-badge.dataset {
  min-width: 72px;
  background: linear-gradient(145deg, #0c7880, #064b52);
  font-size: 11px;
}

.dataset-status {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  margin: 16px 0 13px;
  padding: 10px 12px;
  border: 1px solid #b7d9cb;
  border-radius: 9px;
  background: #f0faf6;
  color: #225e4b;
  font-size: 12px;
}

.dataset-status span {
  color: #4d6d63;
}

.case-select-label {
  display: block;
  margin-bottom: 7px;
  color: #48606f;
  font-size: 12px;
  font-weight: 700;
}

.case-select-row {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 10px;
}

.case-select-row select,
.fields input,
.fields select {
  width: 100%;
  min-height: 42px;
  box-sizing: border-box;
  padding: 9px 12px;
  border: 1px solid #c9d6dd;
  border-radius: 9px;
  background: #fff;
  color: var(--ink);
  font: inherit;
}

.case-detail {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 9px;
  margin-top: 14px;
}

.case-detail > div {
  padding: 11px 12px;
  border: 1px solid var(--line);
  border-radius: 9px;
  background: rgba(255, 255, 255, 0.82);
}

.case-detail span,
.case-detail strong { display: block; }
.case-detail span { margin-bottom: 5px; color: var(--muted); font-size: 10px; }
.case-detail strong { overflow-wrap: anywhere; font-size: 13px; }
.case-detail > p { grid-column: 1 / -1; margin: 0; color: var(--muted); font-size: 11px; }

.wind-input-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px;
}

.input-card {
  display: flex;
  min-width: 0;
  min-height: 245px;
  flex-direction: column;
  padding: clamp(1.15rem, 2vw, 1.45rem);
  border: 1.5px solid #cfdbdf;
  border-radius: 14px;
  background: linear-gradient(145deg, #fbfdfd, #f2f7f7);
  transition: border-color 0.18s ease, box-shadow 0.18s ease, transform 0.18s ease;
}

.input-card.selected {
  border-color: #8bbcc0;
  box-shadow: 0 10px 28px rgba(12, 120, 128, 0.08);
}

.input-card.verified {
  border-color: #78b79f;
  background: linear-gradient(145deg, #fbfefd, #eef8f4);
}

.input-card-head {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  align-items: center;
  gap: 12px;
}

.input-card-head .file-badge {
  min-width: 56px;
  height: 44px;
  margin: 0;
}

.input-card-head .file-badge.track {
  background: #16465b;
  font-size: 10px;
}

.input-number {
  display: block;
  margin-bottom: 3px;
  color: var(--teal);
  font-size: 9px;
  font-weight: 800;
  letter-spacing: 0.09em;
  text-transform: uppercase;
}

.input-card h4 {
  margin: 0;
  font-size: 1rem;
}

.input-card > p {
  margin: 16px 0;
  color: var(--muted);
  font-size: 12px;
  line-height: 1.6;
}

.input-state {
  padding: 6px 9px;
  border-radius: 999px;
  background: #e8eff0;
  color: #60747d;
  font-size: 10px;
  font-weight: 800;
  white-space: nowrap;
}

.input-state.verified {
  background: #daf1e7;
  color: #23634e;
}

.input-file-meta {
  min-width: 0;
  margin: auto 0 14px;
  padding: 10px 11px;
  border: 1px solid #dbe5e7;
  border-radius: 9px;
  background: rgba(255, 255, 255, 0.78);
}

.input-file-meta strong,
.input-file-meta span {
  display: block;
  overflow-wrap: anywhere;
}

.input-file-meta strong { font-size: 12px; }
.input-file-meta span { margin-top: 4px; color: var(--muted); font-size: 10px; }
.input-card > .button { align-self: flex-start; }

.input-validation {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: 14px;
  padding: 13px 14px;
  border: 1px solid #bdd6dc;
  border-radius: 10px;
  background: #f0f7f9;
  color: #315966;
}

.input-validation strong,
.input-validation p { display: block; margin: 0; }
.input-validation strong { font-size: 12px; }
.input-validation p { margin-top: 3px; color: #647d86; font-size: 10px; }

.validation-spinner {
  width: 18px;
  height: 18px;
  flex: 0 0 18px;
  border: 2px solid #b7d4d7;
  border-top-color: var(--teal);
  border-radius: 50%;
  animation: input-spin 0.8s linear infinite;
}

@keyframes input-spin { to { transform: rotate(360deg); } }

.input-ready {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 9px;
  margin-top: 14px;
  padding: 11px;
  border: 1px solid #a9d2c1;
  border-radius: 10px;
  background: #eff9f5;
}

.input-ready > div {
  min-width: 0;
  padding: 8px 9px;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.7);
}

.input-ready span,
.input-ready strong { display: block; overflow-wrap: anywhere; }
.input-ready span { margin-bottom: 4px; color: #55746a; font-size: 9px; }
.input-ready strong { color: #194f3f; font-size: 12px; }

.dropzone {
  min-height: 230px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 1.5rem;
  border: 1.5px dashed #9fc5c6;
  border-radius: 13px;
  background: linear-gradient(145deg, #f7fbfb, #edf6f5);
  text-align: center;
  transition: 0.2s ease;
}

.dropzone.dragging {
  border-color: var(--teal);
  background: #e4f3f2;
  transform: translateY(-1px);
}

.file-badge {
  display: grid;
  min-width: 58px;
  height: 44px;
  place-items: center;
  margin-bottom: 14px;
  padding: 0 8px;
  border-radius: 10px;
  background: var(--teal);
  color: #fff;
  font-size: 12px;
  font-weight: 800;
  letter-spacing: 0.06em;
}

.file-badge.loss { background: #16465b; }
.dropzone h4 { max-width: 100%; margin: 0 0 8px; overflow-wrap: anywhere; font-size: 1.02rem; }
.dropzone p { max-width: 680px; margin: 0 0 1rem; color: var(--muted); font-size: 12px; line-height: 1.55; }

.fields {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  margin: 1rem 0;
}

.fields label {
  display: flex;
  flex-direction: column;
  gap: 6px;
  color: #48606f;
  font-size: 12px;
  font-weight: 700;
}

.file-summary {
  display: flex;
  align-items: center;
  gap: 1rem;
  flex-wrap: wrap;
  margin-top: 13px;
  padding: 13px 15px;
  border: 1px solid var(--line);
  border-radius: 10px;
  background: #f5f9f9;
  font-size: 12px;
}

.file-summary strong { min-width: 0; overflow-wrap: anywhere; font-size: 13px; }
.file-summary span { color: var(--muted); }
.file-summary button {
  margin-left: auto;
  border: 0;
  background: transparent;
  color: #a54141;
  font: inherit;
  font-weight: 700;
  cursor: pointer;
}

.inline-error {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 56px;
  margin-top: 14px;
  padding: 12px 14px;
  border: 1px solid #f0c2c2;
  border-radius: 9px;
  background: #fff7f7;
  color: #8a4b4b;
  font-size: 12px;
}

.inline-error button { border: 0; background: transparent; color: #b84040; font: inherit; font-weight: 700; cursor: pointer; }

.handoff-card {
  display: flex;
  align-items: center;
  gap: 14px;
  min-height: 110px;
}

.handoff-mark {
  display: grid;
  width: 44px;
  height: 44px;
  flex: 0 0 44px;
  place-items: center;
  border-radius: 50%;
  background: #dff4ec;
  color: #1f6b55;
  font-size: 16px;
  font-weight: 800;
}

.handoff-mark.muted { background: #e8eff0; color: #627883; font-size: 11px; }
.handoff-card > div:nth-child(2) { min-width: 0; flex: 1; }
.handoff-card strong { display: block; overflow-wrap: anywhere; }
.handoff-card p { margin: 5px 0 0; overflow-wrap: anywhere; color: var(--muted); font-size: 12px; }

.action-row {
  display: flex;
  align-items: center;
  gap: 14px;
  flex-wrap: wrap;
  margin-top: 1rem;
}

.action-row p { margin: 0; color: var(--muted); font-size: 12px; }

.button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 42px;
  padding: 10px 18px;
  border: 0;
  border-radius: 9px;
  font-size: 13px;
  font-weight: 700;
  text-decoration: none;
  cursor: pointer;
  transition: 0.18s ease;
}

.button:disabled { opacity: 0.45; cursor: not-allowed; }
.button.secondary { border: 1px solid #b9d4d4; background: #fff; color: var(--teal); }
.button.primary { min-width: 160px; background: var(--teal); color: #fff; }
.button.primary:not(:disabled):hover { background: #075f66; }
.button.dark { background: var(--navy); color: #fff; }

button:focus-visible,
a:focus-visible,
input:focus-visible,
select:focus-visible,
summary:focus-visible {
  outline: 3px solid rgba(12, 120, 128, 0.3);
  outline-offset: 2px;
}

.progress-line {
  height: 8px;
  margin-bottom: 1rem;
  overflow: hidden;
  border-radius: 999px;
  background: #e4ecec;
}

.progress-line i {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: linear-gradient(90deg, #0c7880, #2aaeb3);
  transition: width 0.3s ease;
}

.steps { display: grid; gap: 8px; margin: 0; padding: 0; list-style: none; }
.steps li { padding: 8px 10px; border-radius: 8px; background: #f5f9f9; color: var(--muted); font-size: 13px; }
.steps li.active { background: var(--sea); color: var(--teal); font-weight: 600; }
.steps li.done { color: #1f6b55; }

.error-card { border-color: #f0c2c2; background: #fff7f7; }
.error-card strong { display: block; margin-bottom: 6px; color: #b84040; }
.error-card p { margin: 0; color: #8a4b4b; font-size: 13px; }

.result-heading {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 1rem;
  flex-wrap: wrap;
}

.result-actions { display: flex; gap: 8px; flex-wrap: wrap; }
.download-note { flex: 1 1 220px; margin: 0; align-self: center; color: var(--muted); font-size: 11px; line-height: 1.45; }

.metrics {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
  margin-bottom: 1rem;
}

.metrics article { min-width: 0; padding: 14px; border-radius: 12px; background: #f5f9f9; }
.metrics span,
.metrics small { display: block; color: var(--muted); font-size: 11px; }
.metrics strong { display: block; margin: 8px 0 4px; overflow-wrap: anywhere; font-size: 1.2rem; }

.result-split { display: grid; grid-template-columns: minmax(0, 2.4fr) minmax(260px, 0.8fr); align-items: start; gap: 12px; margin-bottom: 12px; }
.result-grid { display: grid; grid-template-columns: 1fr; gap: 12px; margin-bottom: 12px; }
.subpanel { padding: 14px; border: 1px solid var(--line); border-radius: 12px; background: #fff; }
.ranking-panel { min-width: 0; max-height: 600px; overflow: hidden; }
.ranking-table-wrap { max-height: 530px; }
.ranking-panel td:first-child { min-width: 96px; overflow-wrap: anywhere; }
.loss-ranking-panel { max-height: none; overflow: visible; }
.loss-ranking-block { margin-top: 0.9rem; }
.province-loss-block + .loss-ranking-block { padding-top: 0.9rem; border-top: 1px solid var(--line); }
.loss-ranking-block h5 { margin: 0 0 0.45rem; color: #23434f; font-size: 12px; }
.province-ranking-wrap { max-height: 150px; }
.city-ranking-wrap { max-height: 300px; }
.panel-head { display: flex; justify-content: space-between; gap: 8px; margin-bottom: 12px; }
.panel-head h4 { margin: 0; font-size: 14px; }
.panel-head span { color: var(--muted); font-size: 11px; }

.bar-row { display: grid; grid-template-columns: 90px 1fr 100px; gap: 8px; align-items: center; margin-bottom: 10px; font-size: 12px; }
.bar-track { height: 8px; overflow: hidden; border-radius: 999px; background: #e8efef; }
.bar-fill { height: 100%; border-radius: inherit; }
.table-wrap { overflow: auto; }
table { width: 100%; border-collapse: collapse; font-size: 12px; }
th,
td { padding: 8px 6px; border-bottom: 1px solid var(--line); text-align: left; }

.artifact-panel { margin-bottom: 12px; }
.bundle-panel { margin-bottom: 12px; }
.bundle-row { display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap; }
.bundle-download {
  display: inline-flex;
  align-items: center;
  gap: 11px;
  min-height: 54px;
  padding: 9px 14px;
  border: 1px solid #b7d8d7;
  border-radius: 11px;
  background: linear-gradient(135deg, #effaf8, #f7fbfc);
  color: var(--teal);
  text-decoration: none;
}
.bundle-download:hover { border-color: #78b8b5; background: #e8f7f4; }
.bundle-download strong,
.bundle-download small { display: block; }
.bundle-download strong { font-size: 12px; }
.bundle-download small { margin-top: 3px; color: var(--muted); font-size: 10px; }
.bundle-download-symbol {
  display: grid;
  width: 34px;
  height: 34px;
  place-items: center;
  border-radius: 9px;
  background: var(--teal);
  color: #fff;
  font-size: 21px;
  line-height: 1;
}
.filetype-icons { display: flex; align-items: center; gap: 7px; flex-wrap: wrap; }
.filetype-icon { display: inline-grid; width: 42px; height: 48px; place-items: center; color: #45616b; }
.filetype-icon svg { display: block; width: 42px; height: 48px; overflow: visible; }
.filetype-icon svg path { fill: #fff; stroke: currentColor; stroke-width: 1.7; stroke-linejoin: round; }
.filetype-icon svg text { fill: currentColor; font-family: var(--font-body); font-size: 7px; font-weight: 800; }
.filetype-icon--nc { color: #4865ba; }
.filetype-icon--png { color: #d45d52; }
.filetype-icon--csv { color: #258a68; }
.filetype-icon--xlsx { color: #1d7c59; }
.filetype-icon--json { color: #617485; }
.filetype-icon--pdf { color: #ba3f45; }
.filetype-icon--zip { color: #bd8124; }
.wind-track-panel { margin-bottom: 12px; }
.vulnerability-figure { margin: 0 0 12px; }
.vulnerability-figure img { display: block; width: min(100%, 1080px); max-height: 440px; margin: 0 auto; object-fit: contain; }
.vulnerability-figure figcaption { max-width: 1180px; margin: 10px auto 0; color: var(--muted); font-size: 10px; line-height: 1.55; overflow-wrap: anywhere; }
.vulnerability-figure figcaption a { color: var(--teal); }
.compact-vulnerability-figure { margin: 0.85rem 0 0; padding-top: 0.7rem; border-top: 1px solid var(--line); }
.compact-vulnerability-figure .panel-head { align-items: baseline; margin-bottom: 3px; }
.compact-vulnerability-figure .panel-head h4 { font-size: 12px; }
.compact-vulnerability-figure .panel-head span { font-size: 8px; }
.loss-ranking-panel .compact-vulnerability-figure img { width: 100%; max-height: 145px; }
.loss-ranking-panel .compact-vulnerability-figure figcaption { margin-top: 5px; font-size: 8px; line-height: 1.35; }
.artifact-list { display: grid; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); gap: 8px; }
.artifact-list a {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-width: 0;
  padding: 10px 12px;
  border: 1px solid var(--line);
  border-radius: 9px;
  background: #f5f9f9;
  color: var(--teal);
  font-size: 12px;
  font-weight: 700;
  text-decoration: none;
}
.artifact-list a:hover { border-color: #9fc5c6; background: var(--sea); }
.artifact-list span { min-width: 0; overflow-wrap: anywhere; }
.artifact-list small { color: var(--muted); font-size: 10px; font-weight: 500; text-align: right; }

.track-summary { display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: 10px; }
.track-summary div { min-width: 0; padding: 10px; border-radius: 10px; background: #f5f9f9; }
.track-summary span { display: block; margin-bottom: 4px; color: var(--muted); font-size: 11px; }
.track-summary strong { display: block; overflow-wrap: anywhere; font-size: 13px; }

.guide {
  margin-top: 1rem;
  padding-top: 13px;
  border-top: 1px solid var(--line);
}
.guide summary { color: var(--teal); font-size: 12px; font-weight: 700; cursor: pointer; }
.guide p { margin: 12px 0 8px; color: var(--muted); font-size: 12px; line-height: 1.55; }
.text-link { color: var(--teal); font-size: 12px; font-weight: 700; }

@media (max-width: 1100px) {
  .fields,
  .metrics,
  .result-grid,
  .result-split,
  .track-summary,
  .input-ready { grid-template-columns: 1fr; }

  .case-detail { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .bar-row { grid-template-columns: 1fr; }
}

@media (max-width: 720px) {
  .section { padding-inline: 0.75rem; }
  .panel-scroll { padding: 0.8rem; }
  .card { padding: 1rem; }
  .source-switch,
  .dataset-picker,
  .case-select-row,
  .case-detail,
  .wind-input-grid { grid-template-columns: 1fr; }
  .input-card-head { grid-template-columns: auto minmax(0, 1fr); }
  .input-state { grid-column: 1 / -1; justify-self: start; }
  .input-card > .button { width: 100%; }
  .dropzone { min-height: 210px; padding: 1.1rem; }
  .dataset-picker .button { width: 100%; }
  .handoff-card { align-items: flex-start; flex-wrap: wrap; }
  .handoff-card .button { width: 100%; }
  .action-row,
  .result-actions { align-items: stretch; flex-direction: column; }
  .action-row .button,
  .result-actions .button,
  .result-heading > .button { width: 100%; }
  .file-summary button { margin-left: 0; }
}
</style>
