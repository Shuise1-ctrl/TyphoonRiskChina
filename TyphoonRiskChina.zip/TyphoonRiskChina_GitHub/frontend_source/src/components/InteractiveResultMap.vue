<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'

const props = defineProps({
  jobId: { type: String, required: true },
  mode: { type: String, default: 'wind', validator: (value) => ['wind', 'loss'].includes(value) },
  title: { type: String, required: true },
  referenceJobId: { type: String, default: '' },
})
const emit = defineEmits(['rankings-ready'])

const FALLBACK_STOPS = {
  wind: [
    [0, '#313695'],
    [0.2, '#4575b4'],
    [0.4, '#74add1'],
    [0.6, '#66bd63'],
    [0.75, '#fee08b'],
    [0.9, '#f46d43'],
    [1, '#a50026'],
  ],
  loss: [
    [0, '#0d0887'],
    [0.25, '#7e03a8'],
    [0.5, '#cc4778'],
    [0.75, '#f89540'],
    [1, '#f0f921'],
  ],
  exposure: [
    [0, '#440154'],
    [0.25, '#3b528b'],
    [0.5, '#21918c'],
    [0.75, '#5ec962'],
    [1, '#fde725'],
  ],
}

const LAYER_NAMES = {
  max_wind_ms: 'Maximum Wind Speed',
  total_loss: 'Total Loss',
  exposure_value: 'Exposure Value',
  valid_count: 'Valid Time Steps',
  source_count: 'Aggregated Source Cells',
  time_of_max: 'Source Time of Maximum Wind Speed',
  lead_hour_of_max: 'Forecast Lead Time at Maximum Wind Speed',
}

const RANKING_PROVINCES = new Set(['fujian', 'guangdong', 'hainan', 'jiangsu', 'zhejiang'])

const rootEl = ref(null)
const stageEl = ref(null)
const mapEl = ref(null)
const loading = ref(true)
const error = ref('')
const payload = ref(null)
const activeLayerKey = ref('')
const mapHeight = ref(500)
const hovered = ref(null)
const pinned = ref(false)
const fullscreen = ref(false)
const fullscreenSupported = ref(false)
const localWarnings = ref([])

let map = null
let rasterOverlay = null
let rasterObjectUrl = ''
let trackGroup = null
let provinceLabelGroup = null
let cityLabelGroup = null
let hoverTooltip = null
let resizeObserver = null
let intersectionObserver = null
let abortController = null
let renderSequence = 0
let referenceBounds = null

const boundaryRequests = new Map()
const administrativeRecords = { province: [], city: [] }

function boundaryData(url) {
  if (!boundaryRequests.has(url)) {
    boundaryRequests.set(
      url,
      fetch(url).then((response) => {
        if (!response.ok) throw new Error(`Failed to load boundary data (${response.status}).`)
        return response.json()
      }),
    )
  }
  return boundaryRequests.get(url)
}

function flatCoordinates(coordinates, result = []) {
  if (!Array.isArray(coordinates)) return result
  if (coordinates.length >= 2 && finite(coordinates[0]) !== null && finite(coordinates[1]) !== null) {
    result.push([Number(coordinates[0]), Number(coordinates[1])])
    return result
  }
  coordinates.forEach((item) => flatCoordinates(item, result))
  return result
}

function featureRecord(feature, role) {
  const properties = feature?.properties || {}
  const name = role === 'city' ? properties.city_name_en : properties.province_name
  if (!name) return null
  const points = flatCoordinates(feature?.geometry?.coordinates)
  if (!points.length) return null
  const bounds = points.reduce((result, [longitude, latitude]) => ({
    west: Math.min(result.west, longitude),
    east: Math.max(result.east, longitude),
    south: Math.min(result.south, latitude),
    north: Math.max(result.north, latitude),
  }), { west: Infinity, east: -Infinity, south: Infinity, north: -Infinity })
  return {
    feature,
    name: String(name),
    province: properties.province_name ? String(properties.province_name) : null,
    bounds,
    labelPoint: [(bounds.south + bounds.north) / 2, (bounds.west + bounds.east) / 2],
  }
}

function indexAdministrativeFeatures(collection, role) {
  administrativeRecords[role] = (collection?.features || [])
    .map((feature) => featureRecord(feature, role))
    .filter(Boolean)
}

function pointInRing(longitude, latitude, ring) {
  let inside = false
  for (let index = 0, previous = ring.length - 1; index < ring.length; previous = index, index += 1) {
    const currentPoint = ring[index]
    const previousPoint = ring[previous]
    const currentX = Number(currentPoint?.[0])
    const currentY = Number(currentPoint?.[1])
    const previousX = Number(previousPoint?.[0])
    const previousY = Number(previousPoint?.[1])
    if (![currentX, currentY, previousX, previousY].every(Number.isFinite)) continue
    const crosses = currentY > latitude !== previousY > latitude
    if (crosses && longitude < ((previousX - currentX) * (latitude - currentY)) / (previousY - currentY) + currentX) inside = !inside
  }
  return inside
}

function pointInPolygon(longitude, latitude, polygon) {
  if (!Array.isArray(polygon) || !polygon.length || !pointInRing(longitude, latitude, polygon[0])) return false
  return !polygon.slice(1).some((hole) => pointInRing(longitude, latitude, hole))
}

function featureContains(feature, longitude, latitude) {
  const geometry = feature?.geometry
  if (geometry?.type === 'Polygon') return pointInPolygon(longitude, latitude, geometry.coordinates)
  if (geometry?.type === 'MultiPolygon') return geometry.coordinates.some((polygon) => pointInPolygon(longitude, latitude, polygon))
  return false
}

function recordAt(role, latlng) {
  return administrativeRecords[role].find((record) => {
    const bounds = record.bounds
    return latlng.lng >= bounds.west && latlng.lng <= bounds.east &&
      latlng.lat >= bounds.south && latlng.lat <= bounds.north &&
      featureContains(record.feature, latlng.lng, latlng.lat)
  }) || null
}

function administrativeAt(index, latlng) {
  const administrative = payload.value?.administrative || {}
  let province = administrative.province?.values?.[index] || null
  let city = administrative.city?.values?.[index] || null
  if (!city) {
    const cityRecord = recordAt('city', latlng)
    city = cityRecord?.name || null
    province ||= cityRecord?.province || null
  }
  if (!province) province = recordAt('province', latlng)?.name || null
  return { province: province || 'Outside covered provinces', city: city || 'Outside covered cities' }
}

function intersectsGrid(record) {
  const grid = payload.value?.grid?.bounds
  if (!grid) return false
  return !(record.bounds.east < grid.west || record.bounds.west > grid.east ||
    record.bounds.north < grid.south || record.bounds.south > grid.north)
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character])
}

function labelMarker(record, role) {
  return L.marker(record.labelPoint, {
    pane: 'resultLabels',
    interactive: false,
    icon: L.divIcon({
      className: `administrative-label ${role}-label`,
      html: `<span>${escapeHtml(record.name)}</span>`,
      iconSize: null,
    }),
  })
}

function refreshAdministrativeLabels() {
  if (!map || !provinceLabelGroup || !cityLabelGroup) return
  provinceLabelGroup.clearLayers()
  cityLabelGroup.clearLayers()
  administrativeRecords.province
    .filter(intersectsGrid)
    .forEach((record) => labelMarker(record, 'province').addTo(provinceLabelGroup))
  const visible = map.getBounds()
  const centre = map.getCenter()
  const zoom = map.getZoom()
  const cityLimit = zoom >= 7 ? 24 : zoom >= 6 ? 18 : zoom >= 5 ? 12 : 6
  administrativeRecords.city
    .filter((record) => intersectsGrid(record) && visible.contains(record.labelPoint))
    .sort((left, right) => map.distance(left.labelPoint, centre) - map.distance(right.labelPoint, centre))
    .slice(0, cityLimit)
    .forEach((record) => labelMarker(record, 'city').addTo(cityLabelGroup))
}

const displayLayers = computed(() => {
  const layers = payload.value?.layers || {}
  const allowed =
    props.mode === 'wind'
      ? ['max_wind_ms']
      : ['total_loss', 'max_wind_ms', 'exposure_value']
  return allowed
    .filter((key) => layers[key] && layers[key].display !== 'hover')
    .map((key) => ({ key, name: LAYER_NAMES[key] || layers[key].label || key }))
})

const activeLayer = computed(() => payload.value?.layers?.[activeLayerKey.value] || null)

const activeStops = computed(() => colorStops(activeLayer.value, activeLayerKey.value))

const legendGradient = computed(() => {
  const stops = activeStops.value
  return `linear-gradient(90deg, ${stops.map(([position, color]) => `${color} ${position * 100}%`).join(', ')})`
})

const legendDomain = computed(() => {
  const layer = activeLayer.value
  const domain = normalizedDomain(layer)
  return {
    low: formatLayerValue(activeLayerKey.value, domain[0]),
    high: formatLayerValue(activeLayerKey.value, domain[1]),
  }
})

const hoverRows = computed(() => hovered.value?.rows || [])

function finite(value) {
  const number = Number(value)
  return Number.isFinite(number) ? number : null
}

function clamp(value, minimum, maximum) {
  return Math.max(minimum, Math.min(maximum, value))
}

function formatNumber(value, digits = 2) {
  const number = finite(value)
  return number === null
    ? '—'
    : number.toLocaleString('en-US', { maximumFractionDigits: digits })
}

function formatCurrency(value) {
  const number = finite(value)
  if (number === null) return '—'
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'CNY',
    currencyDisplay: 'narrowSymbol',
    notation: Math.abs(number) >= 10000 ? 'compact' : 'standard',
    maximumFractionDigits: 2,
  }).format(number)
}

function formatLayerValue(key, value) {
  if (key === 'total_loss' || key === 'exposure_value') return formatCurrency(value)
  if (key === 'max_wind_ms') {
    const number = finite(value)
    return number === null ? '—' : `${number.toFixed(2)} m/s`
  }
  if (key === 'lead_hour_of_max') {
    const number = finite(value)
    return number === null ? '—' : `${formatNumber(number, 1)} hr`
  }
  if (key === 'valid_count') {
    const number = finite(value)
    return number === null ? '—' : `${formatNumber(number, 0)} hr`
  }
  if (key === 'source_count') {
    const number = finite(value)
    return number === null ? '—' : formatNumber(number, 0)
  }
  if (key === 'time_of_max') return value ? String(value).replace('T', ' ') : '—'
  return formatNumber(value)
}

function normalizedDomain(layer) {
  const supplied = layer?.color_scale?.domain
  if (Array.isArray(supplied) && supplied.length >= 2) {
    const low = finite(supplied[0])
    const high = finite(supplied[1])
    if (low !== null && high !== null && high > low) return [low, high]
  }
  const values = (layer?.values || []).map(finite).filter((value) => value !== null)
  if (!values.length) return [0, 1]
  let low = values[0]
  let high = values[0]
  for (let index = 1; index < values.length; index += 1) {
    if (values[index] < low) low = values[index]
    if (values[index] > high) high = values[index]
  }
  return high > low ? [low, high] : [low, low + 1]
}

function colorStops(layer, key) {
  const supplied = layer?.color_scale?.stops
  if (Array.isArray(supplied) && supplied.length >= 2) {
    const valid = supplied
      .map((item) => [finite(item?.[0]), String(item?.[1] || '')])
      .filter(([position, color]) => position !== null && /^#[0-9a-f]{6}$/i.test(color))
      .sort((a, b) => a[0] - b[0])
    if (valid.length >= 2) return valid
  }
  if (key === 'total_loss') return FALLBACK_STOPS.loss
  if (key === 'exposure_value') return FALLBACK_STOPS.exposure
  return FALLBACK_STOPS.wind
}

function parseHex(color) {
  const value = String(color).replace('#', '')
  return [
    Number.parseInt(value.slice(0, 2), 16),
    Number.parseInt(value.slice(2, 4), 16),
    Number.parseInt(value.slice(4, 6), 16),
  ]
}

function interpolateColor(stops, position) {
  const value = clamp(position, 0, 1)
  let left = stops[0]
  let right = stops[stops.length - 1]
  for (let index = 1; index < stops.length; index += 1) {
    if (value <= stops[index][0]) {
      left = stops[index - 1]
      right = stops[index]
      break
    }
  }
  const width = right[0] - left[0]
  const mix = width > 0 ? (value - left[0]) / width : 0
  const a = parseHex(left[1])
  const b = parseHex(right[1])
  return a.map((channel, index) => Math.round(channel + (b[index] - channel) * mix))
}

function normalizeColorValue(value, layer) {
  const number = finite(value)
  if (number === null) return null
  const [domainLow, domainHigh] = normalizedDomain(layer)
  const logarithmic = ['log', 'logarithmic'].includes(
    String(layer?.color_scale?.type || '').toLowerCase(),
  )
  if (logarithmic) {
    if (number <= 0) return 0
    const low = Math.max(domainLow, Number.MIN_VALUE)
    const high = Math.max(domainHigh, low * 1.000001)
    return clamp((Math.log10(number) - Math.log10(low)) / (Math.log10(high) - Math.log10(low)), 0, 1)
  }
  return clamp((number - domainLow) / (domainHigh - domainLow || 1), 0, 1)
}

function validatePayload(body) {
  const grid = body?.grid
  const shape = grid?.shape
  if (!body || typeof body !== 'object' || !grid || !body.layers) {
    throw new Error('The interactive map data is incomplete.')
  }
  if (!Array.isArray(shape) || shape.length !== 2) throw new Error('The interactive map is missing its grid dimensions.')
  const rows = Number(shape[0])
  const columns = Number(shape[1])
  if (!Number.isInteger(rows) || !Number.isInteger(columns) || rows < 1 || columns < 1 || rows > 512 || columns > 512) {
    throw new Error('The interactive map has invalid grid dimensions.')
  }
  const bounds = grid.bounds || {}
  const coordinates = [bounds.south, bounds.west, bounds.north, bounds.east].map(finite)
  if (coordinates.some((value) => value === null) || coordinates[2] <= coordinates[0] || coordinates[3] <= coordinates[1]) {
    throw new Error('The interactive map has invalid geographic bounds.')
  }
  const cellCount = rows * columns
  Object.entries(body.layers).forEach(([key, layer]) => {
    if (!Array.isArray(layer?.values) || layer.values.length !== cellCount) {
      throw new Error(`Grid data for the ${key} layer is incomplete.`)
    }
  })
  Object.entries(body.administrative || {}).forEach(([key, field]) => {
    if (key === 'encoding') return
    if (!Array.isArray(field?.values) || field.values.length !== cellCount) {
      throw new Error(`Administrative data for ${key} is incomplete.`)
    }
  })
  return body
}

function indexForLatLng(latlng) {
  const grid = payload.value?.grid
  if (!grid) return null
  const [rows, columns] = grid.shape.map(Number)
  const { south, west, north, east } = grid.bounds
  if (latlng.lat < south || latlng.lat > north || latlng.lng < west || latlng.lng > east) return null
  const geographicRow = clamp(Math.floor(((latlng.lat - south) / (north - south)) * rows), 0, rows - 1)
  const column = clamp(Math.floor(((latlng.lng - west) / (east - west)) * columns), 0, columns - 1)
  const row = grid.latitude_direction === 'descending' ? rows - 1 - geographicRow : geographicRow
  return { row, column, index: row * columns + column }
}

function rowsForCell(index, latlng) {
  const layers = payload.value?.layers || {}
  const administrative = administrativeAt(index, latlng)
  const keys =
    props.mode === 'wind'
      ? ['max_wind_ms', 'time_of_max', 'lead_hour_of_max', 'valid_count', 'source_count']
      : ['total_loss', 'max_wind_ms', 'exposure_value', 'source_count']
  return [
    { label: 'Latitude', value: `${latlng.lat.toFixed(4)}°N` },
    { label: 'Longitude', value: `${latlng.lng.toFixed(4)}°E` },
    { label: 'Province', value: administrative.province },
    { label: 'City', value: administrative.city },
    ...keys
      .filter((key) => layers[key])
      .map((key) => ({
        label: LAYER_NAMES[key] || layers[key].label || key,
        value: formatLayerValue(key, layers[key].values[index]),
      })),
  ]
}

function tooltipNode(rows, locked = false) {
  const node = document.createElement('div')
  node.className = 'result-map-tooltip'
  if (locked) {
    const lock = document.createElement('strong')
    lock.textContent = 'Pinned grid cell'
    node.appendChild(lock)
  }
  rows.forEach((row) => {
    const line = document.createElement('div')
    const label = document.createElement('span')
    const value = document.createElement('b')
    label.textContent = row.label
    value.textContent = row.value
    line.append(label, value)
    node.appendChild(line)
  })
  return node
}

function showCell(latlng, lock = false) {
  if (!map || (pinned.value && !lock)) return
  const cell = indexForLatLng(latlng)
  if (!cell) {
    if (!pinned.value) clearHover()
    return
  }
  const sourceCount = finite(payload.value?.layers?.source_count?.values?.[cell.index])
  const activeValue = activeLayer.value?.values?.[cell.index]
  if ((sourceCount !== null && sourceCount <= 0) || (sourceCount === null && activeValue == null)) {
    const administrative = administrativeAt(cell.index, latlng)
    const emptyRows = [
      { label: 'Latitude', value: `${latlng.lat.toFixed(4)}°N` },
      { label: 'Longitude', value: `${latlng.lng.toFixed(4)}°E` },
      { label: 'Province', value: administrative.province },
      { label: 'City', value: administrative.city },
      { label: 'Grid Data', value: 'No source data' },
    ]
    hovered.value = { rows: emptyRows, empty: true }
    hoverTooltip?.setLatLng(latlng).setContent(tooltipNode(emptyRows, lock)).openOn(map)
    if (lock) pinned.value = true
    return
  }
  const rows = rowsForCell(cell.index, latlng)
  hovered.value = { ...cell, rows, empty: false }
  hoverTooltip?.setLatLng(latlng).setContent(tooltipNode(rows, lock)).openOn(map)
  if (lock) pinned.value = true
}

function clearHover(force = false) {
  if (pinned.value && !force) return
  hovered.value = null
  if (map && hoverTooltip) map.closeTooltip(hoverTooltip)
}

function onMapMove(event) {
  showCell(event.latlng, false)
}

function onMapClick(event) {
  pinned.value = false
  showCell(event.latlng, true)
}

function unlockCell() {
  pinned.value = false
  clearHover(true)
}

function canvasBlob(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error('Failed to render the map image.'))), 'image/png')
  })
}

async function renderRaster() {
  if (!map || !payload.value || !activeLayer.value) return
  const sequence = ++renderSequence
  const [rows, columns] = payload.value.grid.shape.map(Number)
  const canvas = document.createElement('canvas')
  canvas.width = columns
  canvas.height = rows
  const context = canvas.getContext('2d', { alpha: true })
  const image = context.createImageData(columns, rows)
  const values = activeLayer.value.values
  const counts = payload.value.layers?.source_count?.values
  const ascending = payload.value.grid.latitude_direction !== 'descending'
  const stops = colorStops(activeLayer.value, activeLayerKey.value)
  for (let canvasRow = 0; canvasRow < rows; canvasRow += 1) {
    const sourceRow = ascending ? rows - 1 - canvasRow : canvasRow
    for (let column = 0; column < columns; column += 1) {
      const sourceIndex = sourceRow * columns + column
      const targetIndex = (canvasRow * columns + column) * 4
      const sourceCount = counts ? finite(counts[sourceIndex]) : null
      const value = values[sourceIndex]
      const populated = sourceCount === null ? value != null : sourceCount > 0
      const position = populated ? normalizeColorValue(value, activeLayer.value) : null
      if (position === null) continue
      const [red, green, blue] = interpolateColor(stops, position)
      image.data[targetIndex] = red
      image.data[targetIndex + 1] = green
      image.data[targetIndex + 2] = blue
      image.data[targetIndex + 3] = 218
    }
  }
  context.putImageData(image, 0, 0)
  const blob = await canvasBlob(canvas)
  if (sequence !== renderSequence || !map) return
  const url = URL.createObjectURL(blob)
  if (rasterOverlay) map.removeLayer(rasterOverlay)
  if (rasterObjectUrl) URL.revokeObjectURL(rasterObjectUrl)
  rasterObjectUrl = url
  const bounds = payload.value.grid.bounds
  rasterOverlay = L.imageOverlay(
    url,
    [
      [bounds.south, bounds.west],
      [bounds.north, bounds.east],
    ],
    { pane: 'resultRaster', opacity: 0.9, interactive: false, className: 'result-raster-image' },
  ).addTo(map)
}

function trackPointTooltip(point) {
  const rows = []
  if (point.time) rows.push(`Source time: ${String(point.time).replace('T', ' ')}`)
  if (point.strength) rows.push(`Intensity: ${point.strength}`)
  if (finite(point.wind_ms) !== null) rows.push(`Track wind speed: ${Number(point.wind_ms).toFixed(2)} m/s`)
  if (finite(point.pressure_hpa) !== null) rows.push(`Central pressure: ${formatNumber(point.pressure_hpa, 1)} hPa`)
  rows.push(`Position: ${Number(point.lat).toFixed(3)}°N, ${Number(point.lon).toFixed(3)}°E`)
  const node = document.createElement('div')
  rows.forEach((text) => {
    const line = document.createElement('div')
    line.textContent = text
    node.appendChild(line)
  })
  return node
}

function drawTrack() {
  if (!map) return
  if (trackGroup) map.removeLayer(trackGroup)
  trackGroup = L.layerGroup([], { pane: 'resultTrack' }).addTo(map)
  const points = (payload.value?.track?.points || []).filter(
    (point) => finite(point?.lat) !== null && finite(point?.lon) !== null,
  )
  if (!points.length) return
  const coordinates = points.map((point) => [Number(point.lat), Number(point.lon)])
  L.polyline(coordinates, { pane: 'resultTrack', color: '#e1272d', weight: 2.5, opacity: 0.95 }).addTo(trackGroup)
  const step = Math.max(1, Math.ceil(points.length / 55))
  points.forEach((point, index) => {
    if (index !== 0 && index !== points.length - 1 && index % step !== 0) return
    L.circleMarker([point.lat, point.lon], {
      pane: 'resultTrack',
      radius: index === points.length - 1 ? 4.2 : 2.6,
      color: '#fff',
      weight: 1,
      fillColor: '#e1272d',
      fillOpacity: 1,
    })
      .bindTooltip(trackPointTooltip(point), { direction: 'top', className: 'track-tooltip' })
      .addTo(trackGroup)
  })
}

async function drawBoundaries() {
  if (!map) return
  try {
    const countries = await boundaryData('/maps/world-countries.geojson')
    if (map) {
      L.geoJSON(countries, {
        pane: 'countryLand',
        style: { color: '#84958b', weight: 0.55, opacity: 0.78, fillColor: '#e3ead8', fillOpacity: 1 },
        interactive: false,
      }).addTo(map)
    }
  } catch {
    localWarnings.value.push('The local world country layer could not be loaded.')
  }
  const definitions = [
    ['/maps/china-provinces.geojson', { color: '#6d7d82', weight: 0.8, opacity: 0.8, fillOpacity: 0 }, 'province'],
    ['/maps/coastal-cities.geojson', { color: '#9ba7aa', weight: 0.42, opacity: 0.72, fillOpacity: 0 }, 'city'],
    ['/maps/nine-dash-line.geojson', { color: '#63747a', weight: 1, opacity: 0.8, dashArray: '5 4', fillOpacity: 0 }, null],
  ]
  const results = await Promise.allSettled(definitions.map(([url]) => boundaryData(url)))
  if (!map) return
  results.forEach((result, index) => {
    if (result.status === 'fulfilled') {
      L.geoJSON(result.value, { pane: 'resultBoundaries', style: definitions[index][1], interactive: false }).addTo(map)
      if (definitions[index][2]) indexAdministrativeFeatures(result.value, definitions[index][2])
    } else {
      localWarnings.value.push(`The local boundary layer ${definitions[index][0].split('/').pop()} could not be loaded.`)
    }
  })
  refreshAdministrativeLabels()
}

function fitGrid() {
  if (!map || !payload.value) return
  const bounds = props.mode === 'loss' && referenceBounds
    ? referenceBounds
    : payload.value.grid.bounds
  map.fitBounds(
    [
      [bounds.south, bounds.west],
      [bounds.north, bounds.east],
    ],
    { padding: [22, 22], maxZoom: 7, animate: false },
  )
}

function initMap() {
  if (!mapEl.value || map) return
  map = L.map(mapEl.value, {
    crs: L.CRS.EPSG4326,
    preferCanvas: true,
    zoomControl: false,
    attributionControl: false,
    minZoom: 2,
    maxZoom: 11,
  })
  map.getContainer().style.backgroundColor = '#c6e2eb'
  map.createPane('resultRaster').style.zIndex = '240'
  map.createPane('countryLand').style.zIndex = '190'
  map.createPane('resultBoundaries').style.zIndex = '340'
  map.createPane('resultLabels').style.zIndex = '390'
  map.createPane('resultTrack').style.zIndex = '440'
  L.control.zoom({ position: 'bottomright' }).addTo(map)
  L.control.scale({ position: 'bottomleft', imperial: false, maxWidth: 110 }).addTo(map)
  hoverTooltip = L.tooltip({ sticky: true, direction: 'top', offset: [0, -8], className: 'result-data-tooltip' })
  map.on('mousemove', onMapMove)
  map.on('click', onMapClick)
  map.on('zoomend moveend', refreshAdministrativeLabels)
  provinceLabelGroup = L.layerGroup().addTo(map)
  cityLabelGroup = L.layerGroup().addTo(map)
  mapEl.value.addEventListener('pointerleave', onPointerLeave)
  fitGrid()
}

function onPointerLeave() {
  if (!pinned.value) clearHover(true)
}

function cleanupMap() {
  renderSequence += 1
  if (resizeObserver) {
    resizeObserver.disconnect()
    resizeObserver = null
  }
  if (intersectionObserver) {
    intersectionObserver.disconnect()
    intersectionObserver = null
  }
  if (mapEl.value) mapEl.value.removeEventListener('pointerleave', onPointerLeave)
  if (map) {
    map.off('mousemove', onMapMove)
    map.off('click', onMapClick)
    map.off('zoomend moveend', refreshAdministrativeLabels)
    map.remove()
    map = null
  }
  rasterOverlay = null
  trackGroup = null
  provinceLabelGroup = null
  cityLabelGroup = null
  hoverTooltip = null
  if (rasterObjectUrl) {
    URL.revokeObjectURL(rasterObjectUrl)
    rasterObjectUrl = ''
  }
}

function observeMap() {
  if (stageEl.value && window.ResizeObserver) {
    resizeObserver = new ResizeObserver(() => map?.invalidateSize({ pan: false, animate: false }))
    resizeObserver.observe(stageEl.value)
  }
  if (rootEl.value && window.IntersectionObserver) {
    intersectionObserver = new IntersectionObserver((entries) => {
      if (entries.some((entry) => entry.isIntersecting)) {
        window.requestAnimationFrame(() => map?.invalidateSize({ pan: false, animate: false }))
      }
    })
    intersectionObserver.observe(rootEl.value)
  }
}

async function loadMap() {
  abortController?.abort()
  abortController = new AbortController()
  cleanupMap()
  loading.value = true
  error.value = ''
  payload.value = null
  hovered.value = null
  pinned.value = false
  localWarnings.value = []
  referenceBounds = null
  emit('rankings-ready', [])
  try {
    const response = await fetch(`/api/jobs/${encodeURIComponent(props.jobId)}/artifacts/interactive-map`, {
      signal: abortController.signal,
      cache: 'no-store',
    })
    if (!response.ok) {
      throw new Error(response.status === 404 ? 'Interactive map data is not available for this result yet.' : `Failed to load the interactive map (${response.status}).`)
    }
    const body = validatePayload(await response.json())
    payload.value = body
    if (props.mode === 'loss' && props.referenceJobId) {
      try {
        const referenceResponse = await fetch(
          `/api/jobs/${encodeURIComponent(props.referenceJobId)}/artifacts/interactive-map`,
          { signal: abortController.signal, cache: 'no-store' },
        )
        if (referenceResponse.ok) {
          referenceBounds = validatePayload(await referenceResponse.json()).grid.bounds
        }
      } catch (referenceError) {
        if (referenceError?.name === 'AbortError') throw referenceError
      }
    }
    activeLayerKey.value = props.mode === 'loss' && body.layers.total_loss ? 'total_loss' : 'max_wind_ms'
    loading.value = false
    await nextTick()
    initMap()
    observeMap()
    await Promise.all([drawBoundaries(), renderRaster()])
    if (props.mode === 'wind') emit('rankings-ready', maximumsByRegion())
    drawTrack()
    fitGrid()
    window.requestAnimationFrame(() => map?.invalidateSize({ pan: false, animate: false }))
  } catch (caught) {
    if (caught?.name === 'AbortError') return
    loading.value = false
    error.value = caught?.message || 'The interactive map is temporarily unavailable.'
  }
}

function maximumsByRegion() {
  const grid = payload.value?.grid
  const values = payload.value?.layers?.max_wind_ms?.values
  if (!grid || !Array.isArray(values)) return []
  const [rows, columns] = grid.shape.map(Number)
  const { south, west, north, east } = grid.bounds
  const latitudeDescending = grid.latitude_direction === 'descending'
  const cityValues = payload.value?.administrative?.city?.values || []
  const provinceValues = payload.value?.administrative?.province?.values || []
  const maxima = new Map()

  values.forEach((value, index) => {
    if (value === null || value === undefined || value === '') return
    const wind = finite(value)
    if (wind === null) return
    const row = Math.floor(index / columns)
    const column = index % columns
    const fraction = (row + 0.5) / rows
    const latitude = latitudeDescending
      ? north - fraction * (north - south)
      : south + fraction * (north - south)
    const longitude = west + ((column + 0.5) / columns) * (east - west)
    const latlng = { lat: latitude, lng: longitude }
    const cityRecord = recordAt('city', latlng)
    const provinceRecord = recordAt('province', latlng)
    const city = cityValues[index] || cityRecord?.name
    const province = provinceValues[index] || cityRecord?.province || provinceRecord?.name
    const provinceKey = String(province || '').trim().toLowerCase().replace(/\s+province$/, '')
    if (!RANKING_PROVINCES.has(provinceKey)) return
    const cityKey = String(city || '').trim().toLowerCase()
    if (!cityKey || cityKey === provinceKey) return
    const region = city && province ? `${city}, ${province}` : city || province
    if (!region) return
    maxima.set(region, Math.max(maxima.get(region) ?? -Infinity, wind))
  })

  return [...maxima.entries()]
    .map(([region, wind]) => ({ region, wind }))
    .sort((left, right) => right.wind - left.wind || left.region.localeCompare(right.region))
}

function selectLayer(key) {
  if (!payload.value?.layers?.[key] || activeLayerKey.value === key) return
  activeLayerKey.value = key
  pinned.value = false
  clearHover(true)
}

function adjustHeight(delta) {
  const current = stageEl.value?.offsetHeight || mapHeight.value
  mapHeight.value = clamp(current + delta, 360, 760)
  nextTick(() => map?.invalidateSize({ pan: false, animate: false }))
}

async function toggleFullscreen() {
  if (!rootEl.value || !document.fullscreenEnabled) return
  try {
    if (document.fullscreenElement === rootEl.value) await document.exitFullscreen()
    else await rootEl.value.requestFullscreen()
  } catch {
    localWarnings.value.push('The browser denied full-screen access. Map zoom and height controls remain available.')
  }
}

function onFullscreenChange() {
  fullscreen.value = document.fullscreenElement === rootEl.value
  window.setTimeout(() => map?.invalidateSize({ pan: false, animate: false }), 80)
}

watch(activeLayerKey, () => renderRaster())
watch(() => props.jobId, loadMap)

onMounted(() => {
  fullscreenSupported.value = Boolean(document.fullscreenEnabled)
  document.addEventListener('fullscreenchange', onFullscreenChange)
  loadMap()
})

onBeforeUnmount(() => {
  abortController?.abort()
  cleanupMap()
  document.removeEventListener('fullscreenchange', onFullscreenChange)
})
</script>

<template>
  <article ref="rootEl" class="result-map-card subpanel" :class="{ fullscreen }">
    <header class="map-heading">
      <div>
        <h4>{{ title }}</h4>
        <p v-if="mode === 'loss'">Loss and exposure are summed within each display cell; wind speed shows the maximum.</p>
      </div>
      <div class="map-actions" aria-label="Map display controls">
        <button type="button" aria-label="Reset the map to its initial extent" title="Reset map extent" @click="fitGrid">Reset</button>
        <button type="button" aria-label="Decrease map height" title="Decrease map height" @click="adjustHeight(-80)">Height −</button>
        <button type="button" aria-label="Increase map height" title="Increase map height" @click="adjustHeight(80)">Height +</button>
        <button
          type="button"
          :disabled="!fullscreenSupported"
          :aria-label="fullscreen ? 'Exit full-screen map' : 'View map in full screen'"
          :aria-pressed="fullscreen"
          @click="toggleFullscreen"
        >
          {{ fullscreen ? 'Exit Full Screen' : 'Full Screen' }}
        </button>
      </div>
    </header>

    <div v-if="displayLayers.length > 1" class="layer-switch" role="group" aria-label="Result layers">
      <button
        v-for="layer in displayLayers"
        :key="layer.key"
        type="button"
        :class="{ active: activeLayerKey === layer.key }"
        :aria-pressed="activeLayerKey === layer.key"
        @click="selectLayer(layer.key)"
      >
        {{ layer.name }}
      </button>
    </div>

    <div v-if="loading" class="map-state" role="status">Preparing the interactive map…</div>
    <div v-else-if="error" class="map-state error" role="alert">
      <p>{{ error }}</p>
      <button type="button" @click="loadMap">Try Again</button>
    </div>

    <template v-else>
      <div
        ref="stageEl"
        class="map-stage"
        :style="{ height: `${mapHeight}px` }"
        aria-label="Interactive results map. Use the mouse wheel to zoom, drag to pan, hover to inspect grid data, and click to pin a cell."
        role="region"
      >
        <div ref="mapEl" class="map-canvas"></div>
        <div class="north-arrow" aria-hidden="true"><span>N</span><i>↑</i></div>
        <div class="map-hint">Hover to inspect · Click to pin · Scroll to zoom</div>
      </div>

      <div class="legend-row" aria-label="Color legend">
        <span>{{ legendDomain.low }}</span>
        <i :style="{ background: legendGradient }"></i>
        <span>{{ legendDomain.high }}</span>
      </div>
      <div class="land-sea-key" aria-label="Land and sea background">
        <span><i class="land-swatch"></i>Land</span>
        <span><i class="sea-swatch"></i>Sea</span>
      </div>

      <section class="hover-details" :aria-live="pinned ? 'polite' : 'off'">
        <div class="hover-head">
          <strong>{{ pinned ? 'Pinned Grid Data' : 'Grid Data' }}</strong>
          <button v-if="pinned" type="button" @click="unlockCell">Unpin</button>
        </div>
        <div v-if="hoverRows.length" class="hover-grid">
          <div v-for="row in hoverRows" :key="row.label">
            <span>{{ row.label }}</span><strong>{{ row.value }}</strong>
          </div>
        </div>
        <p v-else>Hover over a colored grid cell to view all data at that location.</p>
      </section>
    </template>
  </article>
</template>

<style scoped>
.result-map-card {
  margin-bottom: 12px;
  overflow: visible;
  background: #fff;
}

.map-heading {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 12px;
}

.map-heading h4 { margin: 0; color: var(--ink); font-size: 15px; }
.map-heading p { margin: 4px 0 0; color: var(--muted); font-size: 11px; line-height: 1.45; }

.map-actions,
.layer-switch {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.map-actions button,
.layer-switch button,
.map-state button,
.hover-head button {
  min-height: 32px;
  padding: 6px 10px;
  border: 1px solid #bdd0d2;
  border-radius: 8px;
  background: #fff;
  color: #0b6570;
  font: inherit;
  font-size: 11px;
  font-weight: 700;
  cursor: pointer;
}

.map-actions button:hover,
.layer-switch button:hover,
.map-state button:hover,
.hover-head button:hover { border-color: #348b91; background: #edf7f7; }

.map-actions button:focus-visible,
.layer-switch button:focus-visible,
.map-state button:focus-visible,
.hover-head button:focus-visible {
  outline: 3px solid #61b5b866;
  outline-offset: 2px;
}

.map-actions button:disabled { cursor: not-allowed; opacity: 0.45; }
.layer-switch { margin: -2px 0 12px; }
.layer-switch button.active { border-color: #0d7a82; background: #0d7a82; color: #fff; }

.map-state {
  min-height: 260px;
  display: grid;
  place-content: center;
  gap: 10px;
  border: 1px dashed #b9ccce;
  border-radius: 10px;
  background: #f3f8f8;
  color: var(--muted);
  text-align: center;
}

.map-state p { margin: 0; }
.map-state.error { border-color: #e3aaaa; background: #fff6f6; color: #a22626; }

.map-stage {
  position: relative;
  min-height: 360px;
  max-height: 760px;
  overflow: hidden;
  resize: vertical;
  border: 1px solid #b9c8cb;
  border-radius: 10px;
  background: #f5f8f5;
}

.map-canvas {
  width: 100%;
  height: 100%;
  background-color: #c6e2eb;
}

.land-sea-key { display: flex; gap: 14px; margin: -3px 0 10px; color: #627275; font-size: 10px; }
.land-sea-key span { display: inline-flex; align-items: center; gap: 5px; }
.land-sea-key i { display: inline-block; width: 13px; height: 9px; border: 1px solid #82938a; border-radius: 2px; }
.land-swatch { background: #e3ead8; }
.sea-swatch { background: #c6e2eb; }

.north-arrow {
  position: absolute;
  z-index: 650;
  top: 12px;
  right: 12px;
  display: grid;
  place-items: center;
  width: 30px;
  padding: 5px 0;
  border: 1px solid #ccd6d4;
  border-radius: 7px;
  background: #ffffffdd;
  color: #243b3f;
  box-shadow: 0 2px 8px #17394c19;
  pointer-events: none;
}

.north-arrow span { font-size: 10px; font-weight: 800; }
.north-arrow i { font-size: 18px; font-style: normal; line-height: 1; }

.map-hint {
  position: absolute;
  z-index: 650;
  right: 12px;
  bottom: 12px;
  padding: 6px 9px;
  border: 1px solid #d0dcda;
  border-radius: 7px;
  background: #ffffffdf;
  color: #536569;
  font-size: 10px;
  pointer-events: none;
}

.legend-row {
  display: grid;
  grid-template-columns: minmax(70px, auto) 1fr minmax(70px, auto);
  align-items: center;
  gap: 9px;
  margin: 10px 2px 12px;
  color: #536569;
  font-size: 10px;
}

.legend-row i { height: 10px; border: 1px solid #aebcbe; border-radius: 999px; }
.legend-row span:last-child { text-align: right; }

.hover-details {
  min-height: 82px;
  padding: 11px 12px;
  border: 1px solid #d4e0df;
  border-radius: 10px;
  background: #f7faf9;
}

.hover-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.hover-head > strong { font-size: 12px; }
.hover-head button { min-height: 27px; padding: 4px 8px; }
.hover-details > p { margin: 10px 0 0; color: var(--muted); font-size: 11px; }
.hover-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(145px, 1fr)); gap: 8px; margin-top: 9px; }
.hover-grid div { min-width: 0; padding: 7px 9px; border-radius: 7px; background: #fff; }
.hover-grid span,
.hover-grid strong { display: block; overflow-wrap: anywhere; }
.hover-grid span { margin-bottom: 3px; color: var(--muted); font-size: 10px; }
.hover-grid strong { color: var(--ink); font-size: 11px; }

.result-map-card:fullscreen {
  width: 100%;
  height: 100%;
  margin: 0;
  padding: 18px;
  overflow: auto;
  border: 0;
  border-radius: 0;
  background: #fff;
}

.result-map-card:fullscreen .map-stage { height: calc(100vh - 245px) !important; max-height: none; resize: none; }

:deep(.leaflet-container) { color: #243b3f; font-family: inherit; }
:deep(.result-raster-image) { image-rendering: auto; }
:deep(.leaflet-control-zoom a) { color: #0b6570; }
:deep(.leaflet-control-scale-line) { border-color: #42565a; background: #ffffffc9; color: #263a3d; }
:deep(.result-data-tooltip),
:deep(.track-tooltip) {
  border: 1px solid #bfd0d1;
  border-radius: 8px;
  background: #fffffff2;
  color: #243b3f;
  box-shadow: 0 7px 22px #18363e2b;
  font-size: 10px;
  line-height: 1.45;
}

:deep(.result-map-tooltip > strong) { display: block; margin-bottom: 4px; color: #0b6570; }
:deep(.result-map-tooltip > div) { display: flex; justify-content: space-between; gap: 14px; }
:deep(.result-map-tooltip span) { color: #627275; }
:deep(.result-map-tooltip b) { text-align: right; }

:deep(.administrative-label) {
  width: auto !important;
  height: auto !important;
  border: 0;
  background: transparent;
  pointer-events: none !important;
}

:deep(.administrative-label span) {
  display: inline-block;
  transform: translate(-50%, -50%);
  white-space: nowrap;
  color: #31494d;
  text-shadow: 0 0 2px #fff, 0 0 5px #fff, 0 0 8px #fff;
}

:deep(.administrative-label.province-label span) {
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 0.03em;
  text-transform: uppercase;
}

:deep(.administrative-label.city-label span) {
  color: #52666a;
  font-size: 9px;
  font-weight: 700;
}

@media (max-width: 720px) {
  .map-heading { flex-direction: column; }
  .map-actions { width: 100%; }
  .map-actions button { flex: 1 1 auto; }
  .map-stage { height: 420px !important; resize: vertical; }
  .map-hint { display: none; }
  .legend-row { grid-template-columns: 65px 1fr 65px; }
}
</style>
