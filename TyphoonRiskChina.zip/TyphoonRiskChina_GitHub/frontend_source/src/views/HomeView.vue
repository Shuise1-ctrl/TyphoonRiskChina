<script setup>
import HeroSection from '../components/HeroSection.vue'
import StormDatabaseSection from '../components/StormDatabaseSection.vue'
import LossCalcSection from '../components/LossCalcSection.vue'
import SiteFooter from '../components/SiteFooter.vue'
</script>

<template>
  <div class="page">
    <main>
      <HeroSection />
      <StormDatabaseSection />
      <LossCalcSection />
    </main>
    <SiteFooter />
  </div>
</template>

<style scoped>
.page {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background: #f8fbfc;
}

main {
  flex: 1;
}
</style>
