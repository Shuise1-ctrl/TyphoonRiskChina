<script setup>
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { getStormById } from '../data/storms.js'

const route = useRoute()
const router = useRouter()

const storm = computed(() => getStormById(route.params.id))

function pressureText(value) {
  return value == null ? '—' : `${value} hPa`
}

function goBack() {
  router.push({ path: '/', hash: '#storm-database' })
}
</script>

<template>
  <div class="detail-page">
    <header class="topbar">
      <button class="back" type="button" @click="goBack">Back to Storm Archive</button>
      <p v-if="storm" class="top-title">{{ storm.category }} {{ storm.name }} ({{ storm.year }})</p>
    </header>

    <template v-if="storm">
      <section class="track-section" aria-label="Typhoon track map">
        <div class="track-frame">
          <!-- Reserved for track map image or map component -->
          <div class="track-placeholder">
            <p class="placeholder-label">Typhoon Track Map</p>
          </div>
        </div>
      </section>

      <section class="info-section" aria-label="Storm information">
        <div class="info-inner">
          <div class="info-head">
            <h1>{{ storm.category }} {{ storm.name }} ({{ storm.year }})</h1>
            <span class="status" :data-active="storm.status === 'Active'">{{ storm.status }}</span>
          </div>

          <dl class="basics">
            <div>
              <dt>Formed</dt>
              <dd>{{ storm.formed }}</dd>
            </div>
            <div>
              <dt>Dissipated</dt>
              <dd>{{ storm.dissipated }}</dd>
            </div>
            <div>
              <dt>Origin</dt>
              <dd>{{ storm.location }}</dd>
            </div>
            <div>
              <dt>Maximum Wind Speed</dt>
              <dd>{{ storm.maxWind }} km/h</dd>
            </div>
            <div>
              <dt>Minimum Pressure</dt>
              <dd>{{ pressureText(storm.minPressure) }}</dd>
            </div>
            <div>
              <dt>Category</dt>
              <dd>{{ storm.category }}</dd>
            </div>
          </dl>

          <div class="blocks">
            <article class="block">
              <h2>Track Overview</h2>
              <!-- Reserved for track description -->
              <p class="empty">A detailed track summary will be added here.</p>
            </article>

            <article class="block">
              <h2>Impact &amp; Losses</h2>
              <!-- Reserved for impact and loss data -->
              <p class="empty">Impact and loss information will be added here.</p>
            </article>
          </div>
        </div>
      </section>
    </template>

    <section v-else class="not-found">
      <p>Storm record not found.</p>
      <button class="back" type="button" @click="goBack">Back to Storm Archive</button>
    </section>
  </div>
</template>

<style scoped>
.detail-page {
  min-height: 100vh;
  background: #f5f8fa;
  color: var(--ink);
}

.topbar {
  position: sticky;
  top: 0;
  z-index: 5;
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 0.9rem clamp(1rem, 4vw, 2.5rem);
  background: rgba(248, 251, 252, 0.92);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid var(--line);
}

.back {
  flex-shrink: 0;
  min-height: 2.2rem;
  padding: 0 0.9rem;
  border-radius: 0.5rem;
  font-size: 0.9rem;
  color: var(--deep);
  background: #fff;
  border: 1px solid var(--line);
  transition:
    background 0.2s var(--ease),
    border-color 0.2s var(--ease);
}

.back:hover {
  border-color: rgba(74, 143, 163, 0.4);
  background: #f8fbfc;
}

.top-title {
  font-size: 0.95rem;
  font-weight: 500;
  color: var(--ink-soft);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.track-section {
  padding: 1.25rem clamp(1rem, 4vw, 2.5rem) 0;
}

.track-frame {
  max-width: 1200px;
  margin: 0 auto;
  height: min(58vh, 520px);
  min-height: 320px;
  border-radius: 0.85rem;
  overflow: hidden;
  border: 1px solid var(--line);
  background: #0f2430;
}

.track-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 0.55rem;
  background:
    radial-gradient(ellipse 55% 45% at 60% 40%, rgba(78, 150, 170, 0.28), transparent 60%),
    linear-gradient(160deg, #1a3d4d 0%, #0f2430 55%, #0a1a22 100%);
}

.placeholder-label {
  font-size: clamp(1.2rem, 2.5vw, 1.55rem);
  font-weight: 500;
  color: rgba(244, 250, 252, 0.92);
  letter-spacing: 0.04em;
}

.info-section {
  padding: 2rem clamp(1rem, 4vw, 2.5rem) 3.5rem;
}

.info-inner {
  max-width: 1200px;
  margin: 0 auto;
}

.info-head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 1rem;
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
}

h1 {
  font-size: clamp(1.6rem, 3.2vw, 2.2rem);
  font-weight: 600;
  letter-spacing: 0.02em;
}

.status {
  font-size: 0.85rem;
  color: var(--ink-soft);
  letter-spacing: 0.04em;
}

.status[data-active='true'] {
  color: #c45c26;
}

.basics {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 1rem;
  margin-bottom: 1.75rem;
  padding: 1.25rem 1.35rem;
  border: 1px solid var(--line);
  border-radius: 0.75rem;
  background: rgba(255, 255, 255, 0.85);
}

.basics dt {
  font-size: 0.75rem;
  letter-spacing: 0.06em;
  color: rgba(61, 90, 104, 0.75);
  margin-bottom: 0.3rem;
}

.basics dd {
  font-size: 0.98rem;
  line-height: 1.4;
}

.blocks {
  display: grid;
  gap: 1rem;
}

.block {
  padding: 1.35rem 1.4rem;
  border: 1px solid var(--line);
  border-radius: 0.75rem;
  background: rgba(255, 255, 255, 0.85);
}

.block h2 {
  font-size: 1.1rem;
  font-weight: 500;
  margin-bottom: 0.85rem;
  letter-spacing: 0.02em;
}

.empty {
  font-size: 0.95rem;
  color: var(--ink-soft);
  line-height: 1.6;
}

.not-found {
  min-height: 60vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  color: var(--ink-soft);
}

@media (max-width: 800px) {
  .basics {
    grid-template-columns: 1fr 1fr;
  }

  .track-frame {
    min-height: 260px;
    height: 42vh;
  }
}

@media (max-width: 520px) {
  .basics {
    grid-template-columns: 1fr;
  }
}
</style>
