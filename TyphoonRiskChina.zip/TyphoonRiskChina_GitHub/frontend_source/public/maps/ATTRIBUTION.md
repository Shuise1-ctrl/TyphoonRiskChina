Natural Earth country outlines

The unlabelled country polygons in world-countries.geojson are derived from Natural Earth 1:110m Admin 0 Countries, distributed in the GeoPandas sample dataset. Natural Earth data is public domain. The geometry is simplified for display. These lines are for visualization and are not authoritative legal boundaries.

Source: https://www.naturalearthdata.com/downloads/110m-cultural-vectors/110m-admin-0-countries/
