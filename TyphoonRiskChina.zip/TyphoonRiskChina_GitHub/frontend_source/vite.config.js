import { spawn } from 'node:child_process'
import { existsSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

const frontendRoot = dirname(fileURLToPath(import.meta.url))
const backendRoot = resolve(frontendRoot, '..')
const backendPython =
  process.env.TYPHOON_BACKEND_PYTHON ||
  resolve(backendRoot, '.venv', process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python')
const backendHealthUrl = 'http://127.0.0.1:8788/api/health'

async function backendIsReady() {
  try {
    const response = await fetch(backendHealthUrl, {
      signal: AbortSignal.timeout(1000),
    })
    if (!response.ok) return false
    const health = await response.json()
    return health.status === 'ok' && String(health.engine || '').startsWith('TyphoonRiskChina')
  } catch {
    return false
  }
}

function localCalculationService() {
  let backendProcess = null
  let monitorTimer = null

  function stopOwnedBackend() {
    if (backendProcess && backendProcess.exitCode === null) {
      backendProcess.kill()
    }
    backendProcess = null
  }

  async function ensureBackend() {
    if (await backendIsReady()) return
    if (!existsSync(backendPython)) {
      throw new Error(`未找到本地算法环境：${backendPython}`)
    }

    if (!backendProcess || backendProcess.exitCode !== null) {
      backendProcess = spawn(
        backendPython,
        ['-m', 'uvicorn', 'backend.app:app', '--host', '127.0.0.1', '--port', '8788'],
        {
          cwd: backendRoot,
          stdio: 'inherit',
          windowsHide: true,
        },
      )
    }

    for (let attempt = 0; attempt < 80; attempt += 1) {
      if (await backendIsReady()) return
      if (backendProcess.exitCode !== null) {
        throw new Error(`本地算法服务启动失败，退出代码：${backendProcess.exitCode}`)
      }
      await new Promise((resolve) => setTimeout(resolve, 250))
    }
    stopOwnedBackend()
    throw new Error('本地算法服务启动超时')
  }

  return {
    name: 'local-typhoon-calculation-service',
    async configureServer(server) {
      server.middlewares.use((request, response, next) => {
        const remoteAddress = request.socket.remoteAddress || ''
        const isLocal = ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(remoteAddress)
        if (!isLocal) {
          response.statusCode = 403
          response.end('This local application only accepts requests from this computer.')
          return
        }
        next()
      })

      await ensureBackend()

      monitorTimer = setInterval(() => {
        ensureBackend().catch((error) => {
          console.error(`[TyphoonRiskChina] ${error.message}`)
        })
      }, 5000)
      monitorTimer.unref()

      server.httpServer?.once('close', () => {
        clearInterval(monitorTimer)
        stopOwnedBackend()
      })
      process.once('exit', stopOwnedBackend)
    },
  }
}

export default defineConfig({
  plugins: [localCalculationService(), vue()],
  server: {
    host: '127.0.0.1',
    port: 5173,
    strictPort: true,
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8788',
        changeOrigin: true,
      },
    },
  },
})
