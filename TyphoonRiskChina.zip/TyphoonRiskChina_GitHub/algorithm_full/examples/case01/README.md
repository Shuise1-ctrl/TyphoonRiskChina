# Case 01: self-contained reviewer demo

This example needs no FuXi weights, GPU, NetCDF, H5 model, or Parquet exposure assets. It validates a track and a five-row exposure/wind sample, applies the same published TyphoonRiskChina vulnerability equations, and writes CSV, JSON, Markdown, and a run manifest.

```bash
typhoonriskchina check --config examples/case01/config.yml
typhoonriskchina run --config examples/case01/config.yml
```

Outputs are created under `examples/case01/outputs/` and are ignored by Git.

The example verifies software installation and data contracts. It is not an observed or operational loss estimate.
