# Expected result

`loss_summary.json` records the deterministic totals produced by the bundled five-grid input. Minor last-digit differences are acceptable across standard-library implementations, but the grid count, threshold count, exposure total, and component ordering must agree.
