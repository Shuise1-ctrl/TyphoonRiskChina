# Case 02: full NOUL (ID2612) downstream workflow

This case starts from an externally prepared 28-file FNL sequence. Prepare `configs/autodl.settings.json`, then export:

```bash
export TYPHOONRISK_TRACK_FILE=/path/to/working_track.xlsx
export TYPHOONRISK_FNL_DIR=/path/to/ID2612/FNL
```

Validate and run:

```bash
typhoonriskchina check --config examples/case02/config.yml --full-assets
typhoonriskchina run --config examples/case02/config.yml
```

See `docs/ASSETS.md` for the FNL, scaler, downscaling-model and exposure contracts.

FuXi is not executed by this case. For the accepted external FNL input, the highest sampled five-province wind (`15.9243 m/s`) is below the `17.2 m/s` severity-screening threshold, but continuous vulnerability curves remain active. The corrected regression therefore reports non-zero losses rather than truncating them at the screening threshold.
