# Bavi / ID2609

该案例用于全链路回归测试。2026-08-05 验收从更新的 `Bavi.nc` 初始场重新生成 006–168 h 的 28 个 FuXi 文件，再执行降尺度、五省暴露匹配、易损性和报告。大型 NetCDF 不进入 GitHub；可公开的小型结果、图片和清单位于 `expected/`。

```bash
bash scripts/run_bavi.sh --force-downscaling
```

修正验收结果：最高暴露网格采样风速 21.033628 m/s，浙江超过 17.2 m/s 严重程度筛查阈值；连续曲线在福建、广东、江苏和浙江产生模型损失，总损失为 17,400,519.20。修正风险计算生成五省网格风速/损失 CSV、两幅专题图、PDF 和 `result_manifest.json`。输入校验值及完整数值见 `docs/BAVI_ID2609_ACCEPTANCE.md`。
