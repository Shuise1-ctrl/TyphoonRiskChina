# NOUL (ID2612) Example

This folder contains the NOUL storm-track workbook (input/track.xlsx), case configuration, and compact expected outputs. Large FNL NetCDF files, model/scaler assets, and exposure Parquet datasets are supplied separately.

The CLI acceptance fixture was generated with a 60-file forecast sequence extending to 360 h. It is separate from the manuscript's browser workflow, which uses the 28-file sequence through 168 h. Its accepted loss total (RMB 10,124,903.76) is not the manuscript's browser-workflow reference total. For step-by-step reproduction of the manuscript NOUL example, follow the top-level [README](../../../README.md#step-by-step-reproduction-of-noul-id2612).

Run the full CLI fixture on a configured Linux environment after setting TYPHOONRISK_FNL_DIR and TYPHOONRISK_TRACK_FILE:

    bash scripts/run_noul.sh

The 60-file fixture completed downscaling, exposure matching, vulnerability assessment, and reporting. Its acceptance summary is documented in docs/NOUL_ID2612_ACCEPTANCE.md.
