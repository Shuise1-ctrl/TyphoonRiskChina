#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "[TyphoonRiskChina] [1/5] Verifying the cloned repository"
bash scripts/verify_repository.sh

echo "[TyphoonRiskChina] [2/5] Loading Conda shell support"
CONDA_BASE="$(conda info --base 2>/dev/null || true)"
if [[ -z "$CONDA_BASE" && -x /root/miniconda3/bin/conda ]]; then
  CONDA_BASE=/root/miniconda3
fi
if [[ -z "$CONDA_BASE" ]]; then
  echo "Conda was not found. Install Miniconda first." >&2
  exit 1
fi
source "$CONDA_BASE/etc/profile.d/conda.sh"

echo "[TyphoonRiskChina] [3/5] Creating or updating environment typhoonriskchina"
if conda env list | awk '{print $1}' | grep -qx typhoonriskchina; then
  conda env update -n typhoonriskchina -f environment.yml --prune
else
  conda env create -f environment.yml
fi

echo "[TyphoonRiskChina] [4/5] Installing the TyphoonRiskChina package"
conda run -n typhoonriskchina python -m pip install .

echo "[TyphoonRiskChina] [5/5] Running the self-contained reviewer case"
conda run -n typhoonriskchina typhoonriskchina check --config examples/case01/config.yml
conda run -n typhoonriskchina typhoonriskchina run --config examples/case01/config.yml
echo "[TyphoonRiskChina] Installation and reviewer smoke test complete."
echo "[TyphoonRiskChina] Results: $ROOT/examples/case01/outputs"
