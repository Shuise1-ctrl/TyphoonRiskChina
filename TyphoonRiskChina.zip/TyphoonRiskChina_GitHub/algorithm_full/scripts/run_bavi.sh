#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PYTHONPATH="$ROOT/src"
: "${TYPHOONRISK_FNL_DIR:?Export TYPHOONRISK_FNL_DIR to the ID2609/FNL directory}"
: "${TYPHOONRISK_TRACK_FILE:?Export TYPHOONRISK_TRACK_FILE to the ID2609 track workbook}"
exec "${PYTHON_BIN:-python}" -m typhoonriskchina.cli run \
  --config "$ROOT/examples/Bavi_ID2609/config.yml" "$@"
