#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RISK_ENV="${RISK_ENV:-/root/autodl-tmp/envs/typhoon-risk}"
if [[ ! -f "$ROOT/configs/autodl.settings.json" ]]; then
  cp "$ROOT/configs/autodl.settings.example.json" "$ROOT/configs/autodl.settings.json"
  echo "Created configs/autodl.settings.json; review asset paths before running."
fi
python3.10 -m venv "$RISK_ENV"
"$RISK_ENV/bin/pip" install -U pip wheel setuptools
"$RISK_ENV/bin/pip" install -r "$ROOT/requirements/risk.txt"
"$RISK_ENV/bin/pip" install -e "$ROOT"
