#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

required=(
  README.md
  RUNNING_GUIDE.md
  LICENSE
  CITATION.cff
  pyproject.toml
  environment.yml
  src/typhoonriskchina/cli.py
  src/typhoonriskchina/workflow.py
  examples/case01/config.yml
  examples/case01/small_input/track.csv
  examples/case01/small_input/exposure.csv
  examples/Bavi_ID2609/config.yml
  examples/NOUL_ID2612/config.yml
  docs/ASSETS.md
  tests/test_input.py
  tests/test_track.py
  tests/test_workflow.py
  tests/test_external_fnl.py
)

missing=0
for relative_path in "${required[@]}"; do
  if [[ ! -f "$ROOT/$relative_path" ]]; then
    echo "[TyphoonRiskChina] Missing required repository file: $relative_path" >&2
    missing=1
  fi
done

if [[ "$missing" -ne 0 ]]; then
  exit 1
fi

echo "[TyphoonRiskChina] Repository check passed (${#required[@]} required files)."
