#!/usr/bin/env bash
set -euo pipefail

REPO_URL="${TYPHOONRISK_REPO_URL:-https://github.com/Shuise1-ctrl/TyphoonRiskChina.git}"
REPO_REF="${TYPHOONRISK_REF:-main}"
DESTINATION="${TYPHOONRISK_DEST:-TyphoonRiskChina}"

echo "[TyphoonRiskChina] [download 1/4] Checking Linux prerequisites"
command -v git >/dev/null 2>&1 || {
  echo "Git was not found. Install Git and retry." >&2
  exit 1
}
if command -v conda >/dev/null 2>&1; then
  :
elif [[ -x /root/miniconda3/bin/conda ]]; then
  export PATH="/root/miniconda3/bin:$PATH"
else
  echo "Conda was not found. Install Miniconda or Anaconda and retry." >&2
  exit 1
fi

if [[ -e "$DESTINATION" ]]; then
  echo "Destination already exists: $DESTINATION" >&2
  echo "Choose another directory with TYPHOONRISK_DEST=/path/to/new-directory." >&2
  exit 1
fi

echo "[TyphoonRiskChina] [download 2/4] Cloning $REPO_URL ($REPO_REF)"
git clone --depth 1 --branch "$REPO_REF" "$REPO_URL" "$DESTINATION"

echo "[TyphoonRiskChina] [download 3/4] Installing and testing the reviewer environment"
bash "$DESTINATION/scripts/install_linux.sh"

echo "[TyphoonRiskChina] [download 4/4] Complete"
echo "Repository: $(cd "$DESTINATION" && pwd)"
echo "Results: $(cd "$DESTINATION" && pwd)/examples/case01/outputs"
