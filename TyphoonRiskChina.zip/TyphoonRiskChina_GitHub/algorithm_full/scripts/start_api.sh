#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PYTHONPATH="$ROOT/src"
export TYPHOON_RISK_CHINA_SETTINGS="${TYPHOON_RISK_CHINA_SETTINGS:-$ROOT/configs/autodl.settings.json}"
exec "${PYTHON_BIN:-python}" -m uvicorn typhoonriskchina.api:app --host 0.0.0.0 --port "${PORT:-6008}"
