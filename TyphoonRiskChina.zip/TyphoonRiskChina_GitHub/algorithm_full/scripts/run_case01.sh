#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

CONDA_BASE="$(conda info --base 2>/dev/null || true)"
if [[ -z "$CONDA_BASE" && -x /root/miniconda3/bin/conda ]]; then
  CONDA_BASE=/root/miniconda3
fi
if [[ -z "$CONDA_BASE" ]]; then
  echo "Conda was not found. Run bash scripts/install_linux.sh first." >&2
  exit 1
fi
source "$CONDA_BASE/etc/profile.d/conda.sh"

echo "[TyphoonRiskChina] [1/3] Checking the reviewer configuration"
conda run -n typhoonriskchina typhoonriskchina check --config examples/case01/config.yml

echo "[TyphoonRiskChina] [2/3] Running the self-contained reviewer case"
conda run -n typhoonriskchina typhoonriskchina run --config examples/case01/config.yml

echo "[TyphoonRiskChina] [3/3] Listing generated products"
find examples/case01/outputs -maxdepth 1 -type f -printf '%f\n' | sort
