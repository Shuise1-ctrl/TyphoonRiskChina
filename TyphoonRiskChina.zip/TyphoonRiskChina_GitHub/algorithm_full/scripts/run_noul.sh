#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PYTHONPATH="$ROOT/src"
: "${TYPHOONRISK_FNL_DIR:?Export TYPHOONRISK_FNL_DIR to the ID2612/FNL directory}"
: "${TYPHOONRISK_TRACK_FILE:?Export TYPHOONRISK_TRACK_FILE to the ID2612 track workbook}"

exec "${PYTHON_BIN:-python}" -m typhoonriskchina.cli run \
  --config "$ROOT/examples/NOUL_ID2612/config.yml" "$@"
