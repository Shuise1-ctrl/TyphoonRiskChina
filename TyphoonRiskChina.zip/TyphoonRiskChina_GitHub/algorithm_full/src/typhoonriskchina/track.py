"""Small, dependency-free track reader used by the reviewer example."""

from __future__ import annotations

import csv
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path


@dataclass(frozen=True)
class TrackPoint:
    time: datetime
    lat: float
    lon: float


def load_track_csv(path: str | Path) -> list[TrackPoint]:
    source = Path(path)
    points: list[TrackPoint] = []
    with source.open("r", encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            points.append(
                TrackPoint(
                    time=datetime.fromisoformat(row["time"].replace("Z", "+00:00")),
                    lat=float(row["lat"]),
                    lon=float(row["lon"]),
                )
            )
    if len(points) < 2:
        raise ValueError("Track must contain at least two points")
    if any(not (-90 <= point.lat <= 90) for point in points):
        raise ValueError("Track latitude must be between -90 and 90 degrees")
    if any(not (-180 <= point.lon <= 360) for point in points):
        raise ValueError("Track longitude must be between -180 and 360 degrees")
    if any(later.time <= earlier.time for earlier, later in zip(points, points[1:])):
        raise ValueError("Track times must be strictly increasing")
    return points


def summarize_track(points: list[TrackPoint]) -> dict[str, object]:
    return {
        "point_count": len(points),
        "start": asdict(points[0]),
        "end": asdict(points[-1]),
        "latitude_range": [min(point.lat for point in points), max(point.lat for point in points)],
        "longitude_range": [min(point.lon for point in points), max(point.lon for point in points)],
    }
