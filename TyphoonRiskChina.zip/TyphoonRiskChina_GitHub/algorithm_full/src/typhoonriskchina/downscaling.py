"""Adapters for the external FuXi and downscaling executables."""

from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess
import time


def canonical_level_label(value: object) -> str:
    """Normalize FuXi channel labels across common NetCDF encodings.

    Historical files use labels such as ``u10`` and ``r850``. Revised
    initial states may carry ``U10`` and ``R850.0``. Both describe the same
    ordered FuXi channels and must map to one stable downstream label.
    """
    if isinstance(value, bytes):
        text = value.decode("utf-8")
    else:
        text = str(value)
    text = text.strip().lower()
    if len(text) > 1:
        try:
            number = float(text[1:])
        except ValueError:
            return text
        if number.is_integer():
            return f"{text[0]}{int(number)}"
    return text


def canonical_level_labels(values: object) -> list[str]:
    """Return canonical labels and reject ambiguous duplicate channels."""
    labels = [canonical_level_label(value) for value in values]
    if len(labels) != len(set(labels)):
        raise ValueError(f"Duplicate FuXi channel labels after normalization: {labels}")
    return labels


def run_checked(
    command: list[str],
    cwd: Path,
    log_path: Path,
    env: dict[str, str] | None = None,
) -> float:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    with log_path.open("w", encoding="utf-8") as log:
        result = subprocess.run(
            command,
            cwd=cwd,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            text=True,
            check=False,
        )
    elapsed = time.perf_counter() - started
    if result.returncode:
        tail = "\n".join(log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-60:])
        raise RuntimeError(f"Command failed ({result.returncode}): {' '.join(command)}\n{tail}")
    return elapsed


def link_or_copy(source: Path, destination: Path) -> str:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() or destination.is_symlink():
        destination.unlink()
    try:
        destination.symlink_to(source)
        return "symlink"
    except OSError:
        try:
            os.link(source, destination)
            return "hardlink"
        except OSError:
            shutil.copy2(source, destination)
            return "copy"
