from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import shutil
import uuid

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse

from .config import Event, Settings
from .workflow import RunOptions, UnifiedPipeline


SETTINGS_PATH = Path(os.environ.get("TYPHOON_RISK_CHINA_SETTINGS", "configs/autodl.settings.json")).absolute()
SETTINGS = Settings.load(SETTINGS_PATH)
EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="typhoonriskchina")
app = FastAPI(title="TyphoonRiskChina", version="1.1.0")


def _job_root(job_id: str) -> Path:
    if not job_id.isalnum():
        raise HTTPException(400, "Invalid job id")
    return SETTINGS.jobs_root / job_id


def _execute(event: Event, root: Path) -> None:
    UnifiedPipeline(SETTINGS).run(event, root, RunOptions(input_mode="external_fnl", reuse_downscaling=False))


@app.get("/health")
def health() -> dict[str, str]:
    SETTINGS.validate()
    return {"status": "ok"}


@app.post("/jobs", status_code=202)
def create_job(
    case_id: str = Form(...), typhoon_name: str = Form(...),
    track_file: UploadFile = File(...), fnl_files: list[UploadFile] = File(...),
) -> dict[str, str]:
    job_id = uuid.uuid4().hex
    root = _job_root(job_id)
    uploads = root / "uploads"
    fnl_dir = uploads / "FNL"
    fnl_dir.mkdir(parents=True)
    track_path = uploads / "track.xlsx"
    with track_path.open("wb") as stream:
        shutil.copyfileobj(track_file.file, stream)
    for upload in fnl_files:
        name = Path(upload.filename or "").name
        if len(name) != 6 or not name[:3].isdigit() or name[3:].lower() != ".nc":
            raise HTTPException(400, f"Invalid FNL filename: {name!r}; expected 006.nc ... 168.nc")
        with (fnl_dir / name).open("wb") as stream:
            shutil.copyfileobj(upload.file, stream)
    event = Event(
        case_id=case_id.upper(),
        name=typhoon_name,
        track_file=track_path,
        existing_fnl_dir=fnl_dir,
    )
    try:
        UnifiedPipeline._validate_external_fnl(event, "external_fnl")
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(400, str(exc)) from exc
    EXECUTOR.submit(_execute, event, root)
    return {"job_id": job_id, "status_url": f"/jobs/{job_id}"}


@app.get("/jobs/{job_id}")
def job_status(job_id: str) -> dict:
    manifest = _job_root(job_id) / "run_manifest.json"
    if not manifest.exists():
        return {"job_id": job_id, "status": "queued"}
    return json.loads(manifest.read_text(encoding="utf-8"))


@app.get("/jobs/{job_id}/report")
def job_report(job_id: str):
    root = _job_root(job_id)
    reports = list((root / "outputs" / "vulnerability").glob("*.pdf"))
    if not reports:
        raise HTTPException(404, "Report is not ready")
    return FileResponse(reports[0], filename=reports[0].name, media_type="application/pdf")
