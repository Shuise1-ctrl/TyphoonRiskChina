"""Loss-table calculation for the self-contained reviewer example."""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Any

from .vulnerability import component_losses


def calculate_loss_table(exposure_csv: str | Path) -> tuple[list[dict[str, Any]], dict[str, float]]:
    rows: list[dict[str, Any]] = []
    totals = {
        "exposure_value": 0.0,
        "structural_loss": 0.0,
        "roof_loss": 0.0,
        "window_loss": 0.0,
        "nonstructural_loss": 0.0,
        "total_loss": 0.0,
    }
    with Path(exposure_csv).open("r", encoding="utf-8-sig", newline="") as stream:
        for source in csv.DictReader(stream):
            wind = float(source["wind_speed_ms"])
            exposure = float(source["exposure_value"])
            losses = component_losses(wind, exposure)
            row: dict[str, Any] = {
                "grid_id": source["grid_id"],
                "province": source["province"],
                "city": source["city"],
                "wind_speed_ms": wind,
                "exposure_value": exposure,
                **losses,
            }
            rows.append(row)
            totals["exposure_value"] += exposure
            for key in totals:
                if key != "exposure_value":
                    totals[key] += float(losses[key])
    if not rows:
        raise ValueError("Exposure input contains no data rows")
    return rows, totals
