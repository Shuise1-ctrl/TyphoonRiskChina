from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import traceback
from typing import Any

from .config import Event, RunConfig, Settings
from .downscaling import link_or_copy, run_checked
from .loss import calculate_loss_table
from .report import write_demo_outputs
from .track import load_track_csv, summarize_track
from .validation import discover_forecasts, file_record, validate_run_config, validate_sequence


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    temporary.replace(path)


def progress(step: int, total: int, message: str) -> None:
    print(f"[TyphoonRiskChina] [{step}/{total}] {message}", flush=True)


@dataclass(frozen=True)
class RunOptions:
    input_mode: str = "external_fnl"
    reuse_downscaling: bool = True


class UnifiedPipeline:
    def __init__(self, settings: Settings):
        self.settings = settings

    @staticmethod
    def _validate_external_fnl(event: Event, input_mode: str) -> tuple[Path, dict[str, Any]]:
        if input_mode != "external_fnl":
            raise ValueError("TyphoonRiskChina accepts input_mode=external_fnl; FuXi inference is external")
        expected_count = event.downscaling_max_hour // 6
        files = validate_sequence(
            discover_forecasts(event.existing_fnl_dir, event.downscaling_max_hour),
            expected_count,
        )
        return event.existing_fnl_dir, {
            "mode": input_mode,
            "status": "validated",
            "count": len(files),
            "first": files[0].name,
            "last": files[-1].name,
        }

    def _prepare_case(self, event: Event, external_fnl_dir: Path, run_root: Path) -> tuple[Path, dict[str, Any]]:
        case_dir = run_root / "prepared_input" / event.case_id.upper()
        fnl_dir = case_dir / "FNL"
        fnl_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(event.track_file, case_dir / "track.xlsx")
        expected_count = event.downscaling_max_hour // 6
        files = validate_sequence(
            discover_forecasts(external_fnl_dir, event.downscaling_max_hour),
            expected_count,
        )
        if not files:
            raise ValueError(f"No external FNL files through {event.downscaling_max_hour} h in {external_fnl_dir}")
        methods: dict[str, int] = {}
        for source in files:
            method = link_or_copy(source, fnl_dir / source.name)
            methods[method] = methods.get(method, 0) + 1
        return case_dir, {"count": len(files), "max_hour": max(int(path.stem[-3:]) for path in files), "materialization": methods}

    def _run_risk(self, event: Event, case_dir: Path, run_root: Path, reuse: bool) -> dict[str, Any]:
        output_root = run_root / "outputs"
        command = [
            str(self.settings.risk_python), str(self.settings.risk_cli),
            "--case", event.case_id.upper(), "--typhoon-name", event.name,
            "--case-dir", str(case_dir),
            "--runtime-root", str(self.settings.downscaling_runtime),
            "--risk-root", str(self.settings.risk_exposure_root),
            "--output-root", str(output_root),
            "--impact-threshold-ms", str(event.impact_threshold_ms),
        ]
        if not reuse:
            command.append("--force-downscaling")
        env = dict(os.environ)
        env.update({
            "MPLBACKEND": "Agg",
            "TF_CPP_MIN_LOG_LEVEL": "2",
            "CUDA_VISIBLE_DEVICES": "-1",
            # Legal container fallback; Times New Roman is still used when installed.
            "TYPHOON_ALLOW_FONT_FALLBACK": "1",
        })
        elapsed = run_checked(command, self.settings.risk_cli.parent, run_root / "logs" / "risk_pipeline.log", env)
        manifest = output_root / "pipeline_result.json"
        result = json.loads(manifest.read_text(encoding="utf-8"))
        result["seconds"] = elapsed
        return result

    @staticmethod
    def _write_summary(run_root: Path, result: dict[str, Any]) -> None:
        vulnerability = result.get("stages", {}).get("vulnerability", {})
        payload = {
            "case_id": result.get("case_id"),
            "event_id": result.get("event_id"),
            "typhoon_name": result.get("typhoon_name"),
            "affected_provinces": vulnerability.get("affected_provinces", []),
            "totals": vulnerability.get("totals", {}),
            "report": vulnerability.get("files", {}).get("pdf_report"),
        }
        atomic_json(run_root / "loss_summary.json", payload)
        lines = [
            f"# Loss summary — {payload['typhoon_name']} ({payload['case_id']})",
            "", f"Affected provinces: {', '.join(payload['affected_provinces']) or 'none'}", "", "## Totals", "",
        ]
        lines.extend(f"- {key}: {value}" for key, value in payload["totals"].items())
        lines.extend(["", f"PDF report: `{payload['report']}`", ""])
        (run_root / "loss_summary.md").write_text("\n".join(lines), encoding="utf-8")

    def run(self, event: Event, run_root: Path, options: RunOptions) -> dict[str, Any]:
        run_root = run_root.absolute()
        run_root.mkdir(parents=True, exist_ok=True)
        manifest_path = run_root / "run_manifest.json"
        state: dict[str, Any] = {
            "schema_version": "1.0", "status": "running", "started_at_utc": utc_now(),
            "event": {**asdict(event), "track_file": str(event.track_file),
                      "existing_fnl_dir": str(event.existing_fnl_dir)},
            "options": asdict(options), "stages": {},
        }
        atomic_json(manifest_path, state)
        try:
            progress(1, 5, "Validating full-workflow configuration and inputs")
            self.settings.validate()
            event.validate()
            state["inputs"] = {"track": file_record(event.track_file, checksum=True)}
            progress(2, 5, "Validating the external 6-hourly FNL sequence")
            fnl_dir, fnl_result = self._validate_external_fnl(event, options.input_mode)
            state["stages"]["external_fnl_input"] = fnl_result
            atomic_json(manifest_path, state)
            progress(3, 5, "Linking FNL and track inputs to the downscaling case")
            case_dir, prepared = self._prepare_case(event, fnl_dir, run_root)
            state["stages"]["interface_fnl_to_downscaling"] = {"status": "complete", **prepared, "case_dir": str(case_dir)}
            atomic_json(manifest_path, state)
            progress(4, 5, "Running 3-km downscaling, exposure, vulnerability and reporting")
            risk_result = self._run_risk(event, case_dir, run_root, options.reuse_downscaling)
            state["stages"]["downscaling_exposure_vulnerability_report"] = risk_result
            self._write_summary(run_root, risk_result)
            state.update({"status": "complete", "completed_at_utc": utc_now()})
            atomic_json(manifest_path, state)
            progress(5, 5, f"Complete. Manifest: {manifest_path}")
            return state
        except Exception as exc:
            state.update({"status": "failed", "failed_at_utc": utc_now(), "error": {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}})
            atomic_json(manifest_path, state)
            raise


def run_reviewer_demo(config: RunConfig) -> dict[str, Any]:
    """Run the small, self-contained review path without external model assets."""

    manifest_path = config.output_dir / "run_manifest.json"
    state: dict[str, Any] = {
        "schema_version": "1.0",
        "mode": "reviewer_demo",
        "case_id": config.case_id,
        "typhoon_name": config.name,
        "status": "running",
        "started_at_utc": utc_now(),
        "config": str(config.path),
        "stages": {},
    }
    config.output_dir.mkdir(parents=True, exist_ok=True)
    atomic_json(manifest_path, state)
    try:
        progress(1, 5, "Validating YAML configuration and bundled inputs")
        validated = validate_run_config(config)
        state["stages"]["validation"] = {"status": "complete", **validated}
        atomic_json(manifest_path, state)

        progress(2, 5, "Reading and validating the typhoon track")
        track_points = load_track_csv(config.demo_track())
        track_summary = summarize_track(track_points)
        state["stages"]["track"] = {"status": "complete", **track_summary}
        atomic_json(manifest_path, state)

        progress(3, 5, "Applying vulnerability curves and calculating grid losses")
        rows, totals = calculate_loss_table(config.demo_exposure())
        state["stages"]["vulnerability_and_loss"] = {
            "status": "complete",
            "grid_count": len(rows),
            "totals": totals,
        }
        atomic_json(manifest_path, state)

        progress(4, 5, "Writing CSV, JSON and Markdown review products")
        files = write_demo_outputs(
            config.output_dir,
            config.case_id,
            config.name,
            rows,
            totals,
            track_summary,
            config.impact_threshold_ms(),
        )
        state["stages"]["report"] = {"status": "complete", "files": files}
        state.update({"status": "complete", "completed_at_utc": utc_now()})
        atomic_json(manifest_path, state)
        progress(5, 5, f"Complete. Manifest: {manifest_path}")
        return state
    except Exception as exc:
        state.update(
            {
                "status": "failed",
                "failed_at_utc": utc_now(),
                "error": {
                    "type": type(exc).__name__,
                    "message": str(exc),
                    "traceback": traceback.format_exc(),
                },
            }
        )
        atomic_json(manifest_path, state)
        raise


def run_from_config(path: str | Path) -> dict[str, Any]:
    config = RunConfig.load(path)
    if config.mode == "reviewer_demo":
        return run_reviewer_demo(config)
    if config.mode == "full":
        validate_run_config(config, full_assets=False)
        settings = Settings.load(config.full_settings())
        return UnifiedPipeline(settings).run(
            config.full_event(),
            config.output_dir,
            RunOptions(
                input_mode=config.input_mode(),
                reuse_downscaling=config.reuse_downscaling(),
            ),
        )
    raise ValueError(f"Unsupported mode: {config.mode}")
