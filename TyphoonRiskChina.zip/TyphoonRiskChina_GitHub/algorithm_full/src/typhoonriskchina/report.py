"""Portable CSV, JSON and Markdown reporting helpers."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any


def write_demo_outputs(
    output_dir: Path,
    case_id: str,
    name: str,
    rows: list[dict[str, Any]],
    totals: dict[str, float],
    track_summary: dict[str, object],
    threshold: float,
) -> dict[str, str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    loss_csv = output_dir / "grid_loss.csv"
    with loss_csv.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    summary = {
        "schema_version": "1.0",
        "mode": "reviewer_demo",
        "case_id": case_id,
        "typhoon_name": name,
        "grid_count": len(rows),
        "grids_at_or_above_impact_threshold": sum(
            float(row["wind_speed_ms"]) >= threshold for row in rows
        ),
        "impact_threshold_ms": threshold,
        "track": track_summary,
        "totals": totals,
        "interpretation": (
            "Self-contained software verification example; not an observed or operational loss estimate."
        ),
    }
    summary_json = output_dir / "loss_summary.json"
    summary_json.write_text(json.dumps(summary, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    summary_md = output_dir / "loss_summary.md"
    lines = [
        f"# TyphoonRiskChina reviewer example: {name} ({case_id})",
        "",
        summary["interpretation"],
        "",
        "## Totals",
        "",
    ]
    lines.extend(f"- {key}: {value:.6f}" for key, value in totals.items())
    summary_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {
        "grid_loss_csv": str(loss_csv),
        "loss_summary_json": str(summary_json),
        "loss_summary_markdown": str(summary_md),
    }
