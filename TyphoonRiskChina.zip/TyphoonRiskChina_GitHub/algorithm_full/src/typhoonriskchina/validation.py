from __future__ import annotations

from hashlib import sha256
import csv
from pathlib import Path
import re
from typing import Iterable

from .config import RunConfig


LEAD_RE = re.compile(r"(\d{3})(?=\.nc$)", re.IGNORECASE)


def lead_hour(path: Path) -> int:
    match = LEAD_RE.search(path.name)
    if not match:
        raise ValueError(f"Cannot read forecast lead hour from {path.name}")
    return int(match.group(1))


def discover_forecasts(root: Path, max_hour: int | None = None) -> list[Path]:
    selected: dict[int, Path] = {}
    for path in root.glob("*.nc"):
        try:
            hour = lead_hour(path)
        except ValueError:
            continue
        if max_hour is None or hour <= max_hour:
            selected.setdefault(hour, path)
    return [selected[key] for key in sorted(selected)]


def expected_leads(steps: int) -> list[int]:
    return list(range(6, steps * 6 + 1, 6))


def validate_sequence(files: Iterable[Path], expected_count: int | None = None) -> list[Path]:
    paths = sorted(files, key=lead_hour)
    leads = [lead_hour(path) for path in paths]
    if expected_count is not None and leads != expected_leads(expected_count):
        missing = sorted(set(expected_leads(expected_count)) - set(leads))
        raise ValueError(f"Forecast sequence is incomplete; missing lead hours: {missing}")
    if len(leads) != len(set(leads)):
        raise ValueError("Forecast sequence contains duplicate lead hours")
    return paths


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


def file_record(path: Path, checksum: bool = False) -> dict[str, object]:
    record: dict[str, object] = {"path": str(path), "bytes": path.stat().st_size}
    if checksum:
        record["sha256"] = sha256_file(path)
    return record


def require_columns(path: Path, required: set[str]) -> list[str]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.reader(stream)
        header = next(reader, [])
    missing = sorted(required - set(header))
    if missing:
        raise ValueError(f"{path.name} is missing required columns: {missing}")
    return header


def validate_run_config(config: RunConfig, *, full_assets: bool = True) -> dict[str, object]:
    if not config.case_id:
        raise ValueError("case.id is required")
    if config.mode == "reviewer_demo":
        track = config.demo_track()
        exposure = config.demo_exposure()
        if not track.is_file():
            raise FileNotFoundError(f"Demo track file not found: {track}")
        if not exposure.is_file():
            raise FileNotFoundError(f"Demo exposure file not found: {exposure}")
        require_columns(track, {"time", "lat", "lon"})
        require_columns(
            exposure,
            {"grid_id", "province", "city", "wind_speed_ms", "exposure_value"},
        )
        return {
            "mode": config.mode,
            "case_id": config.case_id,
            "track": str(track),
            "exposure": str(exposure),
            "output_dir": str(config.output_dir),
        }
    if config.mode == "full":
        settings_path = config.full_settings()
        if not settings_path.is_file():
            raise FileNotFoundError(
                f"Full settings file not found: {settings_path}. "
                "Copy configs/autodl.settings.example.json and edit the asset paths."
            )
        event = config.full_event()
        if full_assets:
            from .config import Settings

            settings = Settings.load(settings_path)
            settings.validate()
            event.validate()
            expected_count = event.downscaling_max_hour // 6
            files = validate_sequence(
                discover_forecasts(event.existing_fnl_dir, event.downscaling_max_hour),
                expected_count,
            )
        else:
            files = []
        return {
            "mode": config.mode,
            "case_id": event.case_id,
            "settings": str(settings_path),
            "track": str(event.track_file),
            "output_dir": str(config.output_dir),
            "input_mode": config.input_mode(),
            "existing_fnl_dir": str(event.existing_fnl_dir),
            "fnl_count": len(files) if full_assets else None,
        }
    raise ValueError(f"Unsupported mode {config.mode!r}; use reviewer_demo or full")
