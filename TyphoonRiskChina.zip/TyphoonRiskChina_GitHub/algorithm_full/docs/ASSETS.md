# External assets

## GitHub repository

GitHub contains source code, tests, YAML/JSON templates, lightweight `case01`, boundary metadata and compact accepted-result evidence.

## Full-case offline assets

The full Bavi and NOUL examples require:

```text
IDxxxx/
├── FNL/006.nc ... 168.nc
└── track.xlsx
```

They also share:

- `runtime/downscaling/models/direct_unet_model.h5`;
- `runtime/downscaling/scalers/scaler_x.save` and `scaler_y.save`;
- five Parquet files in `runtime/exposure/00000 沿海省份风险暴露/`;
- five Parquet files in `runtime/exposure/00000 沿海省份网格/`.

FuXi graphs, weights and initial states are not TyphoonRiskChina assets. If FuXi generated the FNL files, cite and archive that upstream process separately.

## Validation

```bash
typhoonriskchina verify-fnl --directory /data/ID2609/FNL --count 28
typhoonriskchina check --config examples/Bavi_ID2609/config.yml --full-assets
```

Use the offline illustrative package's SHA-256 manifest after copying assets between computers. Do not commit large NetCDF, H5 or Parquet files to ordinary Git history without an explicit licence and distribution plan.
