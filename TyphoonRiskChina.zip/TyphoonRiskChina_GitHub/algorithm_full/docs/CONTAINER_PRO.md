# Container/API deployment

The FastAPI service accepts event metadata, `track.xlsx` and a repeated multipart field containing the 28 FNL files. It returns a job ID; `GET /jobs/{id}` exposes stage state and `GET /jobs/{id}/report` downloads the PDF.

For browser deployments, uploading roughly 8 GB per case is inefficient. Prefer a resumable object-store upload or an approved server-side mounted case directory, then submit only its identifier. Apply path allow-listing, per-user quotas, checksums, content validation and job isolation.

The backend does not expose or invoke FuXi. Container images therefore need only the TyphoonRiskChina risk/downscaling environment and mounted scientific assets.
