# Input and output contract

## External forecast/track input

- one directory containing exactly `006.nc, 012.nc, ..., 168.nc`;
- one event track workbook named or mapped as `track.xlsx`;
- case identifier such as `ID2609` and typhoon name.

The upstream forecast provider is not called by TyphoonRiskChina. The interface validator checks the 28 lead hours before downscaling.

## Downscaling output

- time-varying high-resolution wind NetCDF;
- fixed-grid maximum wind NetCDF;
- fixed-grid maximum-wind PNG;
- hourly useful-summary CSV.

## Risk input and output

The risk stage combines the fixed-grid wind field with coastal exposure/grid Parquet datasets, vulnerability curves and boundaries. It writes `grid_wind.csv`, `grid_loss.csv`, wind/loss maps, result manifests and a PDF report.

`grid_loss.csv` includes location, exposure, maximum wind, component losses and `total_loss`. The root run directory also contains `loss_summary.json`, `loss_summary.md` and `run_manifest.json`.
