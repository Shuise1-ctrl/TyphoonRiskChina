# GitHub publication guide

This repository is published as `Shuise1-ctrl/TyphoonRiskChina`. The repository root must contain `README.md`, `RUNNING_GUIDE.md`, `pyproject.toml`, `src/`, `scripts/`, `examples/`, and `tests/` directly; do not upload an additional enclosing delivery directory.

## Repository metadata

- Repository name: `TyphoonRiskChina`
- Default branch: `main`
- Release tag: `v1.0.0`
- Author: Zhaodong Wang
- ORCID: <https://orcid.org/0009-0007-8419-9246>
- Repository URL: <https://github.com/Shuise1-ctrl/TyphoonRiskChina>

Suggested description:

```text
Reproducible external-FNL-to-loss-report workflow for typhoon risk assessment in China
```

Suggested topics: `typhoon-risk`, `fuxi`, `downscaling`, `vulnerability`, `disaster-risk`, `china`, `python`, and `reproducible-research`.

## Files to publish

Publish `src/`, `modules/`, `assets/vulnerability/`, example configurations, `examples/`, `requirements/`, `scripts/`, `client/`, `docker/`, `tests/`, `docs/`, `.github/`, and the root metadata/license files.

Do not publish real runtime settings, passwords, access tokens, private keys, model weights, NetCDF forecasts, H5/scaler files, Parquet exposure data, Conda environments, run directories, logs, uploads, or internal manuscript drafts.

## Local graphical publication with GitHub Desktop

1. Install and sign in to GitHub Desktop.
2. Choose **File > Add local repository** and select the `TyphoonRiskChina` directory.
3. If the directory is not yet a Git repository, use the offered option to create a repository in that directory. Use `main` as the branch and do not create another nested project folder.
4. Review the changed-file list. Python caches, generated outputs, large scientific files, and local settings must not appear.
5. Enter the summary `Initial public release of TyphoonRiskChina v1.0.0` and commit to `main`.
6. Click **Publish repository**.
7. Set the name to `TyphoonRiskChina`, add the suggested description, select the personal account, and choose public or private visibility.
8. Publish, open the repository webpage, and confirm that the root layout and README are correct.

## Local command-line publication

Create an empty GitHub repository named `TyphoonRiskChina` without initializing a README, `.gitignore`, or license. Then run from the project root:

```bash
git init -b main
git config user.name "Zhaodong Wang"
git config user.email "YOUR_GITHUB_EMAIL_OR_NOREPLY_ADDRESS"
git add .
git status --short
git commit -m "Initial public release of TyphoonRiskChina v1.0.0"
git remote add origin https://github.com/Shuise1-ctrl/TyphoonRiskChina.git
git push -u origin main
```

Use a personal access token, GitHub CLI, or SSH key for command-line authentication. Do not place a token in the repository URL or a tracked file.

## Web-browser upload

Browser upload is not recommended for this repository because it contains more than 100 files and web upload does not prepare Git history or Linux executable modes as reliably as Git/GitHub Desktop. If browser upload is unavoidable, upload the contents of the project root in multiple batches, never the enclosing directory, and manually exclude `__pycache__`, `.pytest_cache`, outputs, settings, models, forecasts, and credentials.

## Verification after publication

Use a new Linux directory or new server:

```bash
git clone https://github.com/Shuise1-ctrl/TyphoonRiskChina.git
cd TyphoonRiskChina
bash scripts/install_linux.sh
bash scripts/run_case01.sh
```

Run the tests:

```bash
source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate typhoonriskchina
python -m pip install -e ".[dev]"
python -m pytest -q
```

Expected result: `7 passed`. Confirm that `examples/case01/outputs/` contains `grid_loss.csv`, `loss_summary.json`, `loss_summary.md`, and `run_manifest.json`.

## First release

After fresh-clone verification:

```bash
git tag -a v1.0.0 -m "TyphoonRiskChina v1.0.0"
git push origin v1.0.0
```

Create the GitHub Release from `v1.0.0`. If Zenodo archiving is enabled, update `CITATION.cff` with the resulting software DOI in a subsequent metadata commit and release.
