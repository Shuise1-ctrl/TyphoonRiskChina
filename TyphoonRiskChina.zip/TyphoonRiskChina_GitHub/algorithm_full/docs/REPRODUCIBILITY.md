# Reproducibility checklist

1. Record repository commit/tag and Python/Conda lock information.
2. Record all 28 FNL filenames, sizes and SHA-256 values plus upstream provider/version.
3. Record the track workbook checksum and provenance.
4. Record downscaling H5/scaler checksums and exposure/boundary versions.
5. Run `typhoonriskchina verify-fnl --directory <FNL> --count 28`.
6. Run `typhoonriskchina check --config <case-config> --full-assets`.
7. Preserve `run_manifest.json`, `result_manifest.json`, `loss_summary.json`, figures, CSV outputs and PDF report.
8. Compare key regression totals and maps with the accepted Bavi/NOUL evidence.

FuXi reproducibility is maintained in the external upstream archive and is not part of the TyphoonRiskChina environment.
