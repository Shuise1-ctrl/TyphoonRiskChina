# Technical route

```mermaid
flowchart LR
  A["External forecast provider"] --> B["28 FNL NetCDF files<br/>006–168 h"]
  T["track.xlsx"] --> C["Input validation and materialization"]
  B --> C
  C --> D["Hourly 3-km wind downscaling"]
  D --> E["Fixed-grid maximum wind<br/>NC + CSV + PNG"]
  E --> F["Exposure spatial matching"]
  F --> G["Vulnerability and component loss"]
  G --> H["grid_loss.csv + maps + PDF<br/>JSON/Markdown manifests"]
```

FuXi may be the upstream provider, but the software boundary and first auditable input are the FNL directory and track workbook.
