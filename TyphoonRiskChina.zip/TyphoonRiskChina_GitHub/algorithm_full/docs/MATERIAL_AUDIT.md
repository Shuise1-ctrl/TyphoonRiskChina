# Material audit

## Required to execute TyphoonRiskChina

- repository source and Python environment;
- per-case `FNL/006.nc` through `168.nc` and `track.xlsx`;
- downscaling H5 model and two scalers;
- exposure/grid Parquet datasets;
- vulnerability curves, boundaries and report code.

## External upstream, not executed here

FuXi code, ONNX graphs, external weights and initial-state NetCDF are outside TyphoonRiskChina. Preserve them only in the upstream forecast archive if required for provenance.

## Generated products

Prepared-input links/copies, downscaled NetCDF/CSV/PNG, grid wind/loss CSV, maps, JSON/Markdown manifests and PDF reports are run outputs. Compact accepted evidence may be published; large outputs normally remain release assets or archived research data.
