# Runtime optimization

1. Validate the 28-file FNL sequence before loading any NetCDF data.
2. Materialize FNL inputs with symbolic links, then hard links, and copy only as a fallback.
3. Reuse a validated downscaling result when only vulnerability/exposure parameters change.
4. Cache fixed-grid wind products with input/model/config fingerprints to prevent stale reuse.
5. Keep the downscaler and risk tables in one controlled Python environment; FuXi environment conflicts no longer affect this repository.
6. Read only the variables, time window and spatial domain needed downstream when the scientific method permits it, and disclose any contract change.
7. Write stage manifests atomically so interrupted runs can be diagnosed and safely resumed.
