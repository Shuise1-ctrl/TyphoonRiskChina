# Contributing to TyphoonRiskChina

感谢改进代码、文档、案例或测试。提交前请确认贡献内容有权公开，并且不包含模型权重、受限数据、账号密码或个人路径。

## 开发流程

1. 从主分支创建功能分支。
2. 使用 Python 3.10 创建独立环境并运行 `pip install -e ".[dev]"`。
3. 为行为变化增加测试和文档。
4. 运行 `python -m pytest -q` 与 `python -m compileall -q src modules/webready/backend client`。
5. 提交 Pull Request，说明动机、输入输出变化、复现命令和兼容性影响。

大型数据和模型只提交校验信息或下载说明。若新增可公开的小型案例，请放入 `examples/`，并附来源、许可和预期结果。
