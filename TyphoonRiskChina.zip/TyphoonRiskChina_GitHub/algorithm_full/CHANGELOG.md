# Changelog

## 1.1.0 — 2026-08-06

- Moved FuXi outside the executable software boundary.
- Made `FNL/006.nc` through `168.nc` plus `track.xlsx` the full-case input contract.
- Removed FuXi environment, runner and weight validation from downstream runs.
- Added FNL-driven Bavi/NOUL configurations, API upload contract and regression tests.

## 1.0.0 — 2026-08-05

- Corrected the full vulnerability engine so the 17.2 m/s severity-screening threshold no longer forces continuous component losses to zero.
- Added separate `threshold_exceeded` metadata and regression coverage for sub-threshold positive losses.
- Recomputed the revised NOUL and Bavi risk/report evidence using the unified five-province continuous-curve contract.
- Unified downscaling, exposure, vulnerability and reporting stages.
- Added atomic manifests and restart/reuse behavior.
- Added Bavi/NOUL event configurations, FastAPI service, local client and container example.
