## Summary

Describe the change and its scientific or software motivation.

## Data contract

- Inputs changed:
- Outputs changed:
- Backward compatibility:

## Verification

- [ ] `python -m pytest -q`
- [ ] `python -m compileall -q src modules/webready/backend client`
- [ ] No credentials, restricted data, model weights or generated runs are included
- [ ] Documentation and example manifests are updated

## Reproduction

Provide the exact sanitized command and expected result.
