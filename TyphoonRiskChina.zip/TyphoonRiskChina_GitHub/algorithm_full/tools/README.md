# Documentation-builder status

The Python builders in this directory are retained as legacy manuscript-production utilities from the former FuXi-integrated architecture. They are not imported, installed or executed by TyphoonRiskChina 1.1.0. Do not use their older prose as the software specification.

The authoritative external-FNL architecture is defined by the root `README.md`, `RUNNING_GUIDE.md`, `docs/INPUT_OUTPUT.md`, `docs/ASSETS.md` and `docs/TECHNICAL_ROUTE.md`. Update the builders before generating a new manuscript artifact.
