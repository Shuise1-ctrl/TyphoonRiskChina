from __future__ import annotations

import argparse
from datetime import date
import json
from pathlib import Path

from PIL import Image as PILImage, ImageDraw, ImageFont
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
NAVY = "203748"
MUTED = "666666"
TABLE_FILL = "E8EEF5"
LIGHT = "F4F6F9"
GOLD = "B9860B"
WHITE = "FFFFFF"
DXA_WIDTH = 9360


def set_cell_shading(cell, fill: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for edge, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{edge}"))
        if node is None:
            node = OxmlElement(f"w:{edge}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def format_table(table, widths: list[int], header=True):
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.first_child_found_in("w:tblW")
    tbl_w.set(qn("w:w"), str(DXA_WIDTH))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = OxmlElement("w:tblInd")
    tbl_ind.set(qn("w:w"), "120")
    tbl_ind.set(qn("w:type"), "dxa")
    tbl_pr.append(tbl_ind)
    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)
    for r_idx, row in enumerate(table.rows):
        # A row may move to the next page, but must never be split mid-cell.
        tr_pr = row._tr.get_or_add_trPr()
        cant_split = OxmlElement("w:cantSplit")
        cant_split.set(qn("w:val"), "true")
        tr_pr.append(cant_split)
        if r_idx == 0 and header:
            set_repeat_table_header(row)
        for c_idx, cell in enumerate(row.cells):
            cell.width = Inches(widths[c_idx] / 1440)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tc_w = cell._tc.get_or_add_tcPr().first_child_found_in("w:tcW")
            tc_w.set(qn("w:w"), str(widths[c_idx]))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)
            if r_idx == 0 and header:
                set_cell_shading(cell, TABLE_FILL)
                for run in cell.paragraphs[0].runs:
                    run.bold = True


def add_page_field(paragraph):
    run = paragraph.add_run()
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    run._r.extend([fld_begin, instr, fld_end])


def create_numbering(doc: Document, num_id: int, abstract_id: int, kind: str):
    numbering = doc.part.numbering_part.element
    abstract = OxmlElement("w:abstractNum")
    abstract.set(qn("w:abstractNumId"), str(abstract_id))
    multi = OxmlElement("w:multiLevelType")
    multi.set(qn("w:val"), "singleLevel")
    abstract.append(multi)
    lvl = OxmlElement("w:lvl")
    lvl.set(qn("w:ilvl"), "0")
    start = OxmlElement("w:start")
    start.set(qn("w:val"), "1")
    num_fmt = OxmlElement("w:numFmt")
    num_fmt.set(qn("w:val"), "bullet" if kind == "bullet" else "decimal")
    lvl_text = OxmlElement("w:lvlText")
    lvl_text.set(qn("w:val"), "•" if kind == "bullet" else "%1.")
    suff = OxmlElement("w:suff")
    suff.set(qn("w:val"), "tab")
    ppr = OxmlElement("w:pPr")
    tabs = OxmlElement("w:tabs")
    tab = OxmlElement("w:tab")
    tab.set(qn("w:val"), "num")
    tab.set(qn("w:pos"), "540")
    tabs.append(tab)
    ind = OxmlElement("w:ind")
    ind.set(qn("w:left"), "540")
    ind.set(qn("w:hanging"), "270")
    spacing = OxmlElement("w:spacing")
    spacing.set(qn("w:after"), "80")
    spacing.set(qn("w:line"), "300")
    spacing.set(qn("w:lineRule"), "auto")
    ppr.extend([tabs, ind, spacing])
    lvl.extend([start, num_fmt, lvl_text, suff, ppr])
    abstract.append(lvl)
    numbering.append(abstract)
    num = OxmlElement("w:num")
    num.set(qn("w:numId"), str(num_id))
    abstract_ref = OxmlElement("w:abstractNumId")
    abstract_ref.set(qn("w:val"), str(abstract_id))
    num.append(abstract_ref)
    numbering.append(num)


def add_list(doc: Document, items: list[str], numbered=False):
    num_id = 52 if numbered else 51
    for item in items:
        p = doc.add_paragraph()
        p_pr = p._p.get_or_add_pPr()
        num_pr = OxmlElement("w:numPr")
        ilvl = OxmlElement("w:ilvl")
        ilvl.set(qn("w:val"), "0")
        num = OxmlElement("w:numId")
        num.set(qn("w:val"), str(num_id))
        num_pr.extend([ilvl, num])
        p_pr.append(num_pr)
        p.add_run(item)


def add_table(doc: Document, headers: list[str], rows: list[list[str]], widths: list[int]):
    table = doc.add_table(rows=1, cols=len(headers), style="Table Grid")
    for cell, text in zip(table.rows[0].cells, headers):
        cell.text = text
    for values in rows:
        cells = table.add_row().cells
        for cell, value in zip(cells, values):
            cell.text = str(value)
    format_table(table, widths)
    return table


def configure_styles(doc: Document):
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25
    for name, size, color, before, after in (
        ("Heading 1", 16, BLUE, 18, 10),
        ("Heading 2", 13, BLUE, 14, 7),
        ("Heading 3", 12, DARK_BLUE, 10, 5),
    ):
        style = styles[name]
        style.font.name = "Calibri"
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor.from_string(color)
        style.font.bold = True
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True


def configure_page(doc: Document):
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)
    header = section.header.paragraphs[0]
    header.text = "TyphoonRiskChina · Technical and Reproducibility Guide"
    header.alignment = WD_ALIGN_PARAGRAPH.LEFT
    for run in header.runs:
        run.font.size = Pt(8.5)
        run.font.color.rgb = RGBColor.from_string(MUTED)
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    footer.add_run("Page ")
    add_page_field(footer)
    for run in footer.runs:
        run.font.size = Pt(8.5)
        run.font.color.rgb = RGBColor.from_string(MUTED)


def route_image(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    width, height = 2340, 1314
    image = PILImage.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    regular_path = Path("C:/Windows/Fonts/arial.ttf")
    bold_path = Path("C:/Windows/Fonts/arialbd.ttf")
    regular = ImageFont.truetype(str(regular_path), 30) if regular_path.exists() else ImageFont.load_default()
    small = ImageFont.truetype(str(regular_path), 25) if regular_path.exists() else ImageFont.load_default()
    title_font = ImageFont.truetype(str(bold_path), 53) if bold_path.exists() else regular
    boxes = [
        (54, 380, 378, 207, "FuXi initial state\n2×70×721×1440", "#EAF3FA"),
        (540, 380, 378, 207, "FuXi ONNX\nGPU inference", "#DCECF7"),
        (1026, 380, 378, 207, "6-hour forecasts\n28 minimal / 60 full", "#D5E7F3"),
        (1512, 380, 378, 207, "3 km downscaling\nH5 + scalers", "#E8EEF5"),
        (1962, 380, 324, 207, "Max-wind grid\nNC + PNG", "#F0F4F8"),
        (378, 830, 414, 207, "Exposure data\n5-province Parquet", "#FFF3D6"),
        (936, 830, 414, 207, "Spatial exposure\nmatching", "#FCE9B8"),
        (1494, 830, 414, 207, "Vulnerability & loss\ncurves + boundaries", "#F7DFA2"),
        (2016, 830, 270, 207, "PDF / CSV\nJSON report", "#F4CF72"),
        (1512, 1130, 378, 153, "Track workbook\n.xlsx", "#EDE7F6"),
    ]
    for x, y, w, h, label, color in boxes:
        draw.rounded_rectangle((x, y, x+w, y+h), radius=18, fill=color, outline="#54738C", width=3)
        lines = label.split("\n")
        line_height = 38
        start_y = y + (h - line_height * len(lines)) // 2
        for idx, line in enumerate(lines):
            bbox = draw.textbbox((0, 0), line, font=regular)
            draw.text((x + (w - (bbox[2]-bbox[0]))/2, start_y + idx*line_height), line, font=regular, fill="#203748")
    arrows = [((432,484),(540,484)),((918,484),(1026,484)),((1404,484),(1512,484)),((1890,484),(1962,484)),
              ((2124,587),(1143,830)),((792,934),(936,934)),((1350,934),(1494,934)),((1908,934),(2016,934)),
              ((1701,1130),(1701,1037)),((1701,1130),(1701,587))]
    for start, end in arrows:
        draw.line((start, end), fill="#54738C", width=5)
        ex, ey = end
        sx, sy = start
        if abs(ex-sx) > abs(ey-sy):
            sign = 1 if ex > sx else -1
            points = [(ex,ey),(ex-18*sign,ey-11),(ex-18*sign,ey+11)]
        else:
            sign = 1 if ey > sy else -1
            points = [(ex,ey),(ex-11,ey-18*sign),(ex+11,ey-18*sign)]
        draw.polygon(points, fill="#54738C")
    draw.text((54, 80), "TyphoonRiskChina: data plane and audited outputs", font=title_font, fill="#203748")
    draw.text((54, 160), "Large assets are mounted; manifests and logs form the control plane.", font=small, fill="#666666")
    image.save(path, format="PNG")


def load_bavi(path: Path | None) -> dict:
    if not path or not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def para(doc: Document, text: str, bold_prefix: str | None = None):
    p = doc.add_paragraph()
    if bold_prefix and text.startswith(bold_prefix):
        p.add_run(bold_prefix).bold = True
        p.add_run(text[len(bold_prefix):])
    else:
        p.add_run(text)
    return p


def build(output: Path, bavi_manifest: Path | None, route_png: Path):
    route_image(route_png)
    bavi = load_bavi(bavi_manifest)
    doc = Document()
    configure_page(doc)
    configure_styles(doc)
    create_numbering(doc, 51, 51, "bullet")
    create_numbering(doc, 52, 52, "decimal")

    # Editorial cover pattern; compact_reference_guide body preset.
    for _ in range(5):
        doc.add_paragraph()
    kicker = doc.add_paragraph()
    kicker.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = kicker.add_run("TECHNICAL REPORT · REPRODUCIBILITY PACKAGE")
    run.bold = True; run.font.size = Pt(10); run.font.color.rgb = RGBColor.from_string(GOLD)
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_after = Pt(8)
    run = title.add_run("TyphoonRiskChina")
    run.bold = True; run.font.size = Pt(30); run.font.color.rgb = RGBColor.from_string(NAVY)
    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run("FuXi 预报—3 km 降尺度—风险暴露—易损性—损失报告统一系统")
    run.font.size = Pt(15); run.font.color.rgb = RGBColor.from_string(DARK_BLUE)
    subtitle.paragraph_format.space_after = Pt(30)
    meta = doc.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = meta.add_run(f"AutoDL / Reviewer Guide · Version 1.0.0 · {date.today().isoformat()}")
    run.font.size = Pt(10.5); run.font.color.rgb = RGBColor.from_string(MUTED)
    for _ in range(4):
        doc.add_paragraph()
    note = doc.add_paragraph()
    note.alignment = WD_ALIGN_PARAGRAPH.CENTER
    note.add_run("用途：论文复现、系统演示、前端/API 接入与审稿验收\n").bold = True
    note.add_run("注意：研究系统，不替代业务化应急预警或保险定价。")
    doc.add_page_break()

    doc.add_heading("执行摘要", level=1)
    para(doc, "本项目把原本分散的 FuXi、台风降尺度、风险暴露、易损性和报告代码统一为一个可配置流水线。统一入口负责输入校验、阶段复用、日志、失败追踪、文件链接和结果汇总；大模型与大数据继续放在 AutoDL 数据盘，不进入 Git。")
    add_table(doc, ["项目", "已实现状态"], [
        ["NOUL / ID2612", "FuXi 60 个文件已完成并验证连续：006–360 h"],
        ["Bavi / ID2609", "28 个 006–168 h 文件齐全；用于端到端强制重算验收"],
        ["统一代码", "/root/autodl-tmp/TyphoonRiskChina；CLI、API、容器示例、测试和文档齐全"],
        ["最少输入", "2 时次 FuXi 初始场 + 路径工作簿；公共模型/暴露数据只部署一次"],
        ["最终输出", "降尺度 NC/CSV/PNG、网格风速/损失 CSV、图件、PDF、JSON/Markdown 摘要"],
    ], [2160, 7200])
    doc.add_heading("阅读导航", level=2)
    add_list(doc, ["第 1–4 章说明系统边界、材料审计、技术路线与逐阶段输入输出。", "第 5–8 章给出环境、运行命令、Bavi/NOUL 验收。", "第 9–12 章覆盖性能优化、前端、容器和论文写作。", "附录提供审稿检查清单、故障排查和公开发布前事项。"])

    doc.add_heading("1. 目标、范围与设计原则", level=1)
    para(doc, "目标不是重写各科学模块，而是用稳定的数据契约把它们连接起来，并为每次运行产生可追溯证据。编排层不改变 FuXi 或降尺度的数值算法；它只控制输入路径、运行顺序、复用条件和结果登记。")
    add_list(doc, ["单事件隔离：每个算例拥有独立 run root、日志、prepared_input 和 outputs。", "大文件零拷贝优先：符号链接 → 硬链接 → 复制三级降级。", "失败可诊断：manifest 保存异常类型、消息和 traceback，日志保留下游标准输出。", "研究透明：已实测、配置假设和未来扩展在文档中分开标识。", "平台解耦：本地只通过 HTTP 上传必要输入并下载报告；GPU 计算留在 AutoDL。"])

    doc.add_heading("2. 材料扫描与必备文件判定", level=1)
    para(doc, "本地四个功能目录与 Typhoon_Downscaling 参考目录已逐文件扫描。参考目录共 80 个文件，其中 60 个为事件 FNL/FuXi 结果，10 个为 .pyc 缓存；真正必备的模型与 scaler 已在 WebReady 包中，且三个文件 SHA-256 与参考目录一致。")
    add_table(doc, ["类别", "处理结论", "原因"], [
        ["H5 + scaler", "必备，已上传", "降尺度公共模型；哈希一致"],
        ["FNL 006–168", "事件输入 / FuXi 输出", "新事件自动生成；Bavi 已补齐 156/162/168"],
        ["track.xlsx", "事件必备", "降尺度中心定位与报告轨迹"],
        ["Parquet + GeoJSON", "公共必备", "暴露匹配、行政区统计、制图"],
        ["Moving_3km_Output1、PNG、PDF、CSV", "结果，不作为必备上传", "由下游阶段生成"],
        [".pyc、.lnk、Windows runtime_env", "排除", "不可审计、Linux 无效或不可复现"],
    ], [1900, 2460, 5000])

    doc.add_heading("3. 总体技术路线", level=1)
    doc.add_picture(str(route_png), width=Inches(6.45))
    caption = doc.add_paragraph("图 1  TyphoonRiskChina 数据面与控制面。")
    caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
    caption.runs[0].italic = True
    para(doc, "控制面由 CLI/API 维护两层清单：外层 run_manifest.json 记录 FuXi 和接口物化；内层 pipeline_result.json 记录降尺度、暴露、易损性和报告。数据面的大文件只通过路径和链接传递。")

    doc.add_heading("4. 各阶段输入、处理与输出", level=1)
    stages = [
        ["FuXi", "2×70×721×1440 DataArray；short/medium/long ONNX", "GPU 自回归 6 h 步进", "006.nc…；最小 28 / 完整 60"],
        ["接口", "FuXi 文件 + track.xlsx", "连续性校验；选择 ≤168 h；链接", "prepared_input/IDxxxx/FNL"],
        ["降尺度", "28 NC、路径、H5、scaler", "移动窗口特征、U-Net、融合、固定网格", "3 km 时序 NC、诊断 CSV、最大风 NC/PNG"],
        ["暴露", "最大风网格、五省暴露/网格 Parquet", "坐标/网格匹配、影响阈值筛选", "带风速的暴露记录"],
        ["易损性", "暴露记录、曲线、GeoJSON、路径", "损伤率和损失、行政区聚合、制图", "grid_wind/loss.csv、图、统计"],
        ["报告", "统计、图、轨迹、运行元数据", "ReportLab/PDF + 摘要序列化", "PDF、loss_summary.json/md、manifest"],
    ]
    add_table(doc, ["阶段", "输入", "主要处理", "输出"], stages, [1200, 2760, 2700, 2700])
    doc.add_heading("4.1 FuXi 输入要求", level=2)
    add_list(doc, ["time 维长度为 2，且两个时次相隔 6 小时。", "channel 维长度为 70；通道顺序必须与官方训练/样例一致。", "lat 从 90 到 −90，721 点；lon 0–359.75，1440 点。", "输出逐文件约 290.7 MB；60 文件约 17.4 GB。"])
    doc.add_heading("4.2 最终损失报告内容", level=2)
    add_list(doc, ["固定网格最大风速空间分布与台风路径。", "受影响省份/地市、暴露量、网格损失和汇总损失。", "最大风分布图、损失分布图及关键方法参数。", "机器可读 JSON/CSV 与人工可读 PDF 同时输出。"])

    doc.add_heading("5. 环境与依赖隔离", level=1)
    add_table(doc, ["环境", "Python/核心库", "执行设备", "职责"], [
        ["fuxi", "3.10；onnxruntime-gpu 1.23.2", "RTX 5090", "FuXi short/medium/long 推理"],
        ["typhoonriskchina", "3.10；TF/Keras 2.10.1；GIS；ReportLab", "25 vCPU", "降尺度、暴露、易损性、报告、API"],
    ], [1500, 3220, 1800, 2840])
    para(doc, "环境隔离解决 NumPy、CUDA 和 TensorFlow 代际冲突。RTX 5090 对旧 TensorFlow 可能触发超长 PTX JIT，因此下游验收显式设置 CUDA_VISIBLE_DEVICES=-1；FuXi 则已验证实际使用 CUDAExecutionProvider。")

    doc.add_heading("6. 统一代码与使用说明", level=1)
    add_list(doc, ["`scripts/run_bavi.sh`：从更新初始场生成最小 28 文件并运行全链路。", "`scripts/run_noul.sh`：从更新初始场生成 NOUL 60 文件并运行全链路。", "`typhoonriskchina verify-fuxi --count 60`：检查文件连续性。", "`scripts/start_api.sh`：在 6008 启动上传/查询/报告下载服务。"])
    para(doc, "fuxi_mode 有四种：minimal 生成 28 文件；full 生成 60；reuse 复用已有 FuXi 目录；skip 把已有 FNL 视为 FuXi 阶段输入。force-downscaling 关闭结果复用，用于验收；日常演示默认复用完整结果以缩短时间。")
    doc.add_heading("6.1 运行目录", level=2)
    add_table(doc, ["路径", "作用"], [
        ["prepared_input/IDxxxx/FNL", "链接后的标准化下游输入"], ["logs/", "FuXi 与下游日志"],
        ["outputs/downscaling", "降尺度产物"], ["outputs/vulnerability", "风险/易损性/报告产物"],
        ["run_manifest.json", "外层状态、配置、输入校验、异常"], ["loss_summary.json/md", "最终摘要"],
    ], [2700, 6660])

    doc.add_heading("7. Bavi（ID2609）端到端验收", level=1)
    status = bavi.get("status", "pending")
    stages_obj = bavi.get("stages", {})
    inner = stages_obj.get("downscaling_exposure_vulnerability_report", {})
    vulnerability = inner.get("stages", {}).get("vulnerability", {}) if isinstance(inner, dict) else {}
    totals = vulnerability.get("totals", {}) if isinstance(vulnerability, dict) else {}
    add_table(doc, ["检查项", "结果"], [
        ["统一流水线状态", str(status)], ["FuXi/FNL 输入", "28 files, 006–168 h"],
        ["接口物化", "28 symbolic links"], ["受影响省份", ", ".join(vulnerability.get("affected_provinces", [])) or "见运行 manifest"],
        ["总量摘要", (
            f"exposure={totals.get('exposure_value', 0):,.2f}; "
            f"structural={totals.get('structural_loss', 0):,.2f}; "
            f"roof={totals.get('roof_loss', 0):,.2f}; "
            f"window={totals.get('window_loss', 0):,.2f}; "
            f"total={totals.get('total_loss', 0):,.2f}"
        ) if totals else "见运行完成后的 loss_summary.json"],
        ["强制重算", "是；reuse_downscaling=false"],
    ], [2600, 6760])
    para(doc, "验收要求不仅是脚本返回 0，还包括降尺度产物、五省网格 CSV、两张图、PDF 和结果 manifest 均存在。连续曲线修正后的 Bavi 总损失为 17,400,519.20，正式数值应以 examples/Bavi_ID2609/expected/result_manifest.json 为准。")

    doc.add_heading("8. NOUL（ID2612）60 文件验收", level=1)
    add_table(doc, ["项目", "验收结果"], [
        ["初始输入", "Noul.nc，2×70×721×1440"], ["阶段配置", "short=20, medium=20, long=20"],
        ["文件数量", "60"], ["时效范围", "006–360 h，间隔 6 h，无缺号"],
        ["五省最高采样风速", "15.9243 m/s < 17.2 m/s（严重程度筛查未超过）"],
        ["模型损失省份", "福建、广东、海南"], ["总损失", "10,124,903.76"],
        ["保存目录", "/root/autodl-tmp/TyphoonRiskChina/runs/NOUL_ID2612_revised_20260805"],
    ], [2600, 6760])
    para(doc, "下游只链接其中 006–168 h 的 28 个文件；174–360 h 仍完整保留，满足用户要求和长期预报分析，不在 prepared_input 中复制。")

    doc.add_heading("9. 缩短运行时间的优化方案", level=1)
    add_table(doc, ["优先级", "优化", "预期收益", "科学影响"], [
        ["P0", "minimal=[20,8]，只到 168 h", "少 32 次推理与约 9.3 GB 写盘", "不影响当前下游时间窗"],
        ["P0", "符号/硬链接与阶段复用", "避免大文件复制；秒级续跑", "无数值变化"],
        ["P1", "API 单进程模型常驻", "减少重复加载", "无数值变化"],
        ["P1", "批量参数基准测试", "提升 CPU/GPU 吞吐", "需回归数值与内存"],
        ["P2", "NetCDF zlib level 1 归档", "降低长期存储", "无损但增加 CPU 时间"],
        ["研究项", "区域/通道裁剪", "显著降低 I/O", "改变契约，需论文披露和再验证"],
    ], [900, 2800, 2800, 2860])

    doc.add_heading("10. 前端设计", level=1)
    add_list(doc, ["上传区：初始场和路径文件，显示大小、维度、时间和校验状态。", "配置区：事件 ID/名称、minimal/full、影响阈值、是否强制重算。", "进度区：FuXi、接口、降尺度、暴露、易损性/报告五阶段状态和耗时。", "结果区：最大风地图、损失地图、受影响省份卡片、总损失与下载按钮。", "审计区：manifest、软件版本、输入指纹、日志尾部和失败重试。"])
    para(doc, "前端不直接解析数百 MB NetCDF；后端生成 PNG、轻量 GeoJSON/JSON 和统计摘要。大文件上传需要分片、断点续传和后端维度校验。")

    doc.add_heading("11. AutoDL 容器 Example Pro", level=1)
    para(doc, "容器示例使用 6008 端口，挂载 /root/autodl-tmp 和只读 settings.json。POST /jobs 接收两个文件并返回 job_id；GET /jobs/{id} 返回 manifest；GET /jobs/{id}/report 下载 PDF。本地 client/submit_job.py 自动完成提交、轮询和下载。")
    add_list(doc, ["镜像不包含模型和暴露数据，避免体积、许可和更新问题。", "GPU 只分配给 FuXi；旧 TensorFlow 走 CPU。", "示例为单用户科研服务；公网部署前必须加入认证、TLS、限额、队列和清理策略。", "SSH 密码、私钥和令牌不得写入配置或镜像。"])

    doc.add_heading("12. 论文撰写建议", level=1)
    doc.add_heading("12.1 Methods 可直接采用的结构", level=2)
    add_list(doc, ["数据与事件：初始场、路径、暴露数据、行政区边界和研究时间窗。", "全球预报：FuXi 三阶段结构、6 h 步长、完整/最小预报窗。", "统计降尺度：输入变量、移动窗口、模型结构、scaler、融合和固定网格。", "风险暴露：空间匹配、影响阈值、暴露指标和缺失值规则。", "易损性与损失：曲线来源、资产类型、聚合层级和不确定性。", "计算与复现：硬件、软件锁定、种子/确定性、代码与数据可得性。"])
    doc.add_heading("12.2 必须披露的限制", level=2)
    add_list(doc, ["FuXi 预报误差随时效增长，降尺度不能恢复不存在的大尺度信息。", "下垫面和暴露数据的年份/空间分辨率会影响损失。", "易损性曲线的迁移性和资产类别映射是不确定性主要来源。", "当前验收仅覆盖 Bavi 和 NOUL，不能代表所有台风强度、路径和登陆区域。", "系统输出是情景估计，不等同于观测损失或业务定损。"])
    doc.add_heading("12.3 建议图表", level=2)
    add_list(doc, ["图：完整技术路线；Bavi/NOUL 路径；最大风与损失空间分布；计算耗时分解。", "表：数据源与许可；输入输出契约；环境版本；两事件验收；敏感性/不确定性。", "补充材料：manifest 示例、配置文件、文件哈希和 reviewer quickstart。"])

    doc.add_heading("13. 审稿人检查清单", level=1)
    add_list(doc, ["读取 README、第三方资产声明和数据许可。", "核对两个 Python 环境和 GPU provider。", "运行单元测试及 NOUL 60 文件连续性检查。", "执行 Bavi；确认两层 manifest 为 complete。", "检查降尺度四件套、网格 CSV、图和 PDF。", "比较关键统计量与论文表格，记录容差。", "保存 commit、pip freeze、nvidia-smi 和输入指纹。"], numbered=True)

    doc.add_heading("附录 A. 常见问题", level=1)
    add_table(doc, ["症状", "原因", "处理"], [
        ["CUDAExecutionProvider 未启用", "ORT/CUDA 库或模型外部权重路径不完整", "运行 provider 检查；核对三个模型数据文件"],
        ["TensorFlow 首次运行很久", "RTX 5090 与旧 TF 内核不匹配、PTX JIT", "下游设置 CUDA_VISIBLE_DEVICES=-1"],
        ["找不到 FNL", "文件未放入标准目录或文件名无 3 位时效", "使用 prepared_input/IDxxxx/FNL/006.nc 格式"],
        ["NetCDF 打不开", "上传中断、HDF5 锁或文件残缺", "比较字节数；重新上传；xarray 逐文件验证"],
        ["PDF 中文字体异常", "容器缺少 CJK 字体", "安装 Noto CJK 并在报告模块显式注册"],
        ["磁盘增长过快", "完整 60 文件被重复复制", "使用链接；minimal 模式；归档压缩"],
    ], [2800, 3160, 3400])

    doc.add_heading("附录 B. 公开发布前事项", level=1)
    add_list(doc, ["替换 CITATION.cff 中的作者占位符并补论文 DOI。", "为 FuXi、模型、Parquet、GeoJSON、曲线逐项补来源与许可。", "由权利人选择并添加本仓库代码许可证。", "从配置、日志、历史和文档中移除密码、IP、令牌和私有路径。", "为公开样例提供可再分发小数据或官方下载脚本。", "在干净容器/新实例上执行一次 reviewer quickstart。"])

    output.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--bavi-manifest", type=Path)
    parser.add_argument("--route-png", type=Path, required=True)
    args = parser.parse_args()
    build(args.output, args.bavi_manifest, args.route_png)


if __name__ == "__main__":
    main()
