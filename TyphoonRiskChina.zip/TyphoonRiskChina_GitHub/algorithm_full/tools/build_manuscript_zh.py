from __future__ import annotations

import argparse
from pathlib import Path
from zipfile import ZipFile

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


BLUE = RGBColor(46, 116, 181)
DARK_BLUE = RGBColor(31, 77, 120)
MUTED = RGBColor(95, 95, 95)
TABLE_FILL = "F4F6F9"
USABLE_DXA = 9360


def set_font(run, name: str = "Calibri", east_asia: str = "Microsoft YaHei", size: float | None = None,
             bold: bool | None = None, italic: bool | None = None, color: RGBColor | None = None) -> None:
    run.font.name = name
    if run._element.get_or_add_rPr().rFonts is None:
        run._element.get_or_add_rPr().append(OxmlElement("w:rFonts"))
    fonts = run._element.rPr.rFonts
    fonts.set(qn("w:ascii"), name)
    fonts.set(qn("w:hAnsi"), name)
    fonts.set(qn("w:eastAsia"), east_asia)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if color is not None:
        run.font.color.rgb = color


def set_cell_margins(cell, top: int = 80, start: int = 120, bottom: int = 80, end: int = 120) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for edge, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{edge}"))
        if node is None:
            node = OxmlElement(f"w:{edge}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths: list[int]) -> None:
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.first_child_found_in("w:tblW")
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths)))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.first_child_found_in("w:tblInd")
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), "120")
    tbl_ind.set(qn("w:type"), "dxa")
    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)
    for row in table.rows:
        cant_split = OxmlElement("w:cantSplit")
        row._tr.get_or_add_trPr().append(cant_split)
        for index, cell in enumerate(row.cells):
            cell.width = Inches(widths[index] / 1440)
            tc_w = cell._tc.get_or_add_tcPr().first_child_found_in("w:tcW")
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                cell._tc.get_or_add_tcPr().append(tc_w)
            tc_w.set(qn("w:w"), str(widths[index]))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)


def configure_styles(doc: Document) -> None:
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(8)
    normal.paragraph_format.line_spacing = 1.333

    for name, size, color, before, after in (
        ("Heading 1", 16, BLUE, 18, 10),
        ("Heading 2", 13, BLUE, 12, 6),
        ("Heading 3", 12, DARK_BLUE, 8, 4),
    ):
        style = doc.styles[name]
        style.font.name = "Calibri"
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = color
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True


def add_page_number(paragraph) -> None:
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("Page ")
    set_font(run, size=9, color=MUTED)
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    paragraph._p.append(fld)


def set_running_furniture(doc: Document) -> None:
    section = doc.sections[0]
    header = section.header.paragraphs[0]
    header.text = "TyphoonRiskChina · Chinese manuscript body"
    header.alignment = WD_ALIGN_PARAGRAPH.LEFT
    for run in header.runs:
        set_font(run, size=9, color=MUTED)
    add_page_number(section.footer.paragraphs[0])


def add_title_block(doc: Document) -> None:
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(28)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(8)
    run = p.add_run("TyphoonRiskChina")
    set_font(run, size=26, bold=True, color=RGBColor(32, 55, 72))
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(5)
    run = p.add_run("从 FuXi 全球预报到中国沿海台风损失报告的可复现软件")
    set_font(run, size=15, color=DARK_BLUE)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(22)
    run = p.add_run("论文主体中文稿 · Sections 2–5")
    set_font(run, size=10.5, italic=True, color=MUTED)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(18)
    run = p.add_run("软件版本 1.0.0 · 红霞（NOUL，ID2612）实算案例 · 2026-08-04")
    set_font(run, size=10, color=MUTED)


def add_body(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Inches(0.29)
    p.paragraph_format.keep_together = False
    run = p.add_run(text)
    set_font(run, size=11)


def add_caption(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.keep_with_next = False
    run = p.add_run(text)
    set_font(run, size=9.5, italic=True, color=MUTED)


def add_picture(doc: Document, path: Path, caption: str, width: float = 6.25) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next = True
    run = p.add_run()
    shape = run.add_picture(str(path), width=Inches(width))
    doc_pr = shape._inline.docPr
    doc_pr.set("descr", caption)
    add_caption(doc, caption)


def add_results_table(doc: Document) -> None:
    rows = [
        ("FuXi 输出", "60 个；006–360 h；6 h 间隔"),
        ("下游输入", "前 28 个；006–168 h；符号链接"),
        ("下游完成回归", "86.00 s（复用已重算降尺度）"),
        ("固定网格最大/平均风速", "21.8132 / 7.6161 m s⁻¹"),
        ("五省暴露网格最高风速", "15.9243 m s⁻¹"),
        ("严重程度阈值", "15.9243 < 17.2 m s⁻¹；未超过"),
        ("模型损失省份", "福建、广东、海南"),
        ("网格记录", "705,834 条风速 + 705,834 条损失记录"),
        ("五省监测暴露总量", "36,637,704,978.42"),
        ("结构/屋面/门窗损失", "144.20 / 9,967,883.10 / 156,876.45"),
        ("总损失", "10,124,903.76"),
    ]
    table = doc.add_table(rows=1, cols=2)
    table.style = "Table Grid"
    header_repeat = OxmlElement("w:tblHeader")
    header_repeat.set(qn("w:val"), "true")
    table.rows[0]._tr.get_or_add_trPr().append(header_repeat)
    headers = ("指标", "红霞（ID2612）实测结果")
    for i, value in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        shading = OxmlElement("w:shd")
        shading.set(qn("w:fill"), TABLE_FILL)
        cell._tc.get_or_add_tcPr().append(shading)
        run = cell.paragraphs[0].add_run(value)
        set_font(run, size=10, bold=True)
    for key, value in rows:
        cells = table.add_row().cells
        for cell, text in zip(cells, (key, value)):
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            run = cell.paragraphs[0].add_run(text)
            set_font(run, size=9.6)
    set_table_geometry(table, [3000, 6360])
    add_caption(doc, "表 1  红霞（NOUL，ID2612）端到端计算的主要验收指标。")


SECTION_21 = [
    "TyphoonRiskChina 的设计目标是把气象预报、局地风场重建和风险损失评估连接成一个可追踪、可重复执行的软件系统。传统研究往往分别运行数值或数据驱动预报、降尺度脚本、暴露匹配程序和易损性模型，阶段间依靠人工复制文件与修改路径衔接。这种方式容易产生版本漂移、输入错配和不可追溯的中间结果。软件因此采用分层流水线，将数据契约、执行顺序、环境隔离、状态记录和结果汇总集中到统一编排层，同时保留各科学模块原有的计算逻辑，使研究者能够在不重写模型的前提下复现实验。",
    "总体架构分为控制面和数据面。控制面由 Python 包 typhoonriskchina 提供，包含命令行接口、FastAPI 服务、事件配置、输入校验、阶段调度、日志和 manifest 管理。数据面负责传递 FuXi 初始场、逐时效全球预报、3 km 风场、固定网格最大风速、暴露记录和损失结果。大文件不进入代码仓库，而是通过配置指向 AutoDL 数据盘；阶段接口优先创建符号链接，文件系统不支持时再降级为硬链接或复制。该策略把数十 GB 的科学数据与轻量控制代码分离，同时避免重复写盘。",
    "第一层是 FuXi 全球预报模块。软件接收包含两个连续初始时次的 NetCDF DataArray，通道数为 70，空间网格为 721×1440。short、medium 和 long 三个 ONNX 阶段在独立 GPU 环境中依次执行，每次向前推进 6 h。最小模式配置为 20+8 步，生成 006–168 h 的 28 个文件；完整模式配置为 20+20+20 步，生成 006–360 h 的 60 个文件。编排器在进入下一阶段前检查文件数、三位时效命名和 6 h 连续性，防止下载中断或阶段缺失被误认为有效预报。",
    "第二层是 FuXi—降尺度接口。接口从完整预报目录中选择 006–168 h，并建立标准目录 prepared_input/IDxxxx/FNL；路径工作簿复制到事件根目录并统一命名为track.xlsx。事件目录因此同时包含气象场与台风中心轨迹，满足下游移动窗口程序的输入约定。接口把选择数量、最大时效和实际采用的链接方式写入 run_manifest.json。完整模式的 174–360 h 仍保留用于长期预报分析，但不会因当前降尺度时间窗而被再次复制。",
    "第三层包含统计降尺度、风险暴露、易损性和报告源代码，统一保存在 modules/webready/backend。降尺度模块读取全球场和路径，在随台风中心移动的区域内构造模型特征，使用训练完成的 U-Net 类 H5 模型与输入、输出 scaler 预测高分辨率风速，并将逐时结果融合到固定空间网格。风险暴露模块随后把固定网格过程最大风速与福建、广东、海南、江苏和浙江的暴露及网格 Parquet 匹配；易损性模块根据资产类型与风速响应曲线计算结构和非结构损失，并结合行政区边界形成省市汇总。",
    "输出层同时服务人工阅读和机器处理。降尺度阶段产生移动窗口时序 NetCDF、逐时诊断 CSV、固定网格最大风速 NetCDF 和 PNG；风险阶段产生 grid_wind.csv、grid_loss.csv、最大风速分布图和损失分布图；报告阶段形成 PDF、loss_summary.json 与 loss_summary.md。外层 run_manifest.json 记录统一流水线状态，内层 pipeline_result.json 保存下游各模块状态。两层 manifest 共同构成审计链，使审稿人能够确认结果来自哪些输入、在哪个阶段生成、是否复用了旧结果以及失败发生在何处。",
    "为解决 RTX 5090 与旧 TensorFlow 栈之间的依赖冲突，软件明确隔离两个 Python 环境。FuXi 环境使用 ONNX Runtime GPU 和 CUDAExecutionProvider；风险环境固定 Python 3.10、TensorFlow/Keras 2.10.1、NumPy 1.23.5 及 GIS、NetCDF、Parquet 和报告库。由于旧 TensorFlow 在新架构 GPU 上可能触发长时间 PTX JIT，下游默认设置 CUDA_VISIBLE_DEVICES=-1，使用多核 CPU 运行；FuXi 则独占 GPU。环境隔离避免为兼容一个阶段而破坏另一个阶段的二进制依赖。",
    "软件提供 CLI、HTTP API 和容器三种入口。CLI 适合批量实验和审稿人复现；API 在 6008 端口接收初始场和路径工作簿，返回任务标识并提供状态查询与报告下载；容器挂载 AutoDL 数据盘和只读配置，不把模型与暴露数据固化进镜像。API 使用单 worker 队列，避免同一 GPU 上并发启动多个 FuXi 会话。客户端脚本负责本地上传、轮询和下载 PDF，从而形成“本地提交—云端计算—本地取回报告”的 Example Pro 工作方式。",
    "可复现性机制贯穿整个架构。配置文件显式列出解释器、FuXi 入口、模型目录、下游 CLI、降尺度运行资料、暴露根目录和任务目录；事件 JSON 则定义事件编号、名称、初始场、路径、已有预报目录、推理步数和影响阈值。每个阶段开始前验证路径及结构，完成后原子写入 JSON；异常时记录类型、消息、traceback 和日志尾部。仓库另外提供单元测试、GitHub Actions、数据与模型卡、第三方资产声明、案例摘要和校验值，使软件发布、论文复核与后续维护共享同一套证据。",
]


SECTION_22 = [
    "方法流程首先定义严格的输入契约。FuXi 初始场的 time 维长度必须为 2，两个时次相隔 6 h；channel 维长度为 70，变量顺序与训练样例保持一致；纬度由 90°递减至−90°，经度覆盖 0–359.75°。与仅验证扩展名相比，维度、坐标、字节数和可读性检查能够更早识别上传中断、HDF5 残缺或变量顺序错误。对于复用的预报，discover_forecasts 从三位时效文件名解析 lead hour，validate_sequence 根据预期数量构造 6、12、…、6N h 序列，并在存在缺号时停止流水线。",
    "FuXi 推理采用三阶段自回归。每一步读取前一状态并输出下一个 6 h 全球场，short 阶段覆盖近时效，medium 与 long 阶段继续扩展。统一入口把各阶段步数组装成命令行参数，并把输出写入事件独立目录。若目录已经存在且数量与预期相同，系统可以直接复用；否则重新推理。该设计允许完整 360 h 预报与只服务下游的 168 h 最小预报共享同一实现，也使计算预算、磁盘占用和科学时间窗成为可配置选择。",
    "降尺度以台风中心轨迹驱动移动窗口。程序从每个 FuXi 6 h 场提取与近地风相关的气象变量，再沿路径插值形成逐小时中心位置和输入特征；输入 scaler 将变量映射至模型训练尺度，H5 网络输出局地高分辨率风场，输出 scaler 将结果恢复到物理量纲。移动窗口结果经过时空融合形成连续的 3 km 近地风速序列。软件保留逐小时中心、粗场最大风和有用时效摘要，以便识别路径跳变、异常峰值或模型输入不足。",
    "为了与静态暴露网格连接，降尺度时序被聚合为固定网格过程最大风速。设 v(x,t) 为位置 x 在时刻 t 的预测风速，则灾害强度层使用 v_max(x)=max_t v(x,t)。该操作保留事件过程中每个位置遭遇的最大风作用，并输出最大值发生时间。固定网格 NetCDF 是风险模块的主输入，PNG 用于快速质量控制；移动窗口 NetCDF 仍保留完整时间演化，可用于未来研究持续时间、阵风或路径不确定性。",
    "暴露匹配以行政区和网格标识为约束，将 v_max 映射到五省资产记录。系统先验证省级暴露文件、对应网格文件和四类边界资料，再基于坐标或网格标识连接风速、城市、资产与暴露量。默认 17.2 m s⁻¹ 阈值用于识别显著受影响区域，但损失曲线仍对完整匹配网格进行计算，以保持低风速下的连续响应。输出表同时保存经纬度、最大风速、最大值时刻、省市名称和损失分项，便于空间聚合与独立复算。",
    "易损性计算把灾害强度转换为损坏率。对网格 g 和资产分量 k，可表示为 L_gk=E_gk·r_k(v_g)，其中 E_gk 为暴露量，v_g 为匹配后的过程最大风速，r_k 为相应易损性曲线。当前报告区分结构、屋面和门窗损失，非结构损失为屋面与门窗之和，总损失为结构与非结构损失之和。软件没有在编排层改写曲线，而是记录曲线来源、阈值和配置，使论文能够将模型选择与软件执行分开讨论。",
    "城市和省级指标由网格结果聚合获得。对于区域 A，总损失为 L_A=Σ_g∈AΣ_k L_gk，暴露总量采用同一空间集合求和。专题图叠加台风轨迹、行政区边界和风速或损失色标，报告列出受影响省份、重点城市及损失分项。机器可读 CSV/JSON 与人工可读 PDF 使用同一计算结果生成，避免图表与数据表来自不同脚本或不同版本。任何结果解释都应同时报告资产年份、货币单位、价格基年和曲线适用对象。",
    "质量控制分为结构检查、数值检查和过程检查。结构检查验证文件数量、命名、目录和必备资源；数值检查读取 NetCDF、统计最小值、最大值和均值，并检查 NaN/Inf；过程检查要求 FuXi、接口、降尺度、暴露、易损性和报告阶段均产生 complete 状态。运行结果不是仅以退出码 0 判定，而是要求四个降尺度产物、两个网格 CSV、两幅地图、PDF 和两层 manifest 同时存在。单元测试覆盖时效序列契约，案例验收则覆盖真实数据路径。",
    "性能优化遵循“不改变当前科学契约”的原则。首先，minimal 模式只推理至 168 h，比完整模式减少 32 次推理及约 9.3 GB 输出；其次，接口使用链接避免大型 NetCDF 复制；再次，完整降尺度结果可按 manifest 复用，API 进程可常驻以减少重复初始化；最后，FuXi GPU 与旧 TensorFlow CPU 分工消除设备争抢。区域裁剪、通道裁剪、批量推理和压缩归档具有进一步潜力，但会改变输入或数值行为，必须经过回归验证和论文披露后才能作为新版本采用。",
    "方法仍存在边界。FuXi 误差随预报时效增长，统计降尺度不能恢复全球模型未表达的全部小尺度过程；路径误差会改变移动窗口中心；暴露年份、空间分辨率和缺失值规则会影响聚合损失；易损性曲线跨地区、跨资产类型迁移是主要不确定性来源。因此 TyphoonRiskChina 的结果被定义为可复现的情景估计，而不是观测损失、保险定损或实时应急指令。软件的价值在于让这些假设和传播链条可见、可配置并可重复检验。",
]

# Chinese drafting targets calibrated for later translation to approximately
# 1,650 English words across Section 2 while retaining each core method stage.
SECTION_21 = [SECTION_21[index] for index in (0, 1, 2, 4, 6, 8)]
SECTION_22 = [SECTION_22[index] for index in (0, 2, 3, 4, 5, 7, 9)]


SECTION_3 = [
    "为了展示完整工作流，本文选择红霞（NOUL，ID2612）作为说明性案例。更新初始场 Noul.nc 包含两个连续时次、70 通道和 721×1440 网格，SHA-256 为 0c77f46119c23878b82fa63ab1c920e47136439aa43e8b4422d65b51b4d55e13。FuXi 在 RTX 5090 上按 short=20、medium=20、long=20 重新运行，生成从 006 h 到 360 h 的 60 个全球预报文件，文件间隔为 6 h 且无缺号。下游接口从中选择 006–168 h 的 28 个文件，并全部以链接方式物化到事件目录，避免约 8 GB 的重复复制。",
    "红霞下游计算在新版 TyphoonRiskChina 中实际执行，而不是使用预置演示值。外层 run_manifest.json、内层 pipeline_result.json 和风险 result_manifest.json 均记录为 complete。降尺度生成 389.68 MB 的移动窗口时序 NetCDF、逐时诊断 CSV、固定网格最大风速 NetCDF 和预览图；随后生成各 705,834 条的网格风速与网格损失记录、两幅专题图和 1.56 MB 的 PDF 报告。这组产物验证了从全球预报到论文可用统计表和图件的自动衔接。",
    "固定网格过程最大风速为 21.8132 m s⁻¹，空间均值为 7.6161 m s⁻¹。与福建、广东、海南、江苏和浙江的实际暴露网格匹配后，最高采样风速为 15.9243 m s⁻¹，低于默认 17.2 m s⁻¹ 严重程度筛查阈值。该阈值只用于标记强影响网格，不能截断连续易损性函数；修正后的程序仍对五省暴露执行损失计算，并把 threshold_exceeded=false 与模型损失省份分别记录。",
    "五省监测暴露总量为 36,637,704,978.42。结构损失为 144.20，屋面损失为 9,967,883.10，门窗损失为 156,876.45，非结构损失为 10,124,759.55，总损失为 10,124,903.76。模型损失分布在福建、广东和海南，其中广东约 8.59×10⁶。数值单位和货币价格基年继承自外部暴露与易损性资料；最终英文稿必须与数据来源一起明确，不能仅凭数值外观解释为特定年份人民币。",
    "修正回归还说明了筛查指标和连续损失函数必须分离。更新风场未产生任何超过 17.2 m s⁻¹ 的暴露网格，但不代表较低风速下的模型损失为零。GitHub 中的回归测试明确禁止阈值后强制清零，结果清单同时保存 threshold_exceeded、模型损失省份和各损失分项，使论文表格能够追溯该判定。",
    "红霞案例还展示了软件复现机制。事件配置、路径工作簿、损失摘要、两层 manifest 和三幅小型图片已纳入 GitHub examples/NOUL_ID2612；60 个 FuXi 文件、移动窗口 NetCDF 和大型 CSV 保留在 AutoDL 数据盘。审稿人可先运行不依赖大数据的单元测试，再根据资产清单挂载模型与数据，执行 run_noul.sh，并比较文件连续性、固定网格风速统计、受影响省份、损失分项和输出数量。该分层发布方式既保留可审计证据，又避免把约 17 GB 的预报结果写入 Git 历史。",
    "作为说明性示例，红霞结果证明流水线在当前数据和配置上可运行，但不能视为模型精度的独立验证。案例只覆盖一个路径、一个影响区域和一套暴露/曲线组合，预报风场也尚未在本节中与逐站观测进行系统比较。未来案例研究应加入观测对照、不同路径扰动、易损性曲线敏感性、暴露年份情景及不确定性区间，从而区分软件正确性、模型预测能力和损失估计可信度。",
]

# Calibrated for an approximately 720-word English translation.
SECTION_3 = [SECTION_3[index] for index in (0, 1, 2, 3, 4, 6)]


SECTION_4 = [
    "TyphoonRiskChina 的直接影响是把原本分散且高度依赖人工操作的研究链条转化为可复查的软件对象。统一输入契约减少时效缺号、路径错配和旧结果误复用；双层 manifest、日志与结果摘要使论文表格能够追溯到事件配置和文件；环境隔离使新 GPU 上的 ONNX 推理与旧 TensorFlow 模型可以在同一实例共存。这些机制降低了其他研究者理解和重跑多阶段台风风险实验的门槛。",
    "在科学研究方面，软件建立了从全球机器学习天气预报到局地灾害损失的明确接口。研究者可以分别替换预报模型、降尺度模型、暴露数据或易损性曲线，并通过相同输出契约进行对照实验；最小和完整预报模式也支持在计算成本与长期时效之间选择。Bavi 与红霞两个案例为回归测试提供了不同的路径和影响范围，便于后续版本识别数值漂移。",
    "在应用层面，HTTP API、容器和本地提交客户端支持将复杂 GPU/CPU 工作流封装为单事件服务，为前端展示、科研演示和应急情景推演提供基础。然而当前服务是单用户研究原型，尚不具备公网生产系统所需的认证、TLS、配额、持久化队列和容灾能力；损失结果也不能替代业务定损。明确这些边界有助于防止软件工程可用性被误解为预测或决策可靠性。",
    "项目的开放发布策略同样具有方法学意义：轻量代码、边界资料、小型案例和校验信息进入 GitHub，大型或受限模型与数据通过 DOI、授权下载或挂载提供。该做法既符合版本控制和文件大小限制，也迫使研究者记录数据来源、许可、字节数、哈希、坐标系和单位。由此，软件不仅执行模型，还为可重复计算、数据治理和论文审计提供共同框架。",
]


SECTION_5 = [
    "TyphoonRiskChina 将 FuXi 全球预报、3 km 风场降尺度、五省风险暴露、易损性计算和损失报告整合为一条可配置、可审计的流水线。系统通过环境隔离、标准目录、链接式数据传递、双层 manifest、CLI/API/容器入口和 GitHub 案例材料，提高了复杂台风风险实验的可复现性。红霞案例完成 60 个 FuXi 文件和全部下游阶段，证明该架构能够从初始场自动生成网格风速、损失分项、专题图和 PDF 报告。",
    "未来工作应侧重观测验证、路径和模型集合、不确定性传播、暴露与易损性资料的时空更新，以及面向多用户服务的安全与任务调度。所有结果仍应被解释为依赖输入数据、模型和曲线假设的情景估计。",
]


def build(output: Path, route_png: Path, wind_png: Path, loss_png: Path) -> None:
    doc = Document()
    configure_styles(doc)
    set_running_furniture(doc)
    add_title_block(doc)

    doc.add_heading("2. Software description", level=1)
    doc.add_heading("2.1. Software architecture", level=2)
    for index, text in enumerate(SECTION_21):
        add_body(doc, text)
        if index == 1:
            add_picture(doc, route_png, "图 1  TyphoonRiskChina 数据面、控制面与阶段输入输出。", width=6.35)

    doc.add_heading("2.2. Methodology", level=2)
    for text in SECTION_22:
        add_body(doc, text)

    doc.add_heading("3. Illustrative examples: 红霞（NOUL，ID2612）损失计算", level=1)
    for index, text in enumerate(SECTION_3):
        add_body(doc, text)
        if index == 1:
            add_results_table(doc)
        elif index == 2:
            add_picture(doc, wind_png, "图 2  红霞轨迹及广东省暴露网格过程最大风速分布。", width=5.85)
        elif index == 4:
            add_picture(doc, loss_png, "图 3  红霞情景下广东省网格总损失空间分布。", width=5.85)

    doc.add_heading("4. Impact", level=1)
    for text in SECTION_4:
        add_body(doc, text)

    doc.add_heading("5. Conclusions", level=1)
    for text in SECTION_5:
        add_body(doc, text)

    output.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output)
    with ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("DOCX package integrity check failed")

    counts = {
        "section_2_chinese_chars": sum(len(text) for text in SECTION_21 + SECTION_22),
        "section_3_chinese_chars": sum(len(text) for text in SECTION_3),
        "section_4_chinese_chars": sum(len(text) for text in SECTION_4),
        "section_5_chinese_chars": sum(len(text) for text in SECTION_5),
    }
    print(counts)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--route-png", type=Path, required=True)
    parser.add_argument("--wind-png", type=Path, required=True)
    parser.add_argument("--loss-png", type=Path, required=True)
    args = parser.parse_args()
    build(args.output, args.route_png, args.wind_png, args.loss_png)


if __name__ == "__main__":
    main()
