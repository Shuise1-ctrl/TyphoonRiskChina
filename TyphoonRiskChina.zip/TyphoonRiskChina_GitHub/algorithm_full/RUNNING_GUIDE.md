# TyphoonRiskChina Linux running guide

## 1. Scope

TyphoonRiskChina starts at the external-FNL interface. FuXi or another forecast system may produce the upstream fields, but TyphoonRiskChina neither installs nor invokes that provider.

Required per event:

- `FNL/006.nc` through `FNL/168.nc`, exactly 28 six-hourly files;
- `track.xlsx`;
- shared downscaling `direct_unet_model.h5`, `scaler_x.save`, `scaler_y.save`;
- five provincial exposure Parquet files and five provincial grid Parquet files;
- the boundary files already tracked under `assets/`.

## 2. Install on Linux

```bash
git clone https://github.com/Shuise1-ctrl/TyphoonRiskChina.git
cd TyphoonRiskChina
conda env create -f environment-full.yml
conda activate typhoonriskchina-full
python -m pip install -e .
cp configs/autodl.settings.example.json configs/autodl.settings.json
```

Edit `configs/autodl.settings.json` so `risk_python`, `risk_cli`, `downscaling_runtime`, `risk_exposure_root` and `jobs_root` exist. FuXi paths are intentionally absent.

## 3. Validate inputs before a long run

```bash
typhoonriskchina verify-fnl --directory /data/ID2609/FNL --count 28
```

The check rejects a missing lead such as `162.nc`, a duplicate lead or a filename that does not expose a three-digit lead hour.

## 4. Bavi ID2609

```bash
export TYPHOONRISK_FNL_DIR=/data/ID2609/FNL
export TYPHOONRISK_TRACK_FILE=/data/ID2609/track.xlsx
typhoonriskchina check --config examples/Bavi_ID2609/config.yml --full-assets
typhoonriskchina run --config examples/Bavi_ID2609/config.yml
```

Equivalent wrapper:

```bash
bash scripts/run_bavi.sh
```

## 5. NOUL ID2612

```bash
export TYPHOONRISK_FNL_DIR=/data/ID2612/FNL
export TYPHOONRISK_TRACK_FILE=/data/ID2612/track.xlsx
typhoonriskchina check --config examples/NOUL_ID2612/config.yml --full-assets
typhoonriskchina run --config examples/NOUL_ID2612/config.yml
```

Equivalent wrapper: `bash scripts/run_noul.sh`.

## 6. Progress and outputs

The CLI prints five stages: configuration validation, external-FNL validation, FNL/track materialization, downscaling-to-report execution, and completion. `run_manifest.json` records the external input directory, sequence count, first/last lead, track checksum, stage status and output paths.

The key final products are fixed-grid wind NetCDF/PNG, `grid_wind.csv`, `grid_loss.csv`, the wind/loss PNG maps, JSON manifests and the PDF report.

## 7. Transfer to another computer

Copy the complete `Illustrative examples` directory, then run `sha256sum -c CHECKSUMS.sha256`. Native Windows is not the validated full-compute platform; use WSL2 with the required Linux stack, Docker Linux, or an AutoDL/Linux server.

## 8. GitHub boundary

Commit the repository source, configurations, tests, documentation and small expected evidence. Do not commit FNL NetCDF, H5/scalers or exposure Parquet unless licensing and Git LFS/release strategy are explicitly approved. The `.gitignore` rules and `docs/ASSETS.md` document this separation.
