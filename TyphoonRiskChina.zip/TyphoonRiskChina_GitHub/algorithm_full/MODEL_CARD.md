# Model card

TyphoonRiskChina is a composed downstream risk workflow, not a global forecast model. Its executable model component is the learned high-resolution wind downscaler. Deterministic vulnerability curves then combine downscaled hazard with exposure to estimate structural, roof, window, non-structural and total loss.

FuXi is treated as an external upstream provider. Its inference runtime, weights and initial-state preparation are not installed or called by this repository.

The software is intended for scientific scenario analysis and reproducible comparison, not unsupervised operational emergency decisions. Results depend on forecast quality, track accuracy, downscaling-domain coverage, exposure completeness and vulnerability-curve calibration. Validate against observations and local loss records before decision use.
