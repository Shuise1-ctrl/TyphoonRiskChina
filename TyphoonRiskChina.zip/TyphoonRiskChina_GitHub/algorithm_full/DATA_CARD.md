# Data card

TyphoonRiskChina consumes externally generated meteorological forecasts. FuXi is one possible provider but is outside this software's executable boundary.

## Event inputs

For Bavi ID2609 and NOUL ID2612, downscaling consumes 28 NetCDF files named `006.nc` through `168.nc` at 6 h intervals plus `track.xlsx`. The software validates filename continuity before materializing inputs into a run directory.

The illustrative offline release records per-file byte size and SHA-256 in `MATERIALS_MANIFEST.csv` and `CHECKSUMS.sha256`. The FNL files are not committed to ordinary Git history.

## Shared scientific assets

- trained direct U-Net downscaling H5 model;
- input/output scalers;
- coastal provincial exposure and spatial grid Parquet datasets;
- administrative-boundary GeoJSON and curve provenance metadata.

## Provenance requirements

For every release record the upstream forecast provider/version, generation time, valid times, variables, units, coordinate system, missing-value policy, byte size and SHA-256. Also record track source, downscaling model/scaler versions, exposure vintage and redistribution licence.

Exposure datasets may contain economically sensitive spatial attributes. Do not publish them without confirming provenance and redistribution rights.
