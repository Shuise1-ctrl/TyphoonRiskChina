from __future__ import annotations

import argparse
from contextlib import ExitStack
from pathlib import Path
import time
import requests


def main() -> None:
    parser = argparse.ArgumentParser(description="Submit one local event to AutoDL TyphoonRiskChina")
    parser.add_argument("--url", default="http://127.0.0.1:6008")
    parser.add_argument("--case", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--fnl-dir", type=Path, required=True)
    parser.add_argument("--track", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("loss_report.pdf"))
    args = parser.parse_args()
    fnl_paths = sorted(args.fnl_dir.glob("*.nc"))
    if [path.name for path in fnl_paths] != [f"{hour:03d}.nc" for hour in range(6, 169, 6)]:
        raise ValueError("--fnl-dir must contain the complete 006.nc ... 168.nc sequence")
    with ExitStack() as stack:
        track = stack.enter_context(args.track.open("rb"))
        files = [("track_file", (args.track.name, track, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))]
        files.extend(
            ("fnl_files", (path.name, stack.enter_context(path.open("rb")), "application/x-netcdf"))
            for path in fnl_paths
        )
        response = requests.post(
            f"{args.url}/jobs",
            data={"case_id": args.case, "typhoon_name": args.name},
            files=files,
            timeout=3600,
        )
    response.raise_for_status()
    job = response.json()["job_id"]
    while True:
        status = requests.get(f"{args.url}/jobs/{job}", timeout=30).json()
        print(status.get("status", "queued"))
        if status.get("status") == "complete":
            report = requests.get(f"{args.url}/jobs/{job}/report", timeout=300)
            report.raise_for_status()
            args.output.write_bytes(report.content)
            print(f"Saved: {args.output.absolute()}")
            return
        if status.get("status") == "failed":
            raise RuntimeError(status.get("error", {}))
        time.sleep(10)


if __name__ == "__main__":
    main()
