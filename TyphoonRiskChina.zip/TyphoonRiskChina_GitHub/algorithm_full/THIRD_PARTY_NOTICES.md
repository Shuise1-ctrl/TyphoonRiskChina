# Third-party assets

This repository orchestrates but does not redistribute or relicense:

- FuXi source code, ONNX graphs, external model weights and sample data;
- the downscaling H5 model and serialized scalers;
- exposure/grid Parquet datasets;
- vulnerability curves and any boundary dataset not explicitly present under `assets/vulnerability/`.

The small boundary files included under `assets/vulnerability/` retain the source and license notices provided in the adjacent `licenses/` and `docs/` directories. Inclusion in this repository does not replace those upstream terms.

Before public release, record the authoritative citation, DOI/URL, license, modification status and redistribution permission for every item. Large model/data files are intentionally excluded by `.gitignore`.
