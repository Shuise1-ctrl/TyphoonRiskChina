# Windows local integration notes

This portable Windows integration is based on the supplied TyphoonRiskChina
1.1.0 source archive.

## Compatibility changes

- Python 3.10.11 and dependencies live in the application's `.venv-full`.
- Windows installs use `requirements-windows.txt` and `tensorflow-cpu==2.10.1`.
- All NetCDF/HDF5 reads and writes use `h5netcdf` on Windows.
- The changes do not alter the model, scalers, formulae, thresholds, wind
  correction factor, or case inputs.

The generic TensorFlow wheel loaded the local NVIDIA display driver and exited
with `0xc0000005`.  The original netCDF4 backend also exited natively with
`0xc0000409` after TensorFlow loaded a different HDF5 ABI.  CPU TensorFlow plus
H5NetCDF removes both native crashes.

## Tested results (2026-08-06)

Both cases completed all four stages from 28 FNL files on native Windows:

| Case | Runtime | Recomputed total loss |
|---|---:|---:|
| Bavi / ID2609 | 641 s | 16,700,326.046929128 |
| NOUL / ID2612 | 653 s | 13,552,573.757151771 |

The supplied historical fixed-grid files remain valid inputs to the
vulnerability stage and reproduce their manifests exactly:

| Case | Historical fixed-grid loss-only total |
|---|---:|
| Bavi / ID2609 | 17,400,519.19584863 |
| NOUL / ID2612 | 10,124,903.757609027 |

Those historical wind fields are not reproduced by the current supplied
downscaling code and assets: the current source and the original 2026-08-05
archive both set `WIND_CORRECTION_FACTOR = 0.95`, while their resulting wind
fields differ materially from `outputs_corrected`.  Bavi's case workbook also
differs from its acceptance-example workbook.  The web application therefore
shows a warning and reports the new run's canonical
`vulnerability/result_manifest.json`; it never substitutes a historical loss.

Validation evidence is stored under:

`<repo>\data\full_algorithm_validation`
