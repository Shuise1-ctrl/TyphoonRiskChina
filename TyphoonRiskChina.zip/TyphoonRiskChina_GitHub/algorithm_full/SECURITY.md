# Security

Do not commit AutoDL passwords, SSH keys, tokens, proprietary model files or exposure data. The sample FastAPI service is not hardened for public access. Report vulnerabilities privately to the project maintainer named by the manuscript repository.

