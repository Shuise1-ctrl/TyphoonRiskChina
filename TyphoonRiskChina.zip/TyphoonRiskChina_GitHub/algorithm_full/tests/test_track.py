from pathlib import Path

import pytest

from typhoonriskchina.track import load_track_csv, summarize_track


def test_track_is_loaded_and_summarized(tmp_path: Path):
    source = tmp_path / "track.csv"
    source.write_text(
        "time,lat,lon\n"
        "2026-01-01T00:00:00+00:00,20.0,120.0\n"
        "2026-01-01T06:00:00+00:00,21.0,119.0\n",
        encoding="utf-8",
    )
    points = load_track_csv(source)
    summary = summarize_track(points)
    assert summary["point_count"] == 2
    assert summary["latitude_range"] == [20.0, 21.0]


def test_track_times_must_increase(tmp_path: Path):
    source = tmp_path / "track.csv"
    source.write_text(
        "time,lat,lon\n"
        "2026-01-01T06:00:00+00:00,20.0,120.0\n"
        "2026-01-01T00:00:00+00:00,21.0,119.0\n",
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="strictly increasing"):
        load_track_csv(source)
