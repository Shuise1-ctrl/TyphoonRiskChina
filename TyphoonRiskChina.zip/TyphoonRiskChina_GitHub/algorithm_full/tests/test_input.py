from pathlib import Path
import pytest

from typhoonriskchina.downscaling import canonical_level_label, canonical_level_labels
from typhoonriskchina.validation import discover_forecasts, validate_sequence


def test_complete_sequence(tmp_path: Path):
    for hour in (6, 12, 18):
        (tmp_path / f"{hour:03d}.nc").touch()
    files = validate_sequence(discover_forecasts(tmp_path), 3)
    assert [path.name for path in files] == ["006.nc", "012.nc", "018.nc"]


def test_missing_forecast_is_rejected(tmp_path: Path):
    (tmp_path / "006.nc").touch()
    (tmp_path / "018.nc").touch()
    with pytest.raises(ValueError, match="missing lead hours"):
        validate_sequence(discover_forecasts(tmp_path), 3)


def test_revised_fuxi_level_labels_are_normalized():
    assert canonical_level_label("R850.0") == "r850"
    assert canonical_level_label("U10") == "u10"
    assert canonical_level_label("T2M") == "t2m"
    assert canonical_level_labels(["Z50.0", "T100.0", "MSL", "TP"]) == [
        "z50",
        "t100",
        "msl",
        "tp",
    ]
