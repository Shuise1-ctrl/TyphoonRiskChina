import json
from pathlib import Path
import sys

import pytest

from typhoonriskchina.config import Event, RunConfig, Settings
from typhoonriskchina.validation import validate_run_config
from typhoonriskchina.workflow import UnifiedPipeline


def make_fnl(root: Path, missing: int | None = None) -> Path:
    root.mkdir()
    for hour in range(6, 169, 6):
        if hour != missing:
            (root / f"{hour:03d}.nc").touch()
    return root


def make_settings(tmp_path: Path) -> Path:
    risk_cli = tmp_path / "risk_cli.py"
    risk_cli.touch()
    downscaling = tmp_path / "downscaling"
    exposure = tmp_path / "exposure"
    jobs = tmp_path / "jobs"
    for path in (downscaling, exposure, jobs):
        path.mkdir()
    settings = tmp_path / "settings.json"
    settings.write_text(
        json.dumps(
            {
                "risk_python": sys.executable,
                "risk_cli": str(risk_cli),
                "downscaling_runtime": str(downscaling),
                "risk_exposure_root": str(exposure),
                "jobs_root": str(jobs),
                "fuxi_python": "/legacy/value/is/ignored",
            }
        ),
        encoding="utf-8",
    )
    return settings


def test_full_config_accepts_external_fnl_without_fuxi_assets(tmp_path: Path):
    fnl = make_fnl(tmp_path / "FNL")
    track = tmp_path / "track.xlsx"
    track.touch()
    settings = make_settings(tmp_path)
    config = tmp_path / "config.yml"
    config.write_text(
        "schema_version: 1\n"
        "mode: full\n"
        "case:\n  id: ID2609\n  name: Bavi\n"
        f"settings: {settings.name}\n"
        f"event:\n  track_file: {track.name}\n  existing_fnl_dir: {fnl.name}\n"
        "  downscaling_max_hour: 168\n"
        "execution:\n  input_mode: external_fnl\n  reuse_downscaling: false\n"
        "output:\n  directory: runs/ID2609\n",
        encoding="utf-8",
    )
    result = validate_run_config(RunConfig.load(config), full_assets=True)
    assert result["input_mode"] == "external_fnl"
    assert result["fnl_count"] == 28
    assert Settings.load(settings).risk_python.is_file()


def test_external_fnl_missing_lead_is_rejected(tmp_path: Path):
    fnl = make_fnl(tmp_path / "FNL", missing=162)
    track = tmp_path / "track.xlsx"
    track.touch()
    event = Event("ID2612", "NOUL", track, fnl)
    with pytest.raises(ValueError, match="missing lead hours"):
        UnifiedPipeline._validate_external_fnl(event, "external_fnl")


def test_prepare_case_uses_required_track_filename(tmp_path: Path):
    fnl = make_fnl(tmp_path / "FNL")
    track = tmp_path / "source_track.xlsx"
    track.write_bytes(b"track")
    dummy = tmp_path / "dummy"
    dummy.touch()
    settings = Settings(dummy, dummy, tmp_path, tmp_path, tmp_path / "jobs")
    event = Event("ID2609", "Bavi", track, fnl)
    case_dir, result = UnifiedPipeline(settings)._prepare_case(event, fnl, tmp_path / "run")
    assert (case_dir / "track.xlsx").read_bytes() == b"track"
    assert result["count"] == 28
    assert len(list((case_dir / "FNL").glob("*.nc"))) == 28
