import json
from pathlib import Path

from typhoonriskchina.workflow import run_from_config


def test_reviewer_demo_writes_manifest_and_loss_files(tmp_path: Path):
    track = tmp_path / "track.csv"
    track.write_text(
        "time,lat,lon\n"
        "2026-01-01T00:00:00+00:00,20.0,120.0\n"
        "2026-01-01T06:00:00+00:00,21.0,119.0\n",
        encoding="utf-8",
    )
    exposure = tmp_path / "exposure.csv"
    exposure.write_text(
        "grid_id,province,city,wind_speed_ms,exposure_value\n"
        "A,Guangdong,Shantou,18.0,1000000\n",
        encoding="utf-8",
    )
    config = tmp_path / "config.yml"
    config.write_text(
        "schema_version: 1\n"
        "mode: reviewer_demo\n"
        "case:\n  id: case01\n  name: Demo\n"
        "inputs:\n  track: track.csv\n  exposure: exposure.csv\n"
        "output:\n  directory: outputs\n",
        encoding="utf-8",
    )
    result = run_from_config(config)
    assert result["status"] == "complete"
    manifest = json.loads((tmp_path / "outputs" / "run_manifest.json").read_text(encoding="utf-8"))
    assert manifest["stages"]["report"]["status"] == "complete"
    assert (tmp_path / "outputs" / "grid_loss.csv").is_file()
    assert (tmp_path / "outputs" / "loss_summary.json").is_file()
