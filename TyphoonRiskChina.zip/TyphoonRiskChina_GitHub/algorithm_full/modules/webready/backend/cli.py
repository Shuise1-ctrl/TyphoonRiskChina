"""Command-line entry point used by scripts and future backend workers."""

import argparse
import json
import os
from pathlib import Path

os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")

from service import TyphoonDownscalingService


def default_bundle_root():
    return Path(__file__).absolute().parent.parent


def parse_args():
    bundle_root = default_bundle_root()
    parser = argparse.ArgumentParser(description="Typhoon downscaling compute CLI")
    parser.add_argument("--case", default="ID2612", help="Case id, e.g. ID2612")
    parser.add_argument(
        "--mode",
        choices=("check", "prediction", "fixed-grid", "full"),
        default="full",
    )
    parser.add_argument(
        "--runtime-root",
        default=os.environ.get(
            "TYPHOON_DOWNSCALING_ROOT", str(bundle_root / "runtime_data")
        ),
    )
    parser.add_argument(
        "--output-root",
        default=str(bundle_root / "outputs" / "ID2612"),
    )
    parser.add_argument(
        "--case-dir",
        default=None,
        help="Optional external IDxxxx directory containing FNL and the track workbook",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    service = TyphoonDownscalingService(args.runtime_root)

    if args.mode == "check":
        details = service.validate_runtime()
        serializable = {
            case_id: {
                "fnl_dir": str(info["fnl_dir"]),
                "fnl_count": info["fnl_count"],
                "track_file": str(info["track_file"]),
            }
            for case_id, info in details.items()
        }
        print(json.dumps(serializable, ensure_ascii=False, indent=2))
        return

    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)

    if args.mode == "prediction":
        print(service.run_prediction(args.case, output_root, case_dir=args.case_dir))
    elif args.mode == "fixed-grid":
        print(
            service.run_fixed_grid(
                args.case, output_root, show_plot=False, case_dir=args.case_dir
            )
        )
    else:
        result = service.run_case(
            args.case, output_root, show_plot=False, case_dir=args.case_dir
        )
        print(result)


if __name__ == "__main__":
    main()
