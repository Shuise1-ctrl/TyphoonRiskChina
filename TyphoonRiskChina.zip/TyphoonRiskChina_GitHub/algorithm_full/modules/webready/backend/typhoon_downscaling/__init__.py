# ============================================================
# typhoon_downscaling 对外接口
# ============================================================

__all__ = [
    "TyphoonDownscaler",
    "TyphoonResult",
    "run_typhoon",
    "run_typhoons",
]


def __getattr__(name):
    """按需加载 TensorFlow 相关接口，使路径检查不必提前导入模型依赖。"""
    if name in __all__:
        from . import api
        return getattr(api, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
