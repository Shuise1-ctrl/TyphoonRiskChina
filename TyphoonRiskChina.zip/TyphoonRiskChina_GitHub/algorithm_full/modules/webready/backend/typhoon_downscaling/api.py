# ============================================================
# 对外统一调用接口
# ============================================================

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .config import (
    MODEL_PATH,
    SCALER_X_PATH,
    SCALER_Y_PATH,
    TARGET_KM,
    VMIN,
    VMAX,
    create_case,
    validate_common_files,
)
from .core.model_loader import load_model_and_scalers
from .core.pipeline import run_prediction_pipeline
from .core.fixed_grid import extract_fixed_grid_max


@dataclass(frozen=True)
class TyphoonResult:
    typhoon_id: str
    prediction_nc: Path
    diagnostics_csv: Path
    fixed_grid_nc: Path
    fixed_grid_png: Path


class TyphoonDownscaler:
    """
    台风移动窗口降尺度统一接口。

    外部只需要调用：
        runner.run_prediction("ID2609")
        runner.run_fixed_grid("ID2609")
        runner.run_case("ID2609")
        runner.run_cases(["ID2609", "ID2612"])
    """

    def __init__(self):
        self.model = None
        self.scaler_x = None
        self.scaler_y = None

    def load(self):
        """加载公共模型和归一化器；多个台风连续运行时只加载一次。"""
        if self.model is None:
            validate_common_files()
            (
                self.model,
                self.scaler_x,
                self.scaler_y,
            ) = load_model_and_scalers(
                model_path=MODEL_PATH,
                scaler_x_path=SCALER_X_PATH,
                scaler_y_path=SCALER_Y_PATH,
            )
        return self

    def run_prediction(self, typhoon_id: str) -> Path:
        """只运行移动窗口风场预测。"""
        case = create_case(typhoon_id)
        self.load()

        run_prediction_pipeline(
            case=case,
            model=self.model,
            scaler_x=self.scaler_x,
            scaler_y=self.scaler_y,
        )
        return case.prediction_nc

    def run_fixed_grid(self, typhoon_id: str, show_plot=True) -> Path:
        """只将已有移动窗口NC转换为固定网格过程最大风速。"""
        case = create_case(typhoon_id)
        case.output_dir.mkdir(parents=True, exist_ok=True)

        if not case.prediction_nc.exists():
            raise FileNotFoundError(
                f"找不到移动窗口预测文件：{case.prediction_nc}\n"
                f"请先执行 runner.run_prediction('{case.typhoon_id}')。"
            )

        extract_fixed_grid_max(
            nc_file=case.prediction_nc,
            out_nc=case.fixed_grid_nc,
            out_png=case.fixed_grid_png,
            typhoon_id=case.typhoon_id,
            target_km=TARGET_KM,
            vmin=VMIN,
            vmax=VMAX,
            show_plot=show_plot,
        )
        return case.fixed_grid_nc

    def run_case(self, typhoon_id: str, show_plot=True) -> TyphoonResult:
        """依次完成单个台风的预测和固定网格最大风速提取。"""
        case = create_case(typhoon_id)
        self.run_prediction(case.typhoon_id)
        self.run_fixed_grid(case.typhoon_id, show_plot=show_plot)

        return TyphoonResult(
            typhoon_id=case.typhoon_id,
            prediction_nc=case.prediction_nc,
            diagnostics_csv=case.diagnostics_csv,
            fixed_grid_nc=case.fixed_grid_nc,
            fixed_grid_png=case.fixed_grid_png,
        )

    def run_cases(
        self,
        typhoon_ids: Iterable[str],
        show_plot=True,
        continue_on_error=False,
    ) -> dict[str, TyphoonResult]:
        """连续运行多个台风，模型和归一化器只加载一次。"""
        self.load()
        results = {}

        for typhoon_id in typhoon_ids:
            case = create_case(typhoon_id)
            print("\n" + "=" * 72)
            print(f"开始处理：{case.typhoon_id}")
            print("=" * 72)

            try:
                results[case.typhoon_id] = self.run_case(
                    case.typhoon_id,
                    show_plot=show_plot,
                )
            except Exception as exc:
                if not continue_on_error:
                    raise
                print(f"[ERROR] {case.typhoon_id} 运行失败：{exc}")

        return results


# ============================================================
# 函数式快捷接口
# ============================================================

def run_typhoon(typhoon_id: str, show_plot=True) -> TyphoonResult:
    """一行调用单个台风的完整流程。"""
    runner = TyphoonDownscaler()
    return runner.run_case(typhoon_id, show_plot=show_plot)


def run_typhoons(
    typhoon_ids: Iterable[str],
    show_plot=True,
    continue_on_error=False,
) -> dict[str, TyphoonResult]:
    """一行调用多个台风的完整流程。"""
    runner = TyphoonDownscaler()
    return runner.run_cases(
        typhoon_ids,
        show_plot=show_plot,
        continue_on_error=continue_on_error,
    )
