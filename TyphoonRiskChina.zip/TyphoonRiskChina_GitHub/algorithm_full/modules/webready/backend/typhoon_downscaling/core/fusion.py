# ============================================================
# 中心模型与外围粗风场融合、单风眼控制
# ============================================================

import numpy as np
from scipy.ndimage import gaussian_filter

from ..config import (
    H,
    W,
    LARGE_H,
    LARGE_W,
    CENTER_R0,
    CENTER_C0,
    CENTER_MODEL_MAX_WEIGHT,
    WEIGHT_SMOOTH_SIGMA,
    FINAL_MERGE_SMOOTH_SIGMA,
    EYE_RADIUS_CELLS,
    ANOMALY_SMOOTH_SIGMA,
    SUPPRESS_NEGATIVE_ANOMALY_OUTSIDE_EYE,
    COARSE_EYE_FILL_RADIUS_CELLS,
    COARSE_EYE_FILL_SIGMA,
)


# ============================================================
# 1. 中心模型融合权重
# ============================================================

def make_center_blend_weight():
    """
    构造中心模型区的椭圆型平滑权重。

    - 中心区域模型权重大；
    - 向外围逐渐降低；
    - 边缘接近0；
    - 外围采用粗分辨率背景风场。
    """
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)

    cy = (H - 1) / 2.0
    cx = (W - 1) / 2.0

    ry = (H - 1) / 2.0
    rx = (W - 1) / 2.0

    r = np.sqrt(
        ((yy - cy) / ry) ** 2 +
        ((xx - cx) / rx) ** 2
    )

    inner = 0.30
    outer = 0.95

    s = np.clip((r - inner) / (outer - inner), 0.0, 1.0)
    tile_weight = 0.5 * (1.0 + np.cos(np.pi * s))

    tile_weight[r <= inner] = 1.0
    tile_weight[r >= outer] = 0.0

    tile_weight = tile_weight * CENTER_MODEL_MAX_WEIGHT
    tile_weight = gaussian_filter(tile_weight, sigma=WEIGHT_SMOOTH_SIGMA)

    large_weight = np.zeros((LARGE_H, LARGE_W), dtype=np.float32)
    large_weight[
        CENTER_R0:CENTER_R0 + H,
        CENTER_C0:CENTER_C0 + W
    ] = tile_weight.astype(np.float32)

    return large_weight.astype(np.float32)


# ============================================================
# 2. 填平粗背景中的偏移低风速眼区
# ============================================================

def remove_coarse_eye_near_center(coarse_frame):
    """
    去除粗分辨率背景场中靠近台风中心的偏移低风速眼区。
    粗分辨率风场只作为大范围背景，真正风眼由中心模型控制。
    """
    yy, xx = np.mgrid[0:LARGE_H, 0:LARGE_W].astype(np.float32)

    cy = (LARGE_H - 1) / 2.0
    cx = (LARGE_W - 1) / 2.0

    dist = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)

    smooth_bg = gaussian_filter(
        coarse_frame,
        sigma=COARSE_EYE_FILL_SIGMA
    ).astype(np.float32)

    r = COARSE_EYE_FILL_RADIUS_CELLS
    s = np.clip(dist / r, 0.0, 1.0)

    fill_weight = 0.5 * (1.0 + np.cos(np.pi * s))
    fill_weight[dist >= r] = 0.0

    raised_bg = np.maximum(coarse_frame, smooth_bg)

    coarse_noeye = (
        fill_weight * raised_bg +
        (1.0 - fill_weight) * coarse_frame
    )

    return coarse_noeye.astype(np.float32)


# ============================================================
# 3. 中心模型 + 外围粗风场平滑融合
# ============================================================

def merge_center_model_with_outer_coarse(center_model, coarse_large):
    """
    1. 去除粗分辨率背景场中心附近的偏移风眼；
    2. 计算中心模型相对于粗背景的异常；
    3. 台风中心附近允许负异常，保留一个风眼；
    4. 台风中心以外只保留正异常，避免第二个低风速中心；
    5. 最终结果 = 去眼后的粗背景场 + 模型异常增强。
    """
    T = center_model.shape[0]

    blend_weight = make_center_blend_weight()

    final_large = np.zeros_like(coarse_large, dtype=np.float32)
    center_on_large = np.full_like(coarse_large, np.nan, dtype=np.float32)
    anomaly_on_large = np.zeros_like(coarse_large, dtype=np.float32)
    coarse_noeye_all = np.zeros_like(coarse_large, dtype=np.float32)

    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    cy = (H - 1) / 2.0
    cx = (W - 1) / 2.0
    dist_center = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
    allow_eye_center = dist_center <= EYE_RADIUS_CELLS

    yyL, xxL = np.mgrid[0:LARGE_H, 0:LARGE_W].astype(np.float32)
    cyL = CENTER_R0 + cy
    cxL = CENTER_C0 + cx
    dist_large = np.sqrt((yyL - cyL) ** 2 + (xxL - cxL) ** 2)
    allow_eye_large = dist_large <= (EYE_RADIUS_CELLS + 6)

    for t in range(T):
        coarse_raw = coarse_large[t].astype(np.float32)

        coarse_bg = remove_coarse_eye_near_center(coarse_raw)
        coarse_noeye_all[t] = coarse_bg.astype(np.float32)

        coarse_center = coarse_bg[
            CENTER_R0:CENTER_R0 + H,
            CENTER_C0:CENTER_C0 + W
        ].astype(np.float32)

        model_center = center_model[t].astype(np.float32)

        center_on_large[
            t,
            CENTER_R0:CENTER_R0 + H,
            CENTER_C0:CENTER_C0 + W
        ] = model_center

        model_anomaly = model_center - coarse_center

        if SUPPRESS_NEGATIVE_ANOMALY_OUTSIDE_EYE:
            model_anomaly_used = np.maximum(model_anomaly, 0.0)
            model_anomaly_used[allow_eye_center] = model_anomaly[allow_eye_center]
        else:
            model_anomaly_used = model_anomaly.copy()

        temp_anomaly_large = np.zeros((LARGE_H, LARGE_W), dtype=np.float32)
        temp_anomaly_large[
            CENTER_R0:CENTER_R0 + H,
            CENTER_C0:CENTER_C0 + W
        ] = model_anomaly_used.astype(np.float32)

        temp_anomaly_large = gaussian_filter(
            temp_anomaly_large,
            sigma=ANOMALY_SMOOTH_SIGMA
        ).astype(np.float32)

        if SUPPRESS_NEGATIVE_ANOMALY_OUTSIDE_EYE:
            neg_outside = (temp_anomaly_large < 0.0) & (~allow_eye_large)
            temp_anomaly_large[neg_outside] = 0.0

        anomaly_on_large[t] = temp_anomaly_large.astype(np.float32)

        final_t = coarse_bg + blend_weight * temp_anomaly_large
        final_t = np.maximum(final_t, 0.0)
        final_t = gaussian_filter(
            final_t,
            sigma=FINAL_MERGE_SMOOTH_SIGMA
        ).astype(np.float32)

        final_large[t] = final_t.astype(np.float32)

        print(
            f"融合 lead_idx={t:03d} | "
            f"center_max={np.nanmax(model_center):.2f} | "
            f"coarse_raw_max={np.nanmax(coarse_raw):.2f} | "
            f"coarse_noeye_max={np.nanmax(coarse_bg):.2f} | "
            f"anomaly_min={np.nanmin(temp_anomaly_large):.2f} | "
            f"anomaly_max={np.nanmax(temp_anomaly_large):.2f} | "
            f"final_large_max={np.nanmax(final_t):.2f}"
        )

    return (
        final_large.astype(np.float32),
        center_on_large.astype(np.float32),
        blend_weight.astype(np.float32),
        anomaly_on_large.astype(np.float32),
        coarse_noeye_all.astype(np.float32)
    )
