# -*- coding: utf-8 -*-
"""
Created on Sat Aug 22 19:56:53 2026

@author: Admin
"""

# ============================================================
# 台风全过程大范围轨迹合成风场
# Gaussian距离加权融合
#
# 注意：
# prediction.py保存到wind_speed_1h_max_pred中的风场已经完成
# 全过程分段低风速修正，因此本模块不再重复修改风速。
# ============================================================

from pathlib import Path
import json

import numpy as np
import pandas as pd
import xarray as xr

def _netcdf_kwargs():
    import os
    engine = os.environ.get("TYPHOON_NETCDF_ENGINE") or ("h5netcdf" if os.name == "nt" else None)
    return {"engine": engine} if engine else {}


import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection, PolyCollection

from scipy.interpolate import RegularGridInterpolator, griddata
from scipy.ndimage import gaussian_filter

from ..config import (
    TyphoonCase,
    TRACK_TARGET_KM,
    TRACK_BLEND_RADIUS_KM,
    TRACK_MAX_CENTER_DISTANCE_KM,
    TRACK_MIN_BLEND_WEIGHT,
    TRACK_ENABLE_FINAL_SMOOTH,
    TRACK_FINAL_SMOOTH_SIGMA,
    TRACK_VMIN,
    TRACK_VMAX,
    TRACK_SHOW_PATH,
    TRACK_POINT_EVERY_HOURS,
    TRACK_SHOW_LEAD_LABEL,
)


plt.rcParams["font.sans-serif"] = [
    "Microsoft YaHei",
    "SimHei",
    "Arial Unicode MS",
    "DejaVu Sans",
]
plt.rcParams["axes.unicode_minus"] = False


def _country_geometries():
    """Load simplified, unlabelled country outlines bundled with the UI."""
    path = Path(__file__).resolve().parents[6] / "frontend_source" / "public" / "maps" / "world-countries.geojson"
    if not path.exists():
        return [], []
    collection = json.loads(path.read_text(encoding="utf-8"))
    polygons = []
    outlines = []
    for feature in collection.get("features", []):
        geometry = feature.get("geometry") or {}
        kind = geometry.get("type")
        coordinates = geometry.get("coordinates") or []
        parts = [coordinates] if kind == "Polygon" else coordinates if kind == "MultiPolygon" else []
        for polygon in parts:
            if not polygon:
                continue
            exterior = polygon[0]
            if len(exterior) < 3:
                continue
            polygons.append(exterior)
            outlines.append(exterior)
    return polygons, outlines


def _draw_country_base(ax, polygons):
    ax.set_facecolor("#c6e2eb")
    if polygons:
        ax.add_collection(
            PolyCollection(
                polygons,
                facecolors="#e3ead8",
                edgecolors="none",
                linewidths=0,
                zorder=0,
            )
        )


def calculate_distance_squared(
    lon_grid,
    lat_grid,
    storm_lon,
    storm_lat,
):
    dy = (lat_grid - storm_lat) * 111.32

    dx = (
        (lon_grid - storm_lon)
        * 111.32
        * np.cos(np.deg2rad(storm_lat))
    )

    return dx ** 2 + dy ** 2


def interpolate_moving_field(
    xlon,
    xlat,
    field,
    target_lon,
    target_lat,
):
    lat_axis = np.nanmean(xlat, axis=1)
    lon_axis = np.nanmean(xlon, axis=0)

    lat_error = np.nanmax(
        np.abs(xlat - lat_axis[:, None])
    )
    lon_error = np.nanmax(
        np.abs(xlon - lon_axis[None, :])
    )

    if lat_error < 1e-4 and lon_error < 1e-4:
        field_use = field.copy()

        if lat_axis[0] > lat_axis[-1]:
            lat_axis = lat_axis[::-1]
            field_use = field_use[::-1, :]

        if lon_axis[0] > lon_axis[-1]:
            lon_axis = lon_axis[::-1]
            field_use = field_use[:, ::-1]

        interpolator = RegularGridInterpolator(
            (lat_axis, lon_axis),
            field_use,
            method="linear",
            bounds_error=False,
            fill_value=np.nan,
        )

        points = np.column_stack(
            (
                target_lat.ravel(),
                target_lon.ravel(),
            )
        )

        return interpolator(points).reshape(
            target_lon.shape
        )

    source_lon = xlon.ravel()
    source_lat = xlat.ravel()
    source_field = field.ravel()

    valid_source = (
        np.isfinite(source_lon)
        & np.isfinite(source_lat)
        & np.isfinite(source_field)
    )

    return griddata(
        (
            source_lon[valid_source],
            source_lat[valid_source],
        ),
        source_field[valid_source],
        (
            target_lon,
            target_lat,
        ),
        method="linear",
    )


def smooth_nan_field(
    field,
    sigma,
):
    valid = np.isfinite(field)

    values = np.where(
        valid,
        field,
        0.0,
    )

    weights = valid.astype(np.float32)

    smooth_values = gaussian_filter(
        values,
        sigma=sigma,
    )

    smooth_weights = gaussian_filter(
        weights,
        sigma=sigma,
    )

    output = np.full_like(
        field,
        np.nan,
        dtype=np.float32,
    )

    valid_output = smooth_weights > 0.05

    output[valid_output] = (
        smooth_values[valid_output]
        /
        smooth_weights[valid_output]
    )

    output[~valid] = np.nan

    return output.astype(np.float32)


def build_track_composite(
    case: TyphoonCase,
    show_plot: bool = False,
) -> dict[str, Path]:
    prediction_nc = Path(case.prediction_nc)
    output_nc = Path(case.track_composite_nc)
    output_png = Path(case.track_composite_png)

    if not prediction_nc.exists():
        raise FileNotFoundError(
            f"找不到移动窗口预测NC：\n{prediction_nc}"
        )

    output_nc.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    print("\n========== 台风全过程轨迹合成 ==========")
    print("输入NC：", prediction_nc)
    print("输出NC：", output_nc)
    print("输出PNG：", output_png)
    print(
        "注意：wind_speed_1h_max_pred已经完成分段低风速修正，"
        "本模块不再重复乘系数。"
    )

    ds = xr.open_dataset(prediction_nc, **_netcdf_kwargs())

    try:
        required = [
            "wind_speed_1h_max_pred",
            "XLAT",
            "XLONG",
            "storm_center_lat",
            "storm_center_lon",
            "time",
            "lead_hour",
        ]

        missing = [
            name
            for name in required
            if name not in ds
            and name not in ds.coords
        ]

        if missing:
            raise KeyError(
                "移动窗口NC缺少变量：\n"
                + "\n".join(missing)
            )

        wind = ds["wind_speed_1h_max_pred"]

        times = pd.DatetimeIndex(
            pd.to_datetime(ds["time"].values)
        )

        lead_hour = ds["lead_hour"].values.astype(float)
        center_lat = ds["storm_center_lat"].values.astype(float)
        center_lon = ds["storm_center_lon"].values.astype(float)

        ntime = len(times)

        # 全过程移动窗口覆盖范围
        global_lon_min = np.inf
        global_lon_max = -np.inf
        global_lat_min = np.inf
        global_lat_max = -np.inf

        for t in range(ntime):
            xlon = ds["XLONG"].isel(time=t).values
            xlat = ds["XLAT"].isel(time=t).values

            global_lon_min = min(
                global_lon_min,
                float(np.nanmin(xlon)),
            )
            global_lon_max = max(
                global_lon_max,
                float(np.nanmax(xlon)),
            )
            global_lat_min = min(
                global_lat_min,
                float(np.nanmin(xlat)),
            )
            global_lat_max = max(
                global_lat_max,
                float(np.nanmax(xlat)),
            )

        # 固定约3 km经纬网格
        dlat = TRACK_TARGET_KM / 111.32

        mean_lat = float(
            np.nanmean(center_lat)
        )

        cos_lat = np.cos(
            np.deg2rad(mean_lat)
        )

        if abs(cos_lat) < 1e-6:
            cos_lat = 1e-6

        dlon = (
            TRACK_TARGET_KM
            /
            (111.32 * cos_lat)
        )

        fixed_lat = np.arange(
            global_lat_min,
            global_lat_max + dlat,
            dlat,
        )

        fixed_lon = np.arange(
            global_lon_min,
            global_lon_max + dlon,
            dlon,
        )

        nlat = len(fixed_lat)
        nlon = len(fixed_lon)

        weighted_wind_sum = np.zeros(
            (nlat, nlon),
            dtype=np.float64,
        )

        weight_sum = np.zeros(
            (nlat, nlon),
            dtype=np.float64,
        )

        best_distance_squared = np.full(
            (nlat, nlon),
            np.inf,
            dtype=np.float32,
        )

        nearest_time_index = np.full(
            (nlat, nlon),
            -1,
            dtype=np.int32,
        )

        nearest_lead_hour = np.full(
            (nlat, nlon),
            np.nan,
            dtype=np.float32,
        )

        hourly_max = np.nanmax(
            wind.values,
            axis=(1, 2),
        ).astype(np.float32)

        hourly_mean = np.nanmean(
            wind.values,
            axis=(1, 2),
        ).astype(np.float32)

        # 逐小时插值 + Gaussian距离加权
        for t in range(ntime):
            xlon = ds["XLONG"].isel(time=t).values.astype(np.float64)
            xlat = ds["XLAT"].isel(time=t).values.astype(np.float64)

            # 不重复低风速修正
            field = wind.isel(time=t).values.astype(np.float32)

            lon_min = float(np.nanmin(xlon))
            lon_max = float(np.nanmax(xlon))
            lat_min = float(np.nanmin(xlat))
            lat_max = float(np.nanmax(xlat))

            col_start = max(
                0,
                int(np.searchsorted(
                    fixed_lon,
                    lon_min,
                    side="left",
                )),
            )

            col_end = min(
                nlon,
                int(np.searchsorted(
                    fixed_lon,
                    lon_max,
                    side="right",
                )),
            )

            row_start = max(
                0,
                int(np.searchsorted(
                    fixed_lat,
                    lat_min,
                    side="left",
                )),
            )

            row_end = min(
                nlat,
                int(np.searchsorted(
                    fixed_lat,
                    lat_max,
                    side="right",
                )),
            )

            if row_end <= row_start or col_end <= col_start:
                continue

            sub_lon_1d = fixed_lon[col_start:col_end]
            sub_lat_1d = fixed_lat[row_start:row_end]
            sub_lon, sub_lat = np.meshgrid(
                sub_lon_1d,
                sub_lat_1d,
            )

            interpolated_field = interpolate_moving_field(
                xlon=xlon,
                xlat=xlat,
                field=field,
                target_lon=sub_lon,
                target_lat=sub_lat,
            )

            distance_squared = calculate_distance_squared(
                lon_grid=sub_lon,
                lat_grid=sub_lat,
                storm_lon=center_lon[t],
                storm_lat=center_lat[t],
            )

            distance_km = np.sqrt(
                distance_squared
            )

            weight = np.exp(
                -0.5
                *
                (
                    distance_km
                    /
                    TRACK_BLEND_RADIUS_KM
                ) ** 2
            )

            valid = (
                np.isfinite(interpolated_field)
                &
                np.isfinite(weight)
            )

            if TRACK_MAX_CENTER_DISTANCE_KM is not None:
                valid &= (
                    distance_km
                    <=
                    TRACK_MAX_CENTER_DISTANCE_KM
                )

            valid &= (
                weight >= TRACK_MIN_BLEND_WEIGHT
            )

            weighted_sub = weighted_wind_sum[
                row_start:row_end,
                col_start:col_end,
            ]

            weight_sum_sub = weight_sum[
                row_start:row_end,
                col_start:col_end,
            ]

            weighted_sub[valid] += (
                interpolated_field[valid]
                *
                weight[valid]
            )

            weight_sum_sub[valid] += weight[valid]

            best_sub = best_distance_squared[
                row_start:row_end,
                col_start:col_end,
            ]

            nearest_mask = (
                valid
                &
                (distance_squared < best_sub)
            )

            best_sub[nearest_mask] = (
                distance_squared[nearest_mask]
            )

            time_sub = nearest_time_index[
                row_start:row_end,
                col_start:col_end,
            ]

            time_sub[nearest_mask] = t

            lead_sub = nearest_lead_hour[
                row_start:row_end,
                col_start:col_end,
            ]

            lead_sub[nearest_mask] = float(
                lead_hour[t]
            )

            if t % 12 == 0 or t == ntime - 1:
                print(
                    f"轨迹合成 {t + 1:03d}/{ntime:03d} | "
                    f"{times[t]} | "
                    f"lead={int(lead_hour[t]):03d} h | "
                    f"max={hourly_max[t]:.2f}"
                )

        # 最终合成
        track_wind = np.full(
            (nlat, nlon),
            np.nan,
            dtype=np.float32,
        )

        valid_total = weight_sum > 1e-8

        if not np.any(valid_total):
            raise RuntimeError(
                "轨迹合成结果没有有效格点。"
            )

        track_wind[valid_total] = (
            weighted_wind_sum[valid_total]
            /
            weight_sum[valid_total]
        ).astype(np.float32)

        nearest_center_distance_km = np.sqrt(
            best_distance_squared
        ).astype(np.float32)

        nearest_center_distance_km[
            ~valid_total
        ] = np.nan

        if TRACK_ENABLE_FINAL_SMOOTH:
            track_wind_final = smooth_nan_field(
                track_wind,
                TRACK_FINAL_SMOOTH_SIGMA,
            )
        else:
            track_wind_final = track_wind.copy()

        # 保存NC
        output_ds = xr.Dataset(
            data_vars={
                "track_composite_wind": (
                    ("lat", "lon"),
                    track_wind_final.astype(np.float32),
                ),
                "track_composite_wind_before_spatial_smooth": (
                    ("lat", "lon"),
                    track_wind.astype(np.float32),
                ),
                "weight_sum": (
                    ("lat", "lon"),
                    weight_sum.astype(np.float32),
                ),
                "nearest_time_index": (
                    ("lat", "lon"),
                    nearest_time_index.astype(np.int32),
                ),
                "nearest_lead_hour": (
                    ("lat", "lon"),
                    nearest_lead_hour.astype(np.float32),
                ),
                "nearest_center_distance_km": (
                    ("lat", "lon"),
                    nearest_center_distance_km.astype(np.float32),
                ),
                "storm_center_lat": (
                    ("time",),
                    center_lat.astype(np.float32),
                ),
                "storm_center_lon": (
                    ("time",),
                    center_lon.astype(np.float32),
                ),
                "hourly_field_max_wind": (
                    ("time",),
                    hourly_max.astype(np.float32),
                ),
                "hourly_field_mean_wind": (
                    ("time",),
                    hourly_mean.astype(np.float32),
                ),
            },
            coords={
                "lat": ("lat", fixed_lat.astype(np.float32)),
                "lon": ("lon", fixed_lon.astype(np.float32)),
                "time": ("time", times),
                "lead_hour": (
                    "time",
                    lead_hour.astype(np.int32),
                ),
            },
            attrs={
                "typhoon_id": case.typhoon_id,
                "target_resolution_km": float(TRACK_TARGET_KM),
                "track_blend_radius_km": float(TRACK_BLEND_RADIUS_KM),
                "max_center_distance_km": float(TRACK_MAX_CENTER_DISTANCE_KM),
                "method": (
                    "Gaussian storm-center-distance weighted "
                    "multi-time storm-track composite"
                ),
                "source_wind_variable": "wind_speed_1h_max_pred",
                "source_wind_note": (
                    "Source wind already contains prediction-stage "
                    "piecewise low-wind correction; no second correction "
                    "is applied in track_composite.py."
                ),
            },
        )

        output_ds[
            "track_composite_wind"
        ].attrs["units"] = "m s-1"

        if output_nc.exists():
            output_nc.unlink()

        output_ds.to_netcdf(
            output_nc, **_netcdf_kwargs()
        )
        output_ds.close()

        # 裁剪有效范围
        valid_plot = np.isfinite(
            track_wind_final
        )

        rows, cols = np.where(
            valid_plot
        )

        row_min = int(rows.min())
        row_max = int(rows.max()) + 1
        col_min = int(cols.min())
        col_max = int(cols.max()) + 1

        plot_wind = track_wind_final[
            row_min:row_max,
            col_min:col_max,
        ]

        plot_lat = fixed_lat[
            row_min:row_max
        ]

        plot_lon = fixed_lon[
            col_min:col_max
        ]

        # 绘图
        fig, ax = plt.subplots(
            figsize=(12, 8.3),
            dpi=180,
        )

        country_polygons, country_outlines = _country_geometries()
        _draw_country_base(ax, country_polygons)

        pcm = ax.pcolormesh(
            plot_lon,
            plot_lat,
            plot_wind,
            shading="auto",
            cmap="turbo",
            vmin=TRACK_VMIN,
            vmax=TRACK_VMAX,
            alpha=0.86,
            rasterized=True,
        )

        if country_outlines:
            ax.add_collection(
                LineCollection(
                    country_outlines,
                    colors="#84958b",
                    linewidths=0.45,
                    alpha=0.82,
                    zorder=5,
                )
            )

        if TRACK_SHOW_PATH:
            ax.plot(
                center_lon,
                center_lat,
                color="black",
                linewidth=1.35,
                alpha=0.85,
                zorder=10,
                label="Typhoon track",
            )

            label_index = 0
            for t in range(
                0,
                ntime,
                TRACK_POINT_EVERY_HOURS,
            ):
                ax.scatter(
                    center_lon[t],
                    center_lat[t],
                    s=24,
                    facecolor="white",
                    edgecolor="black",
                    linewidth=0.6,
                    zorder=12,
                )

                elapsed_hours = int(round(lead_hour[t] - lead_hour[0]))
                regular_time_label = t == 0 or (
                    elapsed_hours % 48 == 0 and ntime - t > 24
                )
                if TRACK_SHOW_LEAD_LABEL and (regular_time_label or t == ntime - 1):
                    label_offsets = [(8, 8), (-8, 8), (8, -11), (-8, -11)]
                    offset_x, offset_y = label_offsets[label_index % len(label_offsets)]
                    ax.annotate(
                        times[t].strftime("%m-%d %H:%M"),
                        xy=(center_lon[t], center_lat[t]),
                        xytext=(offset_x, offset_y),
                        textcoords="offset points",
                        fontsize=6.3,
                        color="#182326",
                        ha="left" if offset_x > 0 else "right",
                        va="bottom" if offset_y > 0 else "top",
                        bbox={"boxstyle": "round,pad=0.16", "facecolor": "white", "edgecolor": "none", "alpha": 0.78},
                        zorder=13,
                    )
                    label_index += 1

        ax.scatter(
            center_lon[0],
            center_lat[0],
            s=100,
            marker="o",
            facecolor="limegreen",
            edgecolor="black",
            linewidth=0.8,
            zorder=20,
            label="Start",
        )

        ax.scatter(
            center_lon[-1],
            center_lat[-1],
            s=140,
            marker="*",
            facecolor="red",
            edgecolor="black",
            linewidth=0.8,
            zorder=20,
            label="End",
        )

        cbar = fig.colorbar(
            pcm,
            ax=ax,
            fraction=0.040,
            pad=0.025,
        )
        cbar.set_label(
            "Wind speed (m/s)"
        )

        ax.set_xlabel("Longitude")
        ax.set_ylabel("Latitude")
        ax.set_title(
            f"{case.typhoon_id} Storm-track Composite Wind Field\nTrack labels show source date and time"
        )

        ax.grid(
            True,
            linestyle="--",
            linewidth=0.45,
            alpha=0.25,
        )

        ax.legend(
            loc="best",
            fontsize=9,
            framealpha=0.90,
        )

        ax.set_xlim(
            float(plot_lon.min()),
            float(plot_lon.max()),
        )

        ax.set_ylim(
            float(plot_lat.min()),
            float(plot_lat.max()),
        )

        ax.set_aspect(
            "equal",
            adjustable="box",
        )

        fig.tight_layout(
            pad=0.4
        )

        fig.savefig(
            output_png,
            dpi=300,
            bbox_inches="tight",
            pad_inches=0.02,
        )

        if show_plot:
            plt.show()
        else:
            plt.close(fig)

        print("✅ 轨迹合成NC已保存：", output_nc)
        print("✅ 轨迹合成PNG已保存：", output_png)

        return {
            "nc": output_nc,
            "png": output_png,
        }

    finally:
        ds.close()
