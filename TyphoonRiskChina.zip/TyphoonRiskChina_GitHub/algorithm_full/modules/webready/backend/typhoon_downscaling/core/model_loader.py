# ============================================================
# 模型、损失函数、兼容层和归一化器读取
# ============================================================

from pathlib import Path

import joblib
import tensorflow as tf


# ============================================================
# 1. 模型损失函数与兼容层
# ============================================================

def huber_loss(y_true, y_pred, delta=1.0):
    error = y_true - y_pred
    return tf.where(
        tf.abs(error) <= delta,
        0.5 * tf.square(error),
        delta * (tf.abs(error) - 0.5 * delta)
    )


class CompatibleSeparableConv2D(tf.keras.layers.SeparableConv2D):
    def __init__(self, *args, **kwargs):
        kwargs.pop("groups", None)
        kwargs.pop("kernel_initializer", None)
        kwargs.pop("kernel_regularizer", None)
        kwargs.pop("kernel_constraint", None)
        super().__init__(*args, **kwargs)


class CompatibleConv2DTranspose(tf.keras.layers.Conv2DTranspose):
    def __init__(self, *args, **kwargs):
        kwargs.pop("groups", None)
        super().__init__(*args, **kwargs)


class CompatibleConv2D(tf.keras.layers.Conv2D):
    def __init__(self, *args, **kwargs):
        kwargs.pop("groups", None)
        super().__init__(*args, **kwargs)


# ============================================================
# 2. 读取模型和归一化器
# ============================================================

def load_model_and_scalers(model_path, scaler_x_path, scaler_y_path):
    model_path = Path(model_path)
    scaler_x_path = Path(scaler_x_path)
    scaler_y_path = Path(scaler_y_path)

    if not model_path.exists():
        raise FileNotFoundError(f"模型文件不存在：{model_path}")

    if not scaler_x_path.exists():
        raise FileNotFoundError(f"scaler_x.save 不存在：{scaler_x_path}")

    if not scaler_y_path.exists():
        raise FileNotFoundError(f"scaler_y.save 不存在：{scaler_y_path}")

    scaler_x = joblib.load(str(scaler_x_path))
    scaler_y = joblib.load(str(scaler_y_path))

    custom_objects = {
        "huber_loss": huber_loss,
        "SeparableConv2D": CompatibleSeparableConv2D,
        "Conv2DTranspose": CompatibleConv2DTranspose,
        "Conv2D": CompatibleConv2D
    }

    model = tf.keras.models.load_model(
        str(model_path),
        custom_objects=custom_objects,
        compile=False
    )

    print("[OK] 模型加载成功")
    print("[OK] 归一化器加载成功")

    return model, scaler_x, scaler_y
