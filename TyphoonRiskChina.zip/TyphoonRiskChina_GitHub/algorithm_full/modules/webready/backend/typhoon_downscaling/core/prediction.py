# ============================================================
# 模型预测、反归一化、后处理、逐小时汇总表和NetCDF保存
# ============================================================

import os

import numpy as np
import pandas as pd
import xarray as xr

def _netcdf_kwargs():
    engine = os.environ.get("TYPHOON_NETCDF_ENGINE") or ("h5netcdf" if os.name == "nt" else None)
    return {"engine": engine} if engine else {}



from ..config import (
    H,
    W,
    HIGH_RES_KM,
    LARGE_H,
    LARGE_W,
    CENTER_R0,
    CENTER_C0,
    BLEND_TAPER,
    CENTER_MODEL_MAX_WEIGHT,
    EYE_RADIUS_CELLS,
    ANOMALY_SMOOTH_SIGMA,
    SUPPRESS_NEGATIVE_ANOMALY_OUTSIDE_EYE,
    TRAIN_WIND_MAX,
    CLIP_X_SCALED,
    CLIP_Y_PRED,
    POST_CLIP_WIND,
    ENABLE_SOFT_CLIP_X,
    X_CLIP_MIN,
    X_CLIP_MAX,
    ENABLE_SPIKE_CLEAN,
    WIND_CORRECTION_FACTOR,
    SPIKE_CAP_A,
    SPIKE_CAP_B,
    SPIKE_MIN_CAP,
    SPIKE_MAX_CAP,
    ENABLE_CONTINUITY_POST,
    PRED_WEIGHT,
    COARSE_WEIGHT,
    SCALE_BATCH_SIZE,
    PREDICT_BATCH_SIZE,

    # 全过程分段低风速修正
    ENABLE_PIECEWISE_LOW_WIND_CORRECTION,
    LOW_WIND_THRESHOLD_1,
    LOW_WIND_FACTOR_1,
    LOW_WIND_THRESHOLD_2,
    LOW_WIND_FACTOR_2,
)
from .postprocess import (
    clean_unphysical_spikes,
    make_continuous_wind_field,
    apply_piecewise_low_wind_correction,
)
from .fusion import merge_center_model_with_outer_coarse


# ============================================================
# 1. 分批归一化函数
# ============================================================

def transform_X_in_batches(scaler_x, X_all, batch_size=32):
    n = X_all.shape[0]
    X_scaled = np.empty_like(X_all, dtype=np.float32)

    for i in range(0, n, batch_size):
        j = min(i + batch_size, n)
        batch = X_all[i:j].reshape(j - i, -1)

        scaled = scaler_x.transform(batch)
        scaled = scaled.astype(np.float32).reshape(X_all[i:j].shape)

        X_scaled[i:j] = scaled
        print(f"✅ 输入归一化 batch {i} ~ {j - 1} 完成")

    return X_scaled


# ============================================================
# 2. 预测并保存NetCDF
# ============================================================

def predict_and_save_nc(
    model,
    scaler_x,
    scaler_y,
    X_all,
    lat_center_all,
    lon_center_all,
    lat_large_all,
    lon_large_all,
    coarse_large_all,
    lead_hours_hourly,
    init_time_bjt,
    centers,
    output_nc,
    diagnostics_csv,
    typhoon_id,
):
    T = X_all.shape[0]
    output_nc = str(output_nc)
    diagnostics_csv = str(diagnostics_csv)

    print("输入数据形状:", X_all.shape)
    print("中心经纬度形状:", lat_center_all.shape, lon_center_all.shape)
    print("大范围经纬度形状:", lat_large_all.shape, lon_large_all.shape)
    print("大范围粗风场形状:", coarse_large_all.shape)

    # 1. 输入归一化
    X_scaled = transform_X_in_batches(
        scaler_x=scaler_x,
        X_all=X_all,
        batch_size=SCALE_BATCH_SIZE
    )

    print("输入归一化后最小值:", float(np.nanmin(X_scaled)))
    print("输入归一化后最大值:", float(np.nanmax(X_scaled)))
    print("输入归一化后小于0的数量:", int(np.sum(X_scaled < 0.0)))
    print("输入归一化后大于1的数量:", int(np.sum(X_scaled > 1.0)))

    if ENABLE_SOFT_CLIP_X:
        X_scaled = np.clip(X_scaled, X_CLIP_MIN, X_CLIP_MAX)
        print(f"⚠️ 已对输入归一化结果进行软裁剪：{X_CLIP_MIN} ~ {X_CLIP_MAX}")
    elif CLIP_X_SCALED:
        X_scaled = np.clip(X_scaled, 0.0, 1.0)
        print("⚠️ 已将输入归一化结果限制到 0~1")
    else:
        print("✅ 未限制输入归一化结果，保留模型原始输入")

    # 2. 模型预测
    print("✅ 输入归一化完成，开始模型预测")
    y_pred = model.predict(X_scaled, batch_size=PREDICT_BATCH_SIZE, verbose=1)
    y_pred = np.squeeze(y_pred)

    if y_pred.ndim != 3:
        raise ValueError(f"模型输出维度异常，当前 y_pred.shape = {y_pred.shape}")

    print("模型归一化输出最小值:", float(np.nanmin(y_pred)))
    print("模型归一化输出最大值:", float(np.nanmax(y_pred)))
    print("模型归一化输出小于0数量:", int(np.sum(y_pred < 0.0)))
    print("模型归一化输出大于1数量:", int(np.sum(y_pred > 1.0)))

    del X_scaled

    # 3. 反归一化
    y_pred_original = y_pred.copy()
    y_pred_used = y_pred.copy()

    if CLIP_Y_PRED:
        y_pred_used = np.clip(y_pred_used, 0.0, 1.0)
        print("⚠️ 已将模型归一化输出限制到 0~1")
    else:
        print("✅ 未限制模型归一化输出，保留原始预测")

    y_pred_raw_inv = scaler_y.inverse_transform(
        y_pred_original.reshape(T, -1)
    ).reshape(T, H, W)
    y_pred_raw_inv = np.maximum(y_pred_raw_inv, 0).astype(np.float32)

    y_pred_base_inv = scaler_y.inverse_transform(
        y_pred_used.reshape(T, -1)
    ).reshape(T, H, W)
    y_pred_base_inv = np.maximum(y_pred_base_inv, 0).astype(np.float32)

    print("原始反归一化最大风速:", float(np.nanmax(y_pred_raw_inv)))
    print("原始反归一化最小风速:", float(np.nanmin(y_pred_raw_inv)))
    print("原始反归一化平均风速:", float(np.nanmean(y_pred_raw_inv)))

    if POST_CLIP_WIND:
        y_pred_base_inv = np.clip(y_pred_base_inv, 0.0, TRAIN_WIND_MAX)
        print(f"⚠️ 已将最终预测风速限制到 0~{TRAIN_WIND_MAX} m/s")
    else:
        print("✅ 未将最终风速限制到0~35，保留强风预测")

    # 4. 爆点清理
    if ENABLE_SPIKE_CLEAN:
        y_center_clean, spike_mask, spike_caps = clean_unphysical_spikes(
            y_raw=y_pred_base_inv,
            centers=centers
        )
        print("✅ 已完成中心模型区非物理爆点清理")
    else:
        y_center_clean = y_pred_base_inv.copy()
        spike_mask = np.zeros_like(y_center_clean, dtype=np.uint8)
        spike_caps = np.full((T,), np.nan, dtype=np.float32)
        print("⚠️ 未开启爆点清理")

    y_spike_clean = y_center_clean.copy()

    # 5. 中心模型区连续化
    if ENABLE_CONTINUITY_POST:
        y_center_final = make_continuous_wind_field(
            y_spike_clean=y_spike_clean,
            X_all=X_all,
            centers=centers,
            spike_caps=spike_caps
        )
        print("✅ 已完成中心模型区风场连续化后处理")
    else:
        y_center_final = y_spike_clean.copy()
        print("⚠️ 未进行中心模型区风场连续化后处理")

    # 6. 中心模型 + 外围粗分辨率风场融合
    (
        y_large_final,
        y_center_on_large,
        blend_weight,
        model_anomaly_on_large,
        coarse_noeye_all,
    ) = merge_center_model_with_outer_coarse(
        center_model=y_center_final,
        coarse_large=coarse_large_all
    )

    print("✅ 已完成中心降尺度 + 外围粗风场融合")
    print("分段修正前大范围风场形状:", y_large_final.shape)
    print("分段修正前大范围最大风速:", float(np.nanmax(y_large_final)))
    print("分段修正前大范围最小风速:", float(np.nanmin(y_large_final)))
    print("分段修正前大范围平均风速:", float(np.nanmean(y_large_final)))

    # ============================================================
    # 7. 全过程分段低风速修正
    #
    # 规则由config.py统一控制：
    # 0 <= V < LOW_WIND_THRESHOLD_1
    #     -> × LOW_WIND_FACTOR_1
    #
    # LOW_WIND_THRESHOLD_1 <= V < LOW_WIND_THRESHOLD_2
    #     -> × LOW_WIND_FACTOR_2
    #
    # V >= LOW_WIND_THRESHOLD_2
    #     -> 不修正
    #
    # 当前设置：
    # 0~10 m/s  -> ×1.20
    # 10~20 m/s -> ×1.10
    # >=20 m/s  -> 不变
    #
    # 注意：
    # 这里修正的是已经完成“中心模型 + 外围粗场融合”的
    # 最终逐小时249×300大范围风场。
    # 因此后续：
    # - diagnostics_csv
    # - wind_speed_1h_max_pred
    # - fixed_grid最大风速结果
    # 都会自动使用修正后的结果。
    # ============================================================

    (
        y_large_final,
        low_wind_count_0_10,
        low_wind_count_10_20,
    ) = apply_piecewise_low_wind_correction(
        y_large_final
    )

    print("✅ 已完成全过程分段低风速修正")
    print("修正后最终大范围风场形状:", y_large_final.shape)
    print("修正后最终大范围最大风速:", float(np.nanmax(y_large_final)))
    print("修正后最终大范围最小风速:", float(np.nanmin(y_large_final)))
    print("修正后最终大范围平均风速:", float(np.nanmean(y_large_final)))

    # ============================================================
    # 8. 保存逐小时精简汇总表
    # ============================================================

    # 每个预报时效对应的北京时间。
    # 后续保存NetCDF的time坐标也继续使用这个变量。
    times_bjt = [
        pd.to_datetime(init_time_bjt) + pd.Timedelta(hours=int(h))
        for h in lead_hours_hourly
    ]

    # y_large_final就是最终保存到NC变量wind_speed_1h_max_pred中的风场。
    # 按每个时刻的全部south_north和west_east格点计算最大值、平均值。
    hourly_max = np.nanmax(
        y_large_final,
        axis=(1, 2)
    ).astype(np.float32)

    hourly_mean = np.nanmean(
        y_large_final,
        axis=(1, 2)
    ).astype(np.float32)

    # 只保留用户需要的5列，列顺序固定。
    summary_df = pd.DataFrame({
        "lead_time": pd.to_datetime(times_bjt).strftime("%Y.%m.%d %H:%M"),
        "center_lat": centers["center_lat"].values.astype(np.float32),
        "center_lon": centers["center_lon"].values.astype(np.float32),
        "pred_max_wind": hourly_max,
        "pred_mean_wind": hourly_mean,
    })

    summary_df.to_csv(
        diagnostics_csv,
        index=False,
        encoding="utf-8-sig"
    )

    print(f"✅ 逐小时风速汇总表已保存：{diagnostics_csv}")

    # ============================================================
    # 9. 保存NetCDF
    # ============================================================

    ds_out = xr.Dataset(
        data_vars={
            "wind_speed_1h_max_pred": (
                ("time", "south_north", "west_east"),
                y_large_final.astype(np.float32)
            ),
            "coarse_uv_large": (
                ("time", "south_north", "west_east"),
                coarse_large_all.astype(np.float32)
            ),
            "coarse_uv_large_noeye": (
                ("time", "south_north", "west_east"),
                coarse_noeye_all.astype(np.float32)
            ),
            "center_model_on_large": (
                ("time", "south_north", "west_east"),
                y_center_on_large.astype(np.float32)
            ),
            "model_anomaly_on_large": (
                ("time", "south_north", "west_east"),
                model_anomaly_on_large.astype(np.float32)
            ),
            "blend_weight": (
                ("south_north", "west_east"),
                blend_weight.astype(np.float32)
            ),
            "wind_speed_center_model": (
                ("time", "tile_south_north", "tile_west_east"),
                y_center_final.astype(np.float32)
            ),
            "wind_speed_center_model_spike_clean": (
                ("time", "tile_south_north", "tile_west_east"),
                y_spike_clean.astype(np.float32)
            ),
            "wind_speed_center_model_raw": (
                ("time", "tile_south_north", "tile_west_east"),
                y_pred_raw_inv.astype(np.float32)
            ),
            "coarse_uv_center_highres": (
                ("time", "tile_south_north", "tile_west_east"),
                X_all[..., 0].astype(np.float32)
            ),
            "spike_mask_center": (
                ("time", "tile_south_north", "tile_west_east"),
                spike_mask.astype(np.uint8)
            ),
            "spike_cap": (("time",), spike_caps.astype(np.float32)),

            # 每小时分段低风速修正格点数量
            "low_wind_0_10_corrected_count": (
                ("time",),
                low_wind_count_0_10.astype(np.int32)
            ),
            "low_wind_10_20_corrected_count": (
                ("time",),
                low_wind_count_10_20.astype(np.int32)
            ),

            "storm_center_lat": (
                ("time",), centers["center_lat"].values.astype(np.float32)
            ),
            "storm_center_lon": (
                ("time",), centers["center_lon"].values.astype(np.float32)
            ),
            "coarse_window_max_wind": (
                ("time",), centers["coarse_window_max_wind"].values.astype(np.float32)
            ),
            "coarse_window_mean_wind": (
                ("time",), centers["coarse_window_mean_wind"].values.astype(np.float32)
            ),
            "coarse_window_min_slp": (
                ("time",), centers["coarse_window_min_slp"].values.astype(np.float32)
            ),
            "coarse_window_mean_slp": (
                ("time",), centers["coarse_window_mean_slp"].values.astype(np.float32)
            ),
            "coarse_large_max_wind": (
                ("time",), centers["coarse_large_max_wind"].values.astype(np.float32)
            ),
            "coarse_large_mean_wind": (
                ("time",), centers["coarse_large_mean_wind"].values.astype(np.float32)
            )
        },
        coords={
            "time": pd.to_datetime(times_bjt),
            "lead_hour": ("time", lead_hours_hourly.astype(np.int32)),
            "XLAT": (
                ("time", "south_north", "west_east"),
                lat_large_all.astype(np.float32)
            ),
            "XLONG": (
                ("time", "south_north", "west_east"),
                lon_large_all.astype(np.float32)
            ),
            "XLAT_CENTER": (
                ("time", "tile_south_north", "tile_west_east"),
                lat_center_all.astype(np.float32)
            ),
            "XLONG_CENTER": (
                ("time", "tile_south_north", "tile_west_east"),
                lon_center_all.astype(np.float32)
            )
        },
        attrs={
            "description": (
                "Large-area wind field generated by center 3-km downscaled model "
                "plus outer coarse-resolution wind interpolation, followed by "
                "piecewise low-wind correction on the final hourly large-area field."
            ),
            "typhoon_id": typhoon_id,
            "time_zone": "Beijing Time, UTC+8",
            "method": (
                "outer coarse wind background plus center-model local anomaly enhancement "
                "followed by piecewise low-wind correction"
            ),
            "reason_for_change": "Avoid block artifacts and suppress double-eye artifacts caused by direct full-field blending.",
            "input_file_structure": "Global coarse-resolution files with levels: u10, v10, t2m, msl, r850",
            "input_temporal_resolution": "6-hourly coarse-resolution fields interpolated to hourly inputs",
            "track_usage": "Track file is only used for hourly storm-center latitude and longitude.",
            "wind_input_source": "Wind input is derived from coarse-resolution u10 and v10 in 006.nc to 168.nc.",
            "note": "This is a storm-centered moving large grid, not a fixed geographic grid.",
            "center_model_shape": f"{H} x {W}",
            "large_output_shape": f"{LARGE_H} x {LARGE_W}",
            "center_model_coverage_km": f"{H * HIGH_RES_KM:.1f} km x {W * HIGH_RES_KM:.1f} km",
            "large_output_coverage_km": f"{LARGE_H * HIGH_RES_KM:.1f} km x {LARGE_W * HIGH_RES_KM:.1f} km",
            "center_insert_row_col": f"{CENTER_R0}, {CENTER_C0}",
            "blend_taper_cells": str(BLEND_TAPER),
            "blend_taper_km": f"{BLEND_TAPER * HIGH_RES_KM:.1f} km",
            "topo_channel_note": "Neutral terrain and land-surface channels are used for moving-window prediction to avoid fixed-domain artifacts.",
            "soft_clip_x_scaled": f"{ENABLE_SOFT_CLIP_X}, range={X_CLIP_MIN} to {X_CLIP_MAX}",
            "wind_correction_factor": str(WIND_CORRECTION_FACTOR),
            "clip_x_scaled": str(CLIP_X_SCALED),
            "clip_y_pred": str(CLIP_Y_PRED),
            "post_clip_wind": str(POST_CLIP_WIND),
            "enable_spike_clean": str(ENABLE_SPIKE_CLEAN),
            "enable_continuity_post": str(ENABLE_CONTINUITY_POST),

            # 全过程分段低风速修正信息
            "piecewise_low_wind_correction_enabled": str(
                ENABLE_PIECEWISE_LOW_WIND_CORRECTION
            ),
            "low_wind_threshold_1_ms": float(LOW_WIND_THRESHOLD_1),
            "low_wind_factor_1": float(LOW_WIND_FACTOR_1),
            "low_wind_threshold_2_ms": float(LOW_WIND_THRESHOLD_2),
            "low_wind_factor_2": float(LOW_WIND_FACTOR_2),
            "piecewise_low_wind_correction_method": (
                f"0 <= V < {LOW_WIND_THRESHOLD_1} m/s: "
                f"V = V * {LOW_WIND_FACTOR_1}; "
                f"{LOW_WIND_THRESHOLD_1} <= V < "
                f"{LOW_WIND_THRESHOLD_2} m/s: "
                f"V = V * {LOW_WIND_FACTOR_2}; "
                f"V >= {LOW_WIND_THRESHOLD_2} m/s: unchanged."
            ),

            "spike_cap_formula": f"cap = clip({SPIKE_CAP_A} * coarse_window_max_wind + {SPIKE_CAP_B}, {SPIKE_MIN_CAP}, {SPIKE_MAX_CAP})",
            "spike_clean_method": "Values larger than hourly dynamic spike_cap are replaced by local median filter values.",
            "continuity_post_method": "Median filter + Gaussian smoothing + blending with high-resolution interpolated coarse wind in center model window.",
            "double_eye_suppression": "Final field = coarse_large + blend_weight * model_anomaly; negative model anomalies are allowed only within the eye radius around the storm center.",
            "bad_file_handling": "Unreadable FNL files are skipped and missing lead hours are obtained by interpolation."
        }
    )

    ds_out["wind_speed_1h_max_pred"].attrs["units"] = "m s-1"
    ds_out["wind_speed_1h_max_pred"].attrs["long_name"] = (
        "Final large-area wind speed after center/outer fusion and piecewise low-wind correction"
    )
    ds_out["coarse_uv_large"].attrs["units"] = "m s-1"
    ds_out["coarse_uv_large"].attrs["long_name"] = (
        "Large-area coarse-resolution wind speed interpolated to 3-km grid"
    )
    ds_out["coarse_uv_large_noeye"].attrs["units"] = "m s-1"
    ds_out["coarse_uv_large_noeye"].attrs["long_name"] = (
        "Large-area coarse wind background after filling offset low-wind eye near storm center"
    )
    ds_out["center_model_on_large"].attrs["units"] = "m s-1"
    ds_out["model_anomaly_on_large"].attrs["units"] = "m s-1"
    ds_out["model_anomaly_on_large"].attrs["long_name"] = (
        "Effective model anomaly added to the large-area coarse wind background"
    )
    ds_out["blend_weight"].attrs["long_name"] = "Weight of center model in final blending"
    ds_out["wind_speed_center_model"].attrs["units"] = "m s-1"
    ds_out["wind_speed_center_model_raw"].attrs["units"] = "m s-1"
    ds_out["coarse_uv_center_highres"].attrs["units"] = "m s-1"
    ds_out["spike_cap"].attrs["units"] = "m s-1"

    ds_out["low_wind_0_10_corrected_count"].attrs["long_name"] = (
        "Number of grid cells corrected in the first low-wind interval"
    )
    ds_out["low_wind_0_10_corrected_count"].attrs["units"] = "grid cells"

    ds_out["low_wind_10_20_corrected_count"].attrs["long_name"] = (
        "Number of grid cells corrected in the second low-wind interval"
    )
    ds_out["low_wind_10_20_corrected_count"].attrs["units"] = "grid cells"

    ds_out["storm_center_lat"].attrs["units"] = "degrees_north"
    ds_out["storm_center_lon"].attrs["units"] = "degrees_east"
    ds_out["coarse_window_max_wind"].attrs["units"] = "m s-1"
    ds_out["coarse_window_mean_wind"].attrs["units"] = "m s-1"
    ds_out["coarse_window_min_slp"].attrs["units"] = "hPa"
    ds_out["coarse_window_mean_slp"].attrs["units"] = "hPa"
    ds_out["coarse_large_max_wind"].attrs["units"] = "m s-1"
    ds_out["coarse_large_mean_wind"].attrs["units"] = "m s-1"

    if os.path.exists(output_nc):
        try:
            os.remove(output_nc)
            print(f"✅ 已删除旧NC文件：{output_nc}")
        except PermissionError as exc:
            raise PermissionError(
                f"无法删除旧NC文件，可能正在被Spyder或其他程序打开：{output_nc}\n"
                f"请先关闭该NC文件，再重新运行。"
            ) from exc

    ds_out.to_netcdf(output_nc, **_netcdf_kwargs())

    print(f"✅ 预测NC文件已保存：{output_nc}")
    print("输出大范围风速形状:", y_large_final.shape)
    print("最终大范围最大风速:", float(np.nanmax(y_large_final)))
    print("最终大范围最小风速:", float(np.nanmin(y_large_final)))
    print("最终大范围平均风速:", float(np.nanmean(y_large_final)))
    print("中心模型最大风速:", float(np.nanmax(y_center_final)))
    print("外围粗风场最大风速:", float(np.nanmax(coarse_large_all)))
    print("爆点总数量:", int(np.sum(spike_mask)))
    print(
        f"全过程0~{LOW_WIND_THRESHOLD_1:.1f} m/s修正格点总数:",
        int(np.sum(low_wind_count_0_10))
    )
    print(
        f"全过程{LOW_WIND_THRESHOLD_1:.1f}~"
        f"{LOW_WIND_THRESHOLD_2:.1f} m/s修正格点总数:",
        int(np.sum(low_wind_count_10_20))
    )

    return ds_out