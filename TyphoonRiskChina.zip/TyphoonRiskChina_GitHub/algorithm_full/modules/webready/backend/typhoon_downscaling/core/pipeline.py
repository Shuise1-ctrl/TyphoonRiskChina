# ============================================================
# 单个台风移动窗口预测完整流程
# ============================================================

import numpy as np

from ..config import (
    TOPO_FILE,
    WIND_CORRECTION_FACTOR,
    CLIP_X_SCALED,
    CLIP_Y_PRED,
    POST_CLIP_WIND,
    ENABLE_SOFT_CLIP_X,
    X_CLIP_MIN,
    X_CLIP_MAX,
    ENABLE_SPIKE_CLEAN,
    SPIKE_CAP_A,
    SPIKE_CAP_B,
    SPIKE_MIN_CAP,
    SPIKE_MAX_CAP,
    ENABLE_CONTINUITY_POST,
    PRED_WEIGHT,
    COARSE_WEIGHT,
    H,
    W,
    LARGE_H,
    LARGE_W,
    CENTER_R0,
    CENTER_C0,
    BLEND_TAPER,
    CENTER_MODEL_MAX_WEIGHT,
    EYE_RADIUS_CELLS,
    ANOMALY_SMOOTH_SIGMA,
    SUPPRESS_NEGATIVE_ANOMALY_OUTSIDE_EYE,
    HIGH_RES_KM,
    TyphoonCase,
    validate_case_files,
)
from .data_reader import (
    get_init_time_bjt_from_first_file,
    open_global_fnl_dataset,
    read_typhoon_path,
    make_path_interpolators,
)
from .feature_builder import load_fixed_topo_channels, build_hourly_inputs
from .prediction import predict_and_save_nc


def run_prediction_pipeline(case: TyphoonCase, model, scaler_x, scaler_y):
    """运行单个台风的完整移动窗口预测流程。"""
    validate_case_files(case)
    case.output_dir.mkdir(parents=True, exist_ok=True)

    print("========== 台风算例 ==========")
    print("TYPHOON_ID =", case.typhoon_id)
    print("CASE_DIR =", case.case_dir)
    print("FNL_DIR =", case.fnl_dir)
    print("PATH_FILE =", case.track_file)
    print("OUT_DIR =", case.output_dir)

    print("\n========== 参数检查 ==========")
    print("WIND_CORRECTION_FACTOR =", WIND_CORRECTION_FACTOR)
    print("CLIP_X_SCALED =", CLIP_X_SCALED)
    print("CLIP_Y_PRED =", CLIP_Y_PRED)
    print("POST_CLIP_WIND =", POST_CLIP_WIND)
    print("ENABLE_SOFT_CLIP_X =", ENABLE_SOFT_CLIP_X)
    print("X_CLIP_MIN =", X_CLIP_MIN)
    print("X_CLIP_MAX =", X_CLIP_MAX)
    print("ENABLE_SPIKE_CLEAN =", ENABLE_SPIKE_CLEAN)
    print("SPIKE_CAP_A =", SPIKE_CAP_A)
    print("SPIKE_CAP_B =", SPIKE_CAP_B)
    print("SPIKE_MIN_CAP =", SPIKE_MIN_CAP)
    print("SPIKE_MAX_CAP =", SPIKE_MAX_CAP)
    print("ENABLE_CONTINUITY_POST =", ENABLE_CONTINUITY_POST)
    print("PRED_WEIGHT =", PRED_WEIGHT)
    print("COARSE_WEIGHT =", COARSE_WEIGHT)
    print("CENTER WINDOW =", H, "x", W)
    print("LARGE OUTPUT =", LARGE_H, "x", LARGE_W)
    print("CENTER_R0, CENTER_C0 =", CENTER_R0, CENTER_C0)
    print("BLEND_TAPER =", BLEND_TAPER)
    print("CENTER_MODEL_MAX_WEIGHT =", CENTER_MODEL_MAX_WEIGHT)
    print("EYE_RADIUS_CELLS =", EYE_RADIUS_CELLS)
    print("ANOMALY_SMOOTH_SIGMA =", ANOMALY_SMOOTH_SIGMA)
    print("SUPPRESS_NEGATIVE_ANOMALY_OUTSIDE_EYE =", SUPPRESS_NEGATIVE_ANOMALY_OUTSIDE_EYE)
    print("中心模型覆盖范围约:", H * HIGH_RES_KM, "km ×", W * HIGH_RES_KM, "km")
    print("最终大范围覆盖范围约:", LARGE_H * HIGH_RES_KM, "km ×", LARGE_W * HIGH_RES_KM, "km")
    print("OUT_NC =", case.prediction_nc)
    print("DIAG_CSV =", case.diagnostics_csv)

    print("\n========== 1. 加载中性地形通道 ==========")
    topo_channels = load_fixed_topo_channels(TOPO_FILE)

    print("\n========== 2. 读取FNL全球粗分辨率数据 ==========")
    init_time_bjt = get_init_time_bjt_from_first_file(case.fnl_dir)
    ds_all, lead_hours_6h = open_global_fnl_dataset(case.fnl_dir)

    try:
        first_lead = int(np.min(lead_hours_6h))
        last_lead = int(np.max(lead_hours_6h))

        print("\n========== 3. 读取工作路径，只使用台风中心经纬度 ==========")
        path_df = read_typhoon_path(case.track_file, init_time_bjt)
        path_funcs = make_path_interpolators(path_df)

        print("\n========== 4. 生成每小时时效 ==========")
        lead_hours_hourly = np.arange(first_lead, last_lead + 1, 1)

        print("每小时预测范围:", lead_hours_hourly[0], "到", lead_hours_hourly[-1])
        print("总时次数:", len(lead_hours_hourly))

        print("\n========== 5. 构造中心模型输入和外围粗风场 ==========")
        (
            X_all,
            lat_center_all,
            lon_center_all,
            lat_large_all,
            lon_large_all,
            coarse_large_all,
            centers,
        ) = build_hourly_inputs(
            ds_all=ds_all,
            lead_hours_hourly=lead_hours_hourly,
            path_funcs=path_funcs,
            topo_channels=topo_channels
        )

        print("\n========== 6. 模型预测、融合并保存NC ==========")
        ds_out = predict_and_save_nc(
            model=model,
            scaler_x=scaler_x,
            scaler_y=scaler_y,
            X_all=X_all,
            lat_center_all=lat_center_all,
            lon_center_all=lon_center_all,
            lat_large_all=lat_large_all,
            lon_large_all=lon_large_all,
            coarse_large_all=coarse_large_all,
            lead_hours_hourly=lead_hours_hourly,
            init_time_bjt=init_time_bjt,
            centers=centers,
            output_nc=case.prediction_nc,
            diagnostics_csv=case.diagnostics_csv,
            typhoon_id=case.typhoon_id,
        )

        print("\n========== 7. 输出文件信息 ==========")
        print(ds_out)
        ds_out.close()

    finally:
        ds_all.close()

    return case.prediction_nc
