# ============================================================
# FNL数据、起报时间和台风路径读取
# ============================================================

import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import xarray as xr
from scipy.interpolate import interp1d

from typhoonriskchina.downscaling import canonical_level_labels

# 正常通过 typhoon_downscaling 包导入时，使用相对导入。
# 在 Spyder 中直接运行本文件时，自动补充工程根目录后使用绝对导入。
try:
    from ..config import (
        create_case,
        discover_fnl_files,
        extract_fnl_lead_hour,
    )
except ImportError as exc:
    if __package__ not in (None, ""):
        raise

    project_dir = Path(__file__).resolve().parents[2]
    project_dir_text = str(project_dir)

    if project_dir_text not in sys.path:
        sys.path.insert(0, project_dir_text)

    try:
        from typhoon_downscaling.config import (
            create_case,
            discover_fnl_files,
            extract_fnl_lead_hour,
        )
    except ImportError as second_exc:
        raise ImportError(
            "无法导入 typhoon_downscaling.config。"
            f"\n已尝试加入工程目录：{project_dir_text}"
            "\n请确认 data_reader.py 位于："
            "typhoon_downscaling/core/data_reader.py"
        ) from second_exc


def open_fnl_dataset(file_path):
    """Open an external FNL file with a Windows-safe backend.

    Repeated reads through netCDF4 1.7.4 can terminate native Windows Python
    with BEX64/c0000409 before a Python exception can be recorded.  h5netcdf
    reads the same NetCDF4/HDF5 inputs without changing values or dimensions.
    Linux keeps xarray's original default unless explicitly overridden.
    """
    engine = os.environ.get("TYPHOON_FNL_XARRAY_ENGINE") or os.environ.get(
        "TYPHOON_NETCDF_ENGINE"
    )
    if not engine and os.name == "nt":
        engine = "h5netcdf"
    if engine:
        return xr.open_dataset(file_path, engine=engine)
    return xr.open_dataset(file_path)


# ============================================================
# 1. 文件时效与北京时间
# ============================================================

def extract_lead_hour(file_path):
    """保留原函数名，对外统一调用新的稳健时效提取函数。"""
    return extract_fnl_lead_hour(file_path)


def get_init_time_bjt_from_first_file(fnl_dir):
    files = discover_fnl_files(fnl_dir)

    if not files:
        raise FileNotFoundError(f"没有找到 FNL 文件: {fnl_dir}")

    first_file = files[0]
    first_lead = extract_lead_hour(first_file)

    with open_fnl_dataset(first_file) as ds:
        init_time_utc = pd.to_datetime(ds["time"].values[0])

    init_time_bjt = init_time_utc + pd.Timedelta(hours=8)

    print("[OK] FNL文件搜索根目录:", fnl_dir)
    print("[OK] 实际发现FNL文件数:", len(files))
    print("[OK] 第一个FNL文件:", first_file)
    print("[OK] 最后一个FNL文件:", files[-1])
    print("[OK] UTC起报时间:", init_time_utc)
    print("[OK] 北京时间起报时间:", init_time_bjt)
    print(f"[OK] {first_lead:03d}.nc 对应北京时间:",
          init_time_bjt + pd.Timedelta(hours=first_lead))

    return init_time_bjt


# ============================================================
# 2. 读取单个全球文件，提取模型需要变量
# ============================================================

def convert_one_file_to_dataset(file_path):
    """
    文件结构：__xarray_dataarray_variable__(time, step, level, lat, lon)
    提取：u10, v10, t2m, msl, r850
    输出：uv, rh, slp, t2m
    """
    ds = open_fnl_dataset(file_path)

    try:
        da = ds["__xarray_dataarray_variable__"]
        da = da.isel(time=0, step=0)

        # FuXi initial states from different preprocessing versions may label
        # the same channels as either r850/u10 or R850.0/U10. Normalize only
        # coordinate labels; meteorological values and channel order are not
        # modified.
        da = da.assign_coords(level=canonical_level_labels(da["level"].values))
        required_levels = {"u10", "v10", "t2m", "msl", "r850"}
        missing_levels = sorted(required_levels.difference(str(v) for v in da["level"].values))
        if missing_levels:
            raise ValueError(
                "FuXi file is missing required normalized channels: "
                + ", ".join(missing_levels)
            )

        u10 = da.sel(level="u10").drop_vars("level")
        v10 = da.sel(level="v10").drop_vars("level")
        t2m = da.sel(level="t2m").drop_vars("level")
        msl = da.sel(level="msl").drop_vars("level")
        rh = da.sel(level="r850").drop_vars("level")

        uv = np.sqrt(u10 ** 2 + v10 ** 2)

        if float(msl.mean()) > 2000:
            msl = msl / 100.0

        ds_out = xr.Dataset(
            data_vars={
                "uv": uv.astype(np.float32),
                "rh": rh.astype(np.float32),
                "slp": msl.astype(np.float32),
                "t2m": t2m.astype(np.float32)
            },
            coords={
                "lat": ds["lat"],
                "lon": ds["lon"]
            }
        )
        ds_out = ds_out.load()

    finally:
        ds.close()

    return ds_out


# ============================================================
# 3. 批量读取全部NC文件
# ============================================================

def open_global_fnl_dataset(fnl_dir):
    files = discover_fnl_files(fnl_dir)

    if not files:
        raise FileNotFoundError(f"没有找到 nc 文件: {fnl_dir}")

    print("[OK] 将读取以下FNL文件：")
    for path in files:
        print(f"   lead={extract_lead_hour(path):03d} | {path}")

    ds_list = []
    lead_hours = []
    bad_files = []

    for f in files:
        lead = extract_lead_hour(f)
        print(f"正在读取 {os.path.basename(f)} | lead_hour = {lead}")

        try:
            ds_one = convert_one_file_to_dataset(f)
            ds_one = ds_one.expand_dims(lead_hour=[lead])

            ds_list.append(ds_one)
            lead_hours.append(lead)
            print(f"[OK] 读取成功：{os.path.basename(f)}")

        except Exception as e:
            print(f"[ERROR] 读取失败，已跳过：{os.path.basename(f)}")
            print(f"   完整路径：{f}")
            print(f"   错误信息：{e}")
            bad_files.append(f)
            continue

    if len(ds_list) == 0:
        raise RuntimeError("所有 nc 文件都读取失败，无法继续预测。")

    ds_all = xr.concat(ds_list, dim="lead_hour")

    if ds_all["lat"].values[0] > ds_all["lat"].values[-1]:
        ds_all = ds_all.sortby("lat")

    ds_all = ds_all.sortby("lon")
    lead_hours = np.array(lead_hours)

    print("\n[OK] 全球粗分辨率数据读取完成")
    print("成功读取文件数：", len(ds_list))
    print("成功读取时效：", lead_hours)

    if bad_files:
        print("\n[WARN] 以下文件读取失败，已跳过：")
        for f in bad_files:
            print("   ", f)
        print("[WARN] 缺失时效会由前后正常时效线性插值得到。")
        print("[WARN] 正式结果建议重新下载坏文件。")

    print(ds_all)
    return ds_all, lead_hours


# ============================================================
# 4. 读取台风路径，只使用台风中心经纬度
# ============================================================

def read_typhoon_path(path_file, init_time_bjt):
    path_file = str(path_file)
    if not os.path.exists(path_file):
        raise FileNotFoundError(f"路径文件不存在：{path_file}")

    path_df = pd.read_excel(path_file)

    print("[OK] 路径文件原始列名:")
    print(list(path_df.columns))

    rename_dict = {}
    for col in path_df.columns:
        c = str(col).strip()

        if c.lower() in ["time", "datetime", "时间", "日期"]:
            rename_dict[col] = "time"
        elif c.lower() in ["lat", "latitude", "纬度"]:
            rename_dict[col] = "LAT"
        elif c.lower() in ["lon", "long", "longitude", "经度"]:
            rename_dict[col] = "LONG"

    path_df = path_df.rename(columns=rename_dict)

    if not all(c in path_df.columns for c in ["time", "LAT", "LONG"]):
        if path_df.shape[1] >= 4:
            temp = path_df.copy()
            if temp.shape[1] >= 6:
                temp = temp.iloc[:, :6]
                temp.columns = ["time", "strength", "LAT", "LONG", "slp", "uv"]
            else:
                temp = temp.iloc[:, :4]
                temp.columns = ["time", "strength", "LAT", "LONG"]
            path_df = temp

    required = ["time", "LAT", "LONG"]
    for r in required:
        if r not in path_df.columns:
            raise KeyError(
                f"路径文件缺少列 {r}，当前列名为: {list(path_df.columns)}\n"
                f"请检查 Excel 中是否有 time/LAT/LONG 或对应中文列名。"
            )

    path_df["datetime_bjt"] = pd.to_datetime(
        path_df["time"].astype(str).str.replace("：", ":"),
        errors="coerce"
    )

    path_df = path_df.dropna(subset=["datetime_bjt", "LAT", "LONG"])

    path_df["lead_hour"] = (
        path_df["datetime_bjt"] - pd.to_datetime(init_time_bjt)
    ).dt.total_seconds() / 3600.0

    path_df = path_df.sort_values("lead_hour")

    print("[OK] 路径文件读取完成，只使用台风中心经纬度")
    print("路径前5行：")
    print(path_df[["datetime_bjt", "lead_hour", "LAT", "LONG"]].head())

    print("路径后5行：")
    print(path_df[["datetime_bjt", "lead_hour", "LAT", "LONG"]].tail())

    if path_df["lead_hour"].min() > 6 or path_df["lead_hour"].max() < 168:
        print("\n[WARN] 注意：路径文件 lead_hour 范围可能没有覆盖 006 到 168。")
        print("当前路径 lead_hour 范围：",
              path_df["lead_hour"].min(), "到", path_df["lead_hour"].max())

    return path_df


def make_path_interpolators(path_df):
    x = path_df["lead_hour"].values.astype(float)

    funcs = {}
    for col in ["LAT", "LONG"]:
        y = path_df[col].values.astype(float)
        funcs[col] = interp1d(
            x,
            y,
            kind="linear",
            bounds_error=False,
            fill_value="extrapolate"
        )

    return funcs


# ============================================================
# 5. 直接运行本文件时的读取检查
# ============================================================

def _direct_run_check():
    """
    仅用于在 Spyder 中直接运行 data_reader.py 时检查文件发现结果。
    正常预测仍应从工程根目录 main.py 或 TyphoonDownscaler 调用。
    """
    print("=" * 72)
    print("data_reader.py 直接运行检查")
    print("本文件：", Path(__file__).resolve())
    print("工程目录：", Path(__file__).resolve().parents[2])
    print("=" * 72)

    for typhoon_id in ("ID2609", "ID2612"):
        case = create_case(typhoon_id)
        files = discover_fnl_files(case.fnl_dir)

        print(f"\n{typhoon_id}")
        print("FNL搜索目录：", case.fnl_dir)
        print("发现文件数：", len(files))

        if files:
            leads = [extract_lead_hour(path) for path in files]
            print("发现时效：", leads)
            print("第一个文件：", files[0])
            print("最后一个文件：", files[-1])
        else:
            print("[ERROR] 未发现可用FNL文件")

    print("\n[OK] data_reader 模块导入正常。")
    print("正式运行请执行工程根目录 main.py，而不是单独运行core模块。")


if __name__ == "__main__":
    _direct_run_check()
