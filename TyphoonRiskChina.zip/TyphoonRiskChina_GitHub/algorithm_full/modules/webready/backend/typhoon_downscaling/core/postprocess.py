# ============================================================
# 中心模型结果爆点清理、连续化后处理和全过程分段低风速修正
# ============================================================

import numpy as np
from scipy.ndimage import median_filter, gaussian_filter

from ..config import (
    SPIKE_CAP_A,
    SPIKE_CAP_B,
    SPIKE_MIN_CAP,
    SPIKE_MAX_CAP,
    MEDIAN_FILTER_SIZE,
    PRED_MEDIAN_SIZE,
    PRED_GAUSSIAN_SIGMA,
    COARSE_GAUSSIAN_SIGMA,
    FINAL_GAUSSIAN_SIGMA,
    PRED_WEIGHT,
    COARSE_WEIGHT,

    # 全过程分段低风速修正
    ENABLE_PIECEWISE_LOW_WIND_CORRECTION,
    LOW_WIND_THRESHOLD_1,
    LOW_WIND_FACTOR_1,
    LOW_WIND_THRESHOLD_2,
    LOW_WIND_FACTOR_2,
)


# ============================================================
# 1. 爆点清理函数
# ============================================================

def clean_unphysical_spikes(y_raw, centers):
    """
    只清理中心模型结果中的明显非物理异常爆点，
    不对整个风场进行统一限幅。
    """

    y_clean = y_raw.copy().astype(np.float32)

    spike_mask = np.zeros_like(
        y_clean,
        dtype=np.uint8
    )

    spike_caps = []

    T = y_clean.shape[0]


    for t in range(T):

        coarse_max = float(
            centers.iloc[t]["coarse_window_max_wind"]
        )


        # ----------------------------------------------------
        # 当前时刻允许的最大风速上限
        # ----------------------------------------------------

        cap = (
            SPIKE_CAP_A
            *
            coarse_max
            +
            SPIKE_CAP_B
        )


        cap = float(
            np.clip(
                cap,
                SPIKE_MIN_CAP,
                SPIKE_MAX_CAP
            )
        )


        spike_caps.append(
            cap
        )


        # ----------------------------------------------------
        # 当前小时中心模型风场
        # ----------------------------------------------------

        frame = y_clean[t].copy()


        # 超过cap的异常点
        bad = (
            frame
            >
            cap
        )


        bad_count = int(
            np.sum(
                bad
            )
        )


        # ----------------------------------------------------
        # 使用局地中值替换异常爆点
        # ----------------------------------------------------

        if bad_count > 0:

            local_med = median_filter(
                frame,
                size=MEDIAN_FILTER_SIZE
            )


            frame[
                bad
            ] = local_med[
                bad
            ]


            # ------------------------------------------------
            # 中值替换之后如果仍然超过cap，则直接限制为cap
            # ------------------------------------------------

            bad2 = (
                frame
                >
                cap
            )


            if np.sum(
                bad2
            ) > 0:

                frame[
                    bad2
                ] = cap


            y_clean[t] = (
                frame
            )


            spike_mask[t][
                bad
            ] = 1


        print(
            f"lead={int(centers.iloc[t]['lead_hour']):03d} | "
            f"coarse_max={coarse_max:.2f} | "
            f"spike_cap={cap:.2f} | "
            f"清理爆点数={bad_count}"
        )


    return (
        y_clean.astype(
            np.float32
        ),

        spike_mask.astype(
            np.uint8
        ),

        np.array(
            spike_caps,
            dtype=np.float32
        )
    )


# ============================================================
# 2. 中心模型区连续化后处理
# ============================================================

def make_continuous_wind_field(
    y_spike_clean,
    X_all,
    centers,
    spike_caps
):
    """
    对中心模型区进行空间连续化处理。
    """

    y_final = np.zeros_like(
        y_spike_clean,
        dtype=np.float32
    )


    coarse_uv_highres = X_all[
        ...,
        0
    ].astype(
        np.float32
    )


    T = y_spike_clean.shape[0]


    for t in range(T):

        pred = y_spike_clean[
            t
        ].astype(
            np.float32
        )


        coarse = coarse_uv_highres[
            t
        ].astype(
            np.float32
        )


        coarse_max = float(
            centers.iloc[t]["coarse_window_max_wind"]
        )


        cap = float(
            spike_caps[
                t
            ]
        )


        target_max = float(
            np.nanmax(
                pred
            )
        )


        target_max = min(
            target_max,
            cap
        )


        pred_med = median_filter(
            pred,
            size=PRED_MEDIAN_SIZE
        )


        pred_smooth = gaussian_filter(
            pred_med,
            sigma=PRED_GAUSSIAN_SIGMA
        )


        coarse_smooth = gaussian_filter(
            coarse,
            sigma=COARSE_GAUSSIAN_SIGMA
        )


        coarse_current_max = float(
            np.nanmax(
                coarse_smooth
            )
        )


        if coarse_current_max > 1e-6:

            coarse_scaled = (
                coarse_smooth
                /
                coarse_current_max
                *
                target_max
            )

        else:

            coarse_scaled = (
                coarse_smooth.copy()
            )


        combined = (
            PRED_WEIGHT
            *
            pred_smooth
            +
            COARSE_WEIGHT
            *
            coarse_scaled
        )


        combined = gaussian_filter(
            combined,
            sigma=FINAL_GAUSSIAN_SIGMA
        )


        combined_max = float(
            np.nanmax(
                combined
            )
        )


        if combined_max > 1e-6:

            scale_factor = (
                0.95
                *
                target_max
                /
                combined_max
            )


            scale_factor = np.clip(
                scale_factor,
                0.7,
                1.20
            )


            combined = (
                combined
                *
                scale_factor
            )


        combined = np.clip(
            combined,
            0.0,
            cap
        )


        y_final[
            t
        ] = combined.astype(
            np.float32
        )


        print(
            f"连续化 lead={int(centers.iloc[t]['lead_hour']):03d} | "
            f"coarse_max={coarse_max:.2f} | "
            f"cap={cap:.2f} | "
            f"before_max={np.nanmax(pred):.2f} | "
            f"after_max={np.nanmax(combined):.2f}"
        )


    return y_final.astype(
        np.float32
    )


# ============================================================
# 3. 全过程分段低风速修正
# ============================================================

def apply_piecewise_low_wind_correction(
    wind_all
):
    """
    对最终逐小时大范围风场进行分段低风速修正。

    当前规则：
        0 <= V < 10 m/s  -> ×1.20
        10 <= V < 20 m/s -> ×1.10
        V >= 20 m/s      -> 不变
    """

    corrected = (
        wind_all.copy()
        .astype(
            np.float32
        )
    )


    T = corrected.shape[
        0
    ]


    count_0_10 = np.zeros(
        T,
        dtype=np.int32
    )


    count_10_20 = np.zeros(
        T,
        dtype=np.int32
    )


    # ========================================================
    # 未开启修正
    # ========================================================

    if not ENABLE_PIECEWISE_LOW_WIND_CORRECTION:

        print(
            "\n⚠️ 未开启全过程分段低风速修正"
        )


        return (
            corrected,
            count_0_10,
            count_10_20
        )


    # ========================================================
    # 打印当前规则
    # ========================================================

    print(
        "\n========== 全过程分段低风速修正 =========="
    )


    print(
        f"0 <= V < "
        f"{LOW_WIND_THRESHOLD_1:.1f} m/s "
        f"-> × {LOW_WIND_FACTOR_1:.2f}"
    )


    print(
        f"{LOW_WIND_THRESHOLD_1:.1f} <= V < "
        f"{LOW_WIND_THRESHOLD_2:.1f} m/s "
        f"-> × {LOW_WIND_FACTOR_2:.2f}"
    )


    print(
        f"V >= "
        f"{LOW_WIND_THRESHOLD_2:.1f} m/s "
        f"-> 不修正"
    )


    # ========================================================
    # 逐小时处理
    # ========================================================

    for t in range(
        T
    ):

        # 必须根据修正前原值判断区间
        original = corrected[
            t
        ].copy()


        # ====================================================
        # 0~10 m/s -> ×1.20
        # ====================================================

        mask_0_10 = (
            np.isfinite(
                original
            )
            &
            (
                original
                >=
                0.0
            )
            &
            (
                original
                <
                LOW_WIND_THRESHOLD_1
            )
        )


        corrected[
            t
        ][
            mask_0_10
        ] = (
            original[
                mask_0_10
            ]
            *
            LOW_WIND_FACTOR_1
        )


        # ====================================================
        # 10~20 m/s -> ×1.10
        # ====================================================

        mask_10_20 = (
            np.isfinite(
                original
            )
            &
            (
                original
                >=
                LOW_WIND_THRESHOLD_1
            )
            &
            (
                original
                <
                LOW_WIND_THRESHOLD_2
            )
        )


        corrected[
            t
        ][
            mask_10_20
        ] = (
            original[
                mask_10_20
            ]
            *
            LOW_WIND_FACTOR_2
        )


        # ====================================================
        # 统计修正格点
        # ====================================================

        count_0_10[
            t
        ] = int(
            np.sum(
                mask_0_10
            )
        )


        count_10_20[
            t
        ] = int(
            np.sum(
                mask_10_20
            )
        )


        # ====================================================
        # 每12小时输出一次
        # ====================================================

        if (
            t % 12 == 0
            or
            t == T - 1
        ):

            raw_max = float(
                np.nanmax(
                    original
                )
            )


            corrected_max = float(
                np.nanmax(
                    corrected[t]
                )
            )


            raw_mean = float(
                np.nanmean(
                    original
                )
            )


            corrected_mean = float(
                np.nanmean(
                    corrected[t]
                )
            )


            print(
                f"time_idx={t:03d} | "
                f"0~{LOW_WIND_THRESHOLD_1:.0f}修正="
                f"{count_0_10[t]} | "
                f"{LOW_WIND_THRESHOLD_1:.0f}~"
                f"{LOW_WIND_THRESHOLD_2:.0f}修正="
                f"{count_10_20[t]} | "
                f"max={raw_max:.2f}->{corrected_max:.2f} | "
                f"mean={raw_mean:.2f}->{corrected_mean:.2f}"
            )


    # ========================================================
    # 全过程统计
    # ========================================================

    total_count_0_10 = int(
        np.sum(
            count_0_10
        )
    )


    total_count_10_20 = int(
        np.sum(
            count_10_20
        )
    )


    print(
        "\n========== 分段低风速修正完成 =========="
    )


    print(
        f"全过程 "
        f"0~{LOW_WIND_THRESHOLD_1:.1f} m/s "
        f"修正格点总数："
        f"{total_count_0_10}"
    )


    print(
        f"全过程 "
        f"{LOW_WIND_THRESHOLD_1:.1f}~"
        f"{LOW_WIND_THRESHOLD_2:.1f} m/s "
        f"修正格点总数："
        f"{total_count_10_20}"
    )


    print(
        "✅ 全过程分段低风速修正完成"
    )


    return (
        corrected.astype(
            np.float32
        ),

        count_0_10.astype(
            np.int32
        ),

        count_10_20.astype(
            np.int32
        )
    )