# ============================================================
# 中性下垫面、网格、裁剪和逐小时模型输入构造
# ============================================================

import numpy as np
import pandas as pd
from scipy.ndimage import zoom

from ..config import (
    H,
    W,
    CORE_H,
    CORE_W,
    LOW_RES_DEG,
    HIGH_RES_KM,
    LARGE_H,
    LARGE_W,
    WIND_CORRECTION_FACTOR,
)


# ============================================================
# 1. 中性地形/下垫面通道
# ============================================================

def load_fixed_topo_channels(topo_file=None):
    """
    移动窗口预测版本：
    """
    print("[WARN] 当前为移动窗口预测：使用中性地形/下垫面通道。")

    hgt = np.zeros((H, W), dtype=np.float32)
    landmask = np.zeros((H, W), dtype=np.float32)
    lu_index = np.full((H, W), 17.0, dtype=np.float32)
    greenfrac = np.zeros((H, W), dtype=np.float32)
    albedo = np.full((H, W), 0.08, dtype=np.float32)

    topo_stack = np.stack(
        [hgt, landmask, lu_index, greenfrac, albedo],
        axis=-1
    )

    print("[OK] 中性地形通道构造完成:", topo_stack.shape)
    return topo_stack.astype(np.float32)


# ============================================================
# 2. 构造网格和裁剪函数
# ============================================================

def make_lowres_target_grid(center_lat, center_lon):
    lat_vec = center_lat + (np.arange(CORE_H) - CORE_H // 2) * LOW_RES_DEG
    lon_vec = center_lon + (np.arange(CORE_W) - CORE_W // 2) * LOW_RES_DEG
    return lat_vec, lon_vec


def make_highres_center_grid(center_lat, center_lon):
    """生成以台风中心为中心的 99×120 模型窗口。"""
    dlat = HIGH_RES_KM / 111.0

    cos_lat = np.cos(np.deg2rad(center_lat))
    if abs(cos_lat) < 1e-6:
        cos_lat = 1e-6

    dlon = HIGH_RES_KM / (111.0 * cos_lat)

    lat_vec = center_lat + (np.arange(H) - H // 2) * dlat
    lon_vec = center_lon + (np.arange(W) - W // 2) * dlon

    lon_grid, lat_grid = np.meshgrid(lon_vec, lat_vec)
    return lat_grid.astype(np.float32), lon_grid.astype(np.float32)


def make_large_grid(center_lat, center_lon):
    """生成以台风中心为中心的大范围 249×300 网格。"""
    dlat = HIGH_RES_KM / 111.0

    cos_lat = np.cos(np.deg2rad(center_lat))
    if abs(cos_lat) < 1e-6:
        cos_lat = 1e-6

    dlon = HIGH_RES_KM / (111.0 * cos_lat)

    lat_vec = center_lat + (np.arange(LARGE_H) - LARGE_H // 2) * dlat
    lon_vec = center_lon + (np.arange(LARGE_W) - LARGE_W // 2) * dlon

    lon_grid, lat_grid = np.meshgrid(lon_vec, lat_vec)
    return lat_grid.astype(np.float32), lon_grid.astype(np.float32)


def crop_field_to_9x15(da, lead_hour, center_lat, center_lon):
    """
    从全球粗分辨率场中，按当前台风中心裁剪 9×15 窗口。
    同时做 lead_hour 时间插值和经纬度空间插值。
    """
    center_lon = center_lon % 360

    target_lats, target_lons = make_lowres_target_grid(center_lat, center_lon)
    target_lons = target_lons % 360

    sub = da.interp(
        lead_hour=float(lead_hour),
        lat=target_lats,
        lon=target_lons
    )

    values = np.squeeze(sub.values)

    if values.shape != (CORE_H, CORE_W):
        raise ValueError(
            f"裁剪后形状错误，应为 {(CORE_H, CORE_W)}，实际为 {values.shape}"
        )

    return values.astype(np.float32)


def interp_field_to_large_grid(da, lead_hour, lat_grid, lon_grid):
    """
    将全球粗分辨率变量插值到大范围 249×300 网格。
    这里用于外围粗分辨率风速补充。
    """
    lat_vec = lat_grid[:, 0].astype(float)
    lon_vec = (lon_grid[0, :].astype(float) % 360)

    sub = da.interp(
        lead_hour=float(lead_hour),
        lat=lat_vec,
        lon=lon_vec
    )

    values = np.squeeze(sub.values).astype(np.float32)

    if values.shape != (LARGE_H, LARGE_W):
        raise ValueError(
            f"大范围插值后形状错误，应为 {(LARGE_H, LARGE_W)}，实际为 {values.shape}"
        )

    return values


def build_path_channels(center_lat, center_lon, coarse_window_max_wind,
                        coarse_window_min_slp, lat_grid, lon_grid):
    """
    第5通道：距离衰减
    第6通道：粗分辨率 9×15 窗口最大风速
    第7通道：粗分辨率 9×15 窗口最低海平面气压
    """
    center_lon = center_lon % 360
    lon_grid_360 = lon_grid % 360

    dist = np.sqrt(
        (lat_grid - center_lat) ** 2 +
        (lon_grid_360 - center_lon) ** 2
    )

    dist_channel = np.exp(-0.1 * dist)

    wind_channel = np.full((H, W), coarse_window_max_wind, dtype=np.float32)
    slp_channel = np.full((H, W), coarse_window_min_slp, dtype=np.float32)

    return np.stack(
        [dist_channel, wind_channel, slp_channel],
        axis=-1
    ).astype(np.float32)


# ============================================================
# 3. 构造每小时中心模型输入 + 大范围粗风场
# ============================================================

def build_hourly_inputs(ds_all, lead_hours_hourly, path_funcs, topo_channels):
    X_list = []
    lat_center_list = []
    lon_center_list = []
    lat_large_list = []
    lon_large_list = []
    coarse_large_list = []
    center_records = []

    uv_da = ds_all["uv"]
    rh_da = ds_all["rh"]
    slp_da = ds_all["slp"]
    t2m_da = ds_all["t2m"]

    for time_idx, lead in enumerate(lead_hours_hourly):
        center_lat = float(path_funcs["LAT"](lead))
        center_lon = float(path_funcs["LONG"](lead))
        center_lon = center_lon % 360

        # 中心模型窗口网格
        lat_center, lon_center = make_highres_center_grid(center_lat, center_lon)

        # 大范围输出网格
        lat_large, lon_large = make_large_grid(center_lat, center_lon)

        # 中心 9×15 粗分辨率窗口
        uv9 = crop_field_to_9x15(uv_da, lead, center_lat, center_lon)
        rh9 = crop_field_to_9x15(rh_da, lead, center_lat, center_lon)
        slp9 = crop_field_to_9x15(slp_da, lead, center_lat, center_lon)
        t2m9 = crop_field_to_9x15(t2m_da, lead, center_lat, center_lon)

        uv9 = uv9 * WIND_CORRECTION_FACTOR

        coarse_window_max_wind = float(np.nanmax(uv9))
        coarse_window_min_slp = float(np.nanmin(slp9))

        # 第1~4通道：动态气象场
        fnl_stack = np.stack([uv9, rh9, slp9, t2m9], axis=-1)

        fnl_highres = zoom(
            fnl_stack,
            (H / CORE_H, W / CORE_W, 1),
            order=1
        ).astype(np.float32)

        # 第5~7通道
        path_channels = build_path_channels(
            center_lat=center_lat,
            center_lon=center_lon,
            coarse_window_max_wind=coarse_window_max_wind,
            coarse_window_min_slp=coarse_window_min_slp,
            lat_grid=lat_center,
            lon_grid=lon_center
        )

        # 第8~12通道
        topo = topo_channels.astype(np.float32)

        X = np.concatenate([fnl_highres, path_channels, topo], axis=-1).astype(np.float32)

        if X.shape != (H, W, 12):
            raise ValueError(f"输入形状错误，应为 {(H, W, 12)}，实际为 {X.shape}")

        # 外围大范围粗分辨率风速插值到 3 km 网格
        coarse_large = interp_field_to_large_grid(
            da=uv_da,
            lead_hour=lead,
            lat_grid=lat_large,
            lon_grid=lon_large
        )
        coarse_large = coarse_large * WIND_CORRECTION_FACTOR
        coarse_large = np.maximum(coarse_large, 0).astype(np.float32)

        X_list.append(X)
        lat_center_list.append(lat_center)
        lon_center_list.append(lon_center)
        lat_large_list.append(lat_large)
        lon_large_list.append(lon_large)
        coarse_large_list.append(coarse_large)

        center_records.append({
            "time_idx": time_idx,
            "lead_hour": lead,
            "center_lat": center_lat,
            "center_lon": center_lon,
            "coarse_window_max_wind": coarse_window_max_wind,
            "coarse_window_mean_wind": float(np.nanmean(uv9)),
            "coarse_window_min_slp": coarse_window_min_slp,
            "coarse_window_mean_slp": float(np.nanmean(slp9)),
            "coarse_large_max_wind": float(np.nanmax(coarse_large)),
            "coarse_large_mean_wind": float(np.nanmean(coarse_large))
        })

        print(
            f"[OK] lead={int(lead):03d} h 输入完成 | "
            f"中心=({center_lat:.2f}, {center_lon:.2f}) | "
            f"中心9×15粗风速max={coarse_window_max_wind:.2f} m/s | "
            f"大范围粗风速max={np.nanmax(coarse_large):.2f} m/s"
        )

    X_all = np.stack(X_list, axis=0).astype(np.float32)
    lat_center_all = np.stack(lat_center_list, axis=0).astype(np.float32)
    lon_center_all = np.stack(lon_center_list, axis=0).astype(np.float32)
    lat_large_all = np.stack(lat_large_list, axis=0).astype(np.float32)
    lon_large_all = np.stack(lon_large_list, axis=0).astype(np.float32)
    coarse_large_all = np.stack(coarse_large_list, axis=0).astype(np.float32)
    centers = pd.DataFrame(center_records)

    print("[OK] 全部小时中心模型输入构造完成:", X_all.shape)
    print("[OK] 大范围粗风场构造完成:", coarse_large_all.shape)

    return (
        X_all,
        lat_center_all,
        lon_center_all,
        lat_large_all,
        lon_large_all,
        coarse_large_all,
        centers
    )
