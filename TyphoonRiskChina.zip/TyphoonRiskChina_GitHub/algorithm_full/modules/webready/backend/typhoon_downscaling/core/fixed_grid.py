# ============================================================
# 从移动窗口NC中提取每个固定地理位置的过程最大风速
# ============================================================

import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import xarray as xr


def _netcdf_kwargs():
    engine = os.environ.get("TYPHOON_NETCDF_ENGINE")
    if not engine and os.name == "nt":
        engine = "h5netcdf"
    return {"engine": engine} if engine else {}


# ============================================================
# 可直接调用的固定网格处理函数
# ============================================================

def extract_fixed_grid_max(
    nc_file,
    out_nc,
    out_png,
    typhoon_id,
    target_km=3.0,
    vmin=0,
    vmax=75,
    show_plot=True,
):
    """
    输入：
      wind_speed_1h_max_pred(time, south_north, west_east)
      XLAT(time, south_north, west_east)
      XLONG(time, south_north, west_east)

    输出：
      max_wind_speed(lat, lon)
      time_of_max(lat, lon)
      lead_hour_of_max(lat, lon)
      valid_count(lat, lon)
    """
    nc_file = str(nc_file)
    out_nc = str(out_nc)
    out_png = str(out_png)

    os.makedirs(os.path.dirname(out_nc), exist_ok=True)
    ds = xr.open_dataset(nc_file, **_netcdf_kwargs())

    try:
        wind_name = "wind_speed_1h_max_pred"

        if wind_name not in ds:
            raise KeyError(f"NC文件中没有变量：{wind_name}")

        if "XLAT" not in ds or "XLONG" not in ds:
            raise KeyError("NC文件中缺少 XLAT 或 XLONG，无法转换到固定经纬度网格。")

        wind = ds[wind_name]
        times = pd.to_datetime(ds["time"].values)

        if "lead_hour" in ds.coords:
            lead_hours = ds["lead_hour"].values
        elif "lead_hour" in ds:
            lead_hours = ds["lead_hour"].values
        else:
            lead_hours = np.arange(len(times))

        print("[OK] 成功读取NC文件")
        print("风速变量形状:", wind.shape)
        print("时间数量:", len(times))
        print("时间范围:", times[0], "到", times[-1])

        # 4. 构建固定经纬度网格
        lat_all = ds["XLAT"].values
        lon_all = ds["XLONG"].values

        lat_min = float(np.nanmin(lat_all))
        lat_max = float(np.nanmax(lat_all))
        lon_min = float(np.nanmin(lon_all))
        lon_max = float(np.nanmax(lon_all))

        dlat = target_km / 111.0

        mean_lat = 0.5 * (lat_min + lat_max)
        cos_lat = np.cos(np.deg2rad(mean_lat))
        if abs(cos_lat) < 1e-6:
            cos_lat = 1e-6

        dlon = target_km / (111.0 * cos_lat)

        target_lats = np.arange(lat_min, lat_max + dlat, dlat)
        target_lons = np.arange(lon_min, lon_max + dlon, dlon)

        print("[OK] 固定网格范围:")
        print("纬度:", lat_min, "到", lat_max)
        print("经度:", lon_min, "到", lon_max)
        print("固定网格尺寸:", len(target_lats), "×", len(target_lons))
        print("固定网格分辨率约:", target_km, "km")

        # 5. 逐小时插值到固定网格，并提取最大风速
        max_wind = np.full(
            (len(target_lats), len(target_lons)),
            np.nan,
            dtype=np.float32
        )

        time_index_of_max = np.full(
            (len(target_lats), len(target_lons)),
            -1,
            dtype=np.int32
        )

        lead_hour_of_max = np.full(
            (len(target_lats), len(target_lons)),
            np.nan,
            dtype=np.float32
        )

        valid_count = np.zeros(
            (len(target_lats), len(target_lons)),
            dtype=np.int16
        )

        for t in range(len(times)):
            print(f"正在处理第 {t + 1}/{len(times)} 个时刻：{times[t]}")

            wind_t = wind.isel(time=t).values.astype(np.float32)
            lat_t = ds["XLAT"].isel(time=t).values.astype(np.float32)
            lon_t = ds["XLONG"].isel(time=t).values.astype(np.float32)

            lat_src = lat_t[:, 0]
            lon_src = lon_t[0, :]

            if lat_src[0] > lat_src[-1]:
                lat_src = lat_src[::-1]
                wind_t = wind_t[::-1, :]

            if lon_src[0] > lon_src[-1]:
                lon_src = lon_src[::-1]
                wind_t = wind_t[:, ::-1]

            da_t = xr.DataArray(
                wind_t,
                dims=("lat", "lon"),
                coords={"lat": lat_src, "lon": lon_src}
            )

            wind_fixed = da_t.interp(
                lat=target_lats,
                lon=target_lons,
                method="linear"
            ).values.astype(np.float32)

            valid = np.isfinite(wind_fixed)
            valid_count[valid] += 1

            better = valid & (
                (~np.isfinite(max_wind)) |
                (wind_fixed > max_wind)
            )

            max_wind[better] = wind_fixed[better]
            time_index_of_max[better] = t
            lead_hour_of_max[better] = float(lead_hours[t])

        # 6. 生成最大风速出现时间
        time_of_max = np.full(
            time_index_of_max.shape,
            np.datetime64("NaT"),
            dtype="datetime64[ns]"
        )

        valid_idx = time_index_of_max >= 0
        time_values = pd.to_datetime(times).values.astype("datetime64[ns]")
        time_of_max[valid_idx] = time_values[time_index_of_max[valid_idx]]

        # 7. 保存新的NC文件
        ds_out = xr.Dataset(
            data_vars={
                "max_wind_speed": (("lat", "lon"), max_wind.astype(np.float32)),
                "time_of_max": (("lat", "lon"), time_of_max),
                "lead_hour_of_max": (
                    ("lat", "lon"), lead_hour_of_max.astype(np.float32)
                ),
                "time_index_of_max": (
                    ("lat", "lon"), time_index_of_max.astype(np.int32)
                ),
                "valid_count": (("lat", "lon"), valid_count.astype(np.int16))
            },
            coords={
                "lat": target_lats.astype(np.float32),
                "lon": target_lons.astype(np.float32)
            },
            attrs={
                "description": "Track-wise maximum wind speed at each fixed geographic grid point",
                "typhoon_id": typhoon_id,
                "source_file": nc_file,
                "source_variable": wind_name,
                "method": "Each moving-window wind field is interpolated to a fixed lat-lon grid; then the maximum over time is extracted at each fixed location.",
                "target_grid_resolution_km": str(target_km),
                "note": "This is a fixed geographic grid result, suitable for exposure and loss analysis."
            }
        )

        ds_out["max_wind_speed"].attrs["units"] = "m s-1"
        ds_out["max_wind_speed"].attrs["long_name"] = "Maximum wind speed during the whole typhoon process at each fixed grid point"
        ds_out["time_of_max"].attrs["long_name"] = "Time when maximum wind speed occurs"
        ds_out["lead_hour_of_max"].attrs["units"] = "hour"
        ds_out["lead_hour_of_max"].attrs["long_name"] = "Forecast lead hour when maximum wind speed occurs"
        ds_out["valid_count"].attrs["units"] = "hour"
        ds_out["valid_count"].attrs["long_name"] = "Number of hours covered by moving windows at each fixed grid point"

        if os.path.exists(out_nc):
            try:
                os.remove(out_nc)
            except PermissionError as exc:
                raise PermissionError(
                    f"无法删除旧NC文件，可能正在被其他程序打开：{out_nc}"
                ) from exc

        ds_out.to_netcdf(out_nc, **_netcdf_kwargs())
        ds_out.close()

        print("[OK] 固定位置最大风速NC已保存:")
        print(out_nc)
        print("最大风速:", float(np.nanmax(max_wind)))
        print("最小风速:", float(np.nanmin(max_wind)))
        print("平均风速:", float(np.nanmean(max_wind)))

        # 8. 简单画图检查
        plt.figure(figsize=(10, 8))

        pcm = plt.pcolormesh(
            target_lons,
            target_lats,
            max_wind,
            shading="auto",
            cmap="turbo",
            vmin=vmin,
            vmax=vmax
        )

        plt.colorbar(pcm, label="Maximum wind speed (m/s)")
        plt.xlabel("Longitude")
        plt.ylabel("Latitude")
        plt.title(f"{typhoon_id} Fixed-grid Maximum Wind Speed")
        plt.tight_layout()
        plt.savefig(out_png, dpi=300)

        if show_plot:
            plt.show()
        else:
            plt.close()

        print("[OK] 最大风速分布图已保存:")
        print(out_png)

    finally:
        ds.close()

    return out_nc
