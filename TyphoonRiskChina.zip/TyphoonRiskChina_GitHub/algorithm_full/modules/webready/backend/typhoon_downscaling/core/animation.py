"""由第二份脚本封装：最终合成风场的累计圆形揭示动画（不是逐小时瞬时风场）。"""
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd
import xarray as xr

def _netcdf_kwargs():
    import os
    engine = os.environ.get("TYPHOON_NETCDF_ENGINE") or ("h5netcdf" if os.name == "nt" else None)
    return {"engine": engine} if engine else {}


import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter

@dataclass(frozen=True)
class AnimationOptions:
    VMIN: float = 0.0
    VMAX: float = 75.0
    WIND_CIRCLE_RADIUS_KM: float = 350.0
    WIND_CIRCLE_FEATHER_KM: float = 45.0
    FRAME_STEP: int = 1
    FPS: int = 6
    INTERVAL_MS: int = 180
    SHOW_CURRENT_CIRCLE: bool = True
    CURRENT_CIRCLE_LINEWIDTH: float = 1.0
    CURRENT_CIRCLE_ALPHA: float = 0.75
    SHOW_PAST_TRACK: bool = True
    TRACK_POINT_EVERY_HOURS: int = 12
    SHOW_12H_POINTS: bool = True
    SHOW_LEAD_LABELS: bool = True
    SHOW_TIME_TEXT: bool = True
    SHOW_FIGURE: bool = False


def generate_wind_circle_animation(nc_path, typhoon_id=None, output_dir=None,
                                   options=None, output_gif=None):
    """读取合成NC并保存GIF；返回Path。参数默认值以第二份脚本为准。

    time/lead_hour原样显示，不推测或转换输入时区。350 km为显示范围，
    并非气象业务定义的强风半径。任何显示权重均不修改NC中的风速。
    """
    options = options or AnimationOptions()
    NC_PATH = Path(nc_path)
    if not NC_PATH.is_file():
        raise FileNotFoundError(f"找不到输入NC：{NC_PATH}")
    OUT_DIR = Path(output_dir) if output_dir else NC_PATH.parent / "Animation_Wind_Circle"
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    # 数据加载后立刻关闭文件，动画失败也不会占用NC。
    with xr.open_dataset(NC_PATH, **_netcdf_kwargs()) as source:
        ds = source.load()
    TYPHOON_ID = str(typhoon_id or ds.attrs.get("typhoon_id") or NC_PATH.name.split("_")[0])
    OUTPUT_GIF = Path(output_gif) if output_gif else OUT_DIR / f"{TYPHOON_ID}_wind_circle_track_growth.gif"
    OUTPUT_GIF.parent.mkdir(parents=True, exist_ok=True)
    VMIN = options.VMIN
    VMAX = options.VMAX
    WIND_CIRCLE_RADIUS_KM = options.WIND_CIRCLE_RADIUS_KM
    WIND_CIRCLE_FEATHER_KM = options.WIND_CIRCLE_FEATHER_KM
    FRAME_STEP = options.FRAME_STEP
    FPS = options.FPS
    INTERVAL_MS = options.INTERVAL_MS
    SHOW_CURRENT_CIRCLE = options.SHOW_CURRENT_CIRCLE
    CURRENT_CIRCLE_LINEWIDTH = options.CURRENT_CIRCLE_LINEWIDTH
    CURRENT_CIRCLE_ALPHA = options.CURRENT_CIRCLE_ALPHA
    SHOW_PAST_TRACK = options.SHOW_PAST_TRACK
    TRACK_POINT_EVERY_HOURS = options.TRACK_POINT_EVERY_HOURS
    SHOW_12H_POINTS = options.SHOW_12H_POINTS
    SHOW_LEAD_LABELS = options.SHOW_LEAD_LABELS
    SHOW_TIME_TEXT = options.SHOW_TIME_TEXT
    SHOW_FIGURE = options.SHOW_FIGURE
    if FRAME_STEP < 1 or int(FRAME_STEP) != FRAME_STEP:
        raise ValueError("FRAME_STEP必须为正整数")
    if FPS <= 0 or INTERVAL_MS <= 0 or TRACK_POINT_EVERY_HOURS < 1:
        raise ValueError("FPS、INTERVAL_MS和节点间隔必须大于0")
    if int(TRACK_POINT_EVERY_HOURS) != TRACK_POINT_EVERY_HOURS:
        raise ValueError("节点间隔必须为整数")
    if WIND_CIRCLE_RADIUS_KM <= 0 or not 0 <= WIND_CIRCLE_FEATHER_KM <= WIND_CIRCLE_RADIUS_KM:
        raise ValueError("半径必须大于0，羽化宽度必须位于0和半径之间")
    if not VMAX > VMIN:
        raise ValueError("VMAX必须大于VMIN")
    fig = None
    try:
        required_variables = ['track_composite_wind', 'storm_center_lat', 'storm_center_lon', 'time', 'lead_hour', 'lat', 'lon']
        missing_variables = [name for name in required_variables if name not in ds and name not in ds.coords]
        if missing_variables:
            ds.close()
            raise KeyError('NC中缺少以下变量：\n' + '\n'.join(missing_variables))
        final_wind = ds['track_composite_wind'].values.astype(np.float32)
        lat = ds['lat'].values.astype(np.float64)
        lon = ds['lon'].values.astype(np.float64)
        center_lat = ds['storm_center_lat'].values.astype(np.float64)
        center_lon = ds['storm_center_lon'].values.astype(np.float64)
        times = pd.DatetimeIndex(pd.to_datetime(ds['time'].values))
        lead_hour = ds['lead_hour'].values.astype(np.float64)
        ntime = len(times)
        if ntime == 0:
            raise ValueError("time为空，无法生成动画")
        if lat.ndim != 1 or lon.ndim != 1 or final_wind.shape != (len(lat), len(lon)):
            raise ValueError("要求lat/lon为一维，风场维度顺序为(lat, lon)")
        if len(lat) < 2 or len(lon) < 2 or not np.all(np.isfinite(lat)) or not np.all(np.isfinite(lon)):
            raise ValueError("经纬度必须至少各两个有限坐标")
        if not np.any(np.isfinite(final_wind)):
            raise ValueError("最终风场全部为缺测值")
        for name, values in (("storm_center_lat", center_lat), ("storm_center_lon", center_lon), ("lead_hour", lead_hour)):
            if values.shape != (ntime,) or not np.all(np.isfinite(values)):
                raise ValueError(f"{name}长度不匹配或包含无效值")
        if times.hasnans or not times.is_monotonic_increasing:
            raise ValueError("time包含无效值或未按时间升序排列")

        print('时间步数：', ntime)
        print('最终风场范围：', f'{np.nanmin(final_wind):.2f}', '～', f'{np.nanmax(final_wind):.2f} m/s')
        print('风圈半径：', WIND_CIRCLE_RADIUS_KM, 'km')
        lon2d, lat2d = np.meshgrid(lon, lat)

        def distance_km_to_center(lon_grid, lat_grid, center_lon_value, center_lat_value):
            dy = (lat_grid - center_lat_value) * 111.32
            dx = (lon_grid - center_lon_value) * (111.32 * np.cos(np.deg2rad(center_lat_value)))
            return np.sqrt(dx ** 2 + dy ** 2)

        def make_circle_weight(distance_km, radius_km, feather_km):
            weight = np.zeros_like(distance_km, dtype=np.float32)
            if feather_km <= 0:
                weight[distance_km <= radius_km] = 1.0
                return weight
            inner_radius = max(0.0, radius_km - feather_km)
            inside = distance_km <= inner_radius
            weight[inside] = 1.0
            feather_zone = (distance_km > inner_radius) & (distance_km < radius_km)
            if np.any(feather_zone):
                x = (distance_km[feather_zone] - inner_radius) / feather_km
                weight[feather_zone] = 0.5 * (1.0 + np.cos(np.pi * x))
            return weight
        animation_frames = np.arange(0, ntime, FRAME_STEP, dtype=int)
        if animation_frames[-1] != ntime - 1:
            animation_frames = np.append(animation_frames, ntime - 1)
        print('动画帧数：', len(animation_frames))
        cumulative_weight_by_time = {}
        snapshot_times = set(animation_frames.tolist())
        cumulative_weight = np.zeros_like(final_wind, dtype=np.float32)
        print('\n正在预计算圆形风圈推进范围...')
        for t in range(ntime):
            distance_km = distance_km_to_center(lon_grid=lon2d, lat_grid=lat2d, center_lon_value=center_lon[t], center_lat_value=center_lat[t])
            current_circle_weight = make_circle_weight(distance_km=distance_km, radius_km=WIND_CIRCLE_RADIUS_KM, feather_km=WIND_CIRCLE_FEATHER_KM)
            current_circle_weight[~np.isfinite(final_wind)] = 0.0
            cumulative_weight = np.maximum(cumulative_weight, current_circle_weight)
            if t in snapshot_times:
                cumulative_weight_by_time[t] = cumulative_weight.copy()
            if t % 12 == 0 or t == ntime - 1:
                print(f'预计算 {t + 1:03d}/{ntime:03d} | lead={int(lead_hour[t]):03d} h')
        final_full_weight = np.zeros_like(final_wind, dtype=np.float32)
        final_full_weight[np.isfinite(final_wind)] = 1.0
        fig, ax = plt.subplots(figsize=(12, 8.3), dpi=160)
        first_t = int(animation_frames[0])
        first_weight = cumulative_weight_by_time[first_t]
        first_field = np.where(first_weight > 0.01, final_wind, np.nan)
        pcm = ax.pcolormesh(lon2d, lat2d, first_field, shading='auto', cmap='turbo', vmin=VMIN, vmax=VMAX, rasterized=True, zorder=1)
        pcm.set_alpha(first_weight.ravel())
        cbar = fig.colorbar(pcm, ax=ax, fraction=0.04, pad=0.025)
        cbar.set_label('Wind speed (m/s)', fontsize=11)
        ax.scatter(center_lon[0], center_lat[0], s=100, marker='o', facecolor='limegreen', edgecolor='black', linewidth=0.8, zorder=40, label='Start')
        track_line, = ax.plot([], [], color='black', linewidth=1.4, alpha=0.9, zorder=30, label='Typhoon track')
        current_center = ax.scatter([], [], s=80, marker='o', facecolor='red', edgecolor='black', linewidth=0.8, zorder=45, label='Current center')
        current_circle_line, = ax.plot([], [], color='black', linestyle='--', linewidth=CURRENT_CIRCLE_LINEWIDTH, alpha=CURRENT_CIRCLE_ALPHA, zorder=25)
        history_points = ax.scatter([], [], s=24, facecolor='white', edgecolor='black', linewidth=0.6, zorder=35)
        lead_labels = []
        info_text = ax.text(0.02, 0.97, '', transform=ax.transAxes, ha='left', va='top', fontsize=10, bbox=dict(boxstyle='round', facecolor='white', alpha=0.85, edgecolor='gray'), zorder=60)
        ax.set_xlim(float(np.nanmin(lon)), float(np.nanmax(lon)))
        ax.set_ylim(float(np.nanmin(lat)), float(np.nanmax(lat)))
        ax.set_xlabel('Longitude', fontsize=11)
        ax.set_ylabel('Latitude', fontsize=11)
        ax.set_aspect('equal', adjustable='box')
        ax.grid(True, linestyle='--', linewidth=0.45, alpha=0.25)
        title_text = ax.set_title(f'{TYPHOON_ID} Storm-track Composite Wind Field Evolution', fontsize=14, pad=10)
        ax.legend(loc='best', fontsize=9, framealpha=0.9)

        def make_circle_boundary(center_lon_value, center_lat_value, radius_km, npoint=180):
            angle = np.linspace(0.0, 2.0 * np.pi, npoint)
            dlat = radius_km / 111.32
            cos_lat = np.cos(np.deg2rad(center_lat_value))
            if abs(cos_lat) < 1e-06:
                cos_lat = 1e-06
            dlon = radius_km / (111.32 * cos_lat)
            circle_lon = center_lon_value + dlon * np.cos(angle)
            circle_lat = center_lat_value + dlat * np.sin(angle)
            return (circle_lon, circle_lat)

        def update_animation(frame_number):
            nonlocal pcm
            t = int(animation_frames[frame_number])
            if frame_number == len(animation_frames) - 1:
                current_weight = final_full_weight
            else:
                current_weight = cumulative_weight_by_time[t]
            current_field = np.where(current_weight > 0.01, final_wind, np.nan)
            pcm.remove()
            pcm = ax.pcolormesh(lon2d, lat2d, current_field, shading='auto', cmap='turbo', vmin=VMIN, vmax=VMAX, rasterized=True, zorder=1)
            pcm.set_alpha(current_weight.ravel())
            if SHOW_PAST_TRACK:
                track_line.set_data(center_lon[:t + 1], center_lat[:t + 1])
            else:
                track_line.set_data([], [])
            current_center.set_offsets(np.array([[center_lon[t], center_lat[t]]]))
            if SHOW_CURRENT_CIRCLE:
                circle_lon, circle_lat = make_circle_boundary(center_lon_value=center_lon[t], center_lat_value=center_lat[t], radius_km=WIND_CIRCLE_RADIUS_KM)
                current_circle_line.set_data(circle_lon, circle_lat)
            else:
                current_circle_line.set_data([], [])
            if SHOW_12H_POINTS:
                passed_index = np.arange(0, t + 1, TRACK_POINT_EVERY_HOURS, dtype=int)
                points_xy = np.column_stack((center_lon[passed_index], center_lat[passed_index]))
                history_points.set_offsets(points_xy)
            else:
                passed_index = np.array([], dtype=int)
                history_points.set_offsets(np.empty((0, 2)))
            for txt in lead_labels:
                txt.remove()
            lead_labels.clear()
            if SHOW_12H_POINTS and SHOW_LEAD_LABELS:
                for idx in passed_index:
                    txt = ax.text(center_lon[idx] + 0.15, center_lat[idx] + 0.15, f'{int(lead_hour[idx])}h', fontsize=7, color='black', zorder=36)
                    lead_labels.append(txt)
            if SHOW_TIME_TEXT:
                visible_count = int(np.sum(current_weight > 0.01))
                total_count = int(np.sum(np.isfinite(final_wind)))
                completed_percent = 100.0 * visible_count / max(total_count, 1)
                info_text.set_text(f"Lead time: {int(lead_hour[t])} h\nTime: {times[t].strftime('%Y-%m-%d %H:%M')}\nCenter: {center_lon[t]:.2f}°E, {center_lat[t]:.2f}°N\nWind-circle radius: {WIND_CIRCLE_RADIUS_KM:.0f} km\nCompleted: {completed_percent:.1f}%")
            else:
                info_text.set_text('')
            title_text.set_text(f'{TYPHOON_ID} Storm-track Composite Wind Field ({int(lead_hour[t])} h)')
            return (pcm, track_line, current_center, current_circle_line, history_points, info_text)
        animation = FuncAnimation(fig, update_animation, frames=len(animation_frames), interval=INTERVAL_MS, repeat=True, blit=False)
        print('\n正在生成圆形风圈沿路径推进动画...')
        animation.save(OUTPUT_GIF, writer=PillowWriter(fps=FPS), dpi=120)
        print('\n✅ GIF已保存：')
        print(OUTPUT_GIF)
        if SHOW_FIGURE:
            plt.show()
        else:
            plt.close(fig)
        ds.close()
        print('\n========== 全部完成 ==========')
        return OUTPUT_GIF
    finally:
        ds.close()
        if fig is not None:
            plt.close(fig)
