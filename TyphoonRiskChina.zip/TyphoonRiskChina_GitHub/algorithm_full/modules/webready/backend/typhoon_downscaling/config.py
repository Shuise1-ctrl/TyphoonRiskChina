# ============================================================
# 台风降尺度统一配置
# ============================================================

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
import os
import re


# ============================================================
# 1. 工程公共路径
# ============================================================

# 默认把模型、归一化器、输入数据和输出结果保存在当前源码目录旁边，
# 从而避免依赖某台电脑的 C 盘用户目录。
# 也可通过环境变量 TYPHOON_DOWNSCALING_ROOT 临时指定其他位置。
BUNDLE_ROOT = Path(__file__).absolute().parents[2]
DEFAULT_PROJECT_ROOT = BUNDLE_ROOT / "runtime_data"

_project_root_from_env = os.environ.get("TYPHOON_DOWNSCALING_ROOT")
if _project_root_from_env:
    # 保留显式指定的盘符路径；Windows 下 NetCDF/HDF5 需要通过纯英文短盘符
    # 访问包含中文的物理目录，resolve() 会还原成长中文路径并导致打开失败。
    PROJECT_ROOT = Path(_project_root_from_env).expanduser()
else:
    PROJECT_ROOT = DEFAULT_PROJECT_ROOT

DATA_ROOT = PROJECT_ROOT / "date"
MODEL_PATH = PROJECT_ROOT / "models" / "direct_unet_model.h5"
SCALER_X_PATH = PROJECT_ROOT / "scalers" / "scaler_x.save"
SCALER_Y_PATH = PROJECT_ROOT / "scalers" / "scaler_y.save"

# 当前移动窗口版本使用中性下垫面通道，不真正读取地形文件。
TOPO_FILE = None


# ============================================================
# 2. 原始算法参数
#    数值与原始可运行代码保持一致
# ============================================================

H = 99
W = 120

CORE_H = 9
CORE_W = 15

LOW_RES_DEG = 0.25
HIGH_RES_KM = 3.0

LARGE_H = 249
LARGE_W = 300

CENTER_R0 = (LARGE_H - H) // 2
CENTER_C0 = (LARGE_W - W) // 2

BLEND_TAPER = 45

CENTER_MODEL_MAX_WEIGHT = 0.9
WEIGHT_SMOOTH_SIGMA = 2.5
FINAL_MERGE_SMOOTH_SIGMA = 1.0

EYE_RADIUS_CELLS = 14
ANOMALY_SMOOTH_SIGMA = 8
SUPPRESS_NEGATIVE_ANOMALY_OUTSIDE_EYE = True

COARSE_EYE_FILL_RADIUS_CELLS = 70
COARSE_EYE_FILL_SIGMA = 12.0

TRAIN_WIND_MAX = 35.0
CLIP_X_SCALED = False
CLIP_Y_PRED = False
POST_CLIP_WIND = False

ENABLE_SOFT_CLIP_X = True
X_CLIP_MIN = -0.2
X_CLIP_MAX = 1.2

ENABLE_SPIKE_CLEAN = True
WIND_CORRECTION_FACTOR = 1.15
SPIKE_CAP_A = 1.00
SPIKE_CAP_B = 3.0
SPIKE_MIN_CAP = 15.0
SPIKE_MAX_CAP = 45.0
MEDIAN_FILTER_SIZE = 5

ENABLE_CONTINUITY_POST = True
PRED_MEDIAN_SIZE = 3
PRED_GAUSSIAN_SIGMA = 1.2
COARSE_GAUSSIAN_SIGMA = 2.0
FINAL_GAUSSIAN_SIGMA = 4
PRED_WEIGHT = 0.45
COARSE_WEIGHT = 0.55

SCALE_BATCH_SIZE = 32
PREDICT_BATCH_SIZE = 4

TARGET_KM = 3.0
VMIN = 0
VMAX = 75


# ============================================================
# 3. FNL文件自动发现
# ============================================================

# 这些目录属于结果目录，不允许当成FNL输入来源。
_EXCLUDED_INPUT_DIR_NAMES = {
    "moving_3km_output1",
    "output",
    "outputs",
    "useful_plots",
    "useful_plots3",
    "fixed_grid",
    "track_composite_weighted",
    "animation_wind_circle",
}

# 支持常见NetCDF扩展名；原始数据通常为.nc。
_FNL_EXTENSIONS = {".nc", ".nc4", ".cdf"}


def extract_fnl_lead_hour(file_path) -> int:
    """
    从FNL文件名中提取预报时效。

    支持示例：
        006.nc
        fnl_006.nc
        forecast_f006.nc

    为避免把ID2609或日期误认为时效，优先取文件名中最后一个
    0~240之间的数字组。
    """
    path = Path(file_path)
    groups = re.findall(r"\d+", path.stem)

    for text in reversed(groups):
        value = int(text)
        if 0 <= value <= 240:
            return value

    raise ValueError(f"无法从FNL文件名提取0~240小时预报时效：{path.name}")


def _is_excluded_path(path: Path, search_root: Path) -> bool:
    """判断文件是否位于输出或绘图目录中。"""
    try:
        relative_parts = path.relative_to(search_root).parts[:-1]
    except ValueError:
        relative_parts = path.parts[:-1]

    return any(
        str(part).lower() in _EXCLUDED_INPUT_DIR_NAMES
        for part in relative_parts
    )


def discover_fnl_files(search_root) -> list[Path]:
    """
    在指定目录及其所有子目录中自动发现FNL输入文件。

    规则：
    1. 递归查找.nc/.nc4/.cdf；
    2. 排除Moving_3km_Output1等结果目录；
    3. 文件名必须能够提取0~240小时预报时效；
    4. 按预报时效排序；
    5. 同一时效若出现多个文件，优先保留路径更短的文件。
    """
    root = Path(search_root)
    if not root.exists() or not root.is_dir():
        return []

    candidates: list[tuple[int, Path]] = []

    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() not in _FNL_EXTENSIONS:
            continue
        if _is_excluded_path(path, root):
            continue

        try:
            lead = extract_fnl_lead_hour(path)
        except ValueError:
            continue

        candidates.append((lead, path))

    # 同一预报时效只保留一个文件，防止重复输入。
    # 优先路径层级更浅、路径字符串更短的文件。
    selected: dict[int, Path] = {}
    for lead, path in sorted(
        candidates,
        key=lambda item: (item[0], len(item[1].parts), len(str(item[1])))
    ):
        selected.setdefault(lead, path)

    return [selected[lead] for lead in sorted(selected)]


def resolve_fnl_root(case_dir: Path) -> Path:
    """
    自动确定FNL搜索根目录。

    优先常见目录名；若都没有找到输入文件，则使用整个台风目录，
    后续由discover_fnl_files递归搜索。
    """
    preferred_names = (
        "FNL1",
        "FNL",
        "fnl1",
        "fnl",
        "FNL_data",
        "FNL数据",
    )

    for name in preferred_names:
        candidate = case_dir / name
        if candidate.is_dir() and discover_fnl_files(candidate):
            return candidate

    if discover_fnl_files(case_dir):
        return case_dir

    # 即使暂时没有找到，也返回case_dir，让校验函数给出详细错误。
    return case_dir


# ============================================================
# 4. 单个台风算例配置
# ============================================================

@dataclass(frozen=True)
class TyphoonCase:
    typhoon_id: str
    case_dir: Path
    fnl_dir: Path
    track_file: Path
    output_dir: Path
    prediction_nc: Path
    diagnostics_csv: Path
    fixed_grid_nc: Path
    fixed_grid_png: Path


    @property
    def track_composite_nc(self) -> Path:
        return self.output_dir / "Useful_Plots3" / "Track_Composite_Weighted" / f"{self.typhoon_id}_track_composite_weighted.nc"

    @property
    def track_composite_png(self) -> Path:
        return self.track_composite_nc.with_suffix(".png")


def create_case(typhoon_id: str) -> TyphoonCase:
    """根据台风编号自动生成输入和输出路径。"""
    typhoon_id = str(typhoon_id).strip().upper()

    if not re.fullmatch(r"ID\d{4}", typhoon_id):
        raise ValueError(
            f"台风编号格式错误：{typhoon_id}。正确格式应类似 ID2609、ID2612。"
        )

    case_dir = DATA_ROOT / typhoon_id
    fnl_dir = resolve_fnl_root(case_dir)
    track_candidates = (case_dir / "track.xlsx", case_dir / "工作路径.xlsx")
    track_file = next((path for path in track_candidates if path.is_file()), track_candidates[0])

    output_dir = case_dir / "Moving_3km_Output1"

    prediction_nc = output_dir / (
        f"{typhoon_id}_center_model_outer_coarse_largefield_oneeye.nc"
    )
    # Compact hourly summary produced by the current callable implementation.
    diagnostics_csv = output_dir / f"{typhoon_id}_hourly_useful_summary.csv"
    fixed_grid_nc = output_dir / f"{typhoon_id}_fixed_grid_max_wind.nc"
    fixed_grid_png = output_dir / f"{typhoon_id}_fixed_grid_max_wind.png"

    return TyphoonCase(
        typhoon_id=typhoon_id,
        case_dir=case_dir,
        fnl_dir=fnl_dir,
        track_file=track_file,
        output_dir=output_dir,
        prediction_nc=prediction_nc,
        diagnostics_csv=diagnostics_csv,
        fixed_grid_nc=fixed_grid_nc,
        fixed_grid_png=fixed_grid_png,
    )


def validate_common_files() -> None:
    """检查两个台风共用的模型和归一化器文件。"""
    missing = [
        path for path in (MODEL_PATH, SCALER_X_PATH, SCALER_Y_PATH)
        if not path.exists()
    ]
    if missing:
        text = "\n".join(str(path) for path in missing)
        raise FileNotFoundError(f"以下公共文件不存在：\n{text}")


def validate_case_files(case: TyphoonCase) -> None:
    """检查单个台风的输入目录、FNL文件和路径文件。"""
    if not case.case_dir.exists():
        raise FileNotFoundError(f"台风数据目录不存在：{case.case_dir}")

    if not case.fnl_dir.exists():
        raise FileNotFoundError(f"FNL搜索目录不存在：{case.fnl_dir}")

    fnl_files = discover_fnl_files(case.fnl_dir)
    if not fnl_files:
        child_items = []
        try:
            child_items = sorted(p.name for p in case.case_dir.iterdir())
        except OSError:
            pass

        listing = "、".join(child_items[:30]) if child_items else "（无法读取或目录为空）"
        raise FileNotFoundError(
            "没有发现可用的FNL NetCDF文件。\n"
            f"搜索根目录：{case.fnl_dir}\n"
            "程序已经递归搜索.nc、.nc4和.cdf文件，并排除了Moving_3km_Output1等输出目录。\n"
            "可识别文件名示例：006.nc、fnl_006.nc、forecast_f006.nc。\n"
            f"台风目录第一层内容：{listing}"
        )

    if not case.track_file.exists():
        raise FileNotFoundError(f"Track workbook not found: {case.track_file}")

# Latest supplied callable engine + wind-circle display settings.
ENABLE_PIECEWISE_LOW_WIND_CORRECTION = True
LOW_WIND_THRESHOLD_1 = 10.0
LOW_WIND_FACTOR_1 = 1.35
LOW_WIND_THRESHOLD_2 = 18.0
LOW_WIND_FACTOR_2 = 1.2
TRACK_TARGET_KM = 3.0
TRACK_BLEND_RADIUS_KM = 120.0
TRACK_MAX_CENTER_DISTANCE_KM = 450.0
TRACK_MIN_BLEND_WEIGHT = 0.0001
TRACK_ENABLE_FINAL_SMOOTH = True
TRACK_FINAL_SMOOTH_SIGMA = 1.0
TRACK_VMIN = 0.0
TRACK_VMAX = 75.0
TRACK_SHOW_PATH = True
TRACK_POINT_EVERY_HOURS = 12
TRACK_SHOW_LEAD_LABEL = True
