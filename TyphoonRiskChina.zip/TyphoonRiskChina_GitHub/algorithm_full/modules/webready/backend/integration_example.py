"""Minimal example for a future API worker or background job."""

from service import TyphoonDownscalingService


# Create one service per worker process so the model is loaded only once.
service = TyphoonDownscalingService("V:/runtime_data")


def execute_downscaling_job(case_id: str, job_output_dir: str):
    """Call this function from a task queue such as Celery or RQ."""
    return service.run_case(
        case_id=case_id,
        output_root=job_output_dir,
        show_plot=False,
    )
