"""Risk-exposure and vulnerability-resource layout helpers."""

from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path

from typhoon_vulnerability.config import ModuleConfig, PROVINCE_NAMES
from typhoon_vulnerability.io import province_grid_path


EXPOSURE_DIR_NAME = "00000 沿海省份风险暴露"
GRID_DIR_NAME = "00000 沿海省份网格"


def _absolute_path(value: str | Path) -> Path:
    """Return an absolute path without dereferencing Windows SUBST drives."""
    return Path(os.path.abspath(os.path.expanduser(str(value))))


@dataclass(frozen=True)
class ExposureLayout:
    """Resolved external exposure data and bundled boundary resources."""

    risk_root: Path
    exposure_dir: Path
    grid_dir: Path
    boundary_dir: Path

    @classmethod
    def resolve(cls, risk_root: str | Path, bundle_root: str | Path) -> "ExposureLayout":
        risk_root = _absolute_path(risk_root)
        bundle_root = _absolute_path(bundle_root)
        legacy_boundary_dir = bundle_root / "runtime_data" / "vulnerability" / "boundaries"
        repository_boundary_dir = bundle_root.parent.parent / "assets" / "vulnerability" / "boundaries"
        boundary_dir = legacy_boundary_dir if legacy_boundary_dir.exists() else repository_boundary_dir
        return cls(
            risk_root=risk_root,
            exposure_dir=risk_root / EXPOSURE_DIR_NAME,
            grid_dir=risk_root / GRID_DIR_NAME,
            boundary_dir=boundary_dir,
        )

    def validate(self) -> None:
        required = [
            self.exposure_dir,
            self.grid_dir,
            self.boundary_dir / "coastal_provinces.geojson",
            self.boundary_dir / "coastal_prefecture_cities.geojson",
            self.boundary_dir / "china_provinces_with_taiwan.geojson",
            self.boundary_dir / "nine_dash_line.geojson",
        ]
        for province in PROVINCE_NAMES:
            required.append(self.exposure_dir / f"{province}.parquet")
        missing = [path for path in required if not path.exists()]
        if missing:
            message = "\n".join(str(path) for path in missing)
            raise FileNotFoundError(f"Required exposure or boundary data are missing:\n{message}")
        for province in PROVINCE_NAMES:
            province_grid_path(self.grid_dir, province)

    def module_config(
        self,
        impact_threshold_ms: float = 17.2,
        top_city_count: int = 5,
    ) -> ModuleConfig:
        self.validate()
        return ModuleConfig(
            exposure_dir=self.exposure_dir,
            grid_dir=self.grid_dir,
            province_boundaries=self.boundary_dir / "coastal_provinces.geojson",
            city_boundaries=self.boundary_dir / "coastal_prefecture_cities.geojson",
            national_province_boundaries=(
                self.boundary_dir / "china_provinces_with_taiwan.geojson"
            ),
            nine_dash_line=self.boundary_dir / "nine_dash_line.geojson",
            impact_threshold_ms=float(impact_threshold_ms),
            top_city_count=int(top_city_count),
        )
