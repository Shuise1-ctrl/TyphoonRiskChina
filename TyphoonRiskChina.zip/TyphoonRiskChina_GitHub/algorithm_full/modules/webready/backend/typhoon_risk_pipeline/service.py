"""Service layer joining downscaling, exposure and vulnerability analysis."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import traceback
from typing import Any

from service import DownscalingResult, TyphoonDownscalingService
from typhoon_vulnerability.engine import VulnerabilityEngine

from .exposure import ExposureLayout


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _absolute_path(value: str | Path) -> Path:
    """Return an absolute path without dereferencing Windows SUBST drives."""
    return Path(os.path.abspath(os.path.expanduser(str(value))))


def _event_id(case_id: str) -> str:
    match = re.fullmatch(r"ID(\d{4})", case_id.upper())
    if not match:
        raise ValueError(f"Invalid case id: {case_id}. Expected a value like ID2609.")
    return f"20{match.group(1)}"


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=str),
        encoding="utf-8",
    )
    temporary.replace(path)


@dataclass(frozen=True)
class EndToEndResult:
    case_id: str
    event_id: str
    output_root: Path
    downscaling: DownscalingResult
    vulnerability_dir: Path
    pipeline_manifest: Path
    reused_downscaling: bool

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["downscaling"] = {
            key: str(value) for key, value in asdict(self.downscaling).items()
        }
        for key in ("output_root", "vulnerability_dir", "pipeline_manifest"):
            payload[key] = str(payload[key])
        return payload


class TyphoonRiskPipeline:
    """Backend-callable end-to-end compute service."""

    def __init__(
        self,
        runtime_root: str | Path,
        risk_root: str | Path,
        bundle_root: str | Path,
    ):
        self.runtime_root = _absolute_path(runtime_root)
        self.bundle_root = _absolute_path(bundle_root)
        self.exposure = ExposureLayout.resolve(risk_root, self.bundle_root)
        self.downscaling = TyphoonDownscalingService(self.runtime_root)

    def validate(self, case_id: str, case_dir: str | Path | None = None) -> dict[str, Any]:
        self.downscaling.validate_common_runtime()
        self.exposure.validate()
        case = self.downscaling.build_case(case_id, self.bundle_root / "outputs" / "validate", case_dir)
        missing = []
        if not case.case_dir.is_dir():
            missing.append(case.case_dir)
        if not case.fnl_dir.is_dir() or not any(case.fnl_dir.iterdir()):
            missing.append(case.fnl_dir)
        if not case.track_file.is_file():
            missing.append(case.track_file)
        if missing:
            message = "\n".join(str(path) for path in missing)
            raise FileNotFoundError(f"Required case inputs are missing:\n{message}")
        return {
            "case_id": case.typhoon_id,
            "case_dir": str(case.case_dir),
            "fnl_dir": str(case.fnl_dir),
            "track_file": str(case.track_file),
            "risk_root": str(self.exposure.risk_root),
            "status": "ready",
        }

    @staticmethod
    def _result_from_case(case) -> DownscalingResult:
        return DownscalingResult(
            case_id=case.typhoon_id,
            prediction_nc=case.prediction_nc,
            diagnostics_csv=case.diagnostics_csv,
            fixed_grid_nc=case.fixed_grid_nc,
            fixed_grid_png=case.fixed_grid_png,
        )

    def _run_downscaling(
        self,
        case_id: str,
        case_dir: str | Path | None,
        output_dir: Path,
        reuse: bool,
    ) -> tuple[DownscalingResult, bool]:
        case = self.downscaling.build_case(case_id, output_dir, case_dir)
        complete = all(
            path.is_file()
            for path in (
                case.prediction_nc,
                case.diagnostics_csv,
                case.fixed_grid_nc,
                case.fixed_grid_png,
            )
        )
        if reuse and complete:
            return self._result_from_case(case), True
        if reuse and case.prediction_nc.is_file() and case.diagnostics_csv.is_file():
            self.downscaling.run_fixed_grid(
                case.typhoon_id,
                output_dir,
                show_plot=False,
                case_dir=case.case_dir,
            )
            return self._result_from_case(case), True
        return (
            self.downscaling.run_case(
                case.typhoon_id,
                output_dir,
                show_plot=False,
                case_dir=case.case_dir,
            ),
            False,
        )

    def run(
        self,
        case_id: str,
        output_root: str | Path,
        typhoon_name: str | None = None,
        case_dir: str | Path | None = None,
        impact_threshold_ms: float = 17.2,
        reuse_downscaling: bool = True,
    ) -> EndToEndResult:
        case_id = str(case_id).strip().upper()
        event_id = _event_id(case_id)
        typhoon_name = str(typhoon_name or case_id).strip()
        output_root = _absolute_path(output_root)
        downscaling_dir = output_root / "downscaling"
        vulnerability_dir = output_root / "vulnerability"
        intermediate_dir = output_root / "intermediate"
        manifest_path = output_root / "pipeline_result.json"
        output_root.mkdir(parents=True, exist_ok=True)

        status: dict[str, Any] = {
            "schema_version": "1.0",
            "case_id": case_id,
            "event_id": event_id,
            "typhoon_name": typhoon_name,
            "started_at_utc": _utc_now(),
            "status": "running",
            "current_stage": "validation",
            "case_dir": str(_absolute_path(case_dir)) if case_dir else None,
            "risk_root": str(self.exposure.risk_root),
            "stages": {},
        }
        _write_json(manifest_path, status)

        try:
            validated = self.validate(case_id, case_dir)
            status["stages"]["validation"] = {**validated, "status": "complete"}
            status["current_stage"] = "downscaling"
            _write_json(manifest_path, status)

            downscaled, reused = self._run_downscaling(
                case_id,
                case_dir,
                downscaling_dir,
                reuse=reuse_downscaling,
            )
            status["stages"]["downscaling"] = {
                "status": "complete",
                "reused": reused,
                "files": {
                    key: str(Path(value).relative_to(output_root))
                    for key, value in asdict(downscaled).items()
                    if key != "case_id"
                },
            }
            status["current_stage"] = "risk_exposure"
            _write_json(manifest_path, status)

            # Risk exposure is consumed by the vulnerability engine. Record the
            # validated data contract as its own pipeline stage for web clients.
            module_config = self.exposure.module_config(
                impact_threshold_ms=impact_threshold_ms,
                top_city_count=5,
            )
            status["stages"]["risk_exposure"] = {
                "status": "complete",
                "exposure_dir": str(module_config.exposure_dir),
                "grid_dir": str(module_config.grid_dir),
                "provinces": ["fujian", "guangdong", "hainan", "jiangsu", "zhejiang"],
            }
            status["current_stage"] = "vulnerability"
            _write_json(manifest_path, status)

            source_case = self.downscaling.build_case(case_id, downscaling_dir, case_dir)
            intermediate_dir.mkdir(parents=True, exist_ok=True)
            track_copy = intermediate_dir / "track.xlsx"
            shutil.copy2(source_case.track_file, track_copy)
            vulnerability = VulnerabilityEngine(module_config).run(
                nc_path=downscaled.fixed_grid_nc,
                typhoon_name=typhoon_name,
                output_dir=vulnerability_dir,
                track_xlsx=track_copy,
                impact_threshold_ms=impact_threshold_ms,
                event_id=event_id,
            )
            status["stages"]["vulnerability"] = {
                "status": "complete",
                "impact_detected": vulnerability["impact_detected"],
                "screening": vulnerability["screening"],
                "affected_provinces": vulnerability["affected_provinces"],
                "totals": vulnerability["totals"],
                "files": {
                    key: str((vulnerability_dir / value).relative_to(output_root))
                    for key, value in vulnerability["files"].items()
                } | {
                    "result_manifest": str(
                        (vulnerability_dir / "result_manifest.json").relative_to(output_root)
                    )
                },
            }
            status["status"] = "complete"
            status["current_stage"] = None
            status["completed_at_utc"] = _utc_now()
            _write_json(manifest_path, status)
            return EndToEndResult(
                case_id=case_id,
                event_id=event_id,
                output_root=output_root,
                downscaling=downscaled,
                vulnerability_dir=vulnerability_dir,
                pipeline_manifest=manifest_path,
                reused_downscaling=reused,
            )
        except Exception as exc:
            status["status"] = "failed"
            status["failed_at_utc"] = _utc_now()
            status["error"] = {
                "type": type(exc).__name__,
                "message": str(exc),
                "traceback": traceback.format_exc(),
            }
            _write_json(manifest_path, status)
            raise
