"""FastAPI adapter for the unified TyphoonRiskChina pipeline."""

from __future__ import annotations

import os
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from typhoon_risk_pipeline import TyphoonRiskPipeline


BUNDLE_ROOT = Path(__file__).resolve().parent.parent
RUNTIME_ROOT = Path(os.environ.get("TYPHOON_DOWNSCALING_ROOT", BUNDLE_ROOT / "runtime_data"))
RISK_ROOT = Path(
    os.environ.get(
        "TYPHOON_RISK_EXPOSURE_ROOT",
        BUNDLE_ROOT.parent.parent / "风险暴露",
    )
)
CASE_SOURCE_ROOT = os.environ.get("TYPHOON_CASE_SOURCE_ROOT")
OUTPUT_ROOT = Path(os.environ.get("TYPHOON_PIPELINE_OUTPUT_ROOT", BUNDLE_ROOT / "outputs" / "end_to_end"))

app = FastAPI(title="TyphoonRiskChina End-to-End API", version="1.0.0")


class PipelineRequest(BaseModel):
    case_id: str = Field(pattern=r"^ID\d{4}$")
    typhoon_name: str | None = None
    case_dir: str | None = None
    impact_threshold_ms: float = Field(default=17.2, ge=0.0)
    reuse_downscaling: bool = True


def _pipeline() -> TyphoonRiskPipeline:
    return TyphoonRiskPipeline(RUNTIME_ROOT, RISK_ROOT, BUNDLE_ROOT)


def _case_dir(request: PipelineRequest) -> str | None:
    if request.case_dir:
        return request.case_dir
    if CASE_SOURCE_ROOT:
        return str(Path(CASE_SOURCE_ROOT) / request.case_id)
    return None


@app.get("/api/v1/health")
def health() -> dict:
    try:
        pipeline = _pipeline()
        pipeline.downscaling.validate_common_runtime()
        pipeline.exposure.validate()
        return {"status": "ready", "service": app.title, "version": app.version}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get("/api/v1/cases")
def cases() -> dict:
    available = _pipeline().downscaling.available_cases()
    if CASE_SOURCE_ROOT and Path(CASE_SOURCE_ROOT).is_dir():
        available = sorted({*available, *(path.name for path in Path(CASE_SOURCE_ROOT).glob("ID[0-9][0-9][0-9][0-9]") if path.is_dir())})
    return {"cases": available}


@app.post("/api/v1/pipeline/run")
async def run_pipeline(request: PipelineRequest) -> dict:
    try:
        output = OUTPUT_ROOT / request.case_id
        result = await run_in_threadpool(
            _pipeline().run,
            request.case_id,
            output,
            request.typhoon_name,
            _case_dir(request),
            request.impact_threshold_ms,
            request.reuse_downscaling,
        )
        return result.as_dict()
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
