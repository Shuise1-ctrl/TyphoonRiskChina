"""Backend-ready service wrapper for the typhoon downscaling engine."""

from dataclasses import dataclass
from pathlib import Path
import re

from typhoon_downscaling.config import (
    TARGET_KM,
    VMAX,
    VMIN,
    TyphoonCase,
    discover_fnl_files,
    resolve_fnl_root,
)
from typhoon_downscaling.core.fixed_grid import extract_fixed_grid_max
from typhoon_downscaling.core.pipeline import run_prediction_pipeline


@dataclass(frozen=True)
class DownscalingResult:
    case_id: str
    prediction_nc: Path
    diagnostics_csv: Path
    fixed_grid_nc: Path
    fixed_grid_png: Path
    track_composite_nc: Path | None = None
    track_composite_png: Path | None = None
    animation_gif: Path | None = None


class TyphoonDownscalingService:
    """Reusable compute service; load one instance per backend worker."""

    def __init__(self, runtime_root):
        self.runtime_root = Path(runtime_root)
        self.model = None
        self.scaler_x = None
        self.scaler_y = None

    @property
    def model_path(self):
        return self.runtime_root / "models" / "direct_unet_model.h5"

    @property
    def scaler_x_path(self):
        return self.runtime_root / "scalers" / "scaler_x.save"

    @property
    def scaler_y_path(self):
        return self.runtime_root / "scalers" / "scaler_y.save"

    def available_cases(self):
        date_root = self.runtime_root / "date"
        if not date_root.is_dir():
            return []
        return sorted(
            path.name
            for path in date_root.iterdir()
            if path.is_dir() and re.fullmatch(r"ID\d{4}", path.name.upper())
        )

    def validate_runtime(self):
        missing = [
            path
            for path in (self.model_path, self.scaler_x_path, self.scaler_y_path)
            if not path.is_file()
        ]
        case_details = {}
        for case_id in self.available_cases():
            case_dir = self.runtime_root / "date" / case_id
            fnl_dir = resolve_fnl_root(case_dir)
            track_candidates = (case_dir / "track.xlsx", case_dir / "工作路径.xlsx")
            track_file = next((path for path in track_candidates if path.is_file()), track_candidates[0])
            fnl_files = discover_fnl_files(fnl_dir)
            if not track_file.is_file():
                missing.append(track_file)
            if not fnl_files:
                missing.append(fnl_dir)
            case_details[case_id] = {
                "fnl_dir": fnl_dir,
                "fnl_count": len(fnl_files),
                "track_file": track_file,
            }
        if missing:
            text = "\n".join(str(path) for path in missing)
            raise FileNotFoundError(f"Required runtime materials are missing:\n{text}")
        return case_details

    def validate_common_runtime(self):
        missing = [
            path
            for path in (self.model_path, self.scaler_x_path, self.scaler_y_path)
            if not path.is_file()
        ]
        if missing:
            text = "\n".join(str(path) for path in missing)
            raise FileNotFoundError(f"Required model materials are missing:\n{text}")

    def load(self):
        if self.model is None:
            self.validate_common_runtime()
            # TensorFlow is intentionally imported only for an actual prediction.
            # Health checks and exposure-only validation therefore stay fast.
            from typhoon_downscaling.core.model_loader import load_model_and_scalers

            self.model, self.scaler_x, self.scaler_y = load_model_and_scalers(
                self.model_path,
                self.scaler_x_path,
                self.scaler_y_path,
            )
        return self

    def build_case(self, case_id, output_root, case_dir=None):
        case_id = str(case_id).strip().upper()
        if not re.fullmatch(r"ID\d{4}", case_id):
            raise ValueError(f"Invalid case id: {case_id}. Expected a value like ID2612.")

        case_dir = (
            Path(case_dir)
            if case_dir is not None
            else self.runtime_root / "date" / case_id
        )
        output_dir = Path(output_root)
        track_candidates = (case_dir / "track.xlsx", case_dir / "工作路径.xlsx")
        track_file = next((path for path in track_candidates if path.is_file()), track_candidates[0])
        return TyphoonCase(
            typhoon_id=case_id,
            case_dir=case_dir,
            fnl_dir=resolve_fnl_root(case_dir),
            track_file=track_file,
            output_dir=output_dir,
            prediction_nc=output_dir / (
                f"{case_id}_center_model_outer_coarse_largefield_oneeye.nc"
            ),
            diagnostics_csv=output_dir / f"{case_id}_hourly_useful_summary.csv",
            fixed_grid_nc=output_dir / f"{case_id}_fixed_grid_max_wind.nc",
            fixed_grid_png=output_dir / f"{case_id}_fixed_grid_max_wind.png",
        )

    def run_prediction(self, case_id, output_root, case_dir=None):
        case = self.build_case(case_id, output_root, case_dir=case_dir)
        case.output_dir.mkdir(parents=True, exist_ok=True)
        fnl_files = discover_fnl_files(case.fnl_dir)
        missing = []
        if not fnl_files:
            missing.append(case.fnl_dir)
        if not case.track_file.is_file():
            missing.append(case.track_file)
        if missing:
            text = "\n".join(str(path) for path in missing)
            raise FileNotFoundError(f"Required case inputs are missing:\n{text}")
        self.load()
        run_prediction_pipeline(
            case=case,
            model=self.model,
            scaler_x=self.scaler_x,
            scaler_y=self.scaler_y,
        )
        return case.prediction_nc

    def run_fixed_grid(self, case_id, output_root, show_plot=False, case_dir=None):
        case = self.build_case(case_id, output_root, case_dir=case_dir)
        if not case.prediction_nc.is_file():
            raise FileNotFoundError(
                f"Prediction NetCDF does not exist: {case.prediction_nc}"
            )
        extract_fixed_grid_max(
            nc_file=case.prediction_nc,
            out_nc=case.fixed_grid_nc,
            out_png=case.fixed_grid_png,
            typhoon_id=case.typhoon_id,
            target_km=TARGET_KM,
            vmin=VMIN,
            vmax=VMAX,
            show_plot=show_plot,
        )
        return case.fixed_grid_nc

    def run_case(self, case_id, output_root, show_plot=False, case_dir=None):
        case = self.build_case(case_id, output_root, case_dir=case_dir)
        self.run_prediction(case.typhoon_id, output_root, case_dir=case.case_dir)
        self.run_fixed_grid(
            case.typhoon_id, output_root, show_plot=show_plot, case_dir=case.case_dir
        )
        from typhoon_downscaling.core.track_composite import build_track_composite
        from typhoon_downscaling.core.animation import generate_wind_circle_animation, AnimationOptions
        composite = build_track_composite(case, show_plot=show_plot)
        # Current job output is authoritative: never reuse another run's NC.
        gif = generate_wind_circle_animation(
            composite["nc"], case.typhoon_id,
            options=AnimationOptions(SHOW_FIGURE=show_plot))
        print("轨迹合成PNG：", composite["png"])
        print("圆形风圈GIF：", gif)
        return DownscalingResult(
            case_id=case.typhoon_id,
            prediction_nc=case.prediction_nc,
            diagnostics_csv=case.diagnostics_csv,
            fixed_grid_nc=case.fixed_grid_nc,
            fixed_grid_png=case.fixed_grid_png,
            track_composite_nc=composite["nc"],
            track_composite_png=composite["png"],
            animation_gif=gif,
        )
