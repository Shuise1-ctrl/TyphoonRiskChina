"""Command-line interface for the full TyphoonRiskChina pipeline."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")

from typhoon_risk_pipeline import TyphoonRiskPipeline


def bundle_root() -> Path:
    return Path(__file__).resolve().parent.parent


def default_risk_root() -> Path:
    return bundle_root().parent.parent / "风险暴露"


def parse_args() -> argparse.Namespace:
    root = bundle_root()
    parser = argparse.ArgumentParser(
        description="Run downscaling, risk exposure and vulnerability analysis end to end"
    )
    parser.add_argument("--case", required=True, help="Case id, for example ID2609")
    parser.add_argument("--typhoon-name", default=None, help="English typhoon name")
    parser.add_argument(
        "--case-dir",
        default=None,
        help="Optional external IDxxxx directory containing FNL and track.xlsx",
    )
    parser.add_argument(
        "--runtime-root",
        default=os.environ.get("TYPHOON_DOWNSCALING_ROOT", str(root / "runtime_data")),
    )
    parser.add_argument(
        "--risk-root",
        default=os.environ.get("TYPHOON_RISK_EXPOSURE_ROOT", str(default_risk_root())),
    )
    parser.add_argument(
        "--output-root",
        default=None,
        help="Pipeline output directory; defaults to outputs/end_to_end/<case>",
    )
    parser.add_argument("--impact-threshold-ms", type=float, default=17.2)
    parser.add_argument(
        "--force-downscaling",
        action="store_true",
        help="Recompute downscaling even when all expected products already exist",
    )
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="Validate all three module inputs without running computation",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    root = bundle_root()
    output_root = Path(args.output_root or root / "outputs" / "end_to_end" / args.case.upper())
    pipeline = TyphoonRiskPipeline(args.runtime_root, args.risk_root, root)
    if args.check_only:
        result = pipeline.validate(args.case, args.case_dir)
    else:
        result = pipeline.run(
            case_id=args.case,
            output_root=output_root,
            typhoon_name=args.typhoon_name,
            case_dir=args.case_dir,
            impact_threshold_ms=args.impact_threshold_ms,
            reuse_downscaling=not args.force_downscaling,
        ).as_dict()
    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
