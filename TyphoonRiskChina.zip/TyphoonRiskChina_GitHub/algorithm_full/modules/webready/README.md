# Bundled downstream source

This directory contains the Python source used by the TyphoonRiskChina downscaling, exposure, vulnerability and reporting stages. Runtime models and scientific data are deliberately excluded.

- Entry point: `backend/end_to_end_cli.py`
- Downscaling implementation: `backend/typhoon_downscaling/`
- Exposure integration: `backend/typhoon_risk_pipeline/`
- Vulnerability and reporting: `backend/typhoon_vulnerability/`

The code accepts an explicit `--runtime-root` for H5/scalers/event inputs and `--risk-root` for exposure Parquet data. Boundary files are resolved from the legacy runtime bundle when present, otherwise from repository `assets/vulnerability/boundaries/`.

Before redistributing this source, confirm ownership and third-party notices described in the repository `LICENSE` and `THIRD_PARTY_NOTICES.md`.
