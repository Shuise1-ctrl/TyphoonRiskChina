# TyphoonRiskChina

TyphoonRiskChina is an auditable Linux workflow for forecast-driven typhoon wind-field downscaling and direct economic-loss assessment in coastal China. It converts six-hourly meteorological forecast fields into high-resolution wind hazard, matches the hazard to residential-building exposure and vulnerability functions, and produces spatial loss summaries, figures, and a PDF assessment report.

> Workflow boundary: FuXi is an external upstream module. This repository does not install or execute FuXi. The scientific workflow starts from an `IDxxxx/FNL/` directory plus `track.xlsx`.

## Pipeline

```text
external forecast provider
  -> 006.nc ... 168.nc + track.xlsx
  -> hourly 3-km downscaling
  -> fixed-grid maximum wind (.nc/.png)
  -> exposure matching and vulnerability
  -> grid_wind.csv + grid_loss.csv
  -> wind/loss maps + JSON manifests + PDF report
```

## Input contract

Each full case must have exactly 28 files at 6 h intervals:

```text
ID2609/
├── FNL/
│   ├── 006.nc
│   ├── 012.nc
│   ├── ...
│   └── 168.nc
└── track.xlsx
```

The repository keeps source code, tests, small reviewer data and compact accepted evidence. Multi-gigabyte FNL sequences, the downscaling H5/scalers and exposure Parquet datasets stay outside ordinary Git history. See `docs/ASSETS.md`.

## Linux installation

```bash
git clone https://github.com/Shuise1-ctrl/TyphoonRiskChina.git
cd TyphoonRiskChina

conda env create -f environment-full.yml
conda activate typhoonriskchina-full
python -m pip install -e .

cp configs/autodl.settings.example.json configs/autodl.settings.json
# Edit the three runtime/data paths in configs/autodl.settings.json.
```

No FuXi environment, ONNX graph or FuXi weight is required by this installation.

## Validate and run Bavi or NOUL

```bash
export TYPHOONRISK_FNL_DIR=/absolute/path/to/ID2609/FNL
export TYPHOONRISK_TRACK_FILE=/absolute/path/to/ID2609/track.xlsx

typhoonriskchina verify-fnl --directory "$TYPHOONRISK_FNL_DIR" --count 28
typhoonriskchina check --config examples/Bavi_ID2609/config.yml --full-assets
typhoonriskchina run --config examples/Bavi_ID2609/config.yml
```

For NOUL, point the two variables to `ID2612` and use `examples/NOUL_ID2612/config.yml`. Convenience wrappers are `scripts/run_bavi.sh` and `scripts/run_noul.sh`.

## Expected outputs

A successful full run writes these reviewer-visible products below the configured run directory:

- downscaled time-varying wind NetCDF;
- `*_fixed_grid_max_wind.nc` and `*_fixed_grid_max_wind.png`;
- an hourly useful-summary CSV;
- `grid_wind.csv` and `grid_loss.csv`;
- `maximum_wind_distribution.png` and `loss_distribution.png`;
- `loss_summary.json`, `result_manifest.json`, `run_manifest.json` and a PDF loss assessment.

## Self-contained lightweight test

```bash
typhoonriskchina run --config examples/case01/config.yml
python -m pytest -q
```

`case01` exercises the installation and risk/report path without external scientific assets. The two full illustrative cases are distributed separately with FNL data and are excluded by `.gitignore` from GitHub.

## HTTP backend

The optional FastAPI backend accepts `track.xlsx` and the 28 FNL files; it no longer accepts a FuXi initial state.

```bash
bash scripts/start_api.sh
python client/submit_job.py --case ID2609 --name Bavi \
  --fnl-dir /data/ID2609/FNL --track /data/ID2609/track.xlsx
```

For multi-gigabyte production inputs, server-side mounted directories or resumable object storage are preferable to browser multipart upload.

## Citation and licence

Author: Zhaodong Wang, ORCID `0009-0007-8419-9246`. Source code is MIT licensed. Meteorological fields, trained models, exposure data and administrative boundaries retain their own licences; verify redistribution rights before public release.
