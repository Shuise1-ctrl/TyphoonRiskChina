# TyphoonRiskChina reviewer example: ReviewerDemo (case01)

Self-contained software verification example; not an observed or operational loss estimate.

## Totals

- exposure_value: 1010000000.000000
- structural_loss: 586.007012
- roof_loss: 1023719.331030
- window_loss: 21700.527970
- nonstructural_loss: 1045419.859000
- total_loss: 1046005.866012
