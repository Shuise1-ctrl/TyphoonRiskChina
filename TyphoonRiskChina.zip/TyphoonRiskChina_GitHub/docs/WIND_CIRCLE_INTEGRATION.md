# 圆形风场集成与输出位置（2026-11-07）

本次修改发生在完整项目的真实计算链中：
`backend/full_stage_cli.py` → `algorithm_full/modules/webready/backend/service.py` →
`typhoon_downscaling/core/track_composite.py` → `core/animation.py`。
原网页的FNL目录和轨迹工作簿操作方式保持可用；计算完成后新增PNG/GIF预览及独立下载项。
前端源码与用于实际启动的 `web/` 编译产物均已更新。

## PNG准确位置

“项目根目录”是包含 `start_windows.bat`、`backend`、`frontend_source` 的目录。
原7z保留了两层目录：`TyphoonRiskChina/TyphoonRiskChina/`，请进入最里面这一层启动。
正常网页运算完成后：

```text
<项目根目录>/data/jobs/<任务ID>/wind_output/ID2618_track_composite_weighted.png
```

计算原始输出同时位于：

```text
<项目根目录>/data/jobs/<任务ID>/wind_output/algorithm/Useful_Plots3/Track_Composite_Weighted/ID2618_track_composite_weighted.png
```

GIF下载副本：

```text
<项目根目录>/data/jobs/<任务ID>/wind_output/wind_circle_track_growth.gif
```

GIF原始输出：

```text
<项目根目录>/data/jobs/<任务ID>/wind_output/algorithm/Useful_Plots3/Track_Composite_Weighted/Animation_Wind_Circle/ID2618_wind_circle_track_growth.gif
```

轨迹合成NC下载副本：`data/jobs/<任务ID>/wind_output/track_composite_weighted.nc`。
任务ID由软件每次创建任务时生成，不是固定的ID2618。运行日志与wind_manifest.json都会记录文件位置。
网页中的“Storm-track composite wind map (PNG)”可直接打开图片；“Moving wind-circle animation (GIF)”打开动画。
整个结果ZIP内PNG路径为 `wind_results/ID2618_track_composite_weighted.png`。
后端为网页提供的 `track_composite_weighted.png` 是同一PNG的固定文件名副本。

## 科学算法与冲突处理

整合此前提供的callable v4轨迹合成模块，以及第二份动画脚本。
相较项目旧配置，预测阶段WIND_CORRECTION_FACTOR从0.95同步为提供代码的1.15，
新增提供代码的分段低风速修正：原值0≤V<10 m/s乘1.35，10≤V<18 m/s乘1.20，其余保持原值。
这是用户提供的新代码参数，会改变预测、最大风速和后续损失计算结果。
保留项目的Windows h5netcdf、路径与输入验证适配。
第二份动画参数优先：350km半径、45km羽化、每记录一帧、6fps、0–75m/s、turbo。
动画逐渐揭示最终合成场，并非逐小时瞬时风场；350km仅为显示半径。
每个网页任务只使用本任务新生成的合成NC，不读取桌面硬编码路径或其他任务的旧修正文件。
轨迹合成不重复应用低风速系数。
原有固定网格最大风速仍用于原交互地图与损失评估，合成场作为新增输出，二者有不同含义。

## 运行与GitHub更新

1. 解压外层ZIP，再解压其中更新后的 `TyphoonRiskChina.7z`。
2. 进入含 `start_windows.bat` 的项目根目录，按原README配置外部模型、归一化器、FNL和暴露数据。
3. 已有完整环境只需补装Pillow：`.venv-full/Scripts/python.exe -m pip install Pillow`。
   全新环境仍使用setup_full_windows.bat；依赖清单已增加Pillow。
4. 启动软件，按原流程上传匹配的FNL清单和轨迹工作簿，运行新任务。
5. GitHub现有仓库只存README、LICENSE与7z，本次更新保留同样的外层结构，
   可用外层更新后的README及TyphoonRiskChina.7z替换仓库对应文件。
   如果希望GitHub直接展示源码，可将内层应用文件解压到仓库，并按原.gitignore排除运行数据、虚拟环境等。

附件不含真实ID2618模型输入，本包交付的是集成代码；没有伪造真实事件的计算结果。
