# 新手安装与运行问题

这份说明记录首次安装和运行时常见的现象、原因及处理方法。文中的路径均为示例；请使用本机项目目录和配置。

## 1. 网页地址无法访问

**原因：** TyphoonRiskChina 在本机运行。服务进程停止或电脑重启后，127.0.0.1:5173 将不再提供网页。

**处理：** 在项目根目录双击 start_windows.bat，等启动窗口显示服务就绪后，再打开 http://127.0.0.1:5173/。使用期间保持启动窗口运行。

## 2. FNL 文件夹不属于 approved local source

**原因：** 网页会验证所选 FNL 文件清单是否与本机已登记案例一致。文件名、大小或修改时间不一致时，验证会失败。

**处理：** 选择完整的 FNL 文件夹，并确认本地服务能读取同一份文件。案例需登记在 data/approved_wind_sources.json，或放在 runtime/cases 下。标准 FNL 序列须包含 28 个预期 NetCDF 文件。不要在验证后移动或修改文件。

## 3. 两项输入已验证，但 Generate wind field 按钮仍不可用

**原因：** 输入验证和计算引擎状态分别检查。按钮还要求 /api/health 显示 wind.local.ready 为 true。

**处理：** 确认完整 Python 环境、模型和两个 scaler 均已安装并按 config.local.json 配置。使用 start_windows.bat 启动服务，让启动脚本加载本机路径配置；修改配置后重启服务、刷新网页，并重新选择和验证两个输入。直接运行 Uvicorn 可能不会加载该配置。

## 4. setup_full_windows.bat 显示 Press any key to continue 后退出

这句话表示批处理暂停后准备结束，不能单独说明安装成功或失败。查看它上方的最后几行安装日志；需要保留错误信息时，可从项目目录的 PowerShell 窗口运行安装脚本。

## 5. 安装 TensorFlow 时遇到 Windows 路径过长错误

深层目录可能导致 TensorFlow 文件超过 Windows 默认路径长度。可将项目放在较短目录（例如 C:\TyphoonRiskChina）后重试；不必因此直接修改系统全局设置。

## 6. 刷新网页后结果卡片消失

网页展示状态可能在刷新时重置。任务编号仍可用于恢复结果：访问带有 ?resume=<job_id> 的网页地址。新版本也会尝试恢复正在运行的风场任务。

## 7. 风场任务提示 HTTP 500

状态查询请求失败时，任务仍可能在后台运行。先在 data/jobs/<job_id>/job.json 和 calculation.log 查看真实状态，再决定是否重试；大体积 FNL 输入重复计算会耗时较长。可使用 ?resume=<job_id> 恢复任务页面。

## 8. 风场图和损失图边界不一致

风场图和损失图使用统一的有效覆盖区掩膜。地图外观只反映有风场覆盖的网格；损失评估仍按本地配置的省级暴露和网格数据执行。

## 本机科学数据说明

GitHub 上传副本不包含 FNL、模型、scaler、暴露度数据、虚拟环境、本机任务结果或本机配置。请根据 runtime/README.md 和 config.local.json.example 在每台电脑上单独配置这些资产，并在公开前确认数据的再分发许可。