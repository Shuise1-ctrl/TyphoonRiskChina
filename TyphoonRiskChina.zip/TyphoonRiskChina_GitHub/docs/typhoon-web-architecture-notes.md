# TyphoonRiskChina web architecture

![Integrated local architecture](./typhoon-web-architecture-v2.png)

## Integrated local deployment

The production launcher starts one FastAPI/Uvicorn process on
`http://127.0.0.1:5173`. That process serves both the compiled Vue application
and the `/api` endpoints, so normal use does not require Node.js, Vite, or a
second API port. Scientific work is queued locally, and job inputs, logs,
intermediate files, and final products are written below
`data/jobs/<job_id>/`.

## Browser client

The Vue 3 application provides four switchable views: live weather, the local
historical typhoon archive, wind-field analysis, and loss assessment. The
historical view supports filtering, point-by-point playback, and hover details.
Wind and loss result maps use Leaflet, Canvas-rendered raster data, and local
GeoJSON boundaries with zoom, pan, reset, full-screen, and inspection controls.

For a wind run, the browser submits the selected FNL folder manifest and the
track workbook. The large NetCDF bodies are not copied through the browser;
the backend verifies the manifest against a configured local case directory
and reads those files in place.

## Scientific modules

The wind-field module applies the project-supplied TensorFlow downscaling
pipeline, temporal interpolation, fixed-grid conversion, and time-maximum
aggregation. Its fixed-grid result is handed directly to the loss module.
The loss module combines maximum wind speed with the five-province exposure
and grid collections and applies the vulnerability engine to produce
grid-, city-, and province-level summaries.

Both modules expose browser-sized interactive JSON as well as downloadable
scientific and reporting artifacts such as NetCDF, CSV, PNG, PDF, manifests,
and ZIP packages.

## Storage and network boundary

Repository-relative defaults are used throughout: external scientific assets
belong under `runtime/` (or paths selected in the ignored
`config.local.json`), while generated state belongs under `data/`. The API is
bound to the loopback interface. Only the Windy embed and OpenStreetMap tiles
require runtime Internet access; the calculation backend has no outbound
remote-computation client.
