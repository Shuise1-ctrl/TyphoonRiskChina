# External scientific runtime assets

This directory is intentionally committed without the large scientific files. Ordinary GitHub repositories cannot carry the 28-file FNL sequences, model weights, scalers, or five-province exposure collections, and their upstream redistribution terms must be checked separately.

For the standard repository-relative setup, place the assets as follows:

```text
runtime/
├─ cases/
│  └─ DOLPHIN_ID2613/
│     ├─ config.yml                 # optional for the two-input wind UI
│     ├─ track.xlsx              # required only for full server-side cases
│     └─ FNL/
│        ├─ 006.nc
│        ├─ 012.nc
│        ├─ ...
│        └─ 168.nc                  # exactly 28 files, every 6 hours
├─ downscaling/
│  ├─ models/direct_unet_model.h5
│  └─ scalers/
│     ├─ scaler_x.save
│     └─ scaler_y.save
└─ exposure/
   ├─ 00000 沿海省份风险暴露/
   │  ├─ fujian.parquet
   │  ├─ guangdong.parquet
   │  ├─ hainan.parquet
   │  ├─ jiangsu.parquet
   │  └─ zhejiang.parquet
   └─ 00000 沿海省份网格/
      └─ exactly one <province>_*.parquet file for each of the five provinces
```

If the assets live elsewhere, copy `config.local.json.example` to `config.local.json`, edit the paths, and keep that local file out of Git. A case outside `runtime/cases` can also be registered through an ignored `data/approved_wind_sources.json`; use `data/approved_wind_sources.example.json` as the schema template. Registered `case_dir` values must be absolute paths.

The browser does not upload the 28 large NetCDF bodies. It sends a manifest of names, sizes, and modification times; the local backend then verifies that manifest against a configured, readable case directory on the same computer.

Every FNL file must contain the FuXi array variable
`__xarray_dataarray_variable__` with dimensions `time`, `step`, `level`,
`lat`, and `lon`. After case-insensitive label normalization, the `level`
coordinate must provide `u10`, `v10`, `t2m`, `msl`, and `r850`.
