import asyncio
import json
from pathlib import Path
from types import SimpleNamespace
import zipfile

import pytest

from backend import app as backend


def make_case(root: Path) -> dict:
    case_dir = root / "Bavi_ID2609"
    fnl = case_dir / "FNL"
    fnl.mkdir(parents=True)
    track = case_dir / "track.xlsx"
    track.write_bytes(b"track")
    for name in backend.EXPECTED_FNL_NAMES:
        (fnl / name).write_bytes(b"nc")
    return {
        "case_key": "Bavi_ID2609",
        "case_id": "ID2609",
        "typhoon_name": "Bavi",
        "case_dir": case_dir,
        "track_path": track,
        "fnl_count": 28,
        "fnl_bytes": 56,
        "ready": True,
        "issues": [],
        "warnings": [],
    }


def write_wind_output(root: Path) -> None:
    output = root / "wind_output"
    output.mkdir(parents=True, exist_ok=True)
    (output / "fixed_grid_max_wind.nc").write_bytes(b"netcdf")
    (output / "fixed_grid_max_wind.png").write_bytes(b"png")
    (output / "track.xlsx").write_bytes(b"track")
    backend.atomic_json(
        output / "interactive_wind_map.json",
        {"schema_version": "1.0", "kind": "wind", "warnings": []},
    )
    backend.atomic_json(
        output / "wind_manifest.json",
        {
            "mode": "wind",
            "source": "local-case",
            "case_id": "ID2609",
            "typhoon_name": "Bavi",
            "loss_input_ready": True,
            "summary": {
                "grid_count": 100,
                "valid_grid_count": 90,
                "latitude_count": 10,
                "longitude_count": 10,
                "minimum_wind_ms": 0.5,
                "mean_wind_ms": 12.5,
                "maximum_wind_ms": 31.25,
            },
        },
    )


def write_loss_output(root: Path, total_loss: float = 12_345.0) -> None:
    output = root / "loss_output"
    output.mkdir(parents=True, exist_ok=True)
    backend.atomic_json(
        output / "interactive_loss_map.json",
        {"schema_version": "1.0", "kind": "loss", "warnings": []},
    )
    backend.atomic_json(
        output / "result_manifest.json",
        {
            "schema_version": "3.0",
            "mode": "loss",
            "case_id": "ID2609",
            "typhoon_name": "Bavi",
            "event_id": "202609",
            "impact_threshold_ms": 17.2,
            "impact_detected": True,
            "affected_provinces": ["zhejiang"],
            "totals": {"exposure_value": 1_000_000.0, "total_loss": total_loss},
            "province_results": [
                {
                    "province": "zhejiang",
                    "province_name": "Zhejiang",
                    "grid_count": 100,
                    "grids_at_or_above_impact_threshold": 8,
                    "max_wind_ms": 31.25,
                    "exposure_value": 1_000_000.0,
                    "total_loss": total_loss,
                }
            ],
            "top_cities": [],
        },
    )
    backend.atomic_json(
        output / "stage_manifest.json",
        {"status": "complete", "current_stage": None},
    )


def test_loss_package_is_single_safe_wind_and_track_pair(tmp_path):
    archive = tmp_path / "input.zip"
    with zipfile.ZipFile(archive, "w") as bundle:
        bundle.writestr("fixed_grid_max_wind.nc", b"nc")
        bundle.writestr("track.xlsx", b"track")
        bundle.writestr("wind_manifest.json", b"{}")

    nc_path, track_path = backend.extract_loss_input_package(archive, tmp_path / "input")

    assert nc_path.read_bytes() == b"nc"
    assert track_path.read_bytes() == b"track"

    unsafe = tmp_path / "unsafe.zip"
    with zipfile.ZipFile(unsafe, "w") as bundle:
        bundle.writestr("../outside.nc", b"nc")
        bundle.writestr("track.xlsx", b"track")
    with pytest.raises(ValueError):
        backend.extract_loss_input_package(unsafe, tmp_path / "unsafe-input")
    assert not (tmp_path / "outside.nc").exists()


def test_local_wind_job_queues_only_allowlisted_case(tmp_path, monkeypatch):
    case = make_case(tmp_path / "cases")
    submitted = {}

    class FakeExecutor:
        def submit(self, function, *args):
            submitted["function"] = function
            submitted["args"] = args

    monkeypatch.setattr(backend, "JOBS_ROOT", tmp_path / "jobs")
    monkeypatch.setattr(backend, "FULL_EXECUTOR", FakeExecutor())
    monkeypatch.setattr(backend, "get_full_case", lambda key: case)
    monkeypatch.setattr(
        backend,
        "stage_runtime_status",
        lambda *_args, **_kwargs: {"ready": True, "issues": []},
    )

    state = backend.create_local_wind_job(backend.WindLocalJobRequest(case_key="Bavi_ID2609"))

    assert state["mode"] == "wind"
    assert state["source"] == "server-side-local-case"
    assert "case_dir" not in state
    assert submitted["function"] is backend.run_stage_job
    command = submitted["args"][3]
    assert command[0] == "wind-local"
    assert str(case["case_dir"]) in command


def test_wind_result_has_separate_metrics_and_artifacts(tmp_path):
    root = tmp_path / "job"
    write_wind_output(root)
    backend.make_wind_loss_input_package(root)

    result = backend.build_wind_result(
        "a" * 32,
        root,
        {"case_id": "ID2609", "typhoon_name": "Bavi", "warnings": ["case warning"]},
    )

    assert result["mode"] == "wind"
    assert result["summary"]["maximum_wind_ms"] == pytest.approx(31.25)
    assert result["summary"]["max_wind_ms"] == pytest.approx(31.25)
    assert result["summary"]["loss_input_ready"] is True
    assert result["rows"] == []
    assert result["by_province"] == []
    assert result["by_city"] == []
    assert result["warnings"] == ["case warning"]
    assert result["artifacts"]["fixed-wind-nc"].endswith("/artifacts/fixed-wind-nc")
    assert result["interactive_map_url"].endswith("/artifacts/interactive-map")
    assert result["loss_input_url"].endswith("/artifacts/loss-input-package")


def test_loss_from_wind_rejects_non_wind_or_incomplete_job(tmp_path, monkeypatch):
    jobs = tmp_path / "jobs"
    source_id = "b" * 32
    source = jobs / source_id
    source.mkdir(parents=True)
    backend.atomic_json(
        source / "job.json",
        {"job_id": source_id, "mode": "wind", "status": "running"},
    )
    monkeypatch.setattr(backend, "JOBS_ROOT", jobs)
    monkeypatch.setattr(
        backend,
        "stage_runtime_status",
        lambda *_args, **_kwargs: {"ready": True, "issues": []},
    )

    with pytest.raises(backend.HTTPException) as raised:
        backend.create_loss_from_wind_job(
            backend.LossFromWindRequest(wind_job_id=source_id, impact_threshold_ms=17.2)
        )
    assert raised.value.status_code == 409


def test_loss_from_wind_uses_17_3_when_threshold_is_omitted(tmp_path, monkeypatch):
    jobs = tmp_path / "jobs"
    source_id = "1" * 32
    source = jobs / source_id
    write_wind_output(source)
    backend.atomic_json(
        source / "job.json",
        {
            "job_id": source_id,
            "mode": "wind",
            "status": "complete",
            "case_key": "Bavi_ID2609",
            "case_id": "ID2609",
            "typhoon_name": "Bavi",
            "warnings": [],
        },
    )
    submitted = {}

    class FakeExecutor:
        def submit(self, function, *args):
            submitted["function"] = function
            submitted["args"] = args

    monkeypatch.setattr(backend, "JOBS_ROOT", jobs)
    monkeypatch.setattr(backend, "FULL_EXECUTOR", FakeExecutor())
    monkeypatch.setattr(
        backend,
        "stage_runtime_status",
        lambda *_args, **_kwargs: {"ready": True, "issues": []},
    )

    state = backend.create_loss_from_wind_job(
        backend.LossFromWindRequest(wind_job_id=source_id)
    )

    assert state["impact_threshold_ms"] == pytest.approx(17.3)
    command = submitted["args"][3]
    threshold_index = command.index("--impact-threshold") + 1
    assert float(command[threshold_index]) == pytest.approx(17.3)
    persisted = backend.read_json(jobs / state["job_id"] / "job.json")
    assert persisted["impact_threshold_ms"] == pytest.approx(17.3)


def test_stage_subprocess_is_cpu_only_and_builds_wind_bundle(tmp_path, monkeypatch):
    jobs = tmp_path / "jobs"
    job_id = "c" * 32
    root = jobs / job_id
    root.mkdir(parents=True)
    backend.atomic_json(
        root / "job.json",
        {"job_id": job_id, "mode": "wind", "status": "queued"},
    )
    python = tmp_path / "python.exe"
    python.write_bytes(b"python")
    stage_cli = tmp_path / "full_stage_cli.py"
    stage_cli.write_text("# test", encoding="utf-8")
    captured = {}

    def fake_run(command, **kwargs):
        captured["command"] = command
        captured["kwargs"] = kwargs
        output = Path(command[command.index("--output") + 1])
        write_wind_output(root)
        backend.atomic_json(
            output / "stage_manifest.json",
            {"status": "complete", "current_stage": None},
        )
        kwargs["stdout"].write("mock wind stage\n")
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(backend, "JOBS_ROOT", jobs)
    monkeypatch.setattr(backend, "FULL_TEMP_ROOT", tmp_path / "temp")
    monkeypatch.setattr(backend, "FULL_PYTHON", python)
    monkeypatch.setattr(backend, "FULL_STAGE_CLI", stage_cli)
    monkeypatch.setattr(backend.subprocess, "run", fake_run)

    backend.run_stage_job(
        job_id,
        "wind",
        {"case_id": "ID2609", "typhoon_name": "Bavi"},
        ["wind-nc", "--case", "ID2609"],
    )

    state = backend.read_json(root / "job.json")
    assert state["status"] == "complete"
    assert captured["kwargs"]["shell"] is False
    assert captured["kwargs"]["env"]["CUDA_VISIBLE_DEVICES"] == "-1"
    assert captured["kwargs"]["env"]["TYPHOON_NETCDF_ENGINE"] == "h5netcdf"
    assert captured["kwargs"]["timeout"] == backend.STAGE_TIMEOUT_SECONDS["wind-nc"]
    assert (root / "wind_input_for_loss.zip").is_file()
    assert (root / "typhoon_wind_result.zip").is_file()


def test_artifact_keys_are_isolated_by_job_mode(tmp_path, monkeypatch):
    jobs = tmp_path / "jobs"
    job_id = "d" * 32
    root = jobs / job_id
    write_wind_output(root)
    backend.atomic_json(
        root / "job.json",
        {"job_id": job_id, "mode": "wind", "status": "complete"},
    )
    monkeypatch.setattr(backend, "JOBS_ROOT", jobs)

    response = backend.download_full_artifact(job_id, "fixed-wind-nc")
    assert Path(response.path) == root / "wind_output" / "fixed_grid_max_wind.nc"
    with pytest.raises(backend.HTTPException) as raised:
        backend.download_full_artifact(job_id, "grid-loss")
    assert raised.value.status_code == 404


def test_successful_loss_worker_reads_direct_stage_manifest_and_builds_result(
    tmp_path,
    monkeypatch,
):
    jobs = tmp_path / "jobs"
    job_id = "e" * 32
    root = jobs / job_id
    root.mkdir(parents=True)
    backend.atomic_json(
        root / "job.json",
        {"job_id": job_id, "mode": "loss", "status": "queued"},
    )
    python = tmp_path / "python.exe"
    python.write_bytes(b"python")
    stage_cli = tmp_path / "backend with spaces" / "full_stage_cli.py"
    stage_cli.parent.mkdir(parents=True)
    stage_cli.write_text("# test", encoding="utf-8")

    def fake_run(command, **kwargs):
        write_loss_output(root)
        kwargs["stdout"].write("mock loss stage\n")
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(backend, "JOBS_ROOT", jobs)
    monkeypatch.setattr(backend, "FULL_TEMP_ROOT", tmp_path / "temp")
    monkeypatch.setattr(backend, "FULL_PYTHON", python)
    monkeypatch.setattr(backend, "FULL_STAGE_CLI", stage_cli)
    monkeypatch.setattr(backend.subprocess, "run", fake_run)

    backend.run_stage_job(
        job_id,
        "loss",
        {"case_id": "ID2609", "typhoon_name": "Bavi"},
        ["loss", "--case", "ID2609"],
    )

    state = backend.read_json(root / "job.json")
    result = backend.get_result(job_id)
    assert state["status"] == "complete"
    assert state["totals"]["total_loss"] == pytest.approx(12_345.0)
    assert result["mode"] == "loss"
    assert result["summary"]["totals"]["total_loss"] == pytest.approx(12_345.0)
    assert result["artifacts"]["result-manifest"].endswith("/artifacts/result-manifest")
    assert result["interactive_map_url"].endswith("/artifacts/interactive-map")
    assert (root / "typhoon_loss_result.zip").is_file()


def test_stage_runtime_profiles_do_not_require_unrelated_resources(tmp_path, monkeypatch):
    python = tmp_path / "python.exe"
    python.write_bytes(b"python")
    stage_cli = tmp_path / "web" / "backend" / "full_stage_cli.py"
    stage_cli.parent.mkdir(parents=True)
    stage_cli.write_text("# stage", encoding="utf-8")
    (stage_cli.parent / "interactive_map.py").write_text("# map", encoding="utf-8")
    algorithm = tmp_path / "algorithm"
    algorithm_backend = algorithm / "modules" / "webready" / "backend"
    full_cli = algorithm_backend / "end_to_end_cli.py"
    full_cli.parent.mkdir(parents=True)
    full_cli.write_text("# full", encoding="utf-8")
    fixed_grid = algorithm_backend / "typhoon_downscaling" / "core" / "fixed_grid.py"
    fixed_grid.parent.mkdir(parents=True)
    fixed_grid.write_text("# fixed grid", encoding="utf-8")

    monkeypatch.setattr(backend, "FULL_PYTHON", python)
    monkeypatch.setattr(backend, "FULL_STAGE_CLI", stage_cli)
    monkeypatch.setattr(backend, "FULL_ALGORITHM_ROOT", algorithm)
    monkeypatch.setattr(backend, "FULL_CLI", full_cli)
    monkeypatch.setattr(backend, "FULL_RUNTIME_ROOT", tmp_path / "missing-runtime")
    monkeypatch.setattr(backend, "FULL_EXPOSURE_ROOT", tmp_path / "exposure")

    wind_upload = backend.stage_runtime_status("wind-upload", check_python_packages=False)
    wind_local = backend.stage_runtime_status("wind-local", check_python_packages=False)
    assert wind_upload["ready"] is True
    assert wind_local["ready"] is False

    exposure_dir = backend.FULL_EXPOSURE_ROOT / backend.FULL_EXPOSURE_DIR_NAME
    grid_dir = backend.FULL_EXPOSURE_ROOT / backend.FULL_GRID_DIR_NAME
    exposure_dir.mkdir(parents=True)
    grid_dir.mkdir(parents=True)
    for province in backend.FULL_PROVINCES:
        (exposure_dir / f"{province}.parquet").write_bytes(b"parquet")
        (grid_dir / f"{province}_grid.parquet").write_bytes(b"parquet")
    boundary_dir = algorithm / "assets" / "vulnerability" / "boundaries"
    boundary_dir.mkdir(parents=True)
    for name in (
        "coastal_provinces.geojson",
        "coastal_prefecture_cities.geojson",
        "china_provinces_with_taiwan.geojson",
        "nine_dash_line.geojson",
    ):
        (boundary_dir / name).write_text("{}", encoding="utf-8")
    for source in (
        algorithm_backend / "typhoon_risk_pipeline" / "exposure.py",
        algorithm_backend / "typhoon_vulnerability" / "engine.py",
    ):
        source.parent.mkdir(parents=True, exist_ok=True)
        source.write_text("# source", encoding="utf-8")

    loss = backend.stage_runtime_status("loss", check_python_packages=False)
    assert loss["ready"] is True
    assert not any("model" in issue or "scaler" in issue for issue in loss["issues"])


def test_stage_timeout_is_recorded_without_hanging_the_job_queue(tmp_path, monkeypatch):
    jobs = tmp_path / "jobs"
    job_id = "f" * 32
    root = jobs / job_id
    root.mkdir(parents=True)
    backend.atomic_json(
        root / "job.json",
        {"job_id": job_id, "mode": "wind", "status": "queued"},
    )
    python = tmp_path / "python.exe"
    python.write_bytes(b"python")
    stage_cli = tmp_path / "full_stage_cli.py"
    stage_cli.write_text("# test", encoding="utf-8")

    def fake_timeout(command, **kwargs):
        raise backend.subprocess.TimeoutExpired(command, kwargs["timeout"])

    monkeypatch.setattr(backend, "JOBS_ROOT", jobs)
    monkeypatch.setattr(backend, "FULL_TEMP_ROOT", tmp_path / "temp")
    monkeypatch.setattr(backend, "FULL_PYTHON", python)
    monkeypatch.setattr(backend, "FULL_STAGE_CLI", stage_cli)
    monkeypatch.setattr(backend.subprocess, "run", fake_timeout)

    backend.run_stage_job(
        job_id,
        "wind",
        {"case_id": "ID2609", "typhoon_name": "Bavi"},
        ["wind-nc", "--case", "ID2609"],
    )

    state = backend.read_json(root / "job.json")
    assert state["status"] == "failed"
    assert state["error"]["type"] == "TimeoutExpired"
    assert state["error"]["timeout_seconds"] == backend.STAGE_TIMEOUT_SECONDS["wind-nc"]
    assert "[TIMEOUT]" in (root / "calculation.log").read_text(encoding="utf-8")


@pytest.mark.parametrize(
    "unsafe",
    ["/outside.nc", "\\outside.nc", "C:\\outside.nc", "\\\\server\\share\\x.nc", "../x.nc"],
)
def test_safe_relative_path_rejects_rooted_unc_drive_and_parent_paths(unsafe):
    with pytest.raises(ValueError):
        backend.safe_relative_path(unsafe)
