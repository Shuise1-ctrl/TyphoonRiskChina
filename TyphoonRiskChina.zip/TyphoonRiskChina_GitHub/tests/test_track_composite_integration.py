"""Synthetic prediction -> real postprocessing -> API artifacts and ZIP."""
from pathlib import Path
import sys
import json
import zipfile
import numpy as np
import pandas as pd
import xarray as xr
from PIL import Image
from fastapi.testclient import TestClient
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'algorithm_full/modules/webready/backend'))
sys.path.insert(0, str(ROOT / 'backend'))
sys.path.insert(0, str(ROOT / 'algorithm_full/src'))
from service import TyphoonDownscalingService
from backend.full_stage_cli import publish_track_products
from backend import app as web


def test_service_products_downloadable(tmp_path, monkeypatch):
    monkeypatch.setenv('TYPHOON_NETCDF_ENGINE', 'scipy')
    job_id = 'a' * 32
    jobs = tmp_path / 'jobs'
    root = jobs / job_id
    output = root / 'wind_output'
    algorithm = output / 'algorithm'
    algorithm.mkdir(parents=True)
    service = TyphoonDownscalingService(tmp_path / 'runtime')
    def synthetic_prediction(case_id, output_root, case_dir=None):
        case = service.build_case(case_id, output_root, case_dir=case_dir)
        lat, lon = np.meshgrid(np.linspace(20, 20.3, 6), np.linspace(119, 119.4, 8), indexing='ij')
        ds = xr.Dataset({
            'wind_speed_1h_max_pred': (('time', 'south_north', 'west_east'), np.full((3, 6, 8), 20., dtype='float32')),
            'XLAT': (('time', 'south_north', 'west_east'), np.array([lat+t*.03 for t in range(3)])),
            'XLONG': (('time', 'south_north', 'west_east'), np.array([lon+t*.03 for t in range(3)])),
            'storm_center_lat': ('time', [20.15, 20.18, 20.21]),
            'storm_center_lon': ('time', [119.2, 119.23, 119.26]),
        }, coords={'time': pd.date_range('2026-07-01', periods=3, freq='h'), 'lead_hour': ('time', [0, 1, 2])})
        ds.to_netcdf(case.prediction_nc, engine='scipy')
        case.diagnostics_csv.write_text('lead_time,pred_max_wind\n0,20\n')
        return case.prediction_nc
    monkeypatch.setattr(service, 'run_prediction', synthetic_prediction)
    result = service.run_case('ID2618', algorithm)
    assert result.track_composite_png.name == 'ID2618_track_composite_weighted.png'
    with Image.open(result.animation_gif) as gif:
        assert gif.n_frames == 3
    with xr.open_dataset(result.track_composite_nc) as ds:
        np.testing.assert_allclose(ds.track_composite_wind.values[np.isfinite(ds.track_composite_wind)], 20., atol=1e-5)
    files = publish_track_products(result, output, 'ID2618')
    assert files['track_composite_png'] == 'ID2618_track_composite_weighted.png'
    (output/'wind_manifest.json').write_text(json.dumps({'case_id':'ID2618','typhoon_name':'Test','files':files,'summary':{}}))
    (root/'job.json').write_text(json.dumps({'mode':'wind','status':'complete'}))
    payload = web.build_wind_result(job_id, root, {'case_id':'ID2618','typhoon_name':'Test'})
    monkeypatch.setattr(web, 'JOBS_ROOT', jobs)
    with TestClient(web.app) as client:
        for key, media in [('track-composite-map','image/png'),('wind-circle-gif','image/gif'),('track-composite-nc','application/x-netcdf')]:
            response = client.get(payload['artifacts'][key])
            assert response.status_code == 200, response.text
            assert response.headers['content-type'].startswith(media)
    with zipfile.ZipFile(web.make_wind_result_zip(root)) as z:
        names=z.namelist()
        assert 'wind_results/ID2618_track_composite_weighted.png' in names
        assert 'wind_results/wind_circle_track_growth.gif' in names
        assert 'wind_results/track_composite_weighted.nc' in names
