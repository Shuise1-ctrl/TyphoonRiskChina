import json
import math
import os
from pathlib import Path
import re

import numpy as np
import pandas as pd
import pytest
import xarray as xr

from backend.interactive_map import (
    atomic_write_json,
    build_loss_payload,
    build_wind_payload,
    generate_loss_json,
    generate_wind_json,
    read_track_points,
)


REAL_VALIDATION_ROOT = Path(
    os.environ.get("TYPHOON_TEST_VALIDATION_ROOT", "__external_validation_not_configured__")
)
REAL_WIND = (
    REAL_VALIDATION_ROOT
    / "Bavi_prediction_to_wind_retry"
    / "fixed_grid_max_wind.nc"
)
REAL_TRACK = REAL_VALIDATION_ROOT / "Bavi_prediction_to_wind_retry" / "track.xlsx"
REAL_LOSS = REAL_VALIDATION_ROOT / "Bavi_wind_to_loss" / "grid_loss.csv"
REAL_GRID_WIND = REAL_VALIDATION_ROOT / "Bavi_wind_to_loss" / "grid_wind.csv"


def write_track(path: Path) -> None:
    rows = [
        ["ID2609", None, None, None, None, None],
        [None, None, None, None, None, None],
        ["time", "strength", "LAT", "LONG", "slp", "uv"],
        ["2026.07.12  08：00", "强台风", 20.0, 120.0, 970, 35],
        ["2026.07.12  11：00", "Typhoon", 20.5, 119.5, 965, 38],
    ]
    pd.DataFrame(rows).to_excel(path, header=False, index=False)


def recursively_assert_json_safe(value):
    if isinstance(value, dict):
        for item in value.values():
            recursively_assert_json_safe(item)
    elif isinstance(value, list):
        for item in value:
            recursively_assert_json_safe(item)
    elif isinstance(value, float):
        assert math.isfinite(value)
    elif isinstance(value, str):
        assert not re.match(r"^[A-Za-z]:[\\/]", value)


def write_administrative_boundaries(path: Path) -> Path:
    path.mkdir()
    polygon = {
        "type": "Polygon",
        "coordinates": [[[109.0, 19.0], [112.0, 19.0], [112.0, 22.0], [109.0, 22.0], [109.0, 19.0]]],
    }
    (path / "coastal_provinces.geojson").write_text(
        json.dumps(
            {
                "type": "FeatureCollection",
                "features": [
                    {
                        "type": "Feature",
                        "properties": {"province_name": "Guangdong"},
                        "geometry": polygon,
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    (path / "coastal_prefecture_cities.geojson").write_text(
        json.dumps(
            {
                "type": "FeatureCollection",
                "features": [
                    {
                        "type": "Feature",
                        "properties": {
                            "province_name": "Guangdong",
                            "city_name_en": "Guangzhou",
                        },
                        "geometry": polygon,
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    return path


def test_wind_payload_preserves_block_max_and_track(tmp_path):
    lat = np.arange(5, dtype=np.float32) + 20
    lon = np.arange(7, dtype=np.float32) + 110
    wind = np.arange(35, dtype=np.float32).reshape(5, 7)
    wind[1, 1] = 99.0
    wind[4, 6] = np.nan
    valid = np.full((5, 7), 4, dtype=np.int16)
    valid[1, 1] = 12
    dataset = xr.Dataset(
        {
            "max_wind_speed": (("lat", "lon"), wind),
            "valid_count": (("lat", "lon"), valid),
        },
        coords={"lat": lat, "lon": lon},
        attrs={
            "typhoon_id": "ID2609",
            "source_file": r"C:\private\absolute\source.nc",
        },
    )
    netcdf = tmp_path / "fixed.nc"
    dataset.to_netcdf(netcdf, engine="h5netcdf")
    track = tmp_path / "track.xlsx"
    write_track(track)

    payload = build_wind_payload(
        netcdf, track_path=track, case_id="ID9999", max_dimension=3
    )

    assert payload["grid"]["shape"] == [3, 3]
    assert max(
        value
        for value in payload["layers"]["max_wind_ms"]["values"]
        if value is not None
    ) == 99.0
    assert max(payload["layers"]["valid_count"]["values"]) == 12
    assert sum(payload["layers"]["source_count"]["values"]) == 34
    assert payload["track"]["source_id"] == "ID2609"
    assert payload["warnings"] == [
        "Track source ID ID2609 differs from task case ID ID9999; "
        "the source track was preserved unchanged."
    ]
    assert payload["track"]["points"][0] == {
        "lat": 20.0,
        "lon": 120.0,
        "time": "2026-07-12T08:00:00",
        "wind_ms": 35.0,
        "pressure_hpa": 970.0,
        "strength": "Severe Typhoon",
    }
    assert "source_file" not in json.dumps(payload)
    recursively_assert_json_safe(payload)


def test_loss_payload_preserves_sums_maxima_counts_and_nulls(tmp_path):
    loss = pd.DataFrame(
        {
            "lon": [110.0, 110.1, 111.0, 111.1, np.nan],
            "lat": [20.0, 20.1, 21.0, 21.1, 22.0],
            "exposure_value": [100.0, 200.0, 300.0, 400.0, 999.0],
            "max_wind_ms": [10.0, 30.0, 20.0, 40.0, 100.0],
            "total_loss": [1.0, 2.0, 3.0, 4.0, 999.0],
        }
    )
    loss_path = tmp_path / "grid_loss.csv"
    loss.to_csv(loss_path, index=False)

    payload = build_loss_payload(loss_path, max_dimension=2)

    assert payload["grid"]["shape"] == [2, 2]
    assert sum(value or 0 for value in payload["layers"]["total_loss"]["values"]) == 10
    assert sum(value or 0 for value in payload["layers"]["exposure_value"]["values"]) == 1000
    assert max(value for value in payload["layers"]["max_wind_ms"]["values"] if value) == 40
    assert sum(payload["layers"]["source_count"]["values"]) == 4
    assert payload["summary"]["total_loss"] == 10
    assert payload["layers"]["total_loss"]["color_scale"]["type"] == "logarithmic"
    recursively_assert_json_safe(payload)


def test_loss_payload_can_take_wind_from_separate_csv(tmp_path):
    loss_path = tmp_path / "grid_loss.csv"
    wind_path = tmp_path / "grid_wind.csv"
    pd.DataFrame(
        {
            "lon": [110.0, 110.1],
            "lat": [20.0, 20.1],
            "exposure_value": [100.0, 200.0],
            "total_loss": [1.0, 2.0],
        }
    ).to_csv(loss_path, index=False)
    pd.DataFrame(
        {
            "lon": [110.0, 110.1],
            "lat": [20.0, 20.1],
            "max_wind_ms": [12.0, 42.0],
        }
    ).to_csv(wind_path, index=False)

    payload = build_loss_payload(loss_path, grid_wind_path=wind_path, max_dimension=1)

    assert payload["layers"]["max_wind_ms"]["values"] == [42.0]


def test_wind_and_loss_payloads_include_english_administrative_cells(tmp_path):
    boundary_dir = write_administrative_boundaries(tmp_path / "boundaries")
    netcdf = tmp_path / "fixed.nc"
    xr.Dataset(
        {"max_wind_speed": (("lat", "lon"), np.ones((2, 2), dtype=np.float32))},
        coords={"lat": [20.0, 23.0], "lon": [110.0, 114.0]},
    ).to_netcdf(netcdf, engine="h5netcdf")
    wind = build_wind_payload(netcdf, max_dimension=2, boundary_dir=boundary_dir)

    loss_path = tmp_path / "grid_loss.csv"
    pd.DataFrame(
        {
            "lon": [110.0, 114.0],
            "lat": [20.0, 23.0],
            "exposure_value": [100.0, 200.0],
            "max_wind_ms": [20.0, 30.0],
            "total_loss": [1.0, 2.0],
        }
    ).to_csv(loss_path, index=False)
    loss = build_loss_payload(loss_path, max_dimension=2, boundary_dir=boundary_dir)

    for payload in (wind, loss):
        assert payload["schema_version"] == "1.1"
        assert payload["administrative"]["encoding"] == "flat-row-major"
        assert "Guangdong" in payload["administrative"]["province"]["values"]
        assert "Guangzhou" in payload["administrative"]["city"]["values"]
        assert len(payload["administrative"]["province"]["values"]) == math.prod(
            payload["grid"]["shape"]
        )
        assert len(payload["administrative"]["city"]["values"]) == math.prod(
            payload["grid"]["shape"]
        )


def test_strict_atomic_writer_replaces_file_without_nan_or_temp_files(tmp_path):
    output = tmp_path / "nested" / "map.json"
    output.parent.mkdir()
    output.write_text("old", encoding="utf-8")

    atomic_write_json({"finite": 1.0, "missing": float("nan")}, output)

    assert json.loads(output.read_text(encoding="utf-8")) == {
        "finite": 1.0,
        "missing": None,
    }
    assert list(output.parent.glob("*.tmp")) == []


def test_track_reader_rejects_workbook_without_coordinate_header(tmp_path):
    workbook = tmp_path / "bad.xlsx"
    pd.DataFrame([["time", "wind"], ["today", 20]]).to_excel(
        workbook, header=False, index=False
    )
    with pytest.raises(ValueError, match="no track table"):
        read_track_points(workbook)


@pytest.mark.skipif(
    not all(path.is_file() for path in (REAL_WIND, REAL_TRACK, REAL_LOSS, REAL_GRID_WIND)),
    reason="real Bavi validation outputs are not available on this machine",
)
def test_real_bavi_payloads_are_compact_and_keep_scientific_totals(tmp_path):
    wind_json = generate_wind_json(
        REAL_WIND,
        tmp_path / "wind-map.json",
        track_path=REAL_TRACK,
        case_id="ID2609",
    )
    loss_json = generate_loss_json(
        REAL_LOSS,
        tmp_path / "loss-map.json",
        grid_wind_path=REAL_GRID_WIND,
        track_path=REAL_TRACK,
        case_id="ID2609",
    )
    wind = json.loads(wind_json.read_text(encoding="utf-8"))
    loss = json.loads(loss_json.read_text(encoding="utf-8"))

    assert max(wind["grid"]["shape"]) <= 220
    assert max(loss["grid"]["shape"]) <= 220
    assert wind["summary"]["maximum_wind_ms"] == pytest.approx(64.96154022216797)
    assert loss["summary"]["total_loss"] == pytest.approx(16_700_326.046929128)
    # The fixed wind grid peaks over water at about 64.96 m/s, while the
    # exposure/loss grid contains only covered land records and peaks lower.
    assert loss["summary"]["maximum_wind_ms"] == pytest.approx(27.657220077170575)
    assert wind["track"]["source_id"] == "ID2421"
    assert loss["track"]["source_id"] == "ID2421"
    assert wind["warnings"] == loss["warnings"]
    assert "ID2421 differs from task case ID ID2609" in wind["warnings"][0]
    assert 0 < wind_json.stat().st_size < 3_000_000
    assert 0 < loss_json.stat().st_size < 3_000_000
    recursively_assert_json_safe(wind)
    recursively_assert_json_safe(loss)
