"""Optional live smoke test for a running http://localhost:5173 service."""

import json
import shutil
import time
from urllib.request import Request, urlopen

from tests.test_combined_server import APP_ROOT, multipart_body


BASE_URL = "http://127.0.0.1:5173"


def main():
    example = APP_ROOT / "example_folder" / "small_input"
    body, content_type = multipart_body(
        [
            ("paths", "typhoon_example/small_input/track.csv"),
            ("paths", "typhoon_example/small_input/exposure.csv"),
            ("case_id", "case01"),
            ("typhoon_name", "ReviewerDemo"),
            ("impact_threshold_ms", "17.2"),
        ],
        [
            ("files", "track.csv", example / "track.csv"),
            ("files", "exposure.csv", example / "exposure.csv"),
        ],
    )
    request = Request(
        f"{BASE_URL}/api/jobs",
        data=body,
        method="POST",
        headers={"Content-Type": content_type},
    )
    job_id = None
    terminal = False
    try:
        with urlopen(request, timeout=10) as response:
            created = json.load(response)
        job_id = created["job_id"]

        for _ in range(600):
            with urlopen(f"{BASE_URL}/api/jobs/{job_id}", timeout=5) as response:
                state = json.load(response)
            if state["status"] in {"complete", "failed"}:
                terminal = True
                break
            time.sleep(0.1)
        if state["status"] != "complete":
            raise RuntimeError(state)

        with urlopen(f"{BASE_URL}/api/jobs/{job_id}/result", timeout=5) as response:
            result = json.load(response)
        total_loss = result["summary"]["totals"]["total_loss"]
        expected = 1_046_005.8660122628
        if abs(total_loss - expected) >= 0.000001:
            raise RuntimeError(f"unexpected total loss: {total_loss}")
        print(json.dumps({"status": "ok", "total_loss": total_loss}))
    finally:
        if job_id and terminal:
            shutil.rmtree(APP_ROOT / "data" / "jobs" / job_id, ignore_errors=True)


if __name__ == "__main__":
    main()
