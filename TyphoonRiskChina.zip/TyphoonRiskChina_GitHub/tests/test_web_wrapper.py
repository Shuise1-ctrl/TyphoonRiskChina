import csv
from pathlib import Path
import tempfile
import unittest

from backend.app import normalize_and_validate_csv, safe_relative_path
from typhoonriskchina.vulnerability import component_losses


class WebWrapperTests(unittest.TestCase):
    def test_formula_regression(self):
        rows = [
            (17.6, 180_000_000),
            (15.8, 260_000_000),
            (12.4, 320_000_000),
            (8.9, 140_000_000),
            (6.2, 110_000_000),
        ]
        total = sum(component_losses(wind, exposure)["total_loss"] for wind, exposure in rows)
        self.assertAlmostEqual(total, 1_046_005.8660122628, places=6)

    def test_documented_track_aliases_are_normalized(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "track.csv"
            source.write_text(
                "time,latitude,longitude,wind_ms\n"
                "2026-08-01T00:00:00+00:00,20,120,15\n"
                "2026-08-01T06:00:00+00:00,21,119,18\n",
                encoding="utf-8",
            )
            normalized, warnings = normalize_and_validate_csv(source, "track", root)
            with normalized.open("r", encoding="utf-8-sig", newline="") as stream:
                fields = next(csv.reader(stream))
            self.assertEqual(fields[:3], ["time", "lat", "lon"])
            self.assertTrue(warnings)

    def test_negative_exposure_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "exposure.csv"
            source.write_text(
                "grid_id,province,city,wind_speed_ms,exposure_value\n"
                "A,Fujian,Xiamen,20,-1\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "non-negative"):
                normalize_and_validate_csv(source, "exposure", root)

    def test_path_traversal_is_rejected(self):
        with self.assertRaises(ValueError):
            safe_relative_path("../outside.csv")


if __name__ == "__main__":
    unittest.main()
