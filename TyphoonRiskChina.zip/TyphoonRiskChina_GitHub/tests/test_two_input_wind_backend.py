import asyncio
from io import BytesIO
import json
import os
from pathlib import Path
import time

from fastapi import UploadFile
from openpyxl import Workbook
import pytest

from backend import app as backend


def workbook_bytes(
    case_label: str,
    *,
    latitude: float = 20.0,
    include_second_row: bool = True,
) -> bytes:
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.append([case_label])
    worksheet.append([])
    worksheet.append(["time", "strength", "LAT", "LONG", "slp", "uv"])
    worksheet.append(["2026.07.02 08:00", "Tropical storm", latitude, 130.0, 998, 18])
    if include_second_row:
        worksheet.append(["2026.07.02 11:00", "Tropical storm", latitude + 0.2, 129.5, 995, 20])
    stream = BytesIO()
    workbook.save(stream)
    workbook.close()
    return stream.getvalue()


def make_case(
    cases_root: Path,
    *,
    folder: str,
    case_id: str,
    name: str,
    size_offset: int,
    modified_ms: int,
) -> dict:
    case_dir = cases_root / folder
    fnl_dir = case_dir / "FNL"
    fnl_dir.mkdir(parents=True)
    (case_dir / "track.xlsx").write_bytes(workbook_bytes(case_id))
    (case_dir / "config.yml").write_text(
        "schema_version: 1\n"
        "mode: full\n"
        "case:\n"
        f"  id: {case_id}\n"
        f"  name: {name}\n",
        encoding="utf-8",
    )
    for index, filename in enumerate(backend.EXPECTED_FNL_NAMES):
        path = fnl_dir / filename
        path.write_bytes(b"n" * (size_offset + index + 1))
        timestamp = (modified_ms + index * 1000) / 1000
        os.utime(path, (timestamp, timestamp))
    return {
        "folder": folder,
        "case_id": case_id,
        "typhoon_name": name,
        "case_dir": case_dir,
        "fnl_dir": fnl_dir,
    }


def fnl_manifest(fnl_dir: Path) -> list[dict]:
    items = []
    for path in sorted(fnl_dir.iterdir()):
        stat_result = path.stat()
        items.append(
            {
                "path": f"FNL/{path.name}",
                "size": stat_result.st_size,
                "last_modified_ms": stat_result.st_mtime_ns // 1_000_000,
            }
        )
    return items


def write_source_registry(path: Path, *sources: dict) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({"schema_version": 1, "sources": list(sources)}, ensure_ascii=False),
        encoding="utf-8",
    )
    return path


def configure_sources(tmp_path: Path, monkeypatch, *, include_noul: bool = False):
    cases_root = tmp_path / "cases"
    bavi = make_case(
        cases_root,
        folder="Bavi_ID2609",
        case_id="ID2609",
        name="Bavi",
        size_offset=10,
        modified_ms=1_783_849_348_000,
    )
    noul = None
    if include_noul:
        noul = make_case(
            cases_root,
            folder="NOUL_ID2612",
            case_id="ID2612",
            name="NOUL",
            size_offset=100,
            modified_ms=1_784_939_986_000,
        )
    monkeypatch.setattr(backend, "FULL_CASES_ROOT", cases_root)
    monkeypatch.setattr(backend, "FULL_BUNDLE_ROOT", tmp_path)
    monkeypatch.setattr(backend, "FULL_TEMP_ROOT", tmp_path / "temp")
    monkeypatch.setattr(backend, "APPROVED_WIND_SOURCES_PATH", tmp_path / "missing-registry.json")
    monkeypatch.setattr(backend, "_WIND_INPUT_TOKENS", {})
    return bavi, noul


def validate_inputs(manifest: list[dict], track: bytes, *, root_name: str = "FNL"):
    upload = UploadFile(filename="uploaded-track.xlsx", file=BytesIO(track))
    return asyncio.run(
        backend.validate_wind_inputs(
            root_name=root_name,
            fnl_manifest=json.dumps(manifest),
            track_file=upload,
        )
    )


def test_arbitrary_valid_track_is_accepted_and_fnl_config_controls_identity(
    tmp_path,
    monkeypatch,
):
    bavi, _ = configure_sources(tmp_path, monkeypatch)
    uploaded_track = workbook_bytes("ID2421", latitude=11.0)
    assert uploaded_track != (bavi["case_dir"] / "track.xlsx").read_bytes()

    response = validate_inputs(fnl_manifest(bavi["fnl_dir"]), uploaded_track)

    assert response["status"] == "ready"
    assert response["mode"] == "fnl-folder-plus-track-workbook"
    assert response["identity"] == {"case_id": "ID2609", "typhoon_name": "Bavi"}
    assert response["fnl"]["file_count"] == 28
    assert response["verified_in_place"] is True
    assert response["copy_required"] is False
    assert "warnings" not in response
    record = backend._WIND_INPUT_TOKENS[response["input_token"]]
    assert any("internal ID differs" in item for item in record["internal_warnings"])
    assert Path(record["track_path"]).read_bytes() == uploaded_track
    assert str(bavi["fnl_dir"]) not in repr(response)


def test_fnl_only_source_needs_no_server_track_or_config(tmp_path, monkeypatch):
    cases_root = tmp_path / "cases"
    source = make_case(
        cases_root,
        folder="NewEvent_ID2701",
        case_id="ID2701",
        name="NewEvent",
        size_offset=40,
        modified_ms=1_785_000_000_000,
    )
    (source["case_dir"] / "track.xlsx").unlink()
    (source["case_dir"] / "config.yml").unlink()
    monkeypatch.setattr(backend, "FULL_CASES_ROOT", cases_root)
    monkeypatch.setattr(backend, "FULL_BUNDLE_ROOT", tmp_path)
    monkeypatch.setattr(backend, "FULL_TEMP_ROOT", tmp_path / "temp")
    monkeypatch.setattr(backend, "_WIND_INPUT_TOKENS", {})

    response = validate_inputs(
        fnl_manifest(source["fnl_dir"]),
        workbook_bytes("ID9999"),
    )

    assert response["identity"] == {"case_id": "ID2701", "typhoon_name": "NewEvent"}
    assert response["fnl"]["file_count"] == 28


def test_exact_registered_source_outside_legacy_root_is_accepted(tmp_path, monkeypatch):
    source = make_case(
        tmp_path / "external-sources",
        folder="TyphoonRiskChina_ID2613_DOLPHIN_WindAdjusted_20260808",
        case_id="ID9999",
        name="Wrong config identity",
        size_offset=70,
        modified_ms=1_786_150_200_000,
    )
    (source["case_dir"] / "config.yml").unlink()
    registry = write_source_registry(
        tmp_path / "approved-wind-sources.json",
        {
            "case_key": "DOLPHIN_ID2613",
            "case_id": "ID2613",
            "typhoon_name": "DOLPHIN",
            "case_dir": str(source["case_dir"]),
        },
    )
    legacy_root = tmp_path / "legacy-cases"
    legacy_root.mkdir()
    monkeypatch.setattr(backend, "FULL_CASES_ROOT", legacy_root)
    monkeypatch.setattr(backend, "FULL_TEMP_ROOT", tmp_path / "temp")
    monkeypatch.setattr(backend, "APPROVED_WIND_SOURCES_PATH", registry)
    monkeypatch.setattr(backend, "_WIND_INPUT_TOKENS", {})

    response = validate_inputs(
        fnl_manifest(source["fnl_dir"]),
        workbook_bytes("ID2613"),
    )

    assert response["status"] == "ready"
    assert response["identity"] == {"case_id": "ID2613", "typhoon_name": "DOLPHIN"}
    assert response["fnl"]["file_count"] == 28


def test_unregistered_external_source_remains_rejected(tmp_path, monkeypatch):
    source = make_case(
        tmp_path / "external-sources",
        folder="DOLPHIN_ID2613",
        case_id="ID2613",
        name="DOLPHIN",
        size_offset=80,
        modified_ms=1_786_150_300_000,
    )
    legacy_root = tmp_path / "legacy-cases"
    legacy_root.mkdir()
    monkeypatch.setattr(backend, "FULL_CASES_ROOT", legacy_root)
    monkeypatch.setattr(backend, "FULL_TEMP_ROOT", tmp_path / "temp")
    monkeypatch.setattr(backend, "APPROVED_WIND_SOURCES_PATH", tmp_path / "missing.json")
    monkeypatch.setattr(backend, "_WIND_INPUT_TOKENS", {})

    with pytest.raises(backend.HTTPException) as raised:
        validate_inputs(fnl_manifest(source["fnl_dir"]), workbook_bytes("ID2613"))
    assert raised.value.status_code == 400
    assert "does not match any approved" in raised.value.detail


def test_registered_source_must_remain_registered_until_job_creation(tmp_path, monkeypatch):
    source = make_case(
        tmp_path / "external-sources",
        folder="DOLPHIN_ID2613",
        case_id="ID2613",
        name="DOLPHIN",
        size_offset=90,
        modified_ms=1_786_150_400_000,
    )
    registry = write_source_registry(
        tmp_path / "approved-wind-sources.json",
        {
            "case_key": "DOLPHIN_ID2613",
            "case_id": "ID2613",
            "typhoon_name": "DOLPHIN",
            "case_dir": str(source["case_dir"]),
        },
    )
    legacy_root = tmp_path / "legacy-cases"
    legacy_root.mkdir()
    monkeypatch.setattr(backend, "FULL_CASES_ROOT", legacy_root)
    monkeypatch.setattr(backend, "FULL_TEMP_ROOT", tmp_path / "temp")
    monkeypatch.setattr(backend, "APPROVED_WIND_SOURCES_PATH", registry)
    monkeypatch.setattr(backend, "_WIND_INPUT_TOKENS", {})
    monkeypatch.setattr(
        backend,
        "stage_runtime_status",
        lambda *_args, **_kwargs: {"ready": True, "issues": []},
    )

    validation = validate_inputs(fnl_manifest(source["fnl_dir"]), workbook_bytes("ID2613"))
    write_source_registry(registry)

    with pytest.raises(backend.HTTPException) as raised:
        backend.create_wind_inputs_job(
            backend.WindInputsJobRequest(input_token=validation["input_token"])
        )
    assert raised.value.status_code == 409
    assert "no longer approved" in raised.value.detail


def test_rejects_missing_extra_changed_or_invalid_inputs(tmp_path, monkeypatch):
    bavi, _ = configure_sources(tmp_path, monkeypatch)
    valid_manifest = fnl_manifest(bavi["fnl_dir"])
    valid_track = workbook_bytes("ID2421")

    with pytest.raises(backend.HTTPException) as raised:
        validate_inputs(valid_manifest[:-1], valid_track)
    assert raised.value.status_code == 400
    assert "missing forecast hours" in raised.value.detail

    extra_manifest = [*valid_manifest, {"path": "FNL/174.nc", "size": 1, "last_modified_ms": 1}]
    with pytest.raises(backend.HTTPException) as raised:
        validate_inputs(extra_manifest, valid_track)
    assert raised.value.status_code == 400
    assert "outside the required" in raised.value.detail

    changed_manifest = [dict(item) for item in valid_manifest]
    changed_manifest[0]["size"] += 1
    with pytest.raises(backend.HTTPException) as raised:
        validate_inputs(changed_manifest, valid_track)
    assert raised.value.status_code == 400
    assert "does not match any approved" in raised.value.detail

    with pytest.raises(backend.HTTPException) as raised:
        validate_inputs(valid_manifest, b"not an xlsx workbook")
    assert raised.value.status_code == 400
    assert "valid XLSX" in raised.value.detail

    with pytest.raises(backend.HTTPException) as raised:
        validate_inputs(
            valid_manifest,
            workbook_bytes("ID2421", include_second_row=False),
        )
    assert raised.value.status_code == 400
    assert "at least two valid rows" in raised.value.detail


def test_ambiguous_fnl_metadata_is_rejected_without_a_track_tiebreaker(
    tmp_path,
    monkeypatch,
):
    cases_root = tmp_path / "cases"
    first = make_case(
        cases_root,
        folder="Bavi_ID2609",
        case_id="ID2609",
        name="Bavi",
        size_offset=20,
        modified_ms=1_783_849_348_000,
    )
    make_case(
        cases_root,
        folder="NOUL_ID2612",
        case_id="ID2612",
        name="NOUL",
        size_offset=20,
        modified_ms=1_783_849_348_000,
    )
    monkeypatch.setattr(backend, "FULL_CASES_ROOT", cases_root)
    monkeypatch.setattr(backend, "FULL_BUNDLE_ROOT", tmp_path)
    monkeypatch.setattr(backend, "FULL_TEMP_ROOT", tmp_path / "temp")
    monkeypatch.setattr(backend, "_WIND_INPUT_TOKENS", {})

    with pytest.raises(backend.HTTPException) as raised:
        validate_inputs(fnl_manifest(first["fnl_dir"]), workbook_bytes("ID2421"))
    assert raised.value.status_code == 409
    assert "identity is ambiguous" in raised.value.detail


def test_one_use_token_queues_explicit_fnl_and_uploaded_track(
    tmp_path,
    monkeypatch,
):
    bavi, _ = configure_sources(tmp_path, monkeypatch)
    uploaded_track = workbook_bytes("ID2421", latitude=12.0)
    validation = validate_inputs(fnl_manifest(bavi["fnl_dir"]), uploaded_track)
    submitted = {}

    class FakeExecutor:
        def submit(self, function, *args):
            submitted["function"] = function
            submitted["args"] = args

    monkeypatch.setattr(backend, "JOBS_ROOT", tmp_path / "jobs")
    monkeypatch.setattr(backend, "FULL_EXECUTOR", FakeExecutor())
    monkeypatch.setattr(
        backend,
        "stage_runtime_status",
        lambda *_args, **_kwargs: {"ready": True, "issues": []},
    )

    state = backend.create_wind_inputs_job(
        backend.WindInputsJobRequest(input_token=validation["input_token"])
    )

    assert state["source"] == "fnl-folder-plus-track-workbook"
    assert state["case_id"] == "ID2609"
    assert submitted["function"] is backend.run_stage_job
    job_case = submitted["args"][2]
    command = submitted["args"][3]
    assert command[0] == "wind-inputs"
    assert Path(command[command.index("--fnl-dir") + 1]) == bavi["fnl_dir"]
    explicit_track = Path(command[command.index("--track") + 1])
    assert explicit_track == backend.JOBS_ROOT / state["job_id"] / "input" / "track.xlsx"
    assert explicit_track.read_bytes() == uploaded_track
    assert job_case["track_path"] == explicit_track
    assert validation["input_token"] not in backend._WIND_INPUT_TOKENS

    with pytest.raises(backend.HTTPException) as raised:
        backend.create_wind_inputs_job(
            backend.WindInputsJobRequest(input_token=validation["input_token"])
        )
    assert raised.value.status_code == 409
    assert "already been used" in raised.value.detail


def test_expired_or_identity_modified_token_cannot_start_a_job(tmp_path, monkeypatch):
    bavi, _ = configure_sources(tmp_path, monkeypatch)
    manifest = fnl_manifest(bavi["fnl_dir"])
    monkeypatch.setattr(
        backend,
        "stage_runtime_status",
        lambda *_args, **_kwargs: {"ready": True, "issues": []},
    )

    expired = validate_inputs(manifest, workbook_bytes("ID2421"))
    expired_record = backend._WIND_INPUT_TOKENS[expired["input_token"]]
    expired_record["expires_at"] = time.monotonic() - 1
    expired_temp = Path(expired_record["temp_root"])
    with pytest.raises(backend.HTTPException) as raised:
        backend.create_wind_inputs_job(
            backend.WindInputsJobRequest(input_token=expired["input_token"])
        )
    assert raised.value.status_code == 409
    assert "expired" in raised.value.detail
    assert not expired_temp.exists()

    modified = validate_inputs(manifest, workbook_bytes("ID2421", latitude=13.0))
    backend._WIND_INPUT_TOKENS[modified["input_token"]]["case_id"] = "ID2612"
    with pytest.raises(backend.HTTPException) as raised:
        backend.create_wind_inputs_job(
            backend.WindInputsJobRequest(input_token=modified["input_token"])
        )
    assert raised.value.status_code == 409
    assert "identity has changed" in raised.value.detail


def test_startup_removes_workbook_uploads_from_lost_tokens(tmp_path, monkeypatch):
    temporary_root = tmp_path / "full-temp"
    orphan = temporary_root / "validated-wind-inputs" / "orphaned-token"
    orphan.mkdir(parents=True)
    (orphan / "track.xlsx").write_bytes(b"temporary workbook")
    unrelated = tmp_path / "unrelated"
    unrelated.mkdir()
    (unrelated / "keep.txt").write_text("keep", encoding="utf-8")
    monkeypatch.setattr(backend, "FULL_TEMP_ROOT", temporary_root)

    backend.cleanup_abandoned_wind_input_uploads()

    assert not orphan.exists()
    assert (unrelated / "keep.txt").read_text(encoding="utf-8") == "keep"
