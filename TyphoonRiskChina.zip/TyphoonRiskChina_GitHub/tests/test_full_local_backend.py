import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from backend import app as backend


def make_case(root: Path, folder: str = "Bavi_ID2609") -> Path:
    case = root / folder
    fnl = case / "FNL"
    fnl.mkdir(parents=True)
    (case / "track.xlsx").write_bytes(b"track")
    (case / "config.yml").write_text(
        "schema_version: 1\n"
        "mode: full\n"
        "case:\n"
        "  id: ID2609\n"
        "  name: Bavi\n",
        encoding="utf-8",
    )
    for name in backend.EXPECTED_FNL_NAMES:
        (fnl / name).write_bytes(b"nc")
    return case


def write_full_manifests(output: Path, canonical_loss: float = 17_400_519.19584863) -> None:
    vulnerability = output / "vulnerability"
    vulnerability.mkdir(parents=True, exist_ok=True)
    result = {
        "schema_version": "3.0",
        "typhoon_name": "Bavi",
        "event_id": "202609",
        "impact_threshold_ms": 17.2,
        "impact_detected": True,
        "affected_provinces": ["zhejiang"],
        "landfall": {
            "time": "2026-07-11T20:41:40",
            "longitude": 119.94,
            "latitude": 26.60,
            "province_name": "Fujian",
            "city_name": "Ningde",
        },
        "totals": {
            "exposure_value": 36_637_704_978.0,
            "structural_loss": 1_016.0,
            "roof_loss": 17_125_689.0,
            "window_loss": 273_814.19584863,
            "nonstructural_loss": 17_399_503.19584863,
            "total_loss": canonical_loss,
        },
        "province_results": [
            {
                "province": "zhejiang",
                "province_name": "Zhejiang",
                "grid_count": 137_885,
                "grids_at_or_above_impact_threshold": 2_506,
                "max_wind_ms": 21.033627761,
                "exposure_value": 7_286_234_513.0,
                "total_loss": 5_658_456.0,
            }
        ],
        "top_cities": [
            {
                "province": "zhejiang",
                "province_name": "Zhejiang",
                "city_name": "宁波市",
                "city_name_en": "Ningbo",
                "grid_count": 12_188,
                "max_wind_ms": 21.033627761,
                "exposure_value": 1_587_338_173.0,
                "total_loss": 1_609_576.63,
            }
        ],
    }
    (vulnerability / "result_manifest.json").write_text(
        json.dumps(result, ensure_ascii=False), encoding="utf-8"
    )
    (vulnerability / "maximum_wind_distribution.png").write_bytes(b"png")
    (vulnerability / "loss_distribution.png").write_bytes(b"png")
    (vulnerability / "typhoon_loss_assessment.pdf").write_bytes(b"pdf")
    pipeline = {
        "status": "complete",
        "current_stage": None,
        "stages": {"vulnerability": {"totals": {"total_loss": 5_658_456.0}}},
    }
    (output / "pipeline_result.json").write_text(
        json.dumps(pipeline), encoding="utf-8"
    )


def test_scans_only_registered_local_cases_without_exposing_paths(tmp_path, monkeypatch):
    cases_root = tmp_path / "cases"
    make_case(cases_root)
    monkeypatch.setattr(backend, "FULL_CASES_ROOT", cases_root)
    monkeypatch.setattr(backend, "FULL_BUNDLE_ROOT", tmp_path)

    cases = backend.scan_full_cases()

    assert len(cases) == 1
    assert cases[0]["case_key"] == "Bavi_ID2609"
    assert cases[0]["fnl_count"] == 28
    assert cases[0]["ready"] is True
    public = backend.public_full_case(cases[0])
    assert "case_dir" not in public
    assert "track_path" not in public
    with pytest.raises(backend.HTTPException):
        backend.get_full_case("../outside")


def test_full_result_prefers_canonical_vulnerability_manifest(tmp_path):
    root = tmp_path / "job"
    output = root / "full_output"
    write_full_manifests(output)
    case = {"case_id": "ID2609", "typhoon_name": "Bavi"}

    result = backend.build_full_result("a" * 32, root, case)

    assert result["mode"] == "full"
    assert result["summary"]["totals"]["total_loss"] == pytest.approx(
        17_400_519.19584863
    )
    assert result["summary"]["grid_count"] == 137_885
    assert result["summary"]["grids_at_or_above_impact_threshold"] == 2_506
    assert result["by_city"][0]["city"] == "Ningbo"
    assert result["rows"] == []
    assert result["warnings"]
    assert result["artifacts"]["wind-map"].endswith("/artifacts/wind-map")


def test_create_full_job_queues_only_an_opaque_registered_case(tmp_path, monkeypatch):
    case_dir = make_case(tmp_path / "cases")
    track_path = case_dir / "track.xlsx"
    case = {
        "case_key": "Bavi_ID2609",
        "case_id": "ID2609",
        "typhoon_name": "Bavi",
        "case_dir": case_dir,
        "track_path": track_path,
        "fnl_count": 28,
        "fnl_bytes": 56,
        "ready": True,
        "issues": [],
    }
    submitted = {}

    class FakeExecutor:
        def submit(self, function, *args):
            submitted["function"] = function
            submitted["args"] = args

    monkeypatch.setattr(backend, "JOBS_ROOT", tmp_path / "jobs")
    monkeypatch.setattr(
        backend,
        "full_runtime_status",
        lambda **_kwargs: {"ready": True, "issues": []},
    )
    monkeypatch.setattr(backend, "get_full_case", lambda key: case if key == case["case_key"] else None)
    monkeypatch.setattr(backend, "FULL_EXECUTOR", FakeExecutor())

    state = backend.create_full_job(
        backend.FullJobRequest(case_key="Bavi_ID2609", impact_threshold_ms=17.2)
    )

    assert state["mode"] == "full"
    assert state["source"] == "server-side-local-case"
    assert "case_dir" not in state
    assert submitted["function"] is backend.run_full_job
    persisted = backend.read_json(backend.JOBS_ROOT / state["job_id"] / "job.json")
    assert persisted["case_key"] == "Bavi_ID2609"


def test_full_job_passes_local_case_path_without_uploading_fnl(tmp_path, monkeypatch):
    jobs = tmp_path / "jobs"
    job_id = "b" * 32
    root = jobs / job_id
    root.mkdir(parents=True)
    backend.atomic_json(
        root / "job.json",
        {"job_id": job_id, "mode": "full", "status": "queued"},
    )
    case_dir = make_case(tmp_path / "cases")
    case = {
        "case_id": "ID2609",
        "typhoon_name": "Bavi",
        "case_dir": case_dir,
    }
    cli = tmp_path / "algorithm" / "modules" / "webready" / "backend" / "end_to_end_cli.py"
    cli.parent.mkdir(parents=True)
    cli.write_text("# test cli\n", encoding="utf-8")
    python = tmp_path / "full-python.exe"
    python.write_bytes(b"python")
    captured = {}

    def fake_run(command, **kwargs):
        captured["command"] = command
        captured["kwargs"] = kwargs
        kwargs["stdout"].write("mock full run\n")
        output = Path(command[command.index("--output-root") + 1])
        write_full_manifests(output)
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(backend, "JOBS_ROOT", jobs)
    monkeypatch.setattr(backend, "FULL_TEMP_ROOT", tmp_path / "temp")
    monkeypatch.setattr(backend, "FULL_ALGORITHM_ROOT", tmp_path / "algorithm")
    monkeypatch.setattr(backend, "FULL_CLI", cli)
    monkeypatch.setattr(backend, "FULL_PYTHON", python)
    monkeypatch.setattr(backend, "FULL_RUNTIME_ROOT", tmp_path / "runtime")
    monkeypatch.setattr(backend, "FULL_EXPOSURE_ROOT", tmp_path / "exposure")
    monkeypatch.setattr(backend.subprocess, "run", fake_run)

    backend.run_full_job(job_id, case, 17.2, False)

    state = backend.read_json(root / "job.json")
    assert state["status"] == "complete"
    command = captured["command"]
    assert command[command.index("--case-dir") + 1] == str(case_dir)
    assert not any(str(item).lower().endswith(".nc") for item in command)
    assert captured["kwargs"]["shell"] is False
    assert captured["kwargs"]["env"]["TEMP"].startswith(str(tmp_path))
    assert (root / "result.json").is_file()
    assert (root / "typhoon_loss_result.zip").is_file()


def test_full_artifacts_are_selected_from_a_fixed_allowlist(tmp_path, monkeypatch):
    jobs = tmp_path / "jobs"
    job_id = "c" * 32
    root = jobs / job_id
    artifact = root / "full_output" / "vulnerability" / "maximum_wind_distribution.png"
    artifact.parent.mkdir(parents=True)
    artifact.write_bytes(b"png")
    backend.atomic_json(
        root / "job.json",
        {"job_id": job_id, "mode": "full", "status": "complete"},
    )
    monkeypatch.setattr(backend, "JOBS_ROOT", jobs)

    response = backend.download_full_artifact(job_id, "wind-map")

    assert Path(response.path) == artifact
    with pytest.raises(backend.HTTPException) as raised:
        backend.download_full_artifact(job_id, "../../outside")
    assert raised.value.status_code == 404
