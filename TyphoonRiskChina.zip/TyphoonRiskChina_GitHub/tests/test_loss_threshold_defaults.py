from pathlib import Path
import shutil

import pytest

from backend import app as backend
from backend import full_stage_cli


def test_request_models_default_loss_threshold_to_17_3():
    full_request = backend.FullJobRequest(case_key="Bavi_ID2609")
    loss_request = backend.LossFromWindRequest(wind_job_id="a" * 32)

    assert backend.DEFAULT_LOSS_IMPACT_THRESHOLD_MS == pytest.approx(17.3)
    assert full_request.impact_threshold_ms == pytest.approx(17.3)
    assert loss_request.impact_threshold_ms == pytest.approx(17.3)


def test_uploaded_folder_config_falls_back_to_17_3(tmp_path):
    source = Path(__file__).resolve().parent.parent / "example_folder" / "small_input"
    input_root = tmp_path / "input"
    input_root.mkdir()
    shutil.copy2(source / "track.csv", input_root / "track.csv")
    shutil.copy2(source / "exposure.csv", input_root / "exposure.csv")

    prepared = backend.prepare_config(
        tmp_path,
        case_id="ID2609",
        typhoon_name="Bavi",
        impact_threshold_ms=None,
    )

    assert prepared["threshold"] == pytest.approx(17.3)
    generated = backend.yaml.safe_load(
        prepared["config_path"].read_text(encoding="utf-8")
    )
    assert generated["parameters"]["impact_threshold_ms"] == pytest.approx(17.3)


def test_loss_cli_defaults_threshold_to_17_3():
    args = full_stage_cli.build_parser().parse_args(
        [
            "loss",
            "--case",
            "ID2609",
            "--typhoon-name",
            "Bavi",
            "--input-nc",
            "wind.nc",
            "--track-xlsx",
            "track.xlsx",
            "--risk-root",
            "risk",
            "--bundle-root",
            "bundle",
            "--output",
            "output",
        ]
    )

    assert args.impact_threshold == pytest.approx(17.3)
