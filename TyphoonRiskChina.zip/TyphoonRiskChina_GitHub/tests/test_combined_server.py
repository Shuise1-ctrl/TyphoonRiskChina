import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import unittest
from urllib.error import URLError
from urllib.request import Request, urlopen
import uuid


APP_ROOT = Path(__file__).resolve().parent.parent


def free_port() -> int:
    with socket.socket() as server:
        server.bind(("127.0.0.1", 0))
        return server.getsockname()[1]


def multipart_body(fields, files):
    boundary = f"----TyphoonRiskChina{uuid.uuid4().hex}"
    chunks = []
    for name, value in fields:
        chunks.extend(
            [
                f"--{boundary}\r\n".encode(),
                f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode(),
                str(value).encode(),
                b"\r\n",
            ]
        )
    for field_name, filename, path in files:
        chunks.extend(
            [
                f"--{boundary}\r\n".encode(),
                (
                    f'Content-Disposition: form-data; name="{field_name}"; '
                    f'filename="{filename}"\r\n'
                ).encode(),
                b"Content-Type: text/csv\r\n\r\n",
                path.read_bytes(),
                b"\r\n",
            ]
        )
    chunks.append(f"--{boundary}--\r\n".encode())
    return b"".join(chunks), f"multipart/form-data; boundary={boundary}"


class CombinedServerTests(unittest.TestCase):
    def setUp(self):
        self.port = int(os.environ.get("TYPHOON_TEST_PORT") or free_port())
        self.base_url = f"http://127.0.0.1:{self.port}"
        environment = os.environ.copy()
        environment["TYPHOON_WEB_ROOT"] = str(APP_ROOT / "web")
        self.process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "backend.app:app",
                "--host",
                "127.0.0.1",
                "--port",
                str(self.port),
            ],
            cwd=APP_ROOT,
            env=environment,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        for _ in range(80):
            if self.process.poll() is not None:
                self.fail(f"combined server exited with {self.process.returncode}")
            try:
                with urlopen(f"{self.base_url}/api/health", timeout=1) as response:
                    if json.load(response)["status"] == "ok":
                        break
            except URLError:
                time.sleep(0.1)
        else:
            self.fail("combined server did not become healthy")
        self.job_id = None

    def tearDown(self):
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=5)
        if self.job_id:
            shutil.rmtree(APP_ROOT / "data" / "jobs" / self.job_id, ignore_errors=True)

    def test_compiled_frontend_and_loss_api_share_one_server(self):
        with urlopen(f"{self.base_url}/", timeout=5) as response:
            home = response.read().decode()
            self.assertEqual(response.status, 200)
            self.assertIn("TyphoonRiskChina", home)

        with urlopen(f"{self.base_url}/storms/example", timeout=5) as response:
            self.assertEqual(response.status, 200)
            self.assertIn("TyphoonRiskChina", response.read().decode())

        example = APP_ROOT / "example_folder" / "small_input"
        body, content_type = multipart_body(
            [
                ("paths", "typhoon_example/small_input/track.csv"),
                ("paths", "typhoon_example/small_input/exposure.csv"),
                ("case_id", "case01"),
                ("typhoon_name", "ReviewerDemo"),
                ("impact_threshold_ms", "17.2"),
            ],
            [
                ("files", "track.csv", example / "track.csv"),
                ("files", "exposure.csv", example / "exposure.csv"),
            ],
        )
        request = Request(
            f"{self.base_url}/api/jobs",
            data=body,
            method="POST",
            headers={"Content-Type": content_type},
        )
        with urlopen(request, timeout=10) as response:
            created = json.load(response)
            self.assertEqual(response.status, 202)
        self.job_id = created["job_id"]

        state = None
        # Report/package generation can take slightly longer on a busy local
        # machine even after the algorithm manifest is complete.
        for _ in range(480):
            with urlopen(f"{self.base_url}/api/jobs/{self.job_id}", timeout=5) as response:
                state = json.load(response)
            if state["status"] in {"complete", "failed"}:
                break
            time.sleep(0.05)
        self.assertEqual(state["status"], "complete", state)

        with urlopen(f"{self.base_url}/api/jobs/{self.job_id}/result", timeout=5) as response:
            result = json.load(response)
        self.assertAlmostEqual(
            result["summary"]["totals"]["total_loss"],
            1_046_005.8660122628,
            places=6,
        )


if __name__ == "__main__":
    unittest.main()
