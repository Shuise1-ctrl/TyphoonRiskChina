from pathlib import Path
import time

import pytest

from backend import app as backend


def make_approved_bundle(tmp_path: Path, monkeypatch) -> tuple[Path, dict]:
    bundle = tmp_path / "Illustrative examples"
    case_dir = bundle / "cases" / "Bavi_ID2609"
    fnl_dir = case_dir / "FNL"
    fnl_dir.mkdir(parents=True)
    (case_dir / "track.xlsx").write_bytes(b"track")
    (case_dir / "config.yml").write_text(
        "schema_version: 1\n"
        "mode: full\n"
        "case:\n"
        "  id: ID2609\n"
        "  name: Bavi\n",
        encoding="utf-8",
    )
    for name in backend.EXPECTED_FNL_NAMES:
        (fnl_dir / name).write_bytes(name.encode("ascii"))

    runtime = bundle / "runtime" / "downscaling"
    model = runtime / "models" / "direct_unet_model.h5"
    model.parent.mkdir(parents=True)
    model.write_bytes(b"model")
    scalers = runtime / "scalers"
    scalers.mkdir(parents=True)
    (scalers / "scaler_x.save").write_bytes(b"scaler-x")
    (scalers / "scaler_y.save").write_bytes(b"scaler-y")

    monkeypatch.setattr(backend, "FULL_BUNDLE_ROOT", bundle)
    monkeypatch.setattr(backend, "FULL_CASES_ROOT", bundle / "cases")
    monkeypatch.setattr(backend, "_BUNDLE_TOKENS", {})

    files = []
    for path in sorted(item for item in bundle.rglob("*") if item.is_file()):
        relative = path.relative_to(bundle).as_posix()
        files.append(
            backend.LocalBundleManifestFile(
                path=f"{bundle.name}/{relative}",
                size=path.stat().st_size,
                last_modified_ms=1,
            )
        )
    request = backend.LocalBundleValidationRequest(
        root_name=bundle.name,
        files=files,
    )
    case = backend.scan_full_cases()[0]
    return bundle, {"request": request, "case": case}


def test_validates_large_bundle_metadata_without_copying_or_leaking_paths(
    tmp_path,
    monkeypatch,
):
    bundle, prepared = make_approved_bundle(tmp_path, monkeypatch)

    response = backend.validate_wind_bundle(prepared["request"])

    assert response["status"] == "ready"
    assert response["mode"] == "local-large-dataset"
    assert response["verified_in_place"] is True
    assert response["copy_required"] is False
    assert response["file_count"] == len(prepared["request"].files)
    assert response["total_bytes"] == sum(item.size for item in prepared["request"].files)
    assert response["cases"][0]["case_key"] == "Bavi_ID2609"
    assert len(response["bundle_token"]) >= 20
    assert str(bundle.resolve()) not in repr(response)
    assert "case_dir" not in response["cases"][0]


def test_rejects_wrong_root_and_incomplete_wind_runtime(tmp_path, monkeypatch):
    _bundle, prepared = make_approved_bundle(tmp_path, monkeypatch)

    wrong_root = prepared["request"].model_copy(update={"root_name": "cases"})
    with pytest.raises(backend.HTTPException) as raised:
        backend.validate_wind_bundle(wrong_root)
    assert raised.value.status_code == 400
    assert "folder itself" in raised.value.detail

    incomplete = prepared["request"].model_copy(
        update={
            "files": [
                item
                for item in prepared["request"].files
                if not item.path.endswith("direct_unet_model.h5")
            ]
        }
    )
    with pytest.raises(backend.HTTPException) as raised:
        backend.validate_wind_bundle(incomplete)
    assert raised.value.status_code == 400
    assert "wind-model files" in raised.value.detail


def test_verified_token_is_checked_for_local_wind_job(tmp_path, monkeypatch):
    _bundle, prepared = make_approved_bundle(tmp_path, monkeypatch)
    validation = backend.validate_wind_bundle(prepared["request"])
    case = prepared["case"]
    submitted = {}

    class FakeExecutor:
        def submit(self, function, *args):
            submitted["function"] = function
            submitted["args"] = args

    monkeypatch.setattr(backend, "JOBS_ROOT", tmp_path / "jobs")
    monkeypatch.setattr(backend, "FULL_EXECUTOR", FakeExecutor())
    monkeypatch.setattr(backend, "get_full_case", lambda key: case)
    monkeypatch.setattr(
        backend,
        "stage_runtime_status",
        lambda *_args, **_kwargs: {"ready": True, "issues": []},
    )

    state = backend.create_local_wind_job(
        backend.WindLocalJobRequest(
            case_key="Bavi_ID2609",
            bundle_token=validation["bundle_token"],
        )
    )

    assert state["source"] == "local-large-dataset"
    assert submitted["function"] is backend.run_stage_job

    with pytest.raises(backend.HTTPException) as raised:
        backend.create_local_wind_job(
            backend.WindLocalJobRequest(
                case_key="NOUL_ID2612",
                bundle_token=validation["bundle_token"],
            )
        )
    assert raised.value.status_code == 403

    token = validation["bundle_token"]
    _expiry, case_keys = backend._BUNDLE_TOKENS[token]
    backend._BUNDLE_TOKENS[token] = (time.monotonic() - 1, case_keys)
    with pytest.raises(backend.HTTPException) as raised:
        backend.create_local_wind_job(
            backend.WindLocalJobRequest(
                case_key="Bavi_ID2609",
                bundle_token=token,
            )
        )
    assert raised.value.status_code == 409
    assert "Select the Illustrative examples folder again" in raised.value.detail
