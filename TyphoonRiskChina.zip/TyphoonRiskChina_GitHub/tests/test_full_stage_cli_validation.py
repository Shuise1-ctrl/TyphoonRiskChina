from __future__ import annotations

import numpy as np
import pytest

xr = pytest.importorskip("xarray")

from backend import full_stage_cli as stage


def write_prediction(path, *, case_id: str = "ID2609", curved: bool = False) -> None:
    time = np.array([0, 1])
    lat_axis = np.array([20.0, 20.1, 20.2])
    lon_axis = np.array([118.0, 118.1, 118.2, 118.3])
    latitude = np.broadcast_to(lat_axis[None, :, None], (2, 3, 4)).copy()
    longitude = np.broadcast_to(lon_axis[None, None, :], (2, 3, 4)).copy()
    if curved:
        latitude[:, 1, 2] += 0.02
    dataset = xr.Dataset(
        {
            "wind_speed_1h_max_pred": (("time", "y", "x"), np.ones((2, 3, 4))),
            "XLAT": (("time", "y", "x"), latitude),
            "XLONG": (("time", "y", "x"), longitude),
        },
        coords={"time": time},
        attrs={"typhoon_id": case_id},
    )
    dataset.to_netcdf(path, **stage.netcdf_open_kwargs())


def test_prediction_validator_accepts_rectilinear_matching_case(tmp_path):
    prediction = tmp_path / "bavi_prediction.nc"
    write_prediction(prediction)

    stage.validate_prediction_netcdf(prediction, "ID2609")


def test_prediction_validator_rejects_curvilinear_grid(tmp_path):
    prediction = tmp_path / "curved_prediction.nc"
    write_prediction(prediction, curved=True)

    with pytest.raises(ValueError, match="not rectilinear"):
        stage.validate_prediction_netcdf(prediction, "ID2609")


def test_case_identity_validator_rejects_prediction_and_fixed_grid_mismatch(tmp_path):
    prediction = tmp_path / "noul_prediction.nc"
    write_prediction(prediction, case_id="ID2612")

    with pytest.raises(ValueError, match="does not match requested case"):
        stage.validate_prediction_netcdf(prediction, "ID2609")

    fixed_grid = tmp_path / "noul_fixed_grid.nc"
    dataset = xr.Dataset(
        {"max_wind_speed": (("lat", "lon"), np.ones((2, 2)))},
        coords={"lat": [20.0, 20.1], "lon": [118.0, 118.1]},
        attrs={"case_id": "ID2612"},
    )
    dataset.to_netcdf(fixed_grid, **stage.netcdf_open_kwargs())

    with pytest.raises(ValueError, match="does not match requested case"):
        stage.validate_fixed_grid_netcdf(fixed_grid, "ID2609")
