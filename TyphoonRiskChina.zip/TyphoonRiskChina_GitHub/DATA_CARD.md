# Data card

TyphoonRiskChina combines meteorological initial states, typhoon tracks, FuXi forecasts, downscaling assets, exposure grids, and vulnerability parameters. Large or independently licensed scientific data are external to GitHub; the repository stores configurations, checksums, metadata, small examples, and accepted result evidence.

## Revised event initial states

The accepted AutoDL regression on 2026-08-05 used the following uploaded files:

| Event | File | Shape | UTC times | Bytes | SHA-256 |
|---|---|---|---|---:|---|
| Bavi / ID2609 | `Bavi.nc` | `(2, 70, 721, 1440)` | 2026-07-06 18:00; 2026-07-07 00:00 | 581,441,584 | `4925941aea92fa9f709aabc04ae88a43809cca318f9cf8ccac88431a6cbb25d5` |
| NOUL / ID2612 | `Noul.nc` | `(2, 70, 721, 1440)` | 2026-07-23 18:00; 2026-07-24 00:00 | 581,441,590 | `0c77f46119c23878b82fa63ab1c920e47136439aa43e8b4422d65b51b4d55e13` |

Both are float32 arrays with `time`, `level`, `lat`, and `lon` dimensions; latitude runs from 90 to -90 and longitude from 0 to 359.75 degrees. These files use labels such as `U10` and `R850.0`. The software canonicalizes labels without changing numerical values so that both the revised and legacy FuXi naming conventions satisfy the downscaling data contract.

## Publication and provenance

Do not commit the two approximately 581 MB initial states, FuXi output sequences, model weights, H5/scaler files, or exposure Parquet collections to ordinary Git history. For every scientific release, record the source, license, download date, byte size, SHA-256, variable meanings, units, coordinates, and time coverage. Exposure data may encode economically sensitive spatial attributes, so its provenance and redistribution rights must be verified before publication.

The event track, initial state, model versions, parameter thresholds, configuration, Git commit, and result manifests together identify a reproducible run. The accepted Bavi and NOUL evidence is documented in `docs/BAVI_ID2609_ACCEPTANCE.md` and `docs/NOUL_ID2612_ACCEPTANCE.md`.
