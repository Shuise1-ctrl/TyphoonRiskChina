[CmdletBinding()]
param([switch]$Full)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()

$repoRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

function Find-Python310 {
    $candidates = @(
        @{ Name = (Join-Path $repoRoot '.venv\Scripts\python.exe'); Prefix = @() },
        @{ Name = 'py.exe'; Prefix = @('-3.10') },
        @{ Name = 'python.exe'; Prefix = @() },
        @{ Name = 'python'; Prefix = @() }
    )
    foreach ($candidate in $candidates) {
        $command = Get-Command $candidate.Name -ErrorAction SilentlyContinue
        if (-not $command) { continue }
        $prefix = @($candidate.Prefix)
        $version = & $command.Source @prefix -c "import platform,struct; print(platform.python_version()); print(struct.calcsize('P')*8)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $version.Count -ge 2 -and $version[0] -like '3.10.*' -and $version[1] -eq '64') {
            return @{ File = $command.Source; Prefix = $prefix; Version = $version[0] }
        }
    }
    throw 'CPython 3.10 x64 was not found. Install 64-bit Python 3.10, then run this script again.'
}

function New-Environment([string]$environmentPath, [string]$requirementsPath, [hashtable]$launcher) {
    $environmentPython = Join-Path $environmentPath 'Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $environmentPython -PathType Leaf)) {
        Write-Host "Creating $environmentPath with Python $($launcher.Version)..."
        $arguments = @($launcher.Prefix) + @('-m', 'venv', $environmentPath)
        & $launcher.File @arguments
        if ($LASTEXITCODE -ne 0) { throw "Could not create $environmentPath" }
    }
    & $environmentPython -m pip install --upgrade pip
    if ($LASTEXITCODE -ne 0) { throw 'pip upgrade failed.' }
    & $environmentPython -m pip install -r $requirementsPath
    if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed for $requirementsPath" }
    & $environmentPython -m pip check
    if ($LASTEXITCODE -ne 0) { throw "Dependency consistency check failed for $environmentPath" }
}

$pythonLauncher = Find-Python310
New-Environment `
    (Join-Path $repoRoot '.venv') `
    (Join-Path $repoRoot 'backend\requirements.txt') `
    $pythonLauncher

if ($Full) {
    Write-Host 'Installing the full scientific environment. This download is large and may take several minutes.'
    New-Environment `
        (Join-Path $repoRoot '.venv-full') `
        (Join-Path $repoRoot 'algorithm_full\requirements-windows.txt') `
        $pythonLauncher
}

Write-Host ''
Write-Host 'Installation completed successfully.' -ForegroundColor Green
if (-not $Full) {
    Write-Host 'Run setup_full_windows.bat as well before using wind-field downscaling or loss assessment.'
}
