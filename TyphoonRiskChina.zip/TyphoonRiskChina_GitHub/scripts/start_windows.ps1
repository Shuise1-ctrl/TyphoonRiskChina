[CmdletBinding()]
param(
    [int]$Port = 5173,
    [switch]$NoBrowser,
    [switch]$SelfTest
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()

$repoRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$python = Join-Path $repoRoot '.venv\Scripts\python.exe'
$webRoot = Join-Path $repoRoot 'web'
$configurationPath = Join-Path $repoRoot 'config.local.json'
$backendProcess = $null
$expectedAssetPath = $null

function Resolve-ConfiguredPath([object]$value, [string]$fallback) {
    $text = [string]$value
    if ([string]::IsNullOrWhiteSpace($text)) { $text = $fallback }
    if ([System.IO.Path]::IsPathRooted($text)) { return [System.IO.Path]::GetFullPath($text) }
    return [System.IO.Path]::GetFullPath((Join-Path $repoRoot $text))
}

$configuration = $null
if (Test-Path -LiteralPath $configurationPath -PathType Leaf) {
    $configuration = Get-Content -LiteralPath $configurationPath -Raw -Encoding utf8 | ConvertFrom-Json
}

$bundleRoot = Resolve-ConfiguredPath $configuration.full_bundle_root 'runtime'
$casesRoot = Resolve-ConfiguredPath $configuration.cases_root (Join-Path $bundleRoot 'cases')
$downscalingRoot = Resolve-ConfiguredPath $configuration.downscaling_root (Join-Path $bundleRoot 'downscaling')
$exposureRoot = Resolve-ConfiguredPath $configuration.exposure_root (Join-Path $bundleRoot 'exposure')
$fullPython = Resolve-ConfiguredPath $configuration.full_python '.venv-full\Scripts\python.exe'
$approvedSources = Resolve-ConfiguredPath $configuration.approved_wind_sources 'data\approved_wind_sources.json'

$env:TYPHOON_WEB_ROOT = $webRoot
$env:TYPHOON_FULL_ALGORITHM_ROOT = Join-Path $repoRoot 'algorithm_full'
$env:TYPHOON_FULL_BUNDLE_ROOT = $bundleRoot
$env:TYPHOON_FULL_CASES_ROOT = $casesRoot
$env:TYPHOON_FULL_RUNTIME_ROOT = $downscalingRoot
$env:TYPHOON_FULL_EXPOSURE_ROOT = $exposureRoot
$env:TYPHOON_FULL_PYTHON = $fullPython
$env:TYPHOON_FULL_CLI = Join-Path $repoRoot 'algorithm_full\modules\webready\backend\end_to_end_cli.py'
$env:TYPHOON_FULL_STAGE_CLI = Join-Path $repoRoot 'backend\full_stage_cli.py'
$env:TYPHOON_FULL_TEMP_ROOT = Join-Path $repoRoot 'data\full-temp'
$env:TYPHOON_APPROVED_WIND_SOURCES = $approvedSources

function Get-ServiceHealth {
    try {
        return Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/health" -TimeoutSec 2
    }
    catch {
        return $null
    }
}

function Test-IsThisPackage([object]$health) {
    if (-not $health -or $health.status -ne 'ok') { return $false }
    if ([string]$health.service -ne 'TyphoonRiskChina Local Analysis') { return $false }
    if ([string]::IsNullOrWhiteSpace($expectedAssetPath)) { return $false }
    try {
        $indexResponse = Invoke-WebRequest -Uri "http://127.0.0.1:$Port/" -UseBasicParsing -TimeoutSec 2
        return ([string]$indexResponse.Content).Contains($expectedAssetPath)
    }
    catch {
        return $false
    }
}

function Show-Readiness([object]$health) {
    Write-Host "Service: $($health.service) $($health.version)"
    Write-Host "Web/API: ready"
    Write-Host "Wind field: $([bool]$health.engines.wind.local.ready)"
    Write-Host "Loss: $([bool]$health.engines.loss.ready)"
    if (-not $health.engines.wind.local.ready) {
        foreach ($issue in @($health.engines.wind.local.issues)) { Write-Host "  Wind issue: $issue" -ForegroundColor Yellow }
    }
    if (-not $health.engines.loss.ready) {
        foreach ($issue in @($health.engines.loss.issues)) { Write-Host "  Loss issue: $issue" -ForegroundColor Yellow }
    }
}

try {
    if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
        throw 'The basic Python environment is missing. Run setup_windows.bat first.'
    }
    if (-not (Test-Path -LiteralPath (Join-Path $webRoot 'index.html') -PathType Leaf)) {
        throw 'The compiled web application is missing from the web directory.'
    }
    $indexMarkup = Get-Content -LiteralPath (Join-Path $webRoot 'index.html') -Raw -Encoding utf8
    $assetMatch = [regex]::Match($indexMarkup, 'src="(?<path>/assets/[^"?]+\.js)"')
    if (-not $assetMatch.Success) { throw 'The compiled web entry point has no identifiable JavaScript asset.' }
    $expectedAssetPath = $assetMatch.Groups['path'].Value

    $health = Get-ServiceHealth
    if (Test-IsThisPackage $health) {
        Show-Readiness $health
        if (-not $SelfTest -and -not $NoBrowser) { Start-Process "http://127.0.0.1:$Port/" }
        exit 0
    }

    $listener = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($listener) {
        throw "Port $Port is already occupied by process $($listener.OwningProcess). Close that program or choose another port."
    }

    $backendProcess = Start-Process `
        -FilePath $python `
        -ArgumentList @('-m', 'uvicorn', 'backend.app:app', '--host', '127.0.0.1', '--port', [string]$Port) `
        -WorkingDirectory $repoRoot `
        -NoNewWindow `
        -PassThru

    for ($attempt = 0; $attempt -lt 120; $attempt++) {
        Start-Sleep -Milliseconds 250
        if ($backendProcess.HasExited) { throw "The local service exited with code $($backendProcess.ExitCode)." }
        $health = Get-ServiceHealth
        if (Test-IsThisPackage $health) { break }
    }
    if (-not (Test-IsThisPackage $health)) { throw 'The local service did not become ready in time.' }

    Show-Readiness $health
    if ($SelfTest) { exit 0 }

    $url = "http://127.0.0.1:$Port/"
    Write-Host "TyphoonRiskChina is running at $url" -ForegroundColor Green
    Write-Host 'Keep this window open. Close it to stop the local application.'
    if (-not $NoBrowser) { Start-Process $url }
    Wait-Process -Id $backendProcess.Id
}
catch {
    Write-Host "Start failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
finally {
    if ($backendProcess -and -not $backendProcess.HasExited) {
        Stop-Process -Id $backendProcess.Id -Force -ErrorAction SilentlyContinue
    }
}
