[CmdletBinding()]
param([int]$Port = 5173)

$ErrorActionPreference = 'Stop'
$health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/health" -TimeoutSec 10

Write-Host "Service status: $($health.status)"
Write-Host "Service: $($health.service) $($health.version)"
Write-Host "Engine: $($health.engine)"
Write-Host "Wind-field ready: $([bool]$health.engines.wind.local.ready)"
Write-Host "Loss ready: $([bool]$health.engines.loss.ready)"

if (-not $health.engines.wind.local.ready) {
    foreach ($issue in @($health.engines.wind.local.issues)) { Write-Host "Wind issue: $issue" -ForegroundColor Yellow }
}
if (-not $health.engines.loss.ready) {
    foreach ($issue in @($health.engines.loss.issues)) { Write-Host "Loss issue: $issue" -ForegroundColor Yellow }
}

if ($health.status -ne 'ok') { exit 1 }

