# TyphoonRiskChina 中文运行说明

[English README](README.md)

TyphoonRiskChina 是一个本地运行的台风预报驱动风场降尺度与直接经济损失评估框架。Vue 网页和 FastAPI 计算服务运行在同一台电脑上，科学输入与计算结果不会发送到远程计算服务器。

> 本仓库用于“从 GitHub 克隆后在本机运行”。当前没有配置 GitHub Pages，静态资源根路径和 History 路由也按本机根地址设计；即使另行部署静态页面，Pages 仍无法运行 Python、TensorFlow 和 `/api` 计算接口。

## 一、仓库包含什么

| 功能 | 仓库是否包含 | 基础安装后能否使用 | 还需要什么 |
|---|---:|---:|---|
| 已编译网页 | 是 | 是 | 首页 Windy、OSM 底图需要联网 |
| Vue 3 前端源码 | 是 | 是 | 只有重新开发页面才需要 Node.js |
| FastAPI 本地服务 | 是 | 是 | 64 位 Python 3.10 和基础依赖 |
| 历史台风数据库 | 是 | 是 | CMA 轨迹数据随网页提供，OSM 底图需联网 |
| 轻量 reviewer CSV 算法 | 是 | 仅 API | 基础 Python 环境 |
| FNL 风场下尺度 | 仅含源码 | 否 | 完整 Python 环境、H5 模型、scaler 和 28 个 FNL |
| 沿海五省损失评估 | 仅含源码 | 否 | 还需要暴露与网格 Parquet 数据 |

原工作目录约 14 GB，其中包括虚拟环境、历史任务和多份单文件数百 MB 的 NetCDF/CSV，不能直接提交普通 GitHub。当前仓库包保留可公开的源码、编译网页、小样例和测试；FNL、模型、暴露数据按照外部资产管理，并在下文给出完整目录要求。

## 论文术语对齐

| Manuscript term | 本说明中的对应术语 |
|---|---|
| Forecast-driven typhoon wind-field downscaling | 台风预报驱动风场降尺度 |
| Hourly 10-m wind fields at approximately 3 km grid spacing | 约 3 km 网格的逐小时 10 m 风场 |
| Hazard–exposure–vulnerability (HEV) framework | 危险度—暴露度—易损性（HEV）框架 |
| Whole-building vulnerability function and mean loss ratio | 整体建筑易损性函数与平均损失率 |
| Modeled direct economic loss | 模型估算的直接经济损失，不代表实测损失 |

论文中的 NOUL 事件编号为 202612；软件案例目录和界面使用 ID2612。

## 二、目录结构

```text
TyphoonRiskChina/
├─ frontend_source/       当前 Vue 3 + Vite 源码
├─ web/                   已编译网页，日常启动使用
├─ backend/               FastAPI 服务、风场/损失阶段入口
├─ engine/                轻量 reviewer-demo 引擎
├─ algorithm_full/        TyphoonRiskChina 1.1.0 完整算法源码
├─ runtime/               外部科学资产的标准放置位置
├─ example_folder/        小型 CSV 示例
├─ data/                  运行后自动生成 jobs、临时文件和本机白名单
├─ tests/                 后端与集成测试
├─ docs/                  架构、验收与说明文档
├─ setup_windows.bat      安装基础网页/接口环境
├─ setup_full_windows.bat 安装完整科学计算环境
└─ start_windows.bat      在 5173 启动网页和 API
```

## 三、电脑要求

- Windows 10/11 64 位。
- 64 位 CPython 3.10.x。完整算法固定使用 `tensorflow-cpu==2.10.1`，不要用 Python 3.11/3.12 代替完整环境。
- 安装依赖时需要联网。
- 完整 Python 环境约占 2 GB；FNL、暴露数据和输出还需要额外磁盘空间。
- 日常打开已编译网页不需要 Node.js。只有修改前端源码才需要 Node.js 18/20/22 或更高受支持版本。

## 四、第一次安装与打开

### 1. 获取仓库

```powershell
git clone https://github.com/Shuise1-ctrl/TyphoonRiskChina.git
cd TyphoonRiskChina
```

也可以在 GitHub 点击 `Code -> Download ZIP`，下载后解压到普通、可写的文件夹。

### 2. 安装基础环境

双击：

```text
setup_windows.bat
```

脚本会寻找 64 位 Python 3.10，创建 `.venv`，并安装 FastAPI、Uvicorn、上传校验、YAML 和 XLSX 依赖。完成后可以打开网页、使用历史台风数据库、检查接口，并运行轻量 reviewer API。

### 3. 安装完整风场与损失环境

还要计算风场或损失时，再双击：

```text
setup_full_windows.bat
```

它会创建 `.venv-full` 并安装固定版本的 Windows CPU 科学依赖。下载量较大，可能需要几分钟。必须使用 `algorithm_full/requirements-windows.txt`，不要改用通用 TensorFlow/netCDF4 依赖。

### 4. 放置科学资产

默认把外部资产放到 `runtime/`：

```text
runtime/
├─ cases/
│  └─ DOLPHIN_ID2613/
│     ├─ config.yml
│     ├─ track.xlsx
│     └─ FNL/
│        ├─ 006.nc
│        ├─ 012.nc
│        ├─ ...
│        └─ 168.nc
├─ downscaling/
│  ├─ models/direct_unet_model.h5
│  └─ scalers/
│     ├─ scaler_x.save
│     └─ scaler_y.save
└─ exposure/
   ├─ 00000 沿海省份风险暴露/
   │  ├─ fujian.parquet
   │  ├─ guangdong.parquet
   │  ├─ hainan.parquet
   │  ├─ jiangsu.parquet
   │  └─ zhejiang.parquet
   └─ 00000 沿海省份网格/
      └─ 五个省分别且只能有一个 <province>_*.parquet
```

这些文件不在 GitHub 包中，原因包括体积超过 GitHub 普通文件限制，以及模型、暴露数据的再分发许可需要单独确认。

如果资产放在仓库外：

1. 把 `config.local.json.example` 复制为 `config.local.json`；
2. 修改其中路径；
3. 不要把 `config.local.json` 提交 GitHub。

`config.local.json` 只由 `start_windows.bat` 启动器读取；手动启动 Uvicorn 或使用 Vite 开发模式时，需要在同一 PowerShell 会话中显式设置 `.env.example` 列出的 `TYPHOON_*` 环境变量。

如果案例不在 `runtime/cases`，还可以把 `data/approved_wind_sources.example.json` 复制为被忽略的 `data/approved_wind_sources.json`，并把 `case_dir` 改成案例的绝对路径。

### 5. 启动网页

双击：

```text
start_windows.bat
```

浏览器会打开：

[http://127.0.0.1:5173/](http://127.0.0.1:5173/)

请保持控制台窗口开启；关闭窗口即停止本地服务。

启动后可双击 `verify_windows.bat` 检查，或访问：

- 健康状态：`http://127.0.0.1:5173/api/health`
- API 文档：`http://127.0.0.1:5173/docs`

注意：顶层 `status=ok` 只代表网页/API 活着。风场和损失真正可用还需要：

```text
engines.wind.local.ready = true
engines.loss.ready = true
```

## 五、网页功能怎么使用

### 历史台风数据库

可以按年份、名称筛选历史台风，查看路径、强度、逐点播放和悬停信息。轨迹数据库和边界文件随仓库提供；OpenStreetMap 底图需要联网。

### 风场计算

1. 选择名称必须是 `FNL` 的文件夹；
2. 选择匹配的 `.xlsx` 轨迹工作簿；
3. 等待两个输入验证通过；
4. 点击生成风场；
5. 在交互地图中查看最大风速并下载结果。

浏览器不会复制 28 个大型 NetCDF 正文，只发送文件相对名称、大小和修改时间。后端在同一台电脑上把清单与已配置、可读取的 FNL 目录比对，再从本机原目录计算。因此浏览器选择的 FNL 必须与后端 `runtime/cases` 或本机白名单中的文件是同一份文件。

FNL 顶层必须恰好包含 28 个文件，不能多一个 `.nc`：

```text
006.nc, 012.nc, 018.nc, ... , 162.nc, 168.nc
```

每个文件都必须包含 FuXi 数组变量 `__xarray_dataarray_variable__`，维度为 `time`、`step`、`level`、`lat`、`lon`。`level` 标签经大小写和数值后缀规范化后，必须能得到 `u10`、`v10`、`t2m`、`msl`、`r850` 五个通道。

台风轨迹工作簿要求：

- 单个、未加密 `.xlsx`；
- 文件不超过 16 MiB；
- 建议第一张表使用 `time,LAT,LONG`；
- 至少两个不同时间；
- 纬度范围 -90～90，经度范围 -180～360；
- 时间应采用与该案例下尺度一致的北京时间口径。

### 损失评估

风场任务完成后切换到损失模块，直接使用刚生成的固定网格风场计算。后端把最大风速与福建、广东、海南、江苏、浙江的暴露/网格数据匹配，调用易损性引擎，默认使用 17.3 m/s 的报告阈值，输出网格、城市和省级汇总。

当前网页主流程只使用刚完成的风场任务。高级 API 还支持兼容的固定网格 NetCDF 或本站生成的 `wind_input_for_loss.zip`，但建议优先使用本站产物，以保证案例身份和轨迹匹配。

### 新手完整复现 NOUL（ID2612）

仓库提供 NOUL 台风轨迹工作簿： [algorithm_full/examples/NOUL_ID2612/input/track.xlsx](algorithm_full/examples/NOUL_ID2612/input/track.xlsx)。GitHub 包不包含 28 个 FNL NetCDF、H5 模型与 scaler，也不包含沿海五省暴露数据。对照论文结果时，请使用同一版本的数据、模型和程序。

1. **安装环境。** 使用 64 位 Python 3.10。依次双击 setup_windows.bat 和 setup_full_windows.bat，并等待安装完成。若后者显示“按任意键继续”，表示安装报错退出，请先查看上方错误信息。
2. **准备案例目录。** 新建 runtime/cases/NOUL_ID2612/，把 algorithm_full/examples/NOUL_ID2612/config.yml 和仓库提供的 track.xlsx 复制进去，再建立 FNL 子目录。
3. **放入 FNL 文件。** 将原始的 28 个文件 006.nc、012.nc、018.nc、……、168.nc 直接放进 FNL。不要重命名、编辑或混入其他台风文件。轨迹表必须对应 NOUL（ID2612），并包含 time、LAT、LONG 列。
4. **放入模型和暴露数据。** 按 runtime/README.md 放置 direct_unet_model.h5、scaler_x.save、scaler_y.save，以及论文相同版本的五省暴露和网格 Parquet 数据；这些资产不在 GitHub 包内。
5. **配置仓库外的数据。** 若资产放在 runtime/ 外，将 config.local.json.example 复制为 config.local.json 并更新 cases_root、downscaling_root、exposure_root。若 FNL 在仓库外，再根据 data/approved_wind_sources.example.json 创建 data/approved_wind_sources.json。NOUL_ID2612 的 case_dir 必须指向 FNL 子目录的上一级目录。网页选择同一物理 FNL 文件夹；后端会核对文件名、大小和修改时间。
6. **运行计算。** 运行 verify_windows.bat 确认风场与损失引擎均 ready，然后双击 start_windows.bat 并保持窗口开启。打开本地网页，选择 FNL 文件夹本身和同一份 track.xlsx。两个输入都显示 Verified 后，点击 Generate wind field；完成后继续到损失模块并点击 Calculate loss。
7. **核对论文结果。** 参考结果为广东惠州附近登陆，汕尾城市最大风速约 47.01 m/s，总模型损失约人民币 7,493 万元，其中广东约 7,449 万元、福建约 44 万元。要复现这些数值，FNL、轨迹、模型/scaler、暴露数据、易损性曲线和程序版本都要一致。

论文报告的 Windows 11 电脑为 Intel Core i7-13700H、32 GB 内存、NVIDIA RTX A1000 Laptop GPU、Python 3.10.22；NOUL 风场约运行 27 分钟，损失约 2 分钟。实际时间因电脑和数据而异。损失为示例性模型估算，不是实测结果，也未经独立验证。

### 地图渲染与科学计算的区别

为保证浏览器性能，交互数据可能对科学网格进行聚合或降采样，渲染器只在图例色带之间插值颜色。没有数据源的网格保持透明，检查时会显示“无数据源”。这些显示处理不会写回源 NetCDF，也不参加统计或损失计算。

### 当前界面与结果展示

- 首页以 TyphoonRiskChina 为主标题，并提供 Windy 数据来源标注。
- 风场结果在开头显示 UTC+8 登陆信息；地图区分陆地和海洋，并按五个沿海省份显示固定网格风速及排序。
- 风场图与损失图使用一致的台风覆盖范围；轨迹合成风场图片不再单独显示。
- 损失结果将省级汇总与城市排序分开，隐藏零损失地区，标明货币单位，并在表格下方展示带交互数值的易损性曲线。
- 风场和损失结果分别提供 ZIP 一键下载。

## 六、算法处理流程

```text
28 个 6 小时 FNL + 北京时间轨迹工作簿 XLSX
  -> 本机文件清单与路径校验
  -> H5/scaler CPU 风场下尺度
  -> 6 小时到 1 小时插值
  -> 移动窗口风场插值到固定经纬网格
  -> 对时间序列取最大值得到 fixed_grid_max_wind.nc
  -> 沿海五省暴露/网格采样
  -> 易损性曲线与阈值筛查
  -> 网格、城市和省级损失
  -> 交互 JSON、PNG、CSV、NetCDF、PDF、ZIP
```

## 七、输出文件

风场阶段可能生成：

- `fixed_grid_max_wind.nc`
- `fixed_grid_max_wind.png`
- `hourly_summary.csv`
- `wind_manifest.json`、`stage_manifest.json` 和日志
- `interactive_wind_map.json`
- `wind_input_for_loss.zip`

损失阶段可能生成：

- `grid_wind.csv`、`grid_loss.csv`
- 最大风速图与损失分布图 PNG
- `typhoon_loss_assessment.pdf`
- `result_manifest.json`、阶段清单、日志和交互 JSON
- 摘要 ZIP；体积较大的网格 CSV 会在结果页单独下载

全部新任务写入 `data/jobs/<job_id>/`，该目录已经被 `.gitignore` 排除。

## 八、轻量 CSV reviewer 接口

当前页面没有显示旧的轻量 CSV 入口，但后端 API 仍保留：

- 路径 CSV：`time,lat,lon`，ISO 时间严格递增，至少两行；
- 暴露 CSV：`grid_id,province,city,wind_speed_ms,exposure_value`；
- 小样例位于 `example_folder/`；
- 具体请求格式见运行后的 `/docs`。

## 九、前端二次开发

```powershell
cd frontend_source
npm ci
npm run dev
```

开发模式会在 5173 启动 Vite，并在 8788 启动本地计算接口。启动前请关闭旧的 5173/8788 进程。

Vite 默认读取仓库内的 `runtime/` 布局，不会读取 `config.local.json`。如果开发时使用仓库外资产，请先在同一个 PowerShell 会话显式设置 `.env.example` 中的 `TYPHOON_*` 环境变量。

生成正式页面：

```powershell
npm run build
```

发布时将干净的 `frontend_source/dist/` 内容复制到 `web/`。不要提交 `node_modules`、`.npm-cache` 或 `dist`。

## 十、测试

基础测试：

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m pytest -q tests/test_web_wrapper.py tests/test_combined_server.py
```

需要 NumPy/Xarray 或运行科学阶段的测试应使用 `.venv-full`。真实数据回归默认跳过；需要时把 `TYPHOON_TEST_VALIDATION_ROOT` 指向本机验证数据目录。

## 十一、常见问题

- **Python/TensorFlow 安装失败：** 执行 `py -0p`，确认安装的是 64 位 Python 3.10。“No matching distribution”通常表示 Python 版本或架构错误。
- **5173 被占用：** 执行 `Get-NetTCPConnection -LocalPort 5173 -State Listen`，确认进程后关闭旧 Vite/Uvicorn；也可运行 `scripts/start_windows.ps1 -Port 5174`，随后用 `scripts/verify_windows.ps1 -Port 5174` 检查。
- **网页能开但按钮不可用：** 查看 `/api/health` 的 `issues`，常见原因是 `.venv-full`、H5/scaler、Parquet 或案例路径缺失。
- **FNL 验证失败：** 目录必须叫 `FNL`，文件名和数量必须准确；浏览器选择与后端读取的文件名、大小、修改时间都必须一致。
- **地图背景空白：** Windy 和 OSM 需要联网，可能被防火墙、广告拦截或内容策略阻止；这不等于本地计算服务故障。
- **作业失败：** 查看 `data/jobs/<job_id>/job.json`、`calculation.log`、`stage_manifest.json`，并检查磁盘空间、案例 ID 和轨迹工作簿。

## 十二、隐私、网络与科学声明

- API 只绑定 `127.0.0.1`，设计为单机使用；
- 后端计算没有远程 HTTP 计算客户端；
- 首页 Windy 和 OSM 底图是外部网络资源；
- pip/npm 安装依赖时会连接软件包仓库；
- `data/jobs` 可能含输入元数据和结果，应按使用者的数据政策保管和清理。

输出属于研究情景，不是业务预警、实测损失、保险定价或安全决策依据。

## 十三、许可与数据来源

仓库中明确标注的软件代码按所附 MIT License 提供。FNL、H5/scaler、暴露/网格 Parquet、CMA 最佳路径、边界来源、Windy 和 OpenStreetMap 保留各自的许可与使用条件。在向公开仓库增加任何科学数据前，必须确认再分发许可。

详见：[DATA_CARD.md](DATA_CARD.md)、[MODEL_CARD.md](MODEL_CARD.md)、[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) 和 [CITATION.cff](CITATION.cff)。
