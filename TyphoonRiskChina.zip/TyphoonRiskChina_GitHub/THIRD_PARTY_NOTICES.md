# Third-party code, data, and services

The repository MIT license applies only to software material for which the
repository authors hold the necessary rights. Third-party code, data, map
geometry, models, and network services retain their upstream terms.

## Large assets intentionally excluded

The repository does not redistribute FuXi model/data assets, the downscaling
H5 model, serialized scalers, FNL NetCDF sequences, or the five-province
exposure/grid Parquet collections. Users must obtain these assets from an
authorized source and confirm their permitted use before placing them under
`runtime/`.

## Local data included in the web application

- `frontend_source/public/cma-data.js` and its compiled copy `web/cma-data.js`
  contain a local typhoon best-track archive attributed to the China
  Meteorological Administration Tropical Cyclone Data Center. They are not
  relicensed by the repository MIT license. Confirm the dataset's citation,
  modification, and redistribution requirements before public distribution.
- Province, coastal-city, and maritime boundary files are present in
  `frontend_source/public/maps/`, `web/maps/`, and
  `algorithm_full/assets/vulnerability/boundaries/`. Their provenance and
  processing notes are recorded in
  `algorithm_full/assets/vulnerability/licenses/BOUNDARY_SOURCES.md`.
  Natural Earth, AMap/DataV GeoAtlas, geojson.cn, the Ministry of Civil
  Affairs map service, and OpenStreetMap are upstream sources mentioned by
  those notes; inclusion here does not replace their terms.
- The small reviewer example and any sample track workbook retain the rights
  of their original provider unless an adjacent notice states otherwise.

## Runtime services and software dependencies

The Windy embed and OpenStreetMap tile service are accessed over the network
at runtime and are not redistributed. Vue, Vue Router, Leaflet, Vite, FastAPI,
Uvicorn, TensorFlow, and the remaining Python/JavaScript dependencies retain
the licenses distributed with their respective packages.

Before making a public release, record the authoritative citation, DOI or URL,
license, modification status, and redistribution permission for every bundled
dataset. Maps intended for public release in China must also use compliant
standard-map material and follow applicable map-review requirements.
