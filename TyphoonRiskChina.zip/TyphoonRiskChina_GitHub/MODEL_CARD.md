# Model card

TyphoonRiskChina is a composed research workflow, not a single trained model. FuXi produces global deterministic forecasts; a separate learned downscaling model estimates high-resolution wind; rule/curve-based vulnerability logic converts hazard and exposure into loss.

Intended use: research reproducibility, scenario analysis and manuscript review. Not intended for real-time emergency command, insurance pricing or safety-critical decisions without independent validation. Known risks include forecast error growth, domain shift, exposure-data staleness, boundary uncertainty and sensitivity to vulnerability curves/thresholds.
