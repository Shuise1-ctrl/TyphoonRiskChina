from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import shutil
import uuid

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse

from .config import Event, Settings
from .workflow import RunOptions, UnifiedPipeline


SETTINGS_PATH = Path(os.environ.get("TYPHOON_RISK_CHINA_SETTINGS", "configs/autodl.settings.json")).absolute()
SETTINGS = Settings.load(SETTINGS_PATH)
EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="typhoonriskchina")
app = FastAPI(title="TyphoonRiskChina", version="1.0.0")


def _job_root(job_id: str) -> Path:
    if not job_id.isalnum():
        raise HTTPException(400, "Invalid job id")
    return SETTINGS.jobs_root / job_id


def _execute(event: Event, root: Path, fuxi_mode: str) -> None:
    UnifiedPipeline(SETTINGS).run(event, root, RunOptions(fuxi_mode=fuxi_mode, reuse_downscaling=False))


@app.get("/health")
def health() -> dict[str, str]:
    SETTINGS.validate()
    return {"status": "ok"}


@app.post("/jobs", status_code=202)
def create_job(
    case_id: str = Form(...), typhoon_name: str = Form(...),
    fuxi_mode: str = Form("minimal"), initial_state: UploadFile = File(...), track_file: UploadFile = File(...),
) -> dict[str, str]:
    if fuxi_mode not in {"minimal", "full"}:
        raise HTTPException(400, "API upload jobs require fuxi_mode=minimal or full")
    job_id = uuid.uuid4().hex
    root = _job_root(job_id)
    uploads = root / "uploads"
    uploads.mkdir(parents=True)
    initial_path = uploads / "initial_state.nc"
    track_path = uploads / "track.xlsx"
    with initial_path.open("wb") as stream:
        shutil.copyfileobj(initial_state.file, stream)
    with track_path.open("wb") as stream:
        shutil.copyfileobj(track_file.file, stream)
    event = Event(case_id=case_id.upper(), name=typhoon_name, initial_state=initial_path, track_file=track_path)
    EXECUTOR.submit(_execute, event, root, fuxi_mode)
    return {"job_id": job_id, "status_url": f"/jobs/{job_id}"}


@app.get("/jobs/{job_id}")
def job_status(job_id: str) -> dict:
    manifest = _job_root(job_id) / "run_manifest.json"
    if not manifest.exists():
        return {"job_id": job_id, "status": "queued"}
    return json.loads(manifest.read_text(encoding="utf-8"))


@app.get("/jobs/{job_id}/report")
def job_report(job_id: str):
    root = _job_root(job_id)
    reports = list((root / "outputs" / "vulnerability").glob("*.pdf"))
    if not reports:
        raise HTTPException(404, "Report is not ready")
    return FileResponse(reports[0], filename=reports[0].name, media_type="application/pdf")
