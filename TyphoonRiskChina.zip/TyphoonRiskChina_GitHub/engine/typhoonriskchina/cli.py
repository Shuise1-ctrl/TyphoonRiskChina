"""Command-line interface for TyphoonRiskChina."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from . import __version__
from .config import Event, RunConfig, Settings
from .validation import discover_forecasts, validate_run_config, validate_sequence
from .workflow import RunOptions, UnifiedPipeline, run_from_config


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(
        prog="typhoonriskchina",
        description="Auditable typhoon forecast-to-loss workflow for coastal China",
    )
    root.add_argument("--version", action="version", version=f"TyphoonRiskChina {__version__}")
    commands = root.add_subparsers(dest="command", required=True)

    run = commands.add_parser("run", help="Run one YAML-configured example or full event")
    run.add_argument("--config", help="Path to config.yml")
    run.add_argument("--settings", help=argparse.SUPPRESS)
    run.add_argument("--event", help=argparse.SUPPRESS)
    run.add_argument("--run-root", help=argparse.SUPPRESS)
    run.add_argument(
        "--fuxi-mode",
        choices=("reuse", "minimal", "full", "skip"),
        default="reuse",
        help=argparse.SUPPRESS,
    )
    run.add_argument("--force-downscaling", action="store_true", help=argparse.SUPPRESS)

    check = commands.add_parser("check", help="Validate configuration and available inputs")
    check.add_argument("--config", required=True, help="Path to config.yml")
    check.add_argument(
        "--full-assets",
        action="store_true",
        help="For mode=full, also validate every configured model/data asset",
    )

    verify = commands.add_parser("verify-fuxi", help="Verify a 6-hourly FuXi forecast sequence")
    verify.add_argument("--directory", required=True)
    verify.add_argument("--count", type=int, required=True)
    return root


def main() -> None:
    args = parser().parse_args()
    if args.command == "verify-fuxi":
        files = validate_sequence(discover_forecasts(Path(args.directory)), args.count)
        print(
            json.dumps(
                {
                    "status": "ok",
                    "count": len(files),
                    "first": files[0].name,
                    "last": files[-1].name,
                },
                indent=2,
            )
        )
        return
    if args.command == "check":
        config = RunConfig.load(args.config)
        result = validate_run_config(config, full_assets=args.full_assets)
        print(json.dumps({"status": "ok", **result}, ensure_ascii=False, indent=2))
        return
    if args.config:
        result = run_from_config(args.config)
        manifest = RunConfig.load(args.config).output_dir / "run_manifest.json"
    elif args.settings and args.event and args.run_root:
        result = UnifiedPipeline(Settings.load(args.settings)).run(
            Event.load(args.event),
            Path(args.run_root),
            RunOptions(args.fuxi_mode, not args.force_downscaling),
        )
        manifest = Path(args.run_root).absolute() / "run_manifest.json"
    else:
        parser().error("run requires --config (recommended), or legacy --settings/--event/--run-root")
    print(
        json.dumps(
            {
                "status": result["status"],
                "mode": result.get("mode", result.get("options", {}).get("fuxi_mode", "full")),
                "manifest": str(manifest),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
