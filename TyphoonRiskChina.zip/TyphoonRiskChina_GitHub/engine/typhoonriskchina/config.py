from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
from typing import Any

import yaml


def _path(value: str | Path) -> Path:
    return Path(value).expanduser().absolute()


@dataclass(frozen=True)
class Settings:
    fuxi_python: Path
    fuxi_runner: Path
    fuxi_model_dir: Path
    risk_python: Path
    risk_cli: Path
    downscaling_runtime: Path
    risk_exposure_root: Path
    jobs_root: Path

    @classmethod
    def load(cls, path: str | Path) -> "Settings":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(**{key: _path(value) for key, value in data.items()})

    def validate(self) -> None:
        required = {
            "fuxi_python": self.fuxi_python,
            "fuxi_runner": self.fuxi_runner,
            "fuxi_model_dir": self.fuxi_model_dir,
            "risk_python": self.risk_python,
            "risk_cli": self.risk_cli,
            "downscaling_runtime": self.downscaling_runtime,
            "risk_exposure_root": self.risk_exposure_root,
        }
        missing = [f"{name}: {path}" for name, path in required.items() if not path.exists()]
        if missing:
            raise FileNotFoundError("Missing configured resources:\n" + "\n".join(missing))


@dataclass(frozen=True)
class Event:
    case_id: str
    name: str
    track_file: Path
    initial_state: Path | None = None
    existing_fnl_dir: Path | None = None
    existing_fuxi_dir: Path | None = None
    fuxi_steps_minimal: tuple[int, ...] = (20, 8)
    fuxi_steps_full: tuple[int, ...] = (20, 20, 20)
    downscaling_max_hour: int = 168
    impact_threshold_ms: float = 17.2

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Event":
        payload = dict(data)
        for key in ("track_file", "initial_state", "existing_fnl_dir", "existing_fuxi_dir"):
            if payload.get(key):
                payload[key] = _path(payload[key])
            elif key != "track_file":
                payload[key] = None
        for key in ("fuxi_steps_minimal", "fuxi_steps_full"):
            payload[key] = tuple(int(item) for item in payload.get(key, (20, 8) if key.endswith("minimal") else (20, 20, 20)))
        return cls(**payload)

    @classmethod
    def load(cls, path: str | Path) -> "Event":
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))

    def validate(self, fuxi_mode: str) -> None:
        if not self.case_id.upper().startswith("ID") or len(self.case_id) != 6:
            raise ValueError(f"case_id must look like ID2609, got {self.case_id!r}")
        if not self.track_file.is_file():
            raise FileNotFoundError(f"Track workbook not found: {self.track_file}")
        if fuxi_mode in {"minimal", "full"} and not self.initial_state:
            raise ValueError("initial_state is required when FuXi inference is requested")
        if self.initial_state and not self.initial_state.is_file():
            raise FileNotFoundError(f"FuXi initial state not found: {self.initial_state}")


def _expand(value: Any) -> Any:
    if isinstance(value, str):
        expanded = os.path.expandvars(value)
        if "$" in expanded:
            raise ValueError(
                f"An environment variable in {value!r} is not set. "
                "Export the variable before running the full case."
            )
        return expanded
    if isinstance(value, dict):
        return {key: _expand(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_expand(item) for item in value]
    return value


def _relative_path(base: Path, value: str | Path) -> Path:
    path = Path(value).expanduser()
    return path.absolute() if path.is_absolute() else (base / path).absolute()


@dataclass(frozen=True)
class RunConfig:
    """Reviewer-facing YAML configuration for demo or full execution."""

    path: Path
    mode: str
    case_id: str
    name: str
    output_dir: Path
    data: dict[str, Any]

    @classmethod
    def load(cls, path: str | Path) -> "RunConfig":
        config_path = Path(path).expanduser().absolute()
        payload = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("Configuration root must be a YAML mapping")
        payload = _expand(payload)
        case = payload.get("case") or {}
        output = payload.get("output") or {}
        mode = str(payload.get("mode", "reviewer_demo"))
        case_id = str(case.get("id", "")).strip()
        name = str(case.get("name", case_id)).strip()
        output_dir = _relative_path(config_path.parent, output.get("directory", "outputs"))
        return cls(config_path, mode, case_id, name, output_dir, payload)

    def resolve(self, value: str | Path) -> Path:
        return _relative_path(self.path.parent, value)

    def demo_track(self) -> Path:
        return self.resolve(self.data.get("inputs", {}).get("track", ""))

    def demo_exposure(self) -> Path:
        return self.resolve(self.data.get("inputs", {}).get("exposure", ""))

    def impact_threshold_ms(self) -> float:
        return float(self.data.get("parameters", {}).get("impact_threshold_ms", 17.2))

    def full_settings(self) -> Path:
        return self.resolve(self.data.get("settings", ""))

    def full_event(self) -> Event:
        event_data = dict(self.data.get("event") or {})
        for key in ("track_file", "initial_state", "existing_fnl_dir", "existing_fuxi_dir"):
            if event_data.get(key):
                event_data[key] = str(self.resolve(event_data[key]))
        event_data.setdefault("case_id", self.case_id)
        event_data.setdefault("name", self.name)
        event_data.setdefault("impact_threshold_ms", self.impact_threshold_ms())
        return Event.from_dict(event_data)

    def fuxi_mode(self) -> str:
        return str(self.data.get("execution", {}).get("fuxi_mode", "reuse"))

    def reuse_downscaling(self) -> bool:
        return bool(self.data.get("execution", {}).get("reuse_downscaling", True))
