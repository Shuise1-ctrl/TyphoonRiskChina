from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import traceback
from typing import Any

from .config import Event, RunConfig, Settings
from .downscaling import link_or_copy, run_checked
from .loss import calculate_loss_table
from .report import write_demo_outputs
from .track import load_track_csv, summarize_track
from .validation import discover_forecasts, file_record, validate_run_config, validate_sequence


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    temporary.replace(path)


def progress(step: int, total: int, message: str) -> None:
    print(f"[TyphoonRiskChina] [{step}/{total}] {message}", flush=True)


@dataclass(frozen=True)
class RunOptions:
    fuxi_mode: str = "reuse"  # reuse|minimal|full|skip
    reuse_downscaling: bool = True


class UnifiedPipeline:
    def __init__(self, settings: Settings):
        self.settings = settings

    def _run_fuxi(self, event: Event, run_root: Path, mode: str) -> tuple[Path, dict[str, Any]]:
        if mode == "skip":
            if not event.existing_fnl_dir:
                raise ValueError("existing_fnl_dir is required for fuxi_mode=skip")
            files = validate_sequence(discover_forecasts(event.existing_fnl_dir, event.downscaling_max_hour))
            return event.existing_fnl_dir, {"mode": mode, "status": "reused", "count": len(files)}

        if mode == "reuse":
            source = event.existing_fuxi_dir or event.existing_fnl_dir
            if not source:
                raise ValueError("existing_fuxi_dir or existing_fnl_dir is required for fuxi_mode=reuse")
            files = validate_sequence(discover_forecasts(source))
            return source, {"mode": mode, "status": "reused", "count": len(files)}

        if mode not in {"minimal", "full"}:
            raise ValueError(f"Unsupported fuxi_mode: {mode}")
        steps = event.fuxi_steps_minimal if mode == "minimal" else event.fuxi_steps_full
        output_dir = run_root / "fuxi"
        output_dir.mkdir(parents=True, exist_ok=True)
        expected_count = sum(steps)
        existing = discover_forecasts(output_dir)
        if len(existing) != expected_count:
            command = [
                str(self.settings.fuxi_python), str(self.settings.fuxi_runner),
                "--model", str(self.settings.fuxi_model_dir),
                "--input", str(event.initial_state), "--save_dir", str(output_dir),
                "--num_steps", *[str(item) for item in steps],
            ]
            elapsed = run_checked(command, self.settings.fuxi_runner.parent, run_root / "logs" / "fuxi.log")
        else:
            elapsed = 0.0
        files = validate_sequence(discover_forecasts(output_dir), expected_count)
        return output_dir, {"mode": mode, "status": "complete", "count": len(files), "steps": list(steps), "seconds": elapsed}

    def _prepare_case(self, event: Event, fuxi_dir: Path, run_root: Path) -> tuple[Path, dict[str, Any]]:
        case_dir = run_root / "prepared_input" / event.case_id.upper()
        fnl_dir = case_dir / "FNL"
        fnl_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(event.track_file, case_dir / "track.xlsx")
        files = validate_sequence(discover_forecasts(fuxi_dir, event.downscaling_max_hour))
        if not files:
            raise ValueError(f"No FuXi/FNL files through {event.downscaling_max_hour} h in {fuxi_dir}")
        methods: dict[str, int] = {}
        for source in files:
            method = link_or_copy(source, fnl_dir / source.name)
            methods[method] = methods.get(method, 0) + 1
        return case_dir, {"count": len(files), "max_hour": max(int(path.stem[-3:]) for path in files), "materialization": methods}

    def _run_risk(self, event: Event, case_dir: Path, run_root: Path, reuse: bool) -> dict[str, Any]:
        output_root = run_root / "outputs"
        command = [
            str(self.settings.risk_python), str(self.settings.risk_cli),
            "--case", event.case_id.upper(), "--typhoon-name", event.name,
            "--case-dir", str(case_dir),
            "--runtime-root", str(self.settings.downscaling_runtime),
            "--risk-root", str(self.settings.risk_exposure_root),
            "--output-root", str(output_root),
            "--impact-threshold-ms", str(event.impact_threshold_ms),
        ]
        if not reuse:
            command.append("--force-downscaling")
        env = dict(os.environ)
        env.update({
            "MPLBACKEND": "Agg",
            "TF_CPP_MIN_LOG_LEVEL": "2",
            "CUDA_VISIBLE_DEVICES": "-1",
            # Legal container fallback; Times New Roman is still used when installed.
            "TYPHOON_ALLOW_FONT_FALLBACK": "1",
        })
        elapsed = run_checked(command, self.settings.risk_cli.parent, run_root / "logs" / "risk_pipeline.log", env)
        manifest = output_root / "pipeline_result.json"
        result = json.loads(manifest.read_text(encoding="utf-8"))
        result["seconds"] = elapsed
        return result

    @staticmethod
    def _write_summary(run_root: Path, result: dict[str, Any]) -> None:
        vulnerability = result.get("stages", {}).get("vulnerability", {})
        payload = {
            "case_id": result.get("case_id"),
            "event_id": result.get("event_id"),
            "typhoon_name": result.get("typhoon_name"),
            "affected_provinces": vulnerability.get("affected_provinces", []),
            "totals": vulnerability.get("totals", {}),
            "report": vulnerability.get("files", {}).get("pdf_report"),
        }
        atomic_json(run_root / "loss_summary.json", payload)
        lines = [
            f"# Loss summary — {payload['typhoon_name']} ({payload['case_id']})",
            "", f"Affected provinces: {', '.join(payload['affected_provinces']) or 'none'}", "", "## Totals", "",
        ]
        lines.extend(f"- {key}: {value}" for key, value in payload["totals"].items())
        lines.extend(["", f"PDF report: `{payload['report']}`", ""])
        (run_root / "loss_summary.md").write_text("\n".join(lines), encoding="utf-8")

    def run(self, event: Event, run_root: Path, options: RunOptions) -> dict[str, Any]:
        run_root = run_root.absolute()
        run_root.mkdir(parents=True, exist_ok=True)
        manifest_path = run_root / "run_manifest.json"
        state: dict[str, Any] = {
            "schema_version": "1.0", "status": "running", "started_at_utc": utc_now(),
            "event": {**asdict(event), "track_file": str(event.track_file), "initial_state": str(event.initial_state) if event.initial_state else None,
                      "existing_fnl_dir": str(event.existing_fnl_dir) if event.existing_fnl_dir else None,
                      "existing_fuxi_dir": str(event.existing_fuxi_dir) if event.existing_fuxi_dir else None},
            "options": asdict(options), "stages": {},
        }
        atomic_json(manifest_path, state)
        try:
            progress(1, 5, "Validating full-workflow configuration and inputs")
            self.settings.validate()
            event.validate(options.fuxi_mode)
            state["inputs"] = {"track": file_record(event.track_file, checksum=True)}
            if event.initial_state:
                state["inputs"]["initial_state"] = file_record(event.initial_state, checksum=True)
            progress(2, 5, f"Preparing FuXi forecasts (mode={options.fuxi_mode})")
            fuxi_dir, fuxi_result = self._run_fuxi(event, run_root, options.fuxi_mode)
            state["stages"]["fuxi"] = fuxi_result
            atomic_json(manifest_path, state)
            progress(3, 5, "Linking the required forecast window to the downscaling case")
            case_dir, prepared = self._prepare_case(event, fuxi_dir, run_root)
            state["stages"]["interface_fuxi_to_downscaling"] = {"status": "complete", **prepared, "case_dir": str(case_dir)}
            atomic_json(manifest_path, state)
            progress(4, 5, "Running 3-km downscaling, exposure, vulnerability and reporting")
            risk_result = self._run_risk(event, case_dir, run_root, options.reuse_downscaling)
            state["stages"]["downscaling_exposure_vulnerability_report"] = risk_result
            self._write_summary(run_root, risk_result)
            state.update({"status": "complete", "completed_at_utc": utc_now()})
            atomic_json(manifest_path, state)
            progress(5, 5, f"Complete. Manifest: {manifest_path}")
            return state
        except Exception as exc:
            state.update({"status": "failed", "failed_at_utc": utc_now(), "error": {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}})
            atomic_json(manifest_path, state)
            raise


def run_reviewer_demo(config: RunConfig) -> dict[str, Any]:
    """Run the small, self-contained review path without external model assets."""

    manifest_path = config.output_dir / "run_manifest.json"
    state: dict[str, Any] = {
        "schema_version": "1.0",
        "mode": "reviewer_demo",
        "case_id": config.case_id,
        "typhoon_name": config.name,
        "status": "running",
        "started_at_utc": utc_now(),
        "config": str(config.path),
        "stages": {},
    }
    config.output_dir.mkdir(parents=True, exist_ok=True)
    atomic_json(manifest_path, state)
    try:
        progress(1, 5, "Validating YAML configuration and bundled inputs")
        validated = validate_run_config(config)
        state["stages"]["validation"] = {"status": "complete", **validated}
        atomic_json(manifest_path, state)

        progress(2, 5, "Reading and validating the typhoon track")
        track_points = load_track_csv(config.demo_track())
        track_summary = summarize_track(track_points)
        state["stages"]["track"] = {"status": "complete", **track_summary}
        atomic_json(manifest_path, state)

        progress(3, 5, "Applying vulnerability curves and calculating grid losses")
        rows, totals = calculate_loss_table(config.demo_exposure())
        state["stages"]["vulnerability_and_loss"] = {
            "status": "complete",
            "grid_count": len(rows),
            "totals": totals,
        }
        atomic_json(manifest_path, state)

        progress(4, 5, "Writing CSV, JSON and Markdown review products")
        files = write_demo_outputs(
            config.output_dir,
            config.case_id,
            config.name,
            rows,
            totals,
            track_summary,
            config.impact_threshold_ms(),
        )
        state["stages"]["report"] = {"status": "complete", "files": files}
        state.update({"status": "complete", "completed_at_utc": utc_now()})
        atomic_json(manifest_path, state)
        progress(5, 5, f"Complete. Manifest: {manifest_path}")
        return state
    except Exception as exc:
        state.update(
            {
                "status": "failed",
                "failed_at_utc": utc_now(),
                "error": {
                    "type": type(exc).__name__,
                    "message": str(exc),
                    "traceback": traceback.format_exc(),
                },
            }
        )
        atomic_json(manifest_path, state)
        raise


def run_from_config(path: str | Path) -> dict[str, Any]:
    config = RunConfig.load(path)
    if config.mode == "reviewer_demo":
        return run_reviewer_demo(config)
    if config.mode == "full":
        validate_run_config(config, full_assets=False)
        settings = Settings.load(config.full_settings())
        return UnifiedPipeline(settings).run(
            config.full_event(),
            config.output_dir,
            RunOptions(
                fuxi_mode=config.fuxi_mode(),
                reuse_downscaling=config.reuse_downscaling(),
            ),
        )
    raise ValueError(f"Unsupported mode: {config.mode}")
